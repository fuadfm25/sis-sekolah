-- =====================================================================
--  SIS Sekolah – Administrasi Pembelajaran
--  TEMPLATE DATABASE (MySQL 5.7+/8.x, MariaDB 10.3+)
--  Dibangkitkan dari migration aplikasi: 2026-11-23 23:36
--
--  Cara pakai (phpMyAdmin):
--    1. Buat database kosong, mis. db_sis_sekolah  (collation utf8mb4_general_ci)
--    2. Pilih database tsb > tab Import > pilih file ini > Go
--    3. Login: admin / admin123  -> SEGERA ganti password
--    4. Menu Pengaturan Sekolah: isi identitas sekolah, logo, kepala sekolah,
--       lalu klik "Ganti token kiosk" bila memakai absensi RFID/barcode
--  File ini SETARA dengan:  php spark migrate && php spark db:seed DatabaseSeeder
--  Tabel `migrations` sudah terisi, sehingga `php spark migrate` berikutnya
--  hanya menjalankan migration baru (jika ada pembaruan aplikasi).
-- =====================================================================

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+07:00";
START TRANSACTION;

-- =====================================================================
--  STRUKTUR TABEL
-- =====================================================================
-- ---------------------------------------------------------------
-- 2026-11-23-000001_CreateAuthTables.php
CREATE TABLE `users` (
	`id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
	`username` VARCHAR(50) NOT NULL,
	`password` VARCHAR(255) NOT NULL,
	`nama_lengkap` VARCHAR(100) NOT NULL,
	`email` VARCHAR(100) NULL,
	`is_active` TINYINT(1) NOT NULL DEFAULT 1,
	`last_login` DATETIME NULL,
	`created_at` DATETIME NULL,
	`updated_at` DATETIME NULL,
	CONSTRAINT `pk_users` PRIMARY KEY(`id`),
	UNIQUE KEY `username` (`username`)
) DEFAULT CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci;

CREATE TABLE `roles` (
	`id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
	`nama_role` VARCHAR(50) NOT NULL,
	`keterangan` VARCHAR(100) NULL,
	CONSTRAINT `pk_roles` PRIMARY KEY(`id`),
	UNIQUE KEY `nama_role` (`nama_role`)
) DEFAULT CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci;

CREATE TABLE `user_roles` (
	`user_id` INT UNSIGNED NOT NULL,
	`role_id` INT UNSIGNED NOT NULL,
	CONSTRAINT `pk_user_roles` PRIMARY KEY(`user_id`, `role_id`),
	CONSTRAINT `user_roles_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE ON UPDATE CASCADE,
	CONSTRAINT `user_roles_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles`(`id`) ON DELETE CASCADE ON UPDATE CASCADE
) DEFAULT CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci;

CREATE TABLE `pengaturan` (
	`id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
	`kunci` VARCHAR(60) NOT NULL,
	`nilai` TEXT NULL,
	`label` VARCHAR(100) NULL,
	`updated_at` DATETIME NULL,
	CONSTRAINT `pk_pengaturan` PRIMARY KEY(`id`),
	UNIQUE KEY `kunci` (`kunci`)
) DEFAULT CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci;

-- ---------------------------------------------------------------
-- 2026-11-23-000002_CreateMasterTables.php
CREATE TABLE `tahun_pelajaran` (
	`id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
	`tahun_pelajaran` VARCHAR(20) NOT NULL,
	`semester` ENUM('Ganjil','Genap') NOT NULL DEFAULT 'Ganjil',
	`tanggal_mulai` DATE NULL,
	`tanggal_selesai` DATE NULL,
	`is_active` TINYINT(1) NOT NULL DEFAULT 0,
	`created_at` DATETIME NULL,
	`updated_at` DATETIME NULL,
	CONSTRAINT `pk_tahun_pelajaran` PRIMARY KEY(`id`),
	UNIQUE KEY `tahun_pelajaran_semester` (`tahun_pelajaran`, `semester`)
) DEFAULT CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci;

CREATE TABLE `jurusan` (
	`id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
	`kode_jurusan` VARCHAR(20) NOT NULL,
	`nama_jurusan` VARCHAR(100) NOT NULL,
	`created_at` DATETIME NULL,
	`updated_at` DATETIME NULL,
	CONSTRAINT `pk_jurusan` PRIMARY KEY(`id`),
	UNIQUE KEY `kode_jurusan` (`kode_jurusan`)
) DEFAULT CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci;

CREATE TABLE `kelas` (
	`id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
	`tingkat` VARCHAR(5) NOT NULL,
	`nama_kelas` VARCHAR(50) NOT NULL,
	`jurusan_id` INT UNSIGNED NULL,
	`is_active` TINYINT(1) NOT NULL DEFAULT 1,
	`created_at` DATETIME NULL,
	`updated_at` DATETIME NULL,
	CONSTRAINT `pk_kelas` PRIMARY KEY(`id`),
	CONSTRAINT `kelas_jurusan_id_foreign` FOREIGN KEY (`jurusan_id`) REFERENCES `jurusan`(`id`) ON DELETE SET NULL ON UPDATE CASCADE,
	UNIQUE KEY `nama_kelas` (`nama_kelas`)
) DEFAULT CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci;

CREATE TABLE `guru` (
	`id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
	`user_id` INT UNSIGNED NULL,
	`nip` VARCHAR(30) NULL,
	`nuptk` VARCHAR(30) NULL,
	`nama_lengkap` VARCHAR(100) NOT NULL,
	`gelar_depan` VARCHAR(20) NULL,
	`gelar_belakang` VARCHAR(50) NULL,
	`jenis_kelamin` ENUM('L','P') NOT NULL,
	`no_hp` VARCHAR(20) NULL,
	`email` VARCHAR(100) NULL,
	`status_kepegawaian` ENUM('PNS','PPPK','GTY','GTT','Honorer') NOT NULL DEFAULT 'Honorer',
	`is_active` TINYINT(1) NOT NULL DEFAULT 1,
	`created_at` DATETIME NULL,
	`updated_at` DATETIME NULL,
	CONSTRAINT `pk_guru` PRIMARY KEY(`id`),
	CONSTRAINT `guru_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE SET NULL ON UPDATE CASCADE,
	UNIQUE KEY `user_id` (`user_id`)
) DEFAULT CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci;

CREATE TABLE `siswa` (
	`id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
	`nis` VARCHAR(20) NOT NULL,
	`nisn` VARCHAR(20) NULL,
	`nama_lengkap` VARCHAR(100) NOT NULL,
	`jenis_kelamin` ENUM('L','P') NOT NULL,
	`tempat_lahir` VARCHAR(50) NULL,
	`tanggal_lahir` DATE NULL,
	`agama` VARCHAR(20) NULL,
	`alamat` TEXT NULL,
	`nama_wali` VARCHAR(100) NULL,
	`no_hp_wali` VARCHAR(20) NULL,
	`status` ENUM('Aktif','Lulus','Pindah','Keluar') NOT NULL DEFAULT 'Aktif',
	`created_at` DATETIME NULL,
	`updated_at` DATETIME NULL,
	CONSTRAINT `pk_siswa` PRIMARY KEY(`id`),
	UNIQUE KEY `nis` (`nis`)
) DEFAULT CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci;

CREATE TABLE `mata_pelajaran` (
	`id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
	`kode_mapel` VARCHAR(20) NOT NULL,
	`nama_mapel` VARCHAR(100) NOT NULL,
	`kelompok` VARCHAR(50) NULL,
	`is_active` TINYINT(1) NOT NULL DEFAULT 1,
	`created_at` DATETIME NULL,
	`updated_at` DATETIME NULL,
	CONSTRAINT `pk_mata_pelajaran` PRIMARY KEY(`id`),
	UNIQUE KEY `kode_mapel` (`kode_mapel`)
) DEFAULT CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci;

CREATE TABLE `jam_pelajaran` (
	`id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
	`jam_ke` TINYINT UNSIGNED NOT NULL,
	`jam_mulai` TIME NOT NULL,
	`jam_selesai` TIME NOT NULL,
	`is_kbm` TINYINT(1) NOT NULL DEFAULT 1,
	`keterangan` VARCHAR(50) NULL,
	`created_at` DATETIME NULL,
	`updated_at` DATETIME NULL,
	CONSTRAINT `pk_jam_pelajaran` PRIMARY KEY(`id`)
) DEFAULT CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci;

-- ---------------------------------------------------------------
-- 2026-11-23-000003_CreateRombelTables.php
CREATE TABLE `wali_kelas` (
	`id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
	`tahun_pelajaran_id` INT UNSIGNED NOT NULL,
	`kelas_id` INT UNSIGNED NOT NULL,
	`guru_id` INT UNSIGNED NOT NULL,
	`created_at` DATETIME NULL,
	`updated_at` DATETIME NULL,
	CONSTRAINT `pk_wali_kelas` PRIMARY KEY(`id`),
	CONSTRAINT `wali_kelas_tahun_pelajaran_id_foreign` FOREIGN KEY (`tahun_pelajaran_id`) REFERENCES `tahun_pelajaran`(`id`) ON DELETE CASCADE ON UPDATE CASCADE,
	CONSTRAINT `wali_kelas_kelas_id_foreign` FOREIGN KEY (`kelas_id`) REFERENCES `kelas`(`id`) ON DELETE CASCADE ON UPDATE CASCADE,
	CONSTRAINT `wali_kelas_guru_id_foreign` FOREIGN KEY (`guru_id`) REFERENCES `guru`(`id`) ON DELETE CASCADE ON UPDATE CASCADE,
	UNIQUE KEY `tahun_pelajaran_id_kelas_id` (`tahun_pelajaran_id`, `kelas_id`)
) DEFAULT CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci;

CREATE TABLE `anggota_kelas` (
	`id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
	`tahun_pelajaran_id` INT UNSIGNED NOT NULL,
	`kelas_id` INT UNSIGNED NOT NULL,
	`siswa_id` INT UNSIGNED NOT NULL,
	`no_absen` SMALLINT UNSIGNED NULL,
	`status` ENUM('Aktif','Naik Kelas','Tinggal Kelas','Lulus','Pindah') NOT NULL DEFAULT 'Aktif',
	`created_at` DATETIME NULL,
	`updated_at` DATETIME NULL,
	CONSTRAINT `pk_anggota_kelas` PRIMARY KEY(`id`),
	CONSTRAINT `anggota_kelas_tahun_pelajaran_id_foreign` FOREIGN KEY (`tahun_pelajaran_id`) REFERENCES `tahun_pelajaran`(`id`) ON DELETE CASCADE ON UPDATE CASCADE,
	CONSTRAINT `anggota_kelas_kelas_id_foreign` FOREIGN KEY (`kelas_id`) REFERENCES `kelas`(`id`) ON DELETE CASCADE ON UPDATE CASCADE,
	CONSTRAINT `anggota_kelas_siswa_id_foreign` FOREIGN KEY (`siswa_id`) REFERENCES `siswa`(`id`) ON DELETE CASCADE ON UPDATE CASCADE,
	UNIQUE KEY `tahun_pelajaran_id_siswa_id` (`tahun_pelajaran_id`, `siswa_id`),
	KEY `kelas_id` (`kelas_id`)
) DEFAULT CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci;

CREATE TABLE `guru_piket` (
	`id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
	`tahun_pelajaran_id` INT UNSIGNED NOT NULL,
	`guru_id` INT UNSIGNED NOT NULL,
	`hari` TINYINT UNSIGNED NOT NULL,
	`created_at` DATETIME NULL,
	`updated_at` DATETIME NULL,
	CONSTRAINT `pk_guru_piket` PRIMARY KEY(`id`),
	CONSTRAINT `guru_piket_tahun_pelajaran_id_foreign` FOREIGN KEY (`tahun_pelajaran_id`) REFERENCES `tahun_pelajaran`(`id`) ON DELETE CASCADE ON UPDATE CASCADE,
	CONSTRAINT `guru_piket_guru_id_foreign` FOREIGN KEY (`guru_id`) REFERENCES `guru`(`id`) ON DELETE CASCADE ON UPDATE CASCADE,
	UNIQUE KEY `tahun_pelajaran_id_guru_id_hari` (`tahun_pelajaran_id`, `guru_id`, `hari`)
) DEFAULT CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci;

-- ---------------------------------------------------------------
-- 2026-11-23-000004_CreateAkademikTables.php
CREATE TABLE `penugasan_guru` (
	`id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
	`tahun_pelajaran_id` INT UNSIGNED NOT NULL,
	`guru_id` INT UNSIGNED NOT NULL,
	`mapel_id` INT UNSIGNED NOT NULL,
	`kelas_id` INT UNSIGNED NOT NULL,
	`jp_per_minggu` TINYINT UNSIGNED NOT NULL DEFAULT 2,
	`created_at` DATETIME NULL,
	`updated_at` DATETIME NULL,
	CONSTRAINT `pk_penugasan_guru` PRIMARY KEY(`id`),
	CONSTRAINT `penugasan_guru_tahun_pelajaran_id_foreign` FOREIGN KEY (`tahun_pelajaran_id`) REFERENCES `tahun_pelajaran`(`id`) ON DELETE CASCADE ON UPDATE CASCADE,
	CONSTRAINT `penugasan_guru_guru_id_foreign` FOREIGN KEY (`guru_id`) REFERENCES `guru`(`id`) ON DELETE CASCADE ON UPDATE CASCADE,
	CONSTRAINT `penugasan_guru_mapel_id_foreign` FOREIGN KEY (`mapel_id`) REFERENCES `mata_pelajaran`(`id`) ON DELETE CASCADE ON UPDATE CASCADE,
	CONSTRAINT `penugasan_guru_kelas_id_foreign` FOREIGN KEY (`kelas_id`) REFERENCES `kelas`(`id`) ON DELETE CASCADE ON UPDATE CASCADE,
	UNIQUE KEY `tahun_pelajaran_id_mapel_id_kelas_id` (`tahun_pelajaran_id`, `mapel_id`, `kelas_id`),
	KEY `guru_id` (`guru_id`)
) DEFAULT CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci;

CREATE TABLE `jadwal_pelajaran` (
	`id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
	`tahun_pelajaran_id` INT UNSIGNED NOT NULL,
	`penugasan_guru_id` INT UNSIGNED NOT NULL,
	`kelas_id` INT UNSIGNED NOT NULL,
	`hari` TINYINT UNSIGNED NOT NULL,
	`jam_pelajaran_id` INT UNSIGNED NOT NULL,
	`created_at` DATETIME NULL,
	`updated_at` DATETIME NULL,
	CONSTRAINT `pk_jadwal_pelajaran` PRIMARY KEY(`id`),
	CONSTRAINT `jadwal_pelajaran_tahun_pelajaran_id_foreign` FOREIGN KEY (`tahun_pelajaran_id`) REFERENCES `tahun_pelajaran`(`id`) ON DELETE CASCADE ON UPDATE CASCADE,
	CONSTRAINT `jadwal_pelajaran_penugasan_guru_id_foreign` FOREIGN KEY (`penugasan_guru_id`) REFERENCES `penugasan_guru`(`id`) ON DELETE CASCADE ON UPDATE CASCADE,
	CONSTRAINT `jadwal_pelajaran_kelas_id_foreign` FOREIGN KEY (`kelas_id`) REFERENCES `kelas`(`id`) ON DELETE CASCADE ON UPDATE CASCADE,
	CONSTRAINT `jadwal_pelajaran_jam_pelajaran_id_foreign` FOREIGN KEY (`jam_pelajaran_id`) REFERENCES `jam_pelajaran`(`id`) ON DELETE CASCADE ON UPDATE CASCADE,
	UNIQUE KEY `tahun_pelajaran_id_kelas_id_hari_jam_pelajaran_id` (`tahun_pelajaran_id`, `kelas_id`, `hari`, `jam_pelajaran_id`),
	KEY `penugasan_guru_id` (`penugasan_guru_id`)
) DEFAULT CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci;

-- ---------------------------------------------------------------
-- 2026-11-23-000005_CreateJurnalTables.php
CREATE TABLE `jurnal_pembelajaran` (
	`id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
	`tahun_pelajaran_id` INT UNSIGNED NOT NULL,
	`jadwal_pelajaran_id` INT UNSIGNED NULL,
	`penugasan_guru_id` INT UNSIGNED NOT NULL,
	`kelas_id` INT UNSIGNED NOT NULL,
	`tanggal` DATE NOT NULL,
	`jam_ke` VARCHAR(20) NULL,
	`jumlah_jp` TINYINT UNSIGNED NOT NULL DEFAULT 1,
	`pertemuan_ke` SMALLINT UNSIGNED NULL,
	`materi` VARCHAR(255) NOT NULL,
	`tujuan_pembelajaran` TEXT NULL,
	`kegiatan` TEXT NULL,
	`metode` VARCHAR(150) NULL,
	`penilaian` VARCHAR(255) NULL,
	`catatan` TEXT NULL,
	`status_kbm` ENUM('Terlaksana','Penilaian','Tugas Mandiri','Diganti Guru Lain','Tidak Terlaksana') NOT NULL DEFAULT 'Terlaksana',
	`diisi_oleh` INT UNSIGNED NULL,
	`created_at` DATETIME NULL,
	`updated_at` DATETIME NULL,
	CONSTRAINT `pk_jurnal_pembelajaran` PRIMARY KEY(`id`),
	CONSTRAINT `jurnal_pembelajaran_tahun_pelajaran_id_foreign` FOREIGN KEY (`tahun_pelajaran_id`) REFERENCES `tahun_pelajaran`(`id`) ON DELETE CASCADE ON UPDATE CASCADE,
	CONSTRAINT `jurnal_pembelajaran_jadwal_pelajaran_id_foreign` FOREIGN KEY (`jadwal_pelajaran_id`) REFERENCES `jadwal_pelajaran`(`id`) ON DELETE SET NULL ON UPDATE CASCADE,
	CONSTRAINT `jurnal_pembelajaran_penugasan_guru_id_foreign` FOREIGN KEY (`penugasan_guru_id`) REFERENCES `penugasan_guru`(`id`) ON DELETE CASCADE ON UPDATE CASCADE,
	CONSTRAINT `jurnal_pembelajaran_kelas_id_foreign` FOREIGN KEY (`kelas_id`) REFERENCES `kelas`(`id`) ON DELETE CASCADE ON UPDATE CASCADE,
	CONSTRAINT `jurnal_pembelajaran_diisi_oleh_foreign` FOREIGN KEY (`diisi_oleh`) REFERENCES `users`(`id`) ON DELETE SET NULL ON UPDATE CASCADE,
	UNIQUE KEY `jadwal_pelajaran_id_tanggal` (`jadwal_pelajaran_id`, `tanggal`),
	KEY `kelas_id_tanggal` (`kelas_id`, `tanggal`),
	KEY `penugasan_guru_id` (`penugasan_guru_id`)
) DEFAULT CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci;

CREATE TABLE `presensi_mapel` (
	`id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
	`jurnal_id` INT UNSIGNED NOT NULL,
	`siswa_id` INT UNSIGNED NOT NULL,
	`status` ENUM('H','S','I','A','D') NOT NULL DEFAULT 'H',
	`keterangan` VARCHAR(150) NULL,
	`created_at` DATETIME NULL,
	`updated_at` DATETIME NULL,
	CONSTRAINT `pk_presensi_mapel` PRIMARY KEY(`id`),
	CONSTRAINT `presensi_mapel_jurnal_id_foreign` FOREIGN KEY (`jurnal_id`) REFERENCES `jurnal_pembelajaran`(`id`) ON DELETE CASCADE ON UPDATE CASCADE,
	CONSTRAINT `presensi_mapel_siswa_id_foreign` FOREIGN KEY (`siswa_id`) REFERENCES `siswa`(`id`) ON DELETE CASCADE ON UPDATE CASCADE,
	UNIQUE KEY `jurnal_id_siswa_id` (`jurnal_id`, `siswa_id`)
) DEFAULT CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci;

-- ---------------------------------------------------------------
-- 2026-11-23-000006_CreateKesiswaanTables.php
CREATE TABLE `presensi_harian` (
	`id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
	`tahun_pelajaran_id` INT UNSIGNED NOT NULL,
	`kelas_id` INT UNSIGNED NOT NULL,
	`siswa_id` INT UNSIGNED NOT NULL,
	`tanggal` DATE NOT NULL,
	`status` ENUM('H','T','S','I','A') NOT NULL DEFAULT 'H',
	`jam_datang` TIME NULL,
	`keterangan` VARCHAR(150) NULL,
	`dicatat_oleh` INT UNSIGNED NULL,
	`created_at` DATETIME NULL,
	`updated_at` DATETIME NULL,
	CONSTRAINT `pk_presensi_harian` PRIMARY KEY(`id`),
	CONSTRAINT `presensi_harian_tahun_pelajaran_id_foreign` FOREIGN KEY (`tahun_pelajaran_id`) REFERENCES `tahun_pelajaran`(`id`) ON DELETE CASCADE ON UPDATE CASCADE,
	CONSTRAINT `presensi_harian_kelas_id_foreign` FOREIGN KEY (`kelas_id`) REFERENCES `kelas`(`id`) ON DELETE CASCADE ON UPDATE CASCADE,
	CONSTRAINT `presensi_harian_siswa_id_foreign` FOREIGN KEY (`siswa_id`) REFERENCES `siswa`(`id`) ON DELETE CASCADE ON UPDATE CASCADE,
	CONSTRAINT `presensi_harian_dicatat_oleh_foreign` FOREIGN KEY (`dicatat_oleh`) REFERENCES `users`(`id`) ON DELETE SET NULL ON UPDATE CASCADE,
	UNIQUE KEY `tanggal_siswa_id` (`tanggal`, `siswa_id`),
	KEY `kelas_id_tanggal` (`kelas_id`, `tanggal`)
) DEFAULT CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci;

CREATE TABLE `pembiasaan` (
	`id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
	`nama` VARCHAR(100) NOT NULL,
	`kategori` VARCHAR(50) NULL,
	`deskripsi` TEXT NULL,
	`hari` VARCHAR(20) NULL,
	`urutan` SMALLINT NOT NULL DEFAULT 0,
	`is_active` TINYINT(1) NOT NULL DEFAULT 1,
	`created_at` DATETIME NULL,
	`updated_at` DATETIME NULL,
	CONSTRAINT `pk_pembiasaan` PRIMARY KEY(`id`)
) DEFAULT CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci;

CREATE TABLE `pembiasaan_siswa` (
	`id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
	`tahun_pelajaran_id` INT UNSIGNED NOT NULL,
	`kelas_id` INT UNSIGNED NOT NULL,
	`siswa_id` INT UNSIGNED NOT NULL,
	`pembiasaan_id` INT UNSIGNED NOT NULL,
	`tanggal` DATE NOT NULL,
	`terlaksana` TINYINT(1) NOT NULL DEFAULT 0,
	`keterangan` VARCHAR(150) NULL,
	`dicatat_oleh` INT UNSIGNED NULL,
	`created_at` DATETIME NULL,
	`updated_at` DATETIME NULL,
	CONSTRAINT `pk_pembiasaan_siswa` PRIMARY KEY(`id`),
	CONSTRAINT `pembiasaan_siswa_tahun_pelajaran_id_foreign` FOREIGN KEY (`tahun_pelajaran_id`) REFERENCES `tahun_pelajaran`(`id`) ON DELETE CASCADE ON UPDATE CASCADE,
	CONSTRAINT `pembiasaan_siswa_kelas_id_foreign` FOREIGN KEY (`kelas_id`) REFERENCES `kelas`(`id`) ON DELETE CASCADE ON UPDATE CASCADE,
	CONSTRAINT `pembiasaan_siswa_siswa_id_foreign` FOREIGN KEY (`siswa_id`) REFERENCES `siswa`(`id`) ON DELETE CASCADE ON UPDATE CASCADE,
	CONSTRAINT `pembiasaan_siswa_pembiasaan_id_foreign` FOREIGN KEY (`pembiasaan_id`) REFERENCES `pembiasaan`(`id`) ON DELETE CASCADE ON UPDATE CASCADE,
	CONSTRAINT `pembiasaan_siswa_dicatat_oleh_foreign` FOREIGN KEY (`dicatat_oleh`) REFERENCES `users`(`id`) ON DELETE SET NULL ON UPDATE CASCADE,
	UNIQUE KEY `tanggal_siswa_id_pembiasaan_id` (`tanggal`, `siswa_id`, `pembiasaan_id`),
	KEY `kelas_id_tanggal` (`kelas_id`, `tanggal`)
) DEFAULT CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci;

CREATE TABLE `jenis_perilaku` (
	`id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
	`kategori` ENUM('Positif','Negatif') NOT NULL,
	`nama` VARCHAR(150) NOT NULL,
	`tingkat` ENUM('Ringan','Sedang','Berat') NULL,
	`poin` SMALLINT NOT NULL DEFAULT 0,
	`is_active` TINYINT(1) NOT NULL DEFAULT 1,
	`created_at` DATETIME NULL,
	`updated_at` DATETIME NULL,
	CONSTRAINT `pk_jenis_perilaku` PRIMARY KEY(`id`)
) DEFAULT CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci;

CREATE TABLE `catatan_perilaku` (
	`id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
	`tahun_pelajaran_id` INT UNSIGNED NOT NULL,
	`siswa_id` INT UNSIGNED NOT NULL,
	`kelas_id` INT UNSIGNED NULL,
	`jenis_perilaku_id` INT UNSIGNED NULL,
	`tanggal` DATE NOT NULL,
	`kategori` ENUM('Positif','Negatif') NOT NULL,
	`poin` SMALLINT NOT NULL DEFAULT 0,
	`deskripsi` TEXT NOT NULL,
	`lokasi` VARCHAR(100) NULL,
	`tindak_lanjut` TEXT NULL,
	`status` ENUM('Tercatat','Ditindaklanjuti','Dirujuk BK','Ditangani BK','Selesai') NOT NULL DEFAULT 'Tercatat',
	`dicatat_oleh` INT UNSIGNED NULL,
	`created_at` DATETIME NULL,
	`updated_at` DATETIME NULL,
	CONSTRAINT `pk_catatan_perilaku` PRIMARY KEY(`id`),
	CONSTRAINT `catatan_perilaku_tahun_pelajaran_id_foreign` FOREIGN KEY (`tahun_pelajaran_id`) REFERENCES `tahun_pelajaran`(`id`) ON DELETE CASCADE ON UPDATE CASCADE,
	CONSTRAINT `catatan_perilaku_siswa_id_foreign` FOREIGN KEY (`siswa_id`) REFERENCES `siswa`(`id`) ON DELETE CASCADE ON UPDATE CASCADE,
	CONSTRAINT `catatan_perilaku_kelas_id_foreign` FOREIGN KEY (`kelas_id`) REFERENCES `kelas`(`id`) ON DELETE SET NULL ON UPDATE CASCADE,
	CONSTRAINT `catatan_perilaku_jenis_perilaku_id_foreign` FOREIGN KEY (`jenis_perilaku_id`) REFERENCES `jenis_perilaku`(`id`) ON DELETE SET NULL ON UPDATE CASCADE,
	CONSTRAINT `catatan_perilaku_dicatat_oleh_foreign` FOREIGN KEY (`dicatat_oleh`) REFERENCES `users`(`id`) ON DELETE SET NULL ON UPDATE CASCADE,
	KEY `siswa_id_tanggal` (`siswa_id`, `tanggal`),
	KEY `status` (`status`)
) DEFAULT CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci;

-- ---------------------------------------------------------------
-- 2026-11-23-000007_CreateBkTables.php
CREATE TABLE `bk_layanan` (
	`id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
	`tahun_pelajaran_id` INT UNSIGNED NOT NULL,
	`tanggal` DATE NOT NULL,
	`jenis_layanan` ENUM('Konseling Individual','Konseling Kelompok','Bimbingan Klasikal','Bimbingan Kelompok','Konsultasi','Mediasi','Pemanggilan Orang Tua','Kunjungan Rumah','Alih Tangan Kasus') NOT NULL,
	`bidang` ENUM('Pribadi','Sosial','Belajar','Karier') NOT NULL,
	`kelas_id` INT UNSIGNED NULL,
	`catatan_perilaku_id` INT UNSIGNED NULL,
	`topik` VARCHAR(200) NOT NULL,
	`permasalahan` TEXT NULL,
	`penanganan` TEXT NULL,
	`hasil` TEXT NULL,
	`rencana_tindak_lanjut` TEXT NULL,
	`status` ENUM('Dijadwalkan','Berlangsung','Selesai') NOT NULL DEFAULT 'Dijadwalkan',
	`is_rahasia` TINYINT(1) NOT NULL DEFAULT 1,
	`konselor_id` INT UNSIGNED NULL,
	`created_at` DATETIME NULL,
	`updated_at` DATETIME NULL,
	CONSTRAINT `pk_bk_layanan` PRIMARY KEY(`id`),
	CONSTRAINT `bk_layanan_tahun_pelajaran_id_foreign` FOREIGN KEY (`tahun_pelajaran_id`) REFERENCES `tahun_pelajaran`(`id`) ON DELETE CASCADE ON UPDATE CASCADE,
	CONSTRAINT `bk_layanan_kelas_id_foreign` FOREIGN KEY (`kelas_id`) REFERENCES `kelas`(`id`) ON DELETE SET NULL ON UPDATE CASCADE,
	CONSTRAINT `bk_layanan_catatan_perilaku_id_foreign` FOREIGN KEY (`catatan_perilaku_id`) REFERENCES `catatan_perilaku`(`id`) ON DELETE SET NULL ON UPDATE CASCADE,
	CONSTRAINT `bk_layanan_konselor_id_foreign` FOREIGN KEY (`konselor_id`) REFERENCES `users`(`id`) ON DELETE SET NULL ON UPDATE CASCADE,
	KEY `tanggal` (`tanggal`)
) DEFAULT CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci;

CREATE TABLE `bk_peserta` (
	`id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
	`layanan_id` INT UNSIGNED NOT NULL,
	`siswa_id` INT UNSIGNED NOT NULL,
	CONSTRAINT `pk_bk_peserta` PRIMARY KEY(`id`),
	CONSTRAINT `bk_peserta_layanan_id_foreign` FOREIGN KEY (`layanan_id`) REFERENCES `bk_layanan`(`id`) ON DELETE CASCADE ON UPDATE CASCADE,
	CONSTRAINT `bk_peserta_siswa_id_foreign` FOREIGN KEY (`siswa_id`) REFERENCES `siswa`(`id`) ON DELETE CASCADE ON UPDATE CASCADE,
	UNIQUE KEY `layanan_id_siswa_id` (`layanan_id`, `siswa_id`)
) DEFAULT CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci;

-- ---------------------------------------------------------------
-- 2026-11-23-000008_AddKioskPresensi.php
ALTER TABLE `siswa`
	ADD `rfid` VARCHAR(50) NULL AFTER `nisn`;

CREATE UNIQUE INDEX `siswa_rfid` ON `siswa` (`rfid`);

ALTER TABLE `presensi_harian`
	ADD `jam_pulang` TIME NULL AFTER `jam_datang`,
	ADD `sumber` ENUM('Manual','Kiosk') DEFAULT 'Manual' AFTER `keterangan`;

-- ---------------------------------------------------------------
-- 2026-11-23-000009_AddIdentitasSekolah.php
-- ---------------------------------------------------------------
-- 2026-11-23-000010_CreateKalenderAkademik.php
CREATE TABLE `kalender_akademik` (
	`id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
	`tahun_pelajaran_id` INT UNSIGNED NOT NULL,
	`tanggal_mulai` DATE NOT NULL,
	`tanggal_selesai` DATE NOT NULL,
	`jenis` ENUM('Libur Nasional','Cuti Bersama','Libur Semester','Libur Fakultatif','Ujian','Kegiatan Sekolah') NOT NULL,
	`nama` VARCHAR(150) NOT NULL,
	`keterangan` TEXT NULL,
	`ada_kbm` TINYINT(1) NOT NULL DEFAULT 0,
	`ada_absensi` TINYINT(1) NOT NULL DEFAULT 0,
	`created_at` DATETIME NULL,
	`updated_at` DATETIME NULL,
	CONSTRAINT `pk_kalender_akademik` PRIMARY KEY(`id`),
	CONSTRAINT `kalender_akademik_tahun_pelajaran_id_foreign` FOREIGN KEY (`tahun_pelajaran_id`) REFERENCES `tahun_pelajaran`(`id`) ON DELETE CASCADE ON UPDATE CASCADE,
	KEY `tanggal_mulai_tanggal_selesai` (`tanggal_mulai`, `tanggal_selesai`)
) DEFAULT CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci;

-- ---------------------------------------------------------------
-- 2026-11-24-000011_AddKeamananLog.php
CREATE TABLE `log_aktivitas` (
	`id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
	`user_id` INT UNSIGNED NULL,
	`nama_user` VARCHAR(100) NULL,
	`aksi` VARCHAR(30) NOT NULL,
	`objek` VARCHAR(60) NULL,
	`objek_id` INT UNSIGNED NULL,
	`keterangan` TEXT NULL,
	`ip` VARCHAR(45) NULL,
	`created_at` DATETIME NULL,
	CONSTRAINT `pk_log_aktivitas` PRIMARY KEY(`id`),
	KEY `created_at` (`created_at`),
	KEY `objek_objek_id` (`objek`, `objek_id`)
) DEFAULT CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci;

-- ---------------------------------------------------------------
-- 2026-11-24-000012_JamPerHariVersiJadwal.php
ALTER TABLE `jam_pelajaran`
	ADD `hari` TINYINT UNSIGNED NULL AFTER `id`;

ALTER TABLE `jadwal_pelajaran`
	ADD `berlaku_mulai` DATE NULL AFTER `jam_pelajaran_id`,
	ADD `berlaku_sampai` DATE NULL AFTER `berlaku_mulai`;

CREATE INDEX jadwal_tp_kelas_hari ON jadwal_pelajaran (tahun_pelajaran_id, kelas_id, hari);

ALTER TABLE jadwal_pelajaran DROP INDEX tahun_pelajaran_id_kelas_id_hari_jam_pelajaran_id;

ALTER TABLE `jurnal_pembelajaran`
	ADD `guru_id` INT UNSIGNED NULL AFTER `penugasan_guru_id`;

UPDATE jurnal_pembelajaran SET guru_id = (SELECT guru_id FROM penugasan_guru p WHERE p.id = penugasan_guru_id) WHERE guru_id IS NULL;

CREATE INDEX jurnal_guru_tanggal ON jurnal_pembelajaran (guru_id, tanggal);

-- ---------------------------------------------------------------
-- 2026-11-24-000013_KalenderPerKelas.php
ALTER TABLE `kalender_akademik`
	CHANGE `jenis` `jenis` VARCHAR(30) NOT NULL;

ALTER TABLE `kalender_akademik`
	ADD `kelas_ids` VARCHAR(500) NULL AFTER `nama`,
	ADD `hari_jadwal` TINYINT UNSIGNED NULL AFTER `kelas_ids`;

-- ---------------------------------------------------------------
-- 2026-11-24-000014_KehadiranGuruIzin.php
ALTER TABLE `guru`
	ADD `rfid` VARCHAR(50) NULL AFTER `nuptk`;

CREATE UNIQUE INDEX guru_rfid ON guru (rfid);

CREATE TABLE `izin_guru` (
	`id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
	`guru_id` INT UNSIGNED NOT NULL,
	`tanggal_mulai` DATE NOT NULL,
	`tanggal_selesai` DATE NOT NULL,
	`jenis` VARCHAR(2) NOT NULL,
	`keterangan` TEXT NULL,
	`tugas_siswa` TEXT NULL,
	`lampiran` VARCHAR(100) NULL,
	`status` VARCHAR(12) NOT NULL DEFAULT 'Diajukan',
	`diputus_oleh` INT UNSIGNED NULL,
	`catatan_putusan` VARCHAR(255) NULL,
	`created_at` DATETIME NULL,
	`updated_at` DATETIME NULL,
	CONSTRAINT `pk_izin_guru` PRIMARY KEY(`id`),
	CONSTRAINT `izin_guru_guru_id_foreign` FOREIGN KEY (`guru_id`) REFERENCES `guru`(`id`) ON DELETE CASCADE ON UPDATE CASCADE,
	KEY `guru_id_tanggal_mulai` (`guru_id`, `tanggal_mulai`)
) DEFAULT CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci;

CREATE TABLE `presensi_guru` (
	`id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
	`tahun_pelajaran_id` INT UNSIGNED NOT NULL,
	`guru_id` INT UNSIGNED NOT NULL,
	`tanggal` DATE NOT NULL,
	`status` VARCHAR(2) NOT NULL DEFAULT 'H',
	`jam_datang` TIME NULL,
	`jam_pulang` TIME NULL,
	`keterangan` VARCHAR(150) NULL,
	`izin_guru_id` INT UNSIGNED NULL,
	`sumber` VARCHAR(10) NOT NULL DEFAULT 'Manual',
	`dicatat_oleh` INT UNSIGNED NULL,
	`created_at` DATETIME NULL,
	`updated_at` DATETIME NULL,
	CONSTRAINT `pk_presensi_guru` PRIMARY KEY(`id`),
	CONSTRAINT `presensi_guru_tahun_pelajaran_id_foreign` FOREIGN KEY (`tahun_pelajaran_id`) REFERENCES `tahun_pelajaran`(`id`) ON DELETE CASCADE ON UPDATE CASCADE,
	CONSTRAINT `presensi_guru_guru_id_foreign` FOREIGN KEY (`guru_id`) REFERENCES `guru`(`id`) ON DELETE CASCADE ON UPDATE CASCADE,
	CONSTRAINT `presensi_guru_izin_guru_id_foreign` FOREIGN KEY (`izin_guru_id`) REFERENCES `izin_guru`(`id`) ON DELETE SET NULL ON UPDATE CASCADE,
	UNIQUE KEY `tanggal_guru_id` (`tanggal`, `guru_id`)
) DEFAULT CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci;

CREATE TABLE `izin_siswa` (
	`id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
	`siswa_id` INT UNSIGNED NOT NULL,
	`tanggal_mulai` DATE NOT NULL,
	`tanggal_selesai` DATE NOT NULL,
	`jenis` VARCHAR(1) NOT NULL,
	`keterangan` VARCHAR(255) NULL,
	`lampiran` VARCHAR(100) NULL,
	`dicatat_oleh` INT UNSIGNED NULL,
	`created_at` DATETIME NULL,
	`updated_at` DATETIME NULL,
	CONSTRAINT `pk_izin_siswa` PRIMARY KEY(`id`),
	CONSTRAINT `izin_siswa_siswa_id_foreign` FOREIGN KEY (`siswa_id`) REFERENCES `siswa`(`id`) ON DELETE CASCADE ON UPDATE CASCADE,
	KEY `siswa_id_tanggal_mulai` (`siswa_id`, `tanggal_mulai`)
) DEFAULT CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci;

ALTER TABLE `presensi_harian`
	ADD `izin_siswa_id` INT UNSIGNED NULL AFTER `keterangan`;

ALTER TABLE `presensi_harian`
	CHANGE `sumber` `sumber` VARCHAR(10) NOT NULL DEFAULT 'Manual';

-- ---------------------------------------------------------------
-- 2026-11-24-000015_KurikulumMerdeka.php
CREATE TABLE `atp` (
	`id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
	`mapel_id` INT UNSIGNED NOT NULL,
	`tingkat` VARCHAR(5) NOT NULL,
	`fase` VARCHAR(5) NULL,
	`semester` VARCHAR(6) NULL,
	`elemen` VARCHAR(150) NULL,
	`kode` VARCHAR(20) NULL,
	`tujuan` TEXT NOT NULL,
	`alokasi_jp` SMALLINT UNSIGNED NULL,
	`urutan` SMALLINT NOT NULL DEFAULT 0,
	`modul_ajar` VARCHAR(120) NULL,
	`dibuat_oleh` INT UNSIGNED NULL,
	`created_at` DATETIME NULL,
	`updated_at` DATETIME NULL,
	CONSTRAINT `pk_atp` PRIMARY KEY(`id`),
	CONSTRAINT `atp_mapel_id_foreign` FOREIGN KEY (`mapel_id`) REFERENCES `mata_pelajaran`(`id`) ON DELETE CASCADE ON UPDATE CASCADE,
	KEY `mapel_id_tingkat` (`mapel_id`, `tingkat`)
) DEFAULT CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci;

CREATE TABLE `jurnal_atp` (
	`id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
	`jurnal_id` INT UNSIGNED NOT NULL,
	`atp_id` INT UNSIGNED NOT NULL,
	CONSTRAINT `pk_jurnal_atp` PRIMARY KEY(`id`),
	CONSTRAINT `jurnal_atp_jurnal_id_foreign` FOREIGN KEY (`jurnal_id`) REFERENCES `jurnal_pembelajaran`(`id`) ON DELETE CASCADE ON UPDATE CASCADE,
	CONSTRAINT `jurnal_atp_atp_id_foreign` FOREIGN KEY (`atp_id`) REFERENCES `atp`(`id`) ON DELETE CASCADE ON UPDATE CASCADE,
	UNIQUE KEY `jurnal_id_atp_id` (`jurnal_id`, `atp_id`)
) DEFAULT CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci;

CREATE TABLE `kokurikuler` (
	`id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
	`tahun_pelajaran_id` INT UNSIGNED NOT NULL,
	`judul` VARCHAR(200) NOT NULL,
	`tema` VARCHAR(150) NULL,
	`bentuk` VARCHAR(40) NULL,
	`dimensi` VARCHAR(255) NULL,
	`kelas_ids` VARCHAR(500) NULL,
	`tanggal_mulai` DATE NOT NULL,
	`tanggal_selesai` DATE NOT NULL,
	`alokasi_jp` SMALLINT UNSIGNED NULL,
	`deskripsi` TEXT NULL,
	`koordinator_id` INT UNSIGNED NULL,
	`kalender_id` INT UNSIGNED NULL,
	`refleksi` TEXT NULL,
	`created_at` DATETIME NULL,
	`updated_at` DATETIME NULL,
	CONSTRAINT `pk_kokurikuler` PRIMARY KEY(`id`),
	CONSTRAINT `kokurikuler_tahun_pelajaran_id_foreign` FOREIGN KEY (`tahun_pelajaran_id`) REFERENCES `tahun_pelajaran`(`id`) ON DELETE CASCADE ON UPDATE CASCADE
) DEFAULT CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci;


CREATE TABLE `migrations` (
	`id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
	`version` VARCHAR(255) NOT NULL,
	`class` VARCHAR(255) NOT NULL,
	`group` VARCHAR(255) NOT NULL,
	`namespace` VARCHAR(255) NOT NULL,
	`time` INT NOT NULL,
	`batch` INT UNSIGNED NOT NULL,
	CONSTRAINT `pk_migrations` PRIMARY KEY(`id`)
) DEFAULT CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci;

-- ---------------------------------------------------------------
-- 2026-11-24-000016_WajibGantiPassword.php
ALTER TABLE `users`
	ADD `wajib_ganti_password` TINYINT(1) NOT NULL DEFAULT 0 AFTER `is_active`;

-- ---------------------------------------------------------------
-- 2026-11-24-000017_MutasiSiswa.php
CREATE TABLE `mutasi_siswa` (
	`id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
	`tahun_pelajaran_id` INT UNSIGNED NOT NULL,
	`siswa_id` INT UNSIGNED NOT NULL,
	`jenis` VARCHAR(20) NOT NULL,
	`tanggal` DATE NOT NULL,
	`kelas_asal_id` INT UNSIGNED NULL,
	`kelas_tujuan_id` INT UNSIGNED NULL,
	`sekolah` VARCHAR(150) NULL,
	`alasan` VARCHAR(255) NULL,
	`no_surat` VARCHAR(60) NULL,
	`status_sebelum` VARCHAR(20) NULL,
	`dicatat_oleh` INT UNSIGNED NULL,
	`created_at` DATETIME NULL,
	`updated_at` DATETIME NULL,
	CONSTRAINT `pk_mutasi_siswa` PRIMARY KEY(`id`),
	KEY `tahun_pelajaran_id_tanggal` (`tahun_pelajaran_id`, `tanggal`),
	CONSTRAINT `mutasi_siswa_siswa_id_foreign` FOREIGN KEY (`siswa_id`) REFERENCES `siswa`(`id`) ON DELETE CASCADE ON UPDATE CASCADE
) DEFAULT CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci;

-- ---------------------------------------------------------------
-- 2026-11-24-000018_PasswordDiubah.php
ALTER TABLE `users`
	ADD `password_sendiri_at` DATETIME NULL AFTER `wajib_ganti_password`;

-- ---------------------------------------------------------------
-- 2026-11-24-000019_PortalSiswa.php
ALTER TABLE `siswa`
	ADD `password` VARCHAR(255) NULL AFTER `rfid`,
	ADD `login_terakhir` DATETIME NULL AFTER `password`;

-- ---------------------------------------------------------------
-- 2026-11-24-000020_JenisLayananBk.php  (jenis layanan BK lengkap, Permendikbud 111/2014)
ALTER TABLE `bk_layanan`
	MODIFY `jenis_layanan` VARCHAR(50) NOT NULL,
	ADD `komponen` VARCHAR(40) NULL AFTER `jenis_layanan`,
	ADD `format` VARCHAR(20) NULL AFTER `komponen`,
	ADD `media` VARCHAR(20) NULL AFTER `format`,
	ADD `pihak_terkait` VARCHAR(150) NULL AFTER `kelas_id`;
UPDATE `bk_layanan` SET `komponen` = 'Layanan Dasar', `format` = IF(`jenis_layanan` = 'Bimbingan Klasikal', 'Klasikal', 'Kelompok'), `media` = 'Tatap muka'
	WHERE `komponen` IS NULL AND `jenis_layanan` IN ('Bimbingan Klasikal', 'Bimbingan Kelompok');
UPDATE `bk_layanan` SET `komponen` = 'Responsif', `format` = IF(`jenis_layanan` IN ('Konseling Kelompok', 'Mediasi'), 'Kelompok', 'Individual'), `media` = 'Tatap muka'
	WHERE `komponen` IS NULL;

-- ---------------------------------------------------------------
-- 2026-11-24-000021_SinkronAbsensi.php  (izin pulang awal + sinkron absensi mapel)
ALTER TABLE `izin_siswa`
	ADD `jam_keluar` TIME NULL AFTER `jenis`,
	ADD `penjemput` VARCHAR(100) NULL AFTER `jam_keluar`;
ALTER TABLE `presensi_mapel`
	ADD `sumber` VARCHAR(10) NOT NULL DEFAULT 'Guru' AFTER `keterangan`;

-- ---------------------------------------------------------------
-- 2026-11-24-000022_IzinKeluarSatpam.php  (izin keluar sementara + pos gerbang satpam)
ALTER TABLE `izin_siswa`
	ADD `batas_kembali` TIME NULL AFTER `penjemput`,
	ADD `keluar_at` DATETIME NULL AFTER `batas_kembali`,
	ADD `keluar_oleh` INT UNSIGNED NULL AFTER `keluar_at`,
	ADD `kembali_at` DATETIME NULL AFTER `keluar_oleh`,
	ADD `kembali_oleh` INT UNSIGNED NULL AFTER `kembali_at`,
	ADD `status_keluar` VARCHAR(20) NULL AFTER `kembali_oleh`,
	ADD `catatan_perilaku_id` INT UNSIGNED NULL AFTER `status_keluar`;

-- ---------------------------------------------------------------
-- 2026-11-24-000023_PerangkatPembelajaran.php  (perangkat pembelajaran guru → kurikulum → kepala sekolah)
CREATE TABLE IF NOT EXISTS `jenis_perangkat` (
	`id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
	`nama` VARCHAR(120) NOT NULL,
	`periode` VARCHAR(10) NOT NULL DEFAULT 'Semester',
	`wajib` TINYINT(1) NOT NULL DEFAULT 1,
	`keterangan` VARCHAR(255) NULL,
	`urutan` SMALLINT NOT NULL DEFAULT 0,
	`is_active` TINYINT(1) NOT NULL DEFAULT 1,
	`created_at` DATETIME NULL,
	`updated_at` DATETIME NULL,
	CONSTRAINT `pk_jenis_perangkat` PRIMARY KEY(`id`)
) DEFAULT CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `perangkat_pembelajaran` (
	`id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
	`tahun_pelajaran_id` INT UNSIGNED NOT NULL,
	`guru_id` INT UNSIGNED NOT NULL,
	`mapel_id` INT UNSIGNED NOT NULL,
	`tingkat` VARCHAR(5) NOT NULL,
	`jenis_perangkat_id` INT UNSIGNED NOT NULL,
	`file` VARCHAR(120) NULL,
	`nama_file` VARCHAR(150) NULL,
	`tautan` VARCHAR(255) NULL,
	`catatan_guru` TEXT NULL,
	`status` VARCHAR(15) NOT NULL DEFAULT 'Diajukan',
	`versi` SMALLINT UNSIGNED NOT NULL DEFAULT 1,
	`diajukan_at` DATETIME NULL,
	`catatan_pemeriksa` TEXT NULL,
	`diperiksa_oleh` INT UNSIGNED NULL,
	`diperiksa_at` DATETIME NULL,
	`disahkan_oleh` INT UNSIGNED NULL,
	`disahkan_at` DATETIME NULL,
	`created_at` DATETIME NULL,
	`updated_at` DATETIME NULL,
	CONSTRAINT `pk_perangkat_pembelajaran` PRIMARY KEY(`id`),
	CONSTRAINT `uniq_perangkat` UNIQUE (`tahun_pelajaran_id`, `guru_id`, `mapel_id`, `tingkat`, `jenis_perangkat_id`),
	KEY `status` (`status`),
	CONSTRAINT `perangkat_pembelajaran_tahun_pelajaran_id_foreign` FOREIGN KEY (`tahun_pelajaran_id`) REFERENCES `tahun_pelajaran`(`id`) ON DELETE CASCADE ON UPDATE CASCADE,
	CONSTRAINT `perangkat_pembelajaran_guru_id_foreign` FOREIGN KEY (`guru_id`) REFERENCES `guru`(`id`) ON DELETE CASCADE ON UPDATE CASCADE,
	CONSTRAINT `perangkat_pembelajaran_mapel_id_foreign` FOREIGN KEY (`mapel_id`) REFERENCES `mata_pelajaran`(`id`) ON DELETE CASCADE ON UPDATE CASCADE,
	CONSTRAINT `perangkat_pembelajaran_jenis_perangkat_id_foreign` FOREIGN KEY (`jenis_perangkat_id`) REFERENCES `jenis_perangkat`(`id`) ON DELETE CASCADE ON UPDATE CASCADE
) DEFAULT CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `perangkat_riwayat` (
	`id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
	`perangkat_id` INT UNSIGNED NOT NULL,
	`aksi` VARCHAR(20) NOT NULL,
	`versi` SMALLINT UNSIGNED NOT NULL DEFAULT 1,
	`catatan` TEXT NULL,
	`file` VARCHAR(120) NULL,
	`user_id` INT UNSIGNED NULL,
	`created_at` DATETIME NULL,
	CONSTRAINT `pk_perangkat_riwayat` PRIMARY KEY(`id`),
	KEY `perangkat_id` (`perangkat_id`),
	CONSTRAINT `perangkat_riwayat_perangkat_id_foreign` FOREIGN KEY (`perangkat_id`) REFERENCES `perangkat_pembelajaran`(`id`) ON DELETE CASCADE ON UPDATE CASCADE
) DEFAULT CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci;

-- ---------------------------------------------------------------
-- 2026-11-24-000024_ProgramModulAjar.php  (program semester/tahunan dari kalender + penyusun modul ajar)
CREATE TABLE IF NOT EXISTS `promes_item` (
	`id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
	`tahun_pelajaran_id` INT UNSIGNED NOT NULL,
	`guru_id` INT UNSIGNED NOT NULL,
	`mapel_id` INT UNSIGNED NOT NULL,
	`tingkat` VARCHAR(5) NOT NULL,
	`atp_id` INT UNSIGNED NULL,
	`jenis` VARCHAR(10) NOT NULL DEFAULT 'Materi',
	`materi` VARCHAR(255) NOT NULL,
	`tujuan` TEXT NULL,
	`jp` SMALLINT UNSIGNED NOT NULL DEFAULT 0,
	`urutan` SMALLINT NOT NULL DEFAULT 0,
	`created_at` DATETIME NULL,
	`updated_at` DATETIME NULL,
	CONSTRAINT `pk_promes_item` PRIMARY KEY(`id`),
	KEY `tahun_pelajaran_id_guru_id_mapel_id_tingkat` (`tahun_pelajaran_id`, `guru_id`, `mapel_id`, `tingkat`),
	CONSTRAINT `promes_item_tahun_pelajaran_id_foreign` FOREIGN KEY (`tahun_pelajaran_id`) REFERENCES `tahun_pelajaran`(`id`) ON DELETE CASCADE ON UPDATE CASCADE,
	CONSTRAINT `promes_item_guru_id_foreign` FOREIGN KEY (`guru_id`) REFERENCES `guru`(`id`) ON DELETE CASCADE ON UPDATE CASCADE,
	CONSTRAINT `promes_item_mapel_id_foreign` FOREIGN KEY (`mapel_id`) REFERENCES `mata_pelajaran`(`id`) ON DELETE CASCADE ON UPDATE CASCADE
) DEFAULT CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `promes_alokasi` (
	`id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
	`item_id` INT UNSIGNED NOT NULL,
	`pekan` DATE NOT NULL,
	`jp` SMALLINT UNSIGNED NOT NULL DEFAULT 0,
	CONSTRAINT `pk_promes_alokasi` PRIMARY KEY(`id`),
	CONSTRAINT `item_id_pekan` UNIQUE (`item_id`, `pekan`),
	CONSTRAINT `promes_alokasi_item_id_foreign` FOREIGN KEY (`item_id`) REFERENCES `promes_item`(`id`) ON DELETE CASCADE ON UPDATE CASCADE
) DEFAULT CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `modul_ajar` (
	`id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
	`tahun_pelajaran_id` INT UNSIGNED NOT NULL,
	`guru_id` INT UNSIGNED NOT NULL,
	`mapel_id` INT UNSIGNED NOT NULL,
	`tingkat` VARCHAR(5) NOT NULL,
	`promes_item_id` INT UNSIGNED NULL,
	`judul` VARCHAR(200) NOT NULL,
	`format` VARCHAR(10) NOT NULL DEFAULT 'PM',
	`jp` SMALLINT UNSIGNED NOT NULL DEFAULT 0,
	`pertemuan` TINYINT UNSIGNED NOT NULL DEFAULT 1,
	`isi` MEDIUMTEXT NULL,
	`urutan` SMALLINT NOT NULL DEFAULT 0,
	`created_at` DATETIME NULL,
	`updated_at` DATETIME NULL,
	CONSTRAINT `pk_modul_ajar` PRIMARY KEY(`id`),
	KEY `tahun_pelajaran_id_guru_id_mapel_id_tingkat` (`tahun_pelajaran_id`, `guru_id`, `mapel_id`, `tingkat`),
	CONSTRAINT `modul_ajar_tahun_pelajaran_id_foreign` FOREIGN KEY (`tahun_pelajaran_id`) REFERENCES `tahun_pelajaran`(`id`) ON DELETE CASCADE ON UPDATE CASCADE,
	CONSTRAINT `modul_ajar_guru_id_foreign` FOREIGN KEY (`guru_id`) REFERENCES `guru`(`id`) ON DELETE CASCADE ON UPDATE CASCADE,
	CONSTRAINT `modul_ajar_mapel_id_foreign` FOREIGN KEY (`mapel_id`) REFERENCES `mata_pelajaran`(`id`) ON DELETE CASCADE ON UPDATE CASCADE
) DEFAULT CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci;

ALTER TABLE `perangkat_pembelajaran`
	ADD `sumber` VARCHAR(10) NULL AFTER `tautan`;

-- ---------------------------------------------------------------
-- 2026-11-24-100010_PembiasaanMandiri.php  (pembiasaan diisi siswa lewat portal + verifikasi wali kelas)
ALTER TABLE `pembiasaan`
	ADD `pengisi` VARCHAR(10) NOT NULL DEFAULT 'Guru' AFTER `hari`,
	ADD `tempat` VARCHAR(10) NOT NULL DEFAULT 'Sekolah' AFTER `pengisi`,
	ADD `perlu_verifikasi` TINYINT(1) NOT NULL DEFAULT 1 AFTER `tempat`,
	ADD `wajib_catatan` TINYINT(1) NOT NULL DEFAULT 0 AFTER `perlu_verifikasi`,
	ADD `petunjuk_catatan` VARCHAR(100) NULL AFTER `wajib_catatan`,
	ADD `tingkat` VARCHAR(60) NULL AFTER `petunjuk_catatan`;
ALTER TABLE `pembiasaan_siswa`
	ADD `sumber` VARCHAR(10) NOT NULL DEFAULT 'Guru' AFTER `keterangan`,
	ADD `lapor_siswa` TINYINT(1) NULL AFTER `sumber`,
	ADD `lapor_at` DATETIME NULL AFTER `lapor_siswa`,
	ADD `verifikasi` VARCHAR(10) NOT NULL DEFAULT 'Disetujui' AFTER `lapor_at`,
	ADD `diverifikasi_oleh` INT UNSIGNED NULL AFTER `verifikasi`,
	ADD `diverifikasi_at` DATETIME NULL AFTER `diverifikasi_oleh`;

-- ---------------------------------------------------------------
-- 2026-11-24-100011_PembiasaanBerlaku.php  (kegiatan rumah: setiap hari / hari masuk sekolah / hari libur)
ALTER TABLE `pembiasaan`
	ADD `berlaku` VARCHAR(10) NOT NULL DEFAULT 'Semua' AFTER `tempat`;

-- =====================================================================
--  DATA AWAL
-- =====================================================================

-- Role
INSERT INTO `roles` (`id`, `nama_role`, `keterangan`) VALUES
(1, 'admin', 'Administrator Sistem'),
(2, 'kepsek', 'Kepala Sekolah'),
(3, 'kurikulum', 'Wakil Kepala Bidang Kurikulum'),
(4, 'kesiswaan', 'Wakil Kepala Bidang Kesiswaan'),
(5, 'guru', 'Guru Mata Pelajaran'),
(6, 'piket', 'Guru Piket'),
(7, 'bk', 'Guru Bimbingan & Konseling'),
(8, 'tu', 'Staf Tata Usaha');

-- Akun admin (password: admin123)
INSERT INTO `users` (`id`, `username`, `password`, `nama_lengkap`, `email`, `is_active`, `last_login`, `created_at`, `updated_at`) VALUES
(1, 'admin', '$2y$10$LnOWMoHcGwJwOM.iNhORNexe8FBXDj2ftH0ZX1A//tBmZkkUDjjl.', 'Administrator', NULL, 1, NULL, '2026-11-23 23:36:01', NULL);

INSERT INTO `user_roles` (`user_id`, `role_id`) VALUES
(1, 1);

-- Pengaturan sekolah (isi lewat menu Pengaturan Sekolah; token kiosk sengaja kosong)
INSERT INTO `pengaturan` (`id`, `kunci`, `nilai`, `label`, `updated_at`) VALUES
(1, 'kiosk_aktif', '1', 'Absensi kiosk (RFID/barcode) aktif', '2026-11-23 23:36:01'),
(2, 'kiosk_token', '', 'Token alamat kiosk', '2026-11-23 23:36:01'),
(3, 'jam_pulang', '13:00', 'Jam mulai absen pulang (kiosk)', '2026-11-23 23:36:01'),
(4, 'nama_aplikasi', 'SIS Sekolah', 'Nama aplikasi', '2026-11-23 23:36:01'),
(5, 'jenjang', '', 'Jenjang', '2026-11-23 23:36:01'),
(6, 'jenis_nomor', 'NPSN', 'Jenis nomor induk sekolah (NPSN/NSM)', '2026-11-23 23:36:01'),
(7, 'npsn', '', 'NPSN / NSM', '2026-11-23 23:36:01'),
(8, 'kota', '', 'Kota/kabupaten (tempat tanda tangan)', '2026-11-23 23:36:01'),
(9, 'telepon_sekolah', '', 'Telepon sekolah', '2026-11-23 23:36:01'),
(10, 'email_sekolah', '', 'Email sekolah', '2026-11-23 23:36:01'),
(11, 'logo', '', 'Logo sekolah', '2026-11-23 23:36:01'),
(12, 'nama_sekolah', 'Nama Sekolah', 'Nama Sekolah', '2026-11-23 23:36:01'),
(13, 'alamat_sekolah', '', 'Alamat Sekolah', '2026-11-23 23:36:01'),
(14, 'kepala_sekolah', '', 'Nama Kepala Sekolah', '2026-11-23 23:36:01'),
(15, 'nip_kepala_sekolah', '', 'NIP Kepala Sekolah', '2026-11-23 23:36:01'),
(16, 'jam_masuk', '07:00', 'Jam Masuk (batas terlambat)', '2026-11-23 23:36:01'),
(17, 'hari_sekolah', '5', 'Jumlah Hari Sekolah (5/6)', '2026-11-23 23:36:01'),
(18, 'batas_poin_bk', '50', 'Batas Poin Pelanggaran untuk Peringatan BK', '2026-11-23 23:36:01');

-- Jam pelajaran contoh (silakan sesuaikan)
INSERT INTO `jam_pelajaran` (`id`, `jam_ke`, `jam_mulai`, `jam_selesai`, `is_kbm`, `keterangan`, `created_at`, `updated_at`, `hari`) VALUES
(1, 1, '07:00', '07:40', 1, NULL, '2026-11-23 23:36:01', NULL, NULL),
(2, 2, '07:40', '08:20', 1, NULL, '2026-11-23 23:36:01', NULL, NULL),
(3, 3, '08:20', '09:00', 1, NULL, '2026-11-23 23:36:01', NULL, NULL),
(4, 0, '09:00', '09:15', 0, 'Istirahat', '2026-11-23 23:36:01', NULL, NULL),
(5, 4, '09:15', '09:55', 1, NULL, '2026-11-23 23:36:01', NULL, NULL),
(6, 5, '09:55', '10:35', 1, NULL, '2026-11-23 23:36:01', NULL, NULL),
(7, 6, '10:35', '11:15', 1, NULL, '2026-11-23 23:36:01', NULL, NULL),
(8, 0, '11:15', '11:45', 0, 'Istirahat / Sholat', '2026-11-23 23:36:01', NULL, NULL),
(9, 7, '11:45', '12:25', 1, NULL, '2026-11-23 23:36:01', NULL, NULL),
(10, 8, '12:25', '13:05', 1, NULL, '2026-11-23 23:36:01', NULL, NULL);

-- Daftar pembiasaan contoh
INSERT INTO `pembiasaan` (`id`, `nama`, `kategori`, `deskripsi`, `hari`, `urutan`, `is_active`, `created_at`, `updated_at`) VALUES
(1, 'Berdoa sebelum belajar', 'Religius', NULL, NULL, 1, 1, '2026-11-23 23:36:01', NULL),
(2, 'Tadarus / membaca kitab suci', 'Religius', NULL, NULL, 2, 1, '2026-11-23 23:36:01', NULL),
(3, 'Literasi 15 menit', 'Literasi', NULL, NULL, 3, 1, '2026-11-23 23:36:01', NULL),
(4, 'Menyanyikan lagu kebangsaan', 'Nasionalisme', NULL, NULL, 4, 1, '2026-11-23 23:36:01', NULL),
(5, 'Piket kebersihan kelas', 'Kebersihan', NULL, NULL, 5, 1, '2026-11-23 23:36:01', NULL),
(6, 'Berpakaian rapi & lengkap', 'Kedisiplinan', NULL, NULL, 6, 1, '2026-11-23 23:36:01', NULL);

-- Jenis perilaku & poin contoh
INSERT INTO `jenis_perilaku` (`id`, `kategori`, `nama`, `tingkat`, `poin`, `is_active`, `created_at`, `updated_at`) VALUES
(1, 'Negatif', 'Terlambat masuk sekolah', 'Ringan', 5, 1, '2026-11-23 23:36:01', NULL),
(2, 'Negatif', 'Tidak mengerjakan tugas', 'Ringan', 5, 1, '2026-11-23 23:36:01', NULL),
(3, 'Negatif', 'Atribut seragam tidak lengkap', 'Ringan', 5, 1, '2026-11-23 23:36:01', NULL),
(4, 'Negatif', 'Membolos / meninggalkan pelajaran tanpa izin', 'Sedang', 15, 1, '2026-11-23 23:36:01', NULL),
(5, 'Negatif', 'Membawa / menggunakan HP saat KBM tanpa izin', 'Sedang', 10, 1, '2026-11-23 23:36:01', NULL),
(6, 'Negatif', 'Berkata kasar / tidak sopan', 'Sedang', 15, 1, '2026-11-23 23:36:01', NULL),
(7, 'Negatif', 'Berkelahi', 'Berat', 50, 1, '2026-11-23 23:36:01', NULL),
(8, 'Negatif', 'Merokok di lingkungan sekolah', 'Berat', 50, 1, '2026-11-23 23:36:01', NULL),
(9, 'Negatif', 'Perundungan (bullying)', 'Berat', 75, 1, '2026-11-23 23:36:01', NULL),
(10, 'Positif', 'Membantu teman / guru', NULL, 5, 1, '2026-11-23 23:36:01', NULL),
(11, 'Positif', 'Menjadi petugas upacara', NULL, 10, 1, '2026-11-23 23:36:01', NULL),
(12, 'Positif', 'Juara lomba tingkat sekolah', NULL, 20, 1, '2026-11-23 23:36:01', NULL),
(13, 'Positif', 'Juara lomba tingkat kabupaten/kota atau lebih', NULL, 50, 1, '2026-11-23 23:36:01', NULL);

-- Portal siswa aktif
INSERT INTO `pengaturan` (`kunci`, `nilai`) SELECT 'portal_siswa', '1' FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `pengaturan` WHERE `kunci` = 'portal_siswa');

-- Izin keluar & pos gerbang (satpam)
INSERT INTO `roles` (`nama_role`, `keterangan`) SELECT 'satpam', 'Satpam / Petugas Keamanan' FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `roles` WHERE `nama_role` = 'satpam');
INSERT INTO `pengaturan` (`kunci`, `nilai`) SELECT 'toleransi_kembali', '30' FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `pengaturan` WHERE `kunci` = 'toleransi_kembali');
INSERT INTO `pengaturan` (`kunci`, `nilai`) SELECT 'verifikasi_satpam', '1' FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `pengaturan` WHERE `kunci` = 'verifikasi_satpam');
INSERT INTO `pengaturan` (`kunci`, `nilai`) SELECT 'izin_keluar_perilaku', '1' FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `pengaturan` WHERE `kunci` = 'izin_keluar_perilaku');
INSERT INTO `jenis_perilaku` (`kategori`, `nama`, `tingkat`, `poin`, `is_active`, `created_at`) SELECT 'Negatif', 'Terlambat kembali dari izin keluar', 'Ringan', 5, 1, NOW() FROM DUAL
	WHERE NOT EXISTS (SELECT 1 FROM `jenis_perilaku` WHERE `nama` LIKE 'Terlambat kembali%');

-- Jenis perangkat pembelajaran bawaan (hanya bila tabel masih kosong)
INSERT INTO `jenis_perangkat` (`nama`, `periode`, `wajib`, `keterangan`, `urutan`, `is_active`, `created_at`)
SELECT * FROM (SELECT 'Analisis CP & Tujuan Pembelajaran' AS nama, 'Tahunan' AS periode, 1 AS wajib, 'Pemetaan capaian pembelajaran fase menjadi tujuan pembelajaran.' AS keterangan, 1 AS urutan, 1 AS is_active, NOW() AS created_at
UNION ALL SELECT 'Alur Tujuan Pembelajaran (ATP)', 'Tahunan', 1, 'Urutan tujuan pembelajaran selama satu fase/tahun.', 2, 1, NOW()
UNION ALL SELECT 'Program Tahunan (Prota)', 'Tahunan', 1, 'Sebaran tujuan/materi dan alokasi JP dalam satu tahun pelajaran.', 3, 1, NOW()
UNION ALL SELECT 'Program Semester (Promes)', 'Semester', 1, 'Sebaran tujuan/materi per minggu efektif dalam satu semester.', 4, 1, NOW()
UNION ALL SELECT 'Modul Ajar / RPP', 'Semester', 1, 'Rencana pembelajaran (pendekatan pembelajaran mendalam) beserta asesmen, LKPD, dan media.', 5, 1, NOW()
UNION ALL SELECT 'Kriteria Ketercapaian Tujuan Pembelajaran (KKTP)', 'Semester', 1, 'Kriteria/rubrik untuk menentukan ketercapaian tujuan pembelajaran.', 6, 1, NOW()
UNION ALL SELECT 'Instrumen Asesmen', 'Semester', 1, 'Asesmen awal/diagnostik, formatif, dan sumatif beserta kisi-kisi & rubrik.', 7, 1, NOW()
UNION ALL SELECT 'Bahan Ajar / LKPD', 'Semester', 0, 'Bahan ajar, lembar kerja, atau media pendukung.', 8, 1, NOW()
UNION ALL SELECT 'Analisis Hasil Asesmen & Tindak Lanjut', 'Semester', 0, 'Analisis hasil asesmen, program remedial dan pengayaan.', 9, 1, NOW()) AS j
WHERE NOT EXISTS (SELECT 1 FROM `jenis_perangkat`);
INSERT INTO `pengaturan` (`kunci`, `nilai`) SELECT 'perangkat_tenggat', '' FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `pengaturan` WHERE `kunci` = 'perangkat_tenggat');

INSERT INTO `pengaturan` (`kunci`, `nilai`) SELECT 'format_modul', 'otomatis' FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `pengaturan` WHERE `kunci` = 'format_modul');

INSERT INTO `pengaturan` (`kunci`, `nilai`, `label`) SELECT 'pembiasaan_mundur', '1', 'Siswa boleh mengisi pembiasaan sampai N hari ke belakang' FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `pengaturan` WHERE `kunci` = 'pembiasaan_mundur');

-- Catatan migration (agar `php spark migrate` tidak mengulang)
INSERT INTO `migrations` (`version`, `class`, `group`, `namespace`, `time`, `batch`) VALUES
('2026-11-22-000000', 'App\\Database\\Migrations\\PeriksaPemasangan', 'default', 'App', 1795451761, 1),
('2026-11-24-100001', 'App\\Database\\Migrations\\PenggunaSistem', 'default', 'App', 1795451761, 1),
('2026-11-24-100002', 'App\\Database\\Migrations\\DataMaster', 'default', 'App', 1795451761, 1),
('2026-11-24-100003', 'App\\Database\\Migrations\\RombelJadwal', 'default', 'App', 1795451761, 1),
('2026-11-24-100004', 'App\\Database\\Migrations\\Pembelajaran', 'default', 'App', 1795451761, 1),
('2026-11-24-100005', 'App\\Database\\Migrations\\Kesiswaan', 'default', 'App', 1795451761, 1),
('2026-11-24-100006', 'App\\Database\\Migrations\\Kepegawaian', 'default', 'App', 1795451761, 1),
('2026-11-24-100007', 'App\\Database\\Migrations\\BimbinganKonseling', 'default', 'App', 1795451761, 1),
('2026-11-24-100008', 'App\\Database\\Migrations\\PerangkatPembelajaran', 'default', 'App', 1795451761, 1),
('2026-11-24-100009', 'App\\Database\\Migrations\\DataAwal', 'default', 'App', 1795451761, 1),
('2026-11-24-100010', 'App\\Database\\Migrations\\PembiasaanMandiri', 'default', 'App', 1795451761, 1),
('2026-11-24-100011', 'App\\Database\\Migrations\\PembiasaanBerlaku', 'default', 'App', 1795451761, 1);

COMMIT;
SET FOREIGN_KEY_CHECKS = 1;
