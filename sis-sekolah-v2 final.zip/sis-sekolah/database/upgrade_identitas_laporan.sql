-- =====================================================================
--  UPGRADE: identitas sekolah (nama aplikasi, logo, NPSN/NSM, jenjang, kota)
--  untuk kop & tanda tangan laporan cetak.
--  Untuk database SIS Sekolah v2 yang terpasang sebelum fitur ini.
--  Setara dengan: php spark migrate   (pilih SALAH SATU, jangan keduanya)
--  Jalankan upgrade_kiosk.sql lebih dulu bila belum pernah.
-- =====================================================================
SET NAMES utf8mb4;

INSERT IGNORE INTO `pengaturan` (`kunci`, `nilai`, `label`, `updated_at`) VALUES
('nama_aplikasi', 'SIS Sekolah', 'Nama aplikasi', NOW()),
('jenjang', '', 'Jenjang', NOW()),
('jenis_nomor', 'NPSN', 'Jenis nomor induk sekolah (NPSN/NSM)', NOW()),
('npsn', '', 'NPSN / NSM', NOW()),
('kota', '', 'Kota/kabupaten (tempat tanda tangan)', NOW()),
('telepon_sekolah', '', 'Telepon sekolah', NOW()),
('email_sekolah', '', 'Email sekolah', NOW()),
('logo', '', 'Logo sekolah', NOW());

INSERT INTO `migrations` (`version`, `class`, `group`, `namespace`, `time`, `batch`)
SELECT '2026-11-23-000009', 'App\\Database\\Migrations\\AddIdentitasSekolah', 'default', 'App', UNIX_TIMESTAMP(),
       COALESCE((SELECT MAX(`batch`) FROM `migrations` m), 0) + 1
FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM `migrations` WHERE `version` = '2026-11-23-000009');

-- Setelah itu: menu Pengaturan Sekolah > isi identitas & unggah logo.
-- Pastikan folder public/uploads/logo ada dan bisa ditulisi.
