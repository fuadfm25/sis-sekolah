-- =====================================================================
--  UPGRADE: absensi kiosk RFID / barcode
--  Untuk database SIS Sekolah v2 yang SUDAH terpasang sebelum fitur kiosk.
--  Setara dengan: php spark migrate   (pilih SALAH SATU, jangan keduanya)
--  Jalankan di phpMyAdmin > pilih database > tab SQL / Import.
-- =====================================================================
SET NAMES utf8mb4;

ALTER TABLE `siswa`
	ADD `rfid` VARCHAR(50) NULL AFTER `nisn`;
CREATE UNIQUE INDEX `siswa_rfid` ON `siswa` (`rfid`);

ALTER TABLE `presensi_harian`
	ADD `jam_pulang` TIME NULL AFTER `jam_datang`,
	ADD `sumber` ENUM('Manual','Kiosk') DEFAULT 'Manual' AFTER `keterangan`;

INSERT IGNORE INTO `pengaturan` (`kunci`, `nilai`, `label`, `updated_at`) VALUES
('kiosk_aktif', '1', 'Absensi kiosk (RFID/barcode) aktif', NOW()),
('kiosk_token', '', 'Token alamat kiosk', NOW()),
('jam_pulang', '13:00', 'Jam mulai absen pulang (kiosk)', NOW());

INSERT INTO `migrations` (`version`, `class`, `group`, `namespace`, `time`, `batch`)
SELECT '2026-11-23-000008', 'App\\Database\\Migrations\\AddKioskPresensi', 'default', 'App', UNIX_TIMESTAMP(),
       COALESCE((SELECT MAX(`batch`) FROM `migrations` m), 0) + 1
FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM `migrations` WHERE `version` = '2026-11-23-000008');

-- Setelah itu: menu Pengaturan Sekolah > "Ganti token kiosk" untuk membuat alamat kiosk.
