-- =====================================================================
--  SIS Sekolah – UPGRADE ke versi 2 (migration 011–024)
--  Untuk database yang sudah memakai versi sebelumnya (migration s.d. 010).
--  CARA TERMUDAH: jalankan  php spark migrate  (otomatis).
--  Bila tidak ada akses terminal: BACKUP database dulu, lalu Import file ini
--  lewat phpMyAdmin.
--  Isi: log aktivitas, jam pelajaran per hari, versi jadwal + jurnal.guru_id,
--  kalender per kelas & masuk pengganti, kehadiran/izin guru, izin siswa,
--  ATP, jurnal_atp, kokurikuler, wajib ganti password, mutasi siswa, portal siswa.
-- =====================================================================
SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ---------------------------------------------------------------
-- 2026-11-24-000011_AddKeamananLog.php
CREATE TABLE `log_aktivitas` (
	`id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
	`user_id` INT UNSIGNED NULL,
	`nama_user` VARCHAR(100) NULL,
	`aksi` VARCHAR(30) NOT NULL,
	`objek` VARCHAR(60) NULL,
	`objek_id` INT UNSIGNED NULL,
	`keterangan` TEXT NULL,
	`ip` VARCHAR(45) NULL,
	`created_at` DATETIME NULL,
	CONSTRAINT `pk_log_aktivitas` PRIMARY KEY(`id`),
	KEY `created_at` (`created_at`),
	KEY `objek_objek_id` (`objek`, `objek_id`)
) DEFAULT CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci;

-- ---------------------------------------------------------------
-- 2026-11-24-000012_JamPerHariVersiJadwal.php
ALTER TABLE `jam_pelajaran`
	ADD `hari` TINYINT UNSIGNED NULL AFTER `id`;

ALTER TABLE `jadwal_pelajaran`
	ADD `berlaku_mulai` DATE NULL AFTER `jam_pelajaran_id`,
	ADD `berlaku_sampai` DATE NULL AFTER `berlaku_mulai`;

CREATE INDEX jadwal_tp_kelas_hari ON jadwal_pelajaran (tahun_pelajaran_id, kelas_id, hari);

ALTER TABLE jadwal_pelajaran DROP INDEX tahun_pelajaran_id_kelas_id_hari_jam_pelajaran_id;

ALTER TABLE `jurnal_pembelajaran`
	ADD `guru_id` INT UNSIGNED NULL AFTER `penugasan_guru_id`;

UPDATE jurnal_pembelajaran SET guru_id = (SELECT guru_id FROM penugasan_guru p WHERE p.id = penugasan_guru_id) WHERE guru_id IS NULL;

CREATE INDEX jurnal_guru_tanggal ON jurnal_pembelajaran (guru_id, tanggal);

-- ---------------------------------------------------------------
-- 2026-11-24-000013_KalenderPerKelas.php
ALTER TABLE `kalender_akademik`
	CHANGE `jenis` `jenis` VARCHAR(30) NOT NULL;

ALTER TABLE `kalender_akademik`
	ADD `kelas_ids` VARCHAR(500) NULL AFTER `nama`,
	ADD `hari_jadwal` TINYINT UNSIGNED NULL AFTER `kelas_ids`;

-- ---------------------------------------------------------------
-- 2026-11-24-000014_KehadiranGuruIzin.php
ALTER TABLE `guru`
	ADD `rfid` VARCHAR(50) NULL AFTER `nuptk`;

CREATE UNIQUE INDEX guru_rfid ON guru (rfid);

CREATE TABLE `izin_guru` (
	`id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
	`guru_id` INT UNSIGNED NOT NULL,
	`tanggal_mulai` DATE NOT NULL,
	`tanggal_selesai` DATE NOT NULL,
	`jenis` VARCHAR(2) NOT NULL,
	`keterangan` TEXT NULL,
	`tugas_siswa` TEXT NULL,
	`lampiran` VARCHAR(100) NULL,
	`status` VARCHAR(12) NOT NULL DEFAULT 'Diajukan',
	`diputus_oleh` INT UNSIGNED NULL,
	`catatan_putusan` VARCHAR(255) NULL,
	`created_at` DATETIME NULL,
	`updated_at` DATETIME NULL,
	CONSTRAINT `pk_izin_guru` PRIMARY KEY(`id`),
	CONSTRAINT `izin_guru_guru_id_foreign` FOREIGN KEY (`guru_id`) REFERENCES `guru`(`id`) ON DELETE CASCADE ON UPDATE CASCADE,
	KEY `guru_id_tanggal_mulai` (`guru_id`, `tanggal_mulai`)
) DEFAULT CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci;

CREATE TABLE `presensi_guru` (
	`id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
	`tahun_pelajaran_id` INT UNSIGNED NOT NULL,
	`guru_id` INT UNSIGNED NOT NULL,
	`tanggal` DATE NOT NULL,
	`status` VARCHAR(2) NOT NULL DEFAULT 'H',
	`jam_datang` TIME NULL,
	`jam_pulang` TIME NULL,
	`keterangan` VARCHAR(150) NULL,
	`izin_guru_id` INT UNSIGNED NULL,
	`sumber` VARCHAR(10) NOT NULL DEFAULT 'Manual',
	`dicatat_oleh` INT UNSIGNED NULL,
	`created_at` DATETIME NULL,
	`updated_at` DATETIME NULL,
	CONSTRAINT `pk_presensi_guru` PRIMARY KEY(`id`),
	CONSTRAINT `presensi_guru_tahun_pelajaran_id_foreign` FOREIGN KEY (`tahun_pelajaran_id`) REFERENCES `tahun_pelajaran`(`id`) ON DELETE CASCADE ON UPDATE CASCADE,
	CONSTRAINT `presensi_guru_guru_id_foreign` FOREIGN KEY (`guru_id`) REFERENCES `guru`(`id`) ON DELETE CASCADE ON UPDATE CASCADE,
	CONSTRAINT `presensi_guru_izin_guru_id_foreign` FOREIGN KEY (`izin_guru_id`) REFERENCES `izin_guru`(`id`) ON DELETE SET NULL ON UPDATE CASCADE,
	UNIQUE KEY `tanggal_guru_id` (`tanggal`, `guru_id`)
) DEFAULT CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci;

CREATE TABLE `izin_siswa` (
	`id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
	`siswa_id` INT UNSIGNED NOT NULL,
	`tanggal_mulai` DATE NOT NULL,
	`tanggal_selesai` DATE NOT NULL,
	`jenis` VARCHAR(1) NOT NULL,
	`keterangan` VARCHAR(255) NULL,
	`lampiran` VARCHAR(100) NULL,
	`dicatat_oleh` INT UNSIGNED NULL,
	`created_at` DATETIME NULL,
	`updated_at` DATETIME NULL,
	CONSTRAINT `pk_izin_siswa` PRIMARY KEY(`id`),
	CONSTRAINT `izin_siswa_siswa_id_foreign` FOREIGN KEY (`siswa_id`) REFERENCES `siswa`(`id`) ON DELETE CASCADE ON UPDATE CASCADE,
	KEY `siswa_id_tanggal_mulai` (`siswa_id`, `tanggal_mulai`)
) DEFAULT CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci;

ALTER TABLE `presensi_harian`
	ADD `izin_siswa_id` INT UNSIGNED NULL AFTER `keterangan`;

ALTER TABLE `presensi_harian`
	CHANGE `sumber` `sumber` VARCHAR(10) NOT NULL DEFAULT 'Manual';

-- ---------------------------------------------------------------
-- 2026-11-24-000015_KurikulumMerdeka.php
CREATE TABLE `atp` (
	`id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
	`mapel_id` INT UNSIGNED NOT NULL,
	`tingkat` VARCHAR(5) NOT NULL,
	`fase` VARCHAR(5) NULL,
	`semester` VARCHAR(6) NULL,
	`elemen` VARCHAR(150) NULL,
	`kode` VARCHAR(20) NULL,
	`tujuan` TEXT NOT NULL,
	`alokasi_jp` SMALLINT UNSIGNED NULL,
	`urutan` SMALLINT NOT NULL DEFAULT 0,
	`modul_ajar` VARCHAR(120) NULL,
	`dibuat_oleh` INT UNSIGNED NULL,
	`created_at` DATETIME NULL,
	`updated_at` DATETIME NULL,
	CONSTRAINT `pk_atp` PRIMARY KEY(`id`),
	CONSTRAINT `atp_mapel_id_foreign` FOREIGN KEY (`mapel_id`) REFERENCES `mata_pelajaran`(`id`) ON DELETE CASCADE ON UPDATE CASCADE,
	KEY `mapel_id_tingkat` (`mapel_id`, `tingkat`)
) DEFAULT CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci;

CREATE TABLE `jurnal_atp` (
	`id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
	`jurnal_id` INT UNSIGNED NOT NULL,
	`atp_id` INT UNSIGNED NOT NULL,
	CONSTRAINT `pk_jurnal_atp` PRIMARY KEY(`id`),
	CONSTRAINT `jurnal_atp_jurnal_id_foreign` FOREIGN KEY (`jurnal_id`) REFERENCES `jurnal_pembelajaran`(`id`) ON DELETE CASCADE ON UPDATE CASCADE,
	CONSTRAINT `jurnal_atp_atp_id_foreign` FOREIGN KEY (`atp_id`) REFERENCES `atp`(`id`) ON DELETE CASCADE ON UPDATE CASCADE,
	UNIQUE KEY `jurnal_id_atp_id` (`jurnal_id`, `atp_id`)
) DEFAULT CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci;

CREATE TABLE `kokurikuler` (
	`id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
	`tahun_pelajaran_id` INT UNSIGNED NOT NULL,
	`judul` VARCHAR(200) NOT NULL,
	`tema` VARCHAR(150) NULL,
	`bentuk` VARCHAR(40) NULL,
	`dimensi` VARCHAR(255) NULL,
	`kelas_ids` VARCHAR(500) NULL,
	`tanggal_mulai` DATE NOT NULL,
	`tanggal_selesai` DATE NOT NULL,
	`alokasi_jp` SMALLINT UNSIGNED NULL,
	`deskripsi` TEXT NULL,
	`koordinator_id` INT UNSIGNED NULL,
	`kalender_id` INT UNSIGNED NULL,
	`refleksi` TEXT NULL,
	`created_at` DATETIME NULL,
	`updated_at` DATETIME NULL,
	CONSTRAINT `pk_kokurikuler` PRIMARY KEY(`id`),
	CONSTRAINT `kokurikuler_tahun_pelajaran_id_foreign` FOREIGN KEY (`tahun_pelajaran_id`) REFERENCES `tahun_pelajaran`(`id`) ON DELETE CASCADE ON UPDATE CASCADE
) DEFAULT CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci;


-- ---------------------------------------------------------------
-- 2026-11-24-000016_WajibGantiPassword.php
ALTER TABLE `users`
	ADD `wajib_ganti_password` TINYINT(1) NOT NULL DEFAULT 0 AFTER `is_active`;


-- ---------------------------------------------------------------
-- 2026-11-24-000017_MutasiSiswa.php
CREATE TABLE `mutasi_siswa` (
	`id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
	`tahun_pelajaran_id` INT UNSIGNED NOT NULL,
	`siswa_id` INT UNSIGNED NOT NULL,
	`jenis` VARCHAR(20) NOT NULL,
	`tanggal` DATE NOT NULL,
	`kelas_asal_id` INT UNSIGNED NULL,
	`kelas_tujuan_id` INT UNSIGNED NULL,
	`sekolah` VARCHAR(150) NULL,
	`alasan` VARCHAR(255) NULL,
	`no_surat` VARCHAR(60) NULL,
	`status_sebelum` VARCHAR(20) NULL,
	`dicatat_oleh` INT UNSIGNED NULL,
	`created_at` DATETIME NULL,
	`updated_at` DATETIME NULL,
	CONSTRAINT `pk_mutasi_siswa` PRIMARY KEY(`id`),
	KEY `tahun_pelajaran_id_tanggal` (`tahun_pelajaran_id`, `tanggal`),
	CONSTRAINT `mutasi_siswa_siswa_id_foreign` FOREIGN KEY (`siswa_id`) REFERENCES `siswa`(`id`) ON DELETE CASCADE ON UPDATE CASCADE
) DEFAULT CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci;


-- ---------------------------------------------------------------
-- 2026-11-24-000018_PasswordDiubah.php
ALTER TABLE `users`
	ADD `password_sendiri_at` DATETIME NULL AFTER `wajib_ganti_password`;


-- ---------------------------------------------------------------
-- 2026-11-24-000019_PortalSiswa.php
ALTER TABLE `siswa`
	ADD `password` VARCHAR(255) NULL AFTER `rfid`,
	ADD `login_terakhir` DATETIME NULL AFTER `password`;

INSERT INTO `pengaturan` (`kunci`, `nilai`) SELECT 'portal_siswa', '1' FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `pengaturan` WHERE `kunci` = 'portal_siswa');


-- ---------------------------------------------------------------
-- 2026-11-24-000020_JenisLayananBk.php  (jenis layanan BK lengkap, Permendikbud 111/2014)
ALTER TABLE `bk_layanan`
	MODIFY `jenis_layanan` VARCHAR(50) NOT NULL,
	ADD `komponen` VARCHAR(40) NULL AFTER `jenis_layanan`,
	ADD `format` VARCHAR(20) NULL AFTER `komponen`,
	ADD `media` VARCHAR(20) NULL AFTER `format`,
	ADD `pihak_terkait` VARCHAR(150) NULL AFTER `kelas_id`;
UPDATE `bk_layanan` SET `komponen` = 'Layanan Dasar', `format` = IF(`jenis_layanan` = 'Bimbingan Klasikal', 'Klasikal', 'Kelompok'), `media` = 'Tatap muka'
	WHERE `komponen` IS NULL AND `jenis_layanan` IN ('Bimbingan Klasikal', 'Bimbingan Kelompok');
UPDATE `bk_layanan` SET `komponen` = 'Responsif', `format` = IF(`jenis_layanan` IN ('Konseling Kelompok', 'Mediasi'), 'Kelompok', 'Individual'), `media` = 'Tatap muka'
	WHERE `komponen` IS NULL;

-- ---------------------------------------------------------------
-- 2026-11-24-000021_SinkronAbsensi.php  (izin pulang awal + sinkron absensi mapel)
ALTER TABLE `izin_siswa`
	ADD `jam_keluar` TIME NULL AFTER `jenis`,
	ADD `penjemput` VARCHAR(100) NULL AFTER `jam_keluar`;
ALTER TABLE `presensi_mapel`
	ADD `sumber` VARCHAR(10) NOT NULL DEFAULT 'Guru' AFTER `keterangan`;

-- ---------------------------------------------------------------
-- 2026-11-24-000022_IzinKeluarSatpam.php  (izin keluar sementara + pos gerbang satpam)
ALTER TABLE `izin_siswa`
	ADD `batas_kembali` TIME NULL AFTER `penjemput`,
	ADD `keluar_at` DATETIME NULL AFTER `batas_kembali`,
	ADD `keluar_oleh` INT UNSIGNED NULL AFTER `keluar_at`,
	ADD `kembali_at` DATETIME NULL AFTER `keluar_oleh`,
	ADD `kembali_oleh` INT UNSIGNED NULL AFTER `kembali_at`,
	ADD `status_keluar` VARCHAR(20) NULL AFTER `kembali_oleh`,
	ADD `catatan_perilaku_id` INT UNSIGNED NULL AFTER `status_keluar`;

-- ---------------------------------------------------------------
-- 2026-11-24-000023_PerangkatPembelajaran.php  (perangkat pembelajaran guru → kurikulum → kepala sekolah)
CREATE TABLE IF NOT EXISTS `jenis_perangkat` (
	`id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
	`nama` VARCHAR(120) NOT NULL,
	`periode` VARCHAR(10) NOT NULL DEFAULT 'Semester',
	`wajib` TINYINT(1) NOT NULL DEFAULT 1,
	`keterangan` VARCHAR(255) NULL,
	`urutan` SMALLINT NOT NULL DEFAULT 0,
	`is_active` TINYINT(1) NOT NULL DEFAULT 1,
	`created_at` DATETIME NULL,
	`updated_at` DATETIME NULL,
	CONSTRAINT `pk_jenis_perangkat` PRIMARY KEY(`id`)
) DEFAULT CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `perangkat_pembelajaran` (
	`id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
	`tahun_pelajaran_id` INT UNSIGNED NOT NULL,
	`guru_id` INT UNSIGNED NOT NULL,
	`mapel_id` INT UNSIGNED NOT NULL,
	`tingkat` VARCHAR(5) NOT NULL,
	`jenis_perangkat_id` INT UNSIGNED NOT NULL,
	`file` VARCHAR(120) NULL,
	`nama_file` VARCHAR(150) NULL,
	`tautan` VARCHAR(255) NULL,
	`catatan_guru` TEXT NULL,
	`status` VARCHAR(15) NOT NULL DEFAULT 'Diajukan',
	`versi` SMALLINT UNSIGNED NOT NULL DEFAULT 1,
	`diajukan_at` DATETIME NULL,
	`catatan_pemeriksa` TEXT NULL,
	`diperiksa_oleh` INT UNSIGNED NULL,
	`diperiksa_at` DATETIME NULL,
	`disahkan_oleh` INT UNSIGNED NULL,
	`disahkan_at` DATETIME NULL,
	`created_at` DATETIME NULL,
	`updated_at` DATETIME NULL,
	CONSTRAINT `pk_perangkat_pembelajaran` PRIMARY KEY(`id`),
	CONSTRAINT `uniq_perangkat` UNIQUE (`tahun_pelajaran_id`, `guru_id`, `mapel_id`, `tingkat`, `jenis_perangkat_id`),
	KEY `status` (`status`),
	CONSTRAINT `perangkat_pembelajaran_tahun_pelajaran_id_foreign` FOREIGN KEY (`tahun_pelajaran_id`) REFERENCES `tahun_pelajaran`(`id`) ON DELETE CASCADE ON UPDATE CASCADE,
	CONSTRAINT `perangkat_pembelajaran_guru_id_foreign` FOREIGN KEY (`guru_id`) REFERENCES `guru`(`id`) ON DELETE CASCADE ON UPDATE CASCADE,
	CONSTRAINT `perangkat_pembelajaran_mapel_id_foreign` FOREIGN KEY (`mapel_id`) REFERENCES `mata_pelajaran`(`id`) ON DELETE CASCADE ON UPDATE CASCADE,
	CONSTRAINT `perangkat_pembelajaran_jenis_perangkat_id_foreign` FOREIGN KEY (`jenis_perangkat_id`) REFERENCES `jenis_perangkat`(`id`) ON DELETE CASCADE ON UPDATE CASCADE
) DEFAULT CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `perangkat_riwayat` (
	`id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
	`perangkat_id` INT UNSIGNED NOT NULL,
	`aksi` VARCHAR(20) NOT NULL,
	`versi` SMALLINT UNSIGNED NOT NULL DEFAULT 1,
	`catatan` TEXT NULL,
	`file` VARCHAR(120) NULL,
	`user_id` INT UNSIGNED NULL,
	`created_at` DATETIME NULL,
	CONSTRAINT `pk_perangkat_riwayat` PRIMARY KEY(`id`),
	KEY `perangkat_id` (`perangkat_id`),
	CONSTRAINT `perangkat_riwayat_perangkat_id_foreign` FOREIGN KEY (`perangkat_id`) REFERENCES `perangkat_pembelajaran`(`id`) ON DELETE CASCADE ON UPDATE CASCADE
) DEFAULT CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci;

-- ---------------------------------------------------------------
-- 2026-11-24-000024_ProgramModulAjar.php  (program semester/tahunan dari kalender + penyusun modul ajar)
CREATE TABLE IF NOT EXISTS `promes_item` (
	`id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
	`tahun_pelajaran_id` INT UNSIGNED NOT NULL,
	`guru_id` INT UNSIGNED NOT NULL,
	`mapel_id` INT UNSIGNED NOT NULL,
	`tingkat` VARCHAR(5) NOT NULL,
	`atp_id` INT UNSIGNED NULL,
	`jenis` VARCHAR(10) NOT NULL DEFAULT 'Materi',
	`materi` VARCHAR(255) NOT NULL,
	`tujuan` TEXT NULL,
	`jp` SMALLINT UNSIGNED NOT NULL DEFAULT 0,
	`urutan` SMALLINT NOT NULL DEFAULT 0,
	`created_at` DATETIME NULL,
	`updated_at` DATETIME NULL,
	CONSTRAINT `pk_promes_item` PRIMARY KEY(`id`),
	KEY `tahun_pelajaran_id_guru_id_mapel_id_tingkat` (`tahun_pelajaran_id`, `guru_id`, `mapel_id`, `tingkat`),
	CONSTRAINT `promes_item_tahun_pelajaran_id_foreign` FOREIGN KEY (`tahun_pelajaran_id`) REFERENCES `tahun_pelajaran`(`id`) ON DELETE CASCADE ON UPDATE CASCADE,
	CONSTRAINT `promes_item_guru_id_foreign` FOREIGN KEY (`guru_id`) REFERENCES `guru`(`id`) ON DELETE CASCADE ON UPDATE CASCADE,
	CONSTRAINT `promes_item_mapel_id_foreign` FOREIGN KEY (`mapel_id`) REFERENCES `mata_pelajaran`(`id`) ON DELETE CASCADE ON UPDATE CASCADE
) DEFAULT CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `promes_alokasi` (
	`id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
	`item_id` INT UNSIGNED NOT NULL,
	`pekan` DATE NOT NULL,
	`jp` SMALLINT UNSIGNED NOT NULL DEFAULT 0,
	CONSTRAINT `pk_promes_alokasi` PRIMARY KEY(`id`),
	CONSTRAINT `item_id_pekan` UNIQUE (`item_id`, `pekan`),
	CONSTRAINT `promes_alokasi_item_id_foreign` FOREIGN KEY (`item_id`) REFERENCES `promes_item`(`id`) ON DELETE CASCADE ON UPDATE CASCADE
) DEFAULT CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `modul_ajar` (
	`id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
	`tahun_pelajaran_id` INT UNSIGNED NOT NULL,
	`guru_id` INT UNSIGNED NOT NULL,
	`mapel_id` INT UNSIGNED NOT NULL,
	`tingkat` VARCHAR(5) NOT NULL,
	`promes_item_id` INT UNSIGNED NULL,
	`judul` VARCHAR(200) NOT NULL,
	`format` VARCHAR(10) NOT NULL DEFAULT 'PM',
	`jp` SMALLINT UNSIGNED NOT NULL DEFAULT 0,
	`pertemuan` TINYINT UNSIGNED NOT NULL DEFAULT 1,
	`isi` MEDIUMTEXT NULL,
	`urutan` SMALLINT NOT NULL DEFAULT 0,
	`created_at` DATETIME NULL,
	`updated_at` DATETIME NULL,
	CONSTRAINT `pk_modul_ajar` PRIMARY KEY(`id`),
	KEY `tahun_pelajaran_id_guru_id_mapel_id_tingkat` (`tahun_pelajaran_id`, `guru_id`, `mapel_id`, `tingkat`),
	CONSTRAINT `modul_ajar_tahun_pelajaran_id_foreign` FOREIGN KEY (`tahun_pelajaran_id`) REFERENCES `tahun_pelajaran`(`id`) ON DELETE CASCADE ON UPDATE CASCADE,
	CONSTRAINT `modul_ajar_guru_id_foreign` FOREIGN KEY (`guru_id`) REFERENCES `guru`(`id`) ON DELETE CASCADE ON UPDATE CASCADE,
	CONSTRAINT `modul_ajar_mapel_id_foreign` FOREIGN KEY (`mapel_id`) REFERENCES `mata_pelajaran`(`id`) ON DELETE CASCADE ON UPDATE CASCADE
) DEFAULT CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci;

ALTER TABLE `perangkat_pembelajaran`
	ADD `sumber` VARCHAR(10) NULL AFTER `tautan`;

-- ---------------------------------------------------------------
-- 2026-11-24-100010_PembiasaanMandiri.php  (pembiasaan diisi siswa lewat portal + verifikasi wali kelas)
ALTER TABLE `pembiasaan`
	ADD `pengisi` VARCHAR(10) NOT NULL DEFAULT 'Guru' AFTER `hari`,
	ADD `tempat` VARCHAR(10) NOT NULL DEFAULT 'Sekolah' AFTER `pengisi`,
	ADD `perlu_verifikasi` TINYINT(1) NOT NULL DEFAULT 1 AFTER `tempat`,
	ADD `wajib_catatan` TINYINT(1) NOT NULL DEFAULT 0 AFTER `perlu_verifikasi`,
	ADD `petunjuk_catatan` VARCHAR(100) NULL AFTER `wajib_catatan`,
	ADD `tingkat` VARCHAR(60) NULL AFTER `petunjuk_catatan`;
ALTER TABLE `pembiasaan_siswa`
	ADD `sumber` VARCHAR(10) NOT NULL DEFAULT 'Guru' AFTER `keterangan`,
	ADD `lapor_siswa` TINYINT(1) NULL AFTER `sumber`,
	ADD `lapor_at` DATETIME NULL AFTER `lapor_siswa`,
	ADD `verifikasi` VARCHAR(10) NOT NULL DEFAULT 'Disetujui' AFTER `lapor_at`,
	ADD `diverifikasi_oleh` INT UNSIGNED NULL AFTER `verifikasi`,
	ADD `diverifikasi_at` DATETIME NULL AFTER `diverifikasi_oleh`;

-- ---------------------------------------------------------------
-- 2026-11-24-100011_PembiasaanBerlaku.php  (kegiatan rumah: setiap hari / hari masuk sekolah / hari libur)
ALTER TABLE `pembiasaan`
	ADD `berlaku` VARCHAR(10) NOT NULL DEFAULT 'Semua' AFTER `tempat`;

-- Izin keluar & pos gerbang (satpam)
INSERT INTO `roles` (`nama_role`, `keterangan`) SELECT 'satpam', 'Satpam / Petugas Keamanan' FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `roles` WHERE `nama_role` = 'satpam');
INSERT INTO `pengaturan` (`kunci`, `nilai`) SELECT 'toleransi_kembali', '30' FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `pengaturan` WHERE `kunci` = 'toleransi_kembali');
INSERT INTO `pengaturan` (`kunci`, `nilai`) SELECT 'verifikasi_satpam', '1' FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `pengaturan` WHERE `kunci` = 'verifikasi_satpam');
INSERT INTO `pengaturan` (`kunci`, `nilai`) SELECT 'izin_keluar_perilaku', '1' FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `pengaturan` WHERE `kunci` = 'izin_keluar_perilaku');
INSERT INTO `jenis_perilaku` (`kategori`, `nama`, `tingkat`, `poin`, `is_active`, `created_at`) SELECT 'Negatif', 'Terlambat kembali dari izin keluar', 'Ringan', 5, 1, NOW() FROM DUAL
	WHERE NOT EXISTS (SELECT 1 FROM `jenis_perilaku` WHERE `nama` LIKE 'Terlambat kembali%');

-- Jenis perangkat pembelajaran bawaan (hanya bila tabel masih kosong)
INSERT INTO `jenis_perangkat` (`nama`, `periode`, `wajib`, `keterangan`, `urutan`, `is_active`, `created_at`)
SELECT * FROM (SELECT 'Analisis CP & Tujuan Pembelajaran' AS nama, 'Tahunan' AS periode, 1 AS wajib, 'Pemetaan capaian pembelajaran fase menjadi tujuan pembelajaran.' AS keterangan, 1 AS urutan, 1 AS is_active, NOW() AS created_at
UNION ALL SELECT 'Alur Tujuan Pembelajaran (ATP)', 'Tahunan', 1, 'Urutan tujuan pembelajaran selama satu fase/tahun.', 2, 1, NOW()
UNION ALL SELECT 'Program Tahunan (Prota)', 'Tahunan', 1, 'Sebaran tujuan/materi dan alokasi JP dalam satu tahun pelajaran.', 3, 1, NOW()
UNION ALL SELECT 'Program Semester (Promes)', 'Semester', 1, 'Sebaran tujuan/materi per minggu efektif dalam satu semester.', 4, 1, NOW()
UNION ALL SELECT 'Modul Ajar / RPP', 'Semester', 1, 'Rencana pembelajaran (pendekatan pembelajaran mendalam) beserta asesmen, LKPD, dan media.', 5, 1, NOW()
UNION ALL SELECT 'Kriteria Ketercapaian Tujuan Pembelajaran (KKTP)', 'Semester', 1, 'Kriteria/rubrik untuk menentukan ketercapaian tujuan pembelajaran.', 6, 1, NOW()
UNION ALL SELECT 'Instrumen Asesmen', 'Semester', 1, 'Asesmen awal/diagnostik, formatif, dan sumatif beserta kisi-kisi & rubrik.', 7, 1, NOW()
UNION ALL SELECT 'Bahan Ajar / LKPD', 'Semester', 0, 'Bahan ajar, lembar kerja, atau media pendukung.', 8, 1, NOW()
UNION ALL SELECT 'Analisis Hasil Asesmen & Tindak Lanjut', 'Semester', 0, 'Analisis hasil asesmen, program remedial dan pengayaan.', 9, 1, NOW()) AS j
WHERE NOT EXISTS (SELECT 1 FROM `jenis_perangkat`);
INSERT INTO `pengaturan` (`kunci`, `nilai`) SELECT 'perangkat_tenggat', '' FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `pengaturan` WHERE `kunci` = 'perangkat_tenggat');

INSERT INTO `pengaturan` (`kunci`, `nilai`) SELECT 'format_modul', 'otomatis' FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `pengaturan` WHERE `kunci` = 'format_modul');

INSERT INTO `pengaturan` (`kunci`, `nilai`, `label`) SELECT 'pembiasaan_mundur', '1', 'Siswa boleh mengisi pembiasaan sampai N hari ke belakang' FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `pengaturan` WHERE `kunci` = 'pembiasaan_mundur');

-- Catatan migration
INSERT INTO `migrations` (`version`, `class`, `group`, `namespace`, `time`, `batch`) VALUES
('2026-11-24-000011', 'App\\Database\\Migrations\\AddKeamananLog', 'default', 'App', 1795451761, 2),
('2026-11-24-000012', 'App\\Database\\Migrations\\JamPerHariVersiJadwal', 'default', 'App', 1795451761, 2),
('2026-11-24-000013', 'App\\Database\\Migrations\\KalenderPerKelas', 'default', 'App', 1795451761, 2),
('2026-11-24-000014', 'App\\Database\\Migrations\\KehadiranGuruIzin', 'default', 'App', 1795451761, 2),
('2026-11-24-000015', 'App\\Database\\Migrations\\KurikulumMerdeka', 'default', 'App', 1795451761, 2),
('2026-11-24-000016', 'App\\Database\\Migrations\\WajibGantiPassword', 'default', 'App', 1795451761, 2),
('2026-11-24-000017', 'App\\Database\\Migrations\\MutasiSiswa', 'default', 'App', 1795451761, 2),
('2026-11-24-000018', 'App\\Database\\Migrations\\PasswordDiubah', 'default', 'App', 1795451761, 2),
('2026-11-24-000019', 'App\\Database\\Migrations\\PortalSiswa', 'default', 'App', 1795451761, 2),
('2026-11-24-000020', 'App\\Database\\Migrations\\JenisLayananBk', 'default', 'App', 1795451761, 2),
('2026-11-24-000021', 'App\\Database\\Migrations\\SinkronAbsensi', 'default', 'App', 1795451761, 2),
('2026-11-24-000022', 'App\\Database\\Migrations\\IzinKeluarSatpam', 'default', 'App', 1795451761, 2),
('2026-11-24-000023', 'App\\Database\\Migrations\\PerangkatPembelajaran', 'default', 'App', 1795451761, 2),
('2026-11-24-000024', 'App\\Database\\Migrations\\ProgramModulAjar', 'default', 'App', 1795451761, 2),
('2026-11-22-000000', 'App\\Database\\Migrations\\PeriksaPemasangan', 'default', 'App', 1795451761, 2),
('2026-11-24-100001', 'App\\Database\\Migrations\\PenggunaSistem', 'default', 'App', 1795451761, 2),
('2026-11-24-100002', 'App\\Database\\Migrations\\DataMaster', 'default', 'App', 1795451761, 2),
('2026-11-24-100003', 'App\\Database\\Migrations\\RombelJadwal', 'default', 'App', 1795451761, 2),
('2026-11-24-100004', 'App\\Database\\Migrations\\Pembelajaran', 'default', 'App', 1795451761, 2),
('2026-11-24-100005', 'App\\Database\\Migrations\\Kesiswaan', 'default', 'App', 1795451761, 2),
('2026-11-24-100006', 'App\\Database\\Migrations\\Kepegawaian', 'default', 'App', 1795451761, 2),
('2026-11-24-100007', 'App\\Database\\Migrations\\BimbinganKonseling', 'default', 'App', 1795451761, 2),
('2026-11-24-100008', 'App\\Database\\Migrations\\PerangkatPembelajaran', 'default', 'App', 1795451761, 2),
('2026-11-24-100009', 'App\\Database\\Migrations\\DataAwal', 'default', 'App', 1795451761, 2),
('2026-11-24-100010', 'App\\Database\\Migrations\\PembiasaanMandiri', 'default', 'App', 1795451761, 2),
('2026-11-24-100011', 'App\\Database\\Migrations\\PembiasaanBerlaku', 'default', 'App', 1795451761, 2);

SET FOREIGN_KEY_CHECKS = 1;
