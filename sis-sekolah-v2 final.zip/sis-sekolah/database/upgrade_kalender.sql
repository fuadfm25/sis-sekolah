-- =====================================================================
--  UPGRADE: kalender akademik (libur, ujian, kegiatan, pekan efektif)
--  Untuk database SIS Sekolah v2 yang terpasang sebelum fitur ini.
--  Setara dengan: php spark migrate   (pilih SALAH SATU, jangan keduanya)
--  Jalankan upgrade_kiosk.sql & upgrade_identitas_laporan.sql lebih dulu bila belum.
-- =====================================================================
SET NAMES utf8mb4;

CREATE TABLE IF NOT EXISTS `kalender_akademik` (
	`id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
	`tahun_pelajaran_id` INT UNSIGNED NOT NULL,
	`tanggal_mulai` DATE NOT NULL,
	`tanggal_selesai` DATE NOT NULL,
	`jenis` ENUM('Libur Nasional','Cuti Bersama','Libur Semester','Libur Fakultatif','Ujian','Kegiatan Sekolah') NOT NULL,
	`nama` VARCHAR(150) NOT NULL,
	`keterangan` TEXT NULL,
	`ada_kbm` TINYINT(1) NOT NULL DEFAULT 0,
	`ada_absensi` TINYINT(1) NOT NULL DEFAULT 0,
	`created_at` DATETIME NULL,
	`updated_at` DATETIME NULL,
	CONSTRAINT `pk_kalender_akademik` PRIMARY KEY(`id`),
	CONSTRAINT `kalender_akademik_tahun_pelajaran_id_foreign` FOREIGN KEY (`tahun_pelajaran_id`) REFERENCES `tahun_pelajaran`(`id`) ON DELETE CASCADE ON UPDATE CASCADE,
	KEY `tanggal_mulai_tanggal_selesai` (`tanggal_mulai`, `tanggal_selesai`)
) DEFAULT CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci;

INSERT INTO `migrations` (`version`, `class`, `group`, `namespace`, `time`, `batch`)
SELECT '2026-11-23-000010', 'App\\Database\\Migrations\\CreateKalenderAkademik', 'default', 'App', UNIX_TIMESTAMP(),
       COALESCE((SELECT MAX(`batch`) FROM `migrations` m), 0) + 1
FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM `migrations` WHERE `version` = '2026-11-23-000010');

-- Setelah itu (login sebagai kurikulum/admin):
--   1. Pengaturan Akademik > Tahun Pelajaran: lengkapi tanggal mulai & selesai semester.
--   2. Pengaturan Akademik > Setting Kalender & Libur: masukkan libur, ujian, kegiatan.
