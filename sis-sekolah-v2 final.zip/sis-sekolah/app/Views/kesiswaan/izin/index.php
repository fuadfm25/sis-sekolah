<?= $this->extend('layouts/main') ?>
<?= $this->section('actions') ?>
<?php if ($siswa) : ?><button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#modalIzin"><i class="bi bi-plus-lg"></i> Catat Izin</button><?php endif ?>
<?= $this->endSection() ?>
<?= $this->section('content') ?>
<div class="card"><div class="card-body py-3">
    <form class="d-flex flex-wrap gap-2 align-items-center filter" method="get">
        <select name="kelas_id" class="form-select w-auto"><option value="">Semua kelas</option>
            <?php foreach ($kelas as $k) : ?><option value="<?= $k['id'] ?>" <?= $kelasId == $k['id'] ? 'selected' : '' ?>><?= esc($k['nama_kelas']) ?></option><?php endforeach ?></select>
        <input type="date" name="dari" value="<?= esc($dari) ?>" class="form-control w-auto"> s.d.
        <input type="date" name="sampai" value="<?= esc($sampai) ?>" class="form-control w-auto">
        <button class="btn btn-light">Tampilkan</button>
    </form>
</div></div>
<div class="card"><div class="card-body table-responsive">
    <table class="table table-hover align-middle">
        <thead><tr><th>Tanggal</th><th>Siswa</th><th>Kelas</th><th>Jenis</th><th>Keterangan</th><th>Surat</th><th>Dicatat</th><th></th></tr></thead>
        <tbody>
        <?php foreach ($rows as $r) : ?>
            <tr>
                <td class="text-nowrap"><?= tgl_indo($r['tanggal_mulai']) ?><?= $r['tanggal_selesai'] !== $r['tanggal_mulai'] ? ' – ' . tgl_indo($r['tanggal_selesai']) : '' ?></td>
                <td><?= esc($r['nama_lengkap']) ?></td><td><?= esc($r['nama_kelas']) ?></td>
                <td><span class="badge bg-<?= ['S' => 'info', 'I' => 'primary', 'D' => 'success'][$r['jenis']] ?>"><?= \App\Models\IzinSiswaModel::JENIS[$r['jenis']] ?></span>
                    <?php if (! empty($r['jam_keluar'])) : $sk = \App\Libraries\IzinKeluar::status($r); ?><br>
                        <span class="badge text-bg-light border mt-1"><i class="bi bi-box-arrow-right"></i> <?= ! empty($r['batas_kembali']) ? 'keluar ' . substr($r['jam_keluar'], 0, 5) . '–' . substr($r['batas_kembali'], 0, 5) : 'pulang ' . substr($r['jam_keluar'], 0, 5) ?></span>
                        <span class="badge text-bg-<?= $sk['warna'] ?> mt-1"><?= esc($sk['status']) ?><?= $sk['menit'] ? ' ' . $sk['menit'] . ' mnt' : '' ?></span><?php endif ?></td>
                <td><?= esc($r['keterangan']) ?><?php if (! empty($r['penjemput'])) : ?><br><small class="text-muted">Dijemput: <?= esc($r['penjemput']) ?></small><?php endif ?></td>
                <td><?php if ($r['lampiran']) : ?><a href="<?= site_url('izin-siswa/lampiran/' . $r['id']) ?>" target="_blank"><i class="bi bi-paperclip"></i> Lihat</a><?php else : ?><span class="text-muted">-</span><?php endif ?></td>
                <td class="small text-muted"><?= esc($r['pencatat']) ?></td>
                <td class="text-end"><?php if (\App\Libraries\Akses::izinSiswaInput((int) $r['kelas_id'])) : ?><?= delete_button('izin-siswa/hapus/' . $r['id'], '', 'Hapus izin ini? Absensi yang terisi otomatis dari izin ini ikut dihapus.') ?><?php endif ?></td>
            </tr>
        <?php endforeach ?>
        <?php if (! $rows) : ?><tr><td colspan="8" class="text-center text-muted">Belum ada izin pada rentang ini.</td></tr><?php endif ?>
        </tbody>
    </table>
</div></div>
<?php if ($siswa) : ?>
<div class="modal fade" id="modalIzin" tabindex="-1">
    <div class="modal-dialog"><form method="post" action="<?= site_url('izin-siswa/simpan') ?>" enctype="multipart/form-data" class="modal-content"><?= csrf_field() ?>
        <div class="modal-header"><h5 class="modal-title">Catat Izin Siswa</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
        <div class="modal-body row g-2">
            <div class="col-12"><label class="form-label">Siswa</label>
                <select name="siswa_id" class="form-select tom" required><option value="">- pilih -</option>
                    <?php foreach ($siswa as $s) : ?><option value="<?= $s['id'] ?>" <?= old('siswa_id') == $s['id'] ? 'selected' : '' ?>><?= esc($s['nama_lengkap'] . ' — ' . $s['nama_kelas']) ?></option><?php endforeach ?></select></div>
            <div class="col-12"><label class="form-label">Jenis</label>
                <select name="jenis" class="form-select"><?php foreach (\App\Models\IzinSiswaModel::JENIS as $k => $v) : ?><option value="<?= $k ?>" <?= old('jenis') === $k ? 'selected' : '' ?>><?= $v ?></option><?php endforeach ?></select>
                <small class="text-muted">Dispensasi (lomba/tugas sekolah) dicatat hadir.</small></div>
            <div class="col-6"><label class="form-label">Dari</label><input type="date" name="tanggal_mulai" class="form-control" value="<?= old('tanggal_mulai', date('Y-m-d')) ?>" required></div>
            <div class="col-6"><label class="form-label">Sampai</label><input type="date" name="tanggal_selesai" class="form-control" value="<?= old('tanggal_selesai') ?>"></div>
            <?php $mode = old('mode', 'hari'); ?>
            <div class="col-12"><label class="form-label">Waktu izin</label>
                <div class="btn-group w-100" role="group">
                    <?php foreach (['hari' => 'Sepanjang hari', 'pulang' => 'Pulang awal', 'sementara' => 'Keluar & kembali'] as $k => $v) : ?>
                        <input type="radio" class="btn-check" name="mode" id="mode<?= $k ?>" value="<?= $k ?>" <?= $mode === $k ? 'checked' : '' ?>><label class="btn btn-outline-primary" for="mode<?= $k ?>"><?= $v ?></label>
                    <?php endforeach ?>
                </div></div>
            <div class="col-6 box-pulang"><label class="form-label">Jam keluar</label><input type="time" name="jam_keluar" class="form-control" value="<?= esc(old('jam_keluar')) ?>"></div>
            <div class="col-6 box-kembali"><label class="form-label">Batas kembali</label><input type="time" name="batas_kembali" class="form-control" value="<?= esc(old('batas_kembali')) ?>"></div>
            <div class="col-6 box-pulang box-jemput"><label class="form-label">Dijemput oleh</label><input name="penjemput" maxlength="100" class="form-control" value="<?= esc(old('penjemput')) ?>" placeholder="Ayah / Ibu / ..."></div>
            <div class="col-12 box-pulang small text-muted" id="ketMode"></div>
            <div class="col-12"><label class="form-label">Keterangan</label><input name="keterangan" maxlength="255" class="form-control" value="<?= esc(old('keterangan')) ?>" placeholder="Demam / acara keluarga / lomba O2SN"></div>
            <div class="col-12"><label class="form-label">Surat izin / surat dokter (foto atau PDF, maks. 2 MB)</label>
                <input type="file" name="lampiran" class="form-control" accept=".pdf,.jpg,.jpeg,.png" capture="environment"></div>
        </div>
        <div class="modal-footer"><button class="btn btn-primary">Simpan</button></div>
    </form></div>
</div>
<?php endif ?>
<?= $this->endSection() ?>
<?= $this->section('scripts') ?>
<script>
(function () {
    var radios = document.querySelectorAll('[name=mode]'); if (!radios.length) return;
    var sampai = document.querySelector('[name=tanggal_selesai]'), jam = document.querySelector('[name=jam_keluar]'), batas = document.querySelector('[name=batas_kembali]');
    var ket = {
        pulang: 'Absensi pagi tetap hadir; absensi mapel sesudah siswa keluar gerbang otomatis berstatus sesuai jenis izin.',
        sementara: 'Satpam mencatat keluar & kembali di Pos Gerbang. Mapel selama izin = jenis izin; terlambat kembali lebih dari <?= (int) \App\Libraries\IzinKeluar::toleransi() ?> menit = membolos (alpa di mapel berikutnya).'
    };
    function hhmm(d) { return ('0' + d.getHours()).slice(-2) + ':' + ('0' + d.getMinutes()).slice(-2); }
    function atur() {
        var m = document.querySelector('[name=mode]:checked').value;
        document.querySelectorAll('.box-pulang').forEach(function (e) { e.style.display = m === 'hari' ? 'none' : ''; });
        document.querySelectorAll('.box-kembali').forEach(function (e) { e.style.display = m === 'sementara' ? '' : 'none'; });
        document.querySelectorAll('.box-jemput').forEach(function (e) { e.style.display = m === 'pulang' ? '' : 'none'; });
        sampai.closest('.col-6').style.display = m === 'hari' ? '' : 'none';
        jam.required = m !== 'hari'; batas.required = m === 'sementara';
        if (m === 'hari') { jam.value = ''; batas.value = ''; }
        if (m !== 'hari' && !jam.value) { jam.value = hhmm(new Date()); }
        if (m === 'sementara' && !batas.value) { batas.value = hhmm(new Date(Date.now() + 3600000)); }
        if (m !== 'sementara') { batas.value = ''; }
        document.getElementById('ketMode').textContent = ket[m] || '';
    }
    radios.forEach(function (r) { r.addEventListener('change', atur); }); atur();
})();
</script>
<?= $this->endSection() ?>
