<?= $this->extend('layouts/main') ?>
<?= $this->section('actions') ?>
<a href="<?= site_url('laporan/mutasi') ?>" target="_blank" class="btn btn-light"><i class="bi bi-printer me-1"></i>Cetak</a>
<?php if ($kelola) : ?>
<div class="dropdown d-inline-block">
    <button class="btn btn-primary dropdown-toggle" data-bs-toggle="dropdown"><i class="bi bi-plus-lg me-1"></i>Catat Mutasi</button>
    <ul class="dropdown-menu dropdown-menu-end">
        <li><a class="dropdown-item" href="#" data-bs-toggle="modal" data-bs-target="#mKeluar"><i class="bi bi-box-arrow-right me-2 text-danger"></i>Siswa keluar / pindah sekolah</a></li>
        <li><a class="dropdown-item" href="#" data-bs-toggle="modal" data-bs-target="#mMasuk"><i class="bi bi-box-arrow-in-right me-2 text-success"></i>Siswa masuk (pindahan)</a></li>
        <li><a class="dropdown-item" href="#" data-bs-toggle="modal" data-bs-target="#mPindah"><i class="bi bi-arrow-left-right me-2 text-primary"></i>Pindah kelas</a></li>
    </ul>
</div>
<?php endif ?>
<?= $this->endSection() ?>
<?= $this->section('content') ?>
<?php $J = \App\Models\MutasiSiswaModel::JENIS; ?>
<div class="row g-3 mb-1">
    <?php foreach ([['Masuk', $hit['masuk'], 'box-arrow-in-right', 'hijau', 'Masuk'], ['Keluar', $hit['keluar'], 'box-arrow-right', 'merah', 'keluar'], ['Pindah kelas', $hit['pindah'], 'arrow-left-right', 'biru', 'Pindah Kelas'], ['Lulus', $hit['lulus'], 'mortarboard', 'emas', 'Lulus']] as [$l, $n, $ik, $w, $f]) : ?>
        <div class="col-6 col-lg-3"><a href="?jenis=<?= urlencode($f) ?>" class="text-decoration-none"><div class="card"><div class="card-body stat-card">
            <div class="stat-ikon <?= $w ?>"><i class="bi bi-<?= $ik ?>"></i></div><div><div class="small text-muted fw-semibold"><?= $l ?></div><div class="stat-angka text-body"><?= $n ?></div></div>
        </div></div></a></div>
    <?php endforeach ?>
</div>
<div class="card"><div class="card-body">
    <?php if ($jenis) : ?><p class="small mb-2">Filter: <b><?= esc($jenis) ?></b> · <a href="<?= site_url('mutasi') ?>">tampilkan semua</a></p><?php endif ?>
    <div class="table-responsive">
    <table class="table table-hover align-middle tabel-hp">
        <thead><tr><th>Tanggal</th><th>Siswa</th><th>Jenis</th><th>Kelas</th><th>Sekolah asal/tujuan</th><th>Alasan / No. surat</th><th></th></tr></thead>
        <tbody>
        <?php foreach ($rows as $r) : ?>
            <tr>
                <td data-label="Tanggal" class="text-nowrap"><?= tgl_indo($r['tanggal']) ?></td>
                <td data-label="Siswa"><b><?= esc($r['nama_lengkap']) ?></b><div class="small text-muted">NIS <?= esc($r['nis']) ?><?= $r['nisn'] ? ' · NISN ' . esc($r['nisn']) : '' ?></div></td>
                <td data-label="Jenis"><span class="badge bg-<?= $J[$r['jenis']][3] ?? 'secondary' ?>"><?= esc($J[$r['jenis']][0] ?? $r['jenis']) ?></span></td>
                <td data-label="Kelas" class="text-nowrap"><?= esc($r['kelas_asal'] ?: '–') ?><?= $r['kelas_tujuan'] ? ' <i class="bi bi-arrow-right"></i> ' . esc($r['kelas_tujuan']) : '' ?></td>
                <td data-label="Sekolah"><?= esc($r['sekolah'] ?: '–') ?></td>
                <td data-label="Alasan" class="small"><?= esc($r['alasan'] ?: '') ?><?= $r['no_surat'] ? '<div class="text-muted">No. ' . esc($r['no_surat']) . '</div>' : '' ?></td>
                <td class="text-end"><?php if ($kelola && isset($terakhir[(int) $r['id']])) : ?>
                    <form method="post" action="<?= site_url('mutasi/batal/' . $r['id']) ?>" onsubmit="return confirm('Batalkan mutasi ini dan kembalikan status siswa?')"><?= csrf_field() ?><button class="btn btn-sm btn-outline-danger" title="Batalkan (salah input)"><i class="bi bi-arrow-counterclockwise"></i></button></form>
                <?php endif ?></td>
            </tr>
        <?php endforeach ?>
        <?php if (! $rows) : ?><tr><td colspan="7" class="text-center text-muted">Belum ada mutasi.</td></tr><?php endif ?>
        </tbody>
    </table>
    </div>
</div></div>

<?php if ($kelola) : $optSiswa = ''; foreach ($siswa as $s) { $optSiswa .= '<option value="' . $s['id'] . '">' . esc($s['nama_lengkap'] . ' — ' . $s['nama_kelas'] . ' (' . $s['nis'] . ')') . '</option>'; } ?>
<div class="modal fade" id="mKeluar" tabindex="-1"><div class="modal-dialog"><form method="post" action="<?= site_url('mutasi/keluar') ?>" class="modal-content"><?= csrf_field() ?>
    <div class="modal-header"><h5 class="modal-title">Siswa Keluar</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
    <div class="modal-body row g-2">
        <div class="col-12"><label class="form-label">Siswa</label><select name="siswa_id" class="form-select tom" required><option value="">- pilih -</option><?= $optSiswa ?></select></div>
        <div class="col-md-7"><label class="form-label">Jenis</label><select name="jenis" class="form-select"><?php foreach (\App\Models\MutasiSiswaModel::KELUAR as $k) : ?><option value="<?= $k ?>"><?= $J[$k][0] ?></option><?php endforeach ?></select></div>
        <div class="col-md-5"><label class="form-label">Tanggal</label><input type="date" name="tanggal" class="form-control" value="<?= date('Y-m-d') ?>" required></div>
        <div class="col-12"><label class="form-label">Sekolah tujuan</label><input name="sekolah" class="form-control" maxlength="150" placeholder="Untuk pindah sekolah"></div>
        <div class="col-md-7"><label class="form-label">Alasan</label><input name="alasan" class="form-control" maxlength="255" placeholder="Mengikuti orang tua pindah tugas"></div>
        <div class="col-md-5"><label class="form-label">No. surat</label><input name="no_surat" class="form-control" maxlength="60"></div>
        <div class="col-12 small text-muted">Siswa tidak lagi muncul di absensi, jurnal, dan kiosk. Riwayat absensi & catatannya tetap tersimpan.</div>
    </div>
    <div class="modal-footer"><button class="btn btn-danger">Simpan mutasi keluar</button></div>
</form></div></div>

<div class="modal fade" id="mMasuk" tabindex="-1"><div class="modal-dialog modal-lg"><form method="post" action="<?= site_url('mutasi/masuk') ?>" class="modal-content"><?= csrf_field() ?>
    <div class="modal-header"><h5 class="modal-title">Siswa Masuk (Pindahan)</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
    <div class="modal-body row g-2">
        <div class="col-md-4"><label class="form-label">NIS *</label><input name="nis" class="form-control" required value="<?= esc(old('nis')) ?>"></div>
        <div class="col-md-4"><label class="form-label">NISN</label><input name="nisn" class="form-control" value="<?= esc(old('nisn')) ?>"></div>
        <div class="col-md-4"><label class="form-label">L/P *</label><select name="jenis_kelamin" class="form-select"><option value="L">Laki-laki</option><option value="P" <?= old('jenis_kelamin') === 'P' ? 'selected' : '' ?>>Perempuan</option></select></div>
        <div class="col-md-8"><label class="form-label">Nama lengkap *</label><input name="nama_lengkap" class="form-control" required value="<?= esc(old('nama_lengkap')) ?>"></div>
        <div class="col-md-4"><label class="form-label">Masuk ke kelas *</label><select name="kelas_id" class="form-select" required><option value="">- pilih -</option><?php foreach ($kelas as $k) : ?><option value="<?= $k['id'] ?>"><?= esc($k['nama_kelas']) ?></option><?php endforeach ?></select></div>
        <div class="col-md-4"><label class="form-label">Tempat lahir</label><input name="tempat_lahir" class="form-control" value="<?= esc(old('tempat_lahir')) ?>"></div>
        <div class="col-md-4"><label class="form-label">Tanggal lahir</label><input type="date" name="tanggal_lahir" class="form-control" value="<?= esc(old('tanggal_lahir')) ?>"></div>
        <div class="col-md-4"><label class="form-label">Tanggal masuk *</label><input type="date" name="tanggal" class="form-control" value="<?= old('tanggal', date('Y-m-d')) ?>" required></div>
        <div class="col-md-6"><label class="form-label">Nama wali</label><input name="nama_wali" class="form-control" value="<?= esc(old('nama_wali')) ?>"></div>
        <div class="col-md-6"><label class="form-label">No HP wali</label><input name="no_hp_wali" class="form-control" value="<?= esc(old('no_hp_wali')) ?>"></div>
        <div class="col-md-6"><label class="form-label">Sekolah asal</label><input name="sekolah" class="form-control" maxlength="150" value="<?= esc(old('sekolah')) ?>"></div>
        <div class="col-md-6"><label class="form-label">No. surat pindah</label><input name="no_surat" class="form-control" maxlength="60" value="<?= esc(old('no_surat')) ?>"></div>
        <div class="col-12"><label class="form-label">Alamat</label><input name="alamat" class="form-control" value="<?= esc(old('alamat')) ?>"></div>
        <div class="col-12 small text-muted">Bila NISN/NIS cocok dengan siswa lama yang pernah keluar, data siswa itu diaktifkan kembali (tidak dibuat ganda).</div>
    </div>
    <div class="modal-footer"><button class="btn btn-success">Simpan siswa masuk</button></div>
</form></div></div>

<div class="modal fade" id="mPindah" tabindex="-1"><div class="modal-dialog"><form method="post" action="<?= site_url('mutasi/pindah-kelas') ?>" class="modal-content"><?= csrf_field() ?>
    <div class="modal-header"><h5 class="modal-title">Pindah Kelas</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
    <div class="modal-body row g-2">
        <div class="col-12"><label class="form-label">Siswa</label><select name="siswa_id" class="form-select tom" required><option value="">- pilih -</option><?= $optSiswa ?></select></div>
        <div class="col-md-7"><label class="form-label">Kelas tujuan</label><select name="kelas_id" class="form-select" required><option value="">- pilih -</option><?php foreach ($kelas as $k) : ?><option value="<?= $k['id'] ?>"><?= esc($k['nama_kelas']) ?></option><?php endforeach ?></select></div>
        <div class="col-md-5"><label class="form-label">Tanggal</label><input type="date" name="tanggal" class="form-control" value="<?= date('Y-m-d') ?>" required></div>
        <div class="col-12"><label class="form-label">Alasan</label><input name="alasan" class="form-control" maxlength="255" placeholder="Pemerataan jumlah siswa / penjurusan"></div>
    </div>
    <div class="modal-footer"><button class="btn btn-primary">Pindahkan</button></div>
</form></div></div>
<?php endif ?>
<?= $this->endSection() ?>
