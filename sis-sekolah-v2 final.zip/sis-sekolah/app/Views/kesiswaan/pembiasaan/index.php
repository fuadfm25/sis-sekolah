<?= $this->extend('layouts/main') ?>
<?= $this->section('content') ?>
<div class="card"><div class="card-body py-3">
    <form class="d-flex flex-wrap gap-2 align-items-center filter" method="get">
        <select name="kelas_id" class="form-select w-auto" onchange="this.form.submit()">
            <?php foreach ($kelas as $k) : ?><option value="<?= $k['id'] ?>" <?= $kelasId == $k['id'] ? 'selected' : '' ?>><?= esc($k['nama_kelas']) ?></option><?php endforeach ?>
        </select>
        <input type="date" name="tanggal" value="<?= $tanggal ?>" max="<?= date('Y-m-d') ?>" class="form-control w-auto" onchange="this.form.submit()">
        <strong><?= tgl_indo($tanggal, true) ?></strong>
        <?php $sudahGuru = (bool) array_filter(array_merge([], ...array_map('array_values', array_values($data))), static fn ($r) => $r['sumber'] === 'Guru'); ?>
        <?= $sudahGuru ? '<span class="badge bg-success">Sudah diisi</span>' : '<span class="badge bg-warning">Belum diisi</span>' ?>
    </form>
</div></div>

<?php if ($menunggu) : $bisaVerif = \App\Libraries\Akses::pembiasaanInput($kelasId); ?>
<form method="post" action="<?= site_url('pembiasaan/verifikasi') ?>"><?= csrf_field() ?><input type="hidden" name="kelas_id" value="<?= $kelasId ?>">
<div class="card border-warning">
    <div class="card-header d-flex flex-wrap justify-content-between gap-2 align-items-center">
        <h5 class="card-title mb-0"><i class="bi bi-hourglass-split"></i> Laporan siswa menunggu verifikasi (<?= count($menunggu) ?>)</h5>
        <?php if ($bisaVerif) : ?><div class="d-flex gap-2">
            <button name="aksi" value="setujui" class="btn btn-sm btn-success">Setujui yang dicentang</button>
            <button name="aksi" value="tolak" class="btn btn-sm btn-outline-danger" onclick="return confirm('Tolak laporan yang dicentang?')">Tolak</button></div><?php endif ?>
    </div>
    <div class="card-body table-responsive" style="max-height:340px">
        <table class="table table-sm align-middle mb-0">
            <thead><tr><th style="width:30px"><input type="checkbox" class="form-check-input" onclick="document.querySelectorAll('.cek-verif').forEach(c => c.checked = this.checked)" checked></th>
                <th>Tanggal</th><th>Siswa</th><th>Kegiatan</th><th>Laporan</th><th>Keterangan siswa</th></tr></thead>
            <tbody>
            <?php foreach ($menunggu as $m) : ?>
                <tr><td><input type="checkbox" class="form-check-input cek-verif" name="ids[]" value="<?= $m['id'] ?>" checked></td>
                    <td class="text-nowrap small"><?= tgl_indo($m['tanggal']) ?></td><td><?= esc($m['nama_lengkap']) ?></td>
                    <td><?= esc($m['nama_pembiasaan']) ?> <span class="badge text-bg-light border"><?= $m['tempat'] === 'Rumah' ? 'rumah' : 'sekolah' ?></span></td>
                    <td><?= (int) $m['lapor_siswa'] ? '<span class="text-success">✓ dilakukan</span>' : '<span class="text-muted">tidak</span>' ?></td>
                    <td class="small"><?= esc($m['keterangan'] ?? '') ?></td></tr>
            <?php endforeach ?>
            </tbody>
        </table>
    </div>
</div>
</form>
<?php endif ?>

<?php if (! $pembiasaan) : ?>
    <div class="alert alert-info">Tidak ada pembiasaan yang berlaku pada hari ini. <?php if (has_role('kesiswaan')) : ?><a href="<?= site_url('pembiasaan/master') ?>">Atur daftar pembiasaan</a>.<?php endif ?></div>
<?php else : ?>
<?php if (! $status['absensi']) : ?><div class="alert alert-<?= $status['warna'] === 'success' ? 'light' : $status['warna'] ?> bg-opacity-25"><i class="bi bi-calendar-x"></i> Siswa tidak masuk: <?= esc($status['label']) ?>.</div>
<?php elseif (! $bisaInput) : ?><div class="alert alert-light border"><i class="bi bi-eye"></i> Mode lihat saja – pengisian pembiasaan dilakukan oleh wali kelas atau kesiswaan.</div><?php endif ?>
<form method="post" action="<?= site_url('pembiasaan/simpan') ?>">
    <fieldset <?= $bisaInput ? '' : 'disabled' ?>>
    <?= csrf_field() ?>
    <input type="hidden" name="kelas_id" value="<?= $kelasId ?>"><input type="hidden" name="tanggal" value="<?= $tanggal ?>">
    <?php foreach ($pembiasaan as $p) : ?><input type="hidden" name="pembiasaan_ids[]" value="<?= $p['id'] ?>"><?php endforeach ?>
    <div class="card">
        <div class="card-body table-responsive">
            <table class="table table-sm table-hover table-bordered align-middle">
                <thead class="table-light">
                    <tr><th>No</th><th>Nama</th>
                        <?php foreach ($pembiasaan as $p) : ?>
                            <th class="text-center small" title="<?= esc($p['deskripsi'] ?? '', 'attr') ?>"><?= esc($p['nama']) ?><br>
                                <input type="checkbox" class="form-check-input cek-kolom" data-p="<?= $p['id'] ?>" title="Centang semua"></th>
                        <?php endforeach ?>
                        <th>Keterangan</th></tr>
                </thead>
                <tbody>
                <?php foreach ($siswa as $s) :
                    $absen = in_array($pagi[$s['id']] ?? '', ['S', 'I', 'A'], true);
                    $baris = $data[$s['id']] ?? null;
                ?>
                    <tr class="<?= $absen ? 'table-light text-muted' : '' ?>">
                        <td><?= esc($s['no_absen']) ?></td>
                        <td><?= esc($s['nama_lengkap']) ?> <?= $absen ? badge_presensi($pagi[$s['id']]) : '' ?></td>
                        <?php foreach ($pembiasaan as $p) :
                            $sel = $baris[$p['id']] ?? null; $lapor = $sel && $sel['verifikasi'] === 'Menunggu';
                            $oldCek = old('cek'); $checked = old('kelas_id') !== null ? ! empty($oldCek[$s['id']][$p['id']]) : ($sel ? ($lapor ? (int) $sel['lapor_siswa'] : (int) $sel['terlaksana']) : ($baris ? false : ($bisaInput && ! $absen))); ?>
                            <td class="text-center <?= $lapor ? 'table-warning' : '' ?>" title="<?= $lapor ? 'Dilaporkan siswa, belum diverifikasi – menyimpan berarti menyetujui keputusan ini' : ($sel && $sel['sumber'] === 'Siswa' ? 'Diisi siswa' : '') ?>"><input type="checkbox" class="form-check-input p<?= $p['id'] ?>" name="cek[<?= $s['id'] ?>][<?= $p['id'] ?>]" value="1" <?= $checked ? 'checked' : '' ?>><?= $sel && $sel['sumber'] === 'Siswa' ? '<i class="bi bi-person-check small text-muted ms-1"></i>' : '' ?></td>
                        <?php endforeach ?>
                        <td><input name="ket[<?= $s['id'] ?>]" class="form-control form-control-sm" value="<?= esc($baris ? (current($baris)['keterangan'] ?? '') : '') ?>"></td>
                    </tr>
                <?php endforeach ?>
                </tbody>
            </table>
            <small class="text-muted">Siswa yang sakit/izin/alpa pada absensi pagi tidak dicentang secara otomatis. Sel kuning = laporan siswa yang belum diverifikasi; menyimpan halaman ini sekaligus memverifikasinya.</small>
        </div>
        <?php if ($bisaInput) : ?><div class="card-footer"><button class="btn btn-primary"><i class="bi bi-save"></i> Simpan</button></div><?php endif ?>
    </div>
    </fieldset>
</form>
<?php endif ?>
<?= $this->endSection() ?>
<?= $this->section('scripts') ?>
<script>
document.querySelectorAll('.cek-kolom').forEach(function (c) {
    c.addEventListener('change', function () { document.querySelectorAll('input.p' + c.dataset.p).forEach(x => x.checked = c.checked); });
});
</script>
<?= $this->endSection() ?>
