<?= $this->extend('layouts/main') ?>
<?= $this->section('actions') ?><button onclick="window.print()" class="btn btn-light"><i class="bi bi-printer"></i> Cetak</button><?= $this->endSection() ?>
<?= $this->section('content') ?>
<div class="card no-print"><div class="card-body py-3">
    <form class="d-flex flex-wrap gap-2 filter" method="get">
        <select name="kelas_id" class="form-select w-auto"><?php foreach ($kelas as $k) : ?><option value="<?= $k['id'] ?>" <?= $kelasId == $k['id'] ? 'selected' : '' ?>><?= esc($k['nama_kelas']) ?></option><?php endforeach ?></select>
        <input type="date" name="dari" value="<?= esc($dari) ?>" class="form-control w-auto">
        <input type="date" name="sampai" value="<?= esc($sampai) ?>" class="form-control w-auto">
        <button class="btn btn-primary">Tampilkan</button>
    </form>
</div></div>
<div class="card"><div class="card-body table-responsive">
    <?= $this->include('partials/print_header') ?>
    <h6 class="print-only text-center">Rekap Pembiasaan <?= esc($subtitle) ?></h6>
    <table class="table table-bordered table-sm align-middle">
        <thead class="table-light"><tr><th>No</th><th>Nama</th>
            <?php foreach ($pembiasaan as $p) : ?><th class="text-center small"><?= esc($p['nama']) ?></th><?php endforeach ?>
            <th class="text-center">Rata-rata</th></tr></thead>
        <tbody>
        <?php foreach ($siswa as $s) : $sum = 0; $n = 0; ?>
            <tr><td><?= esc($s['no_absen']) ?></td><td><?= esc($s['nama_lengkap']) ?></td>
                <?php foreach ($pembiasaan as $p) : $d = $data[$s['id']][$p['id']] ?? null; ?>
                    <?php if ($d && $d['total']) : $pct = round($d['ya'] / $d['total'] * 100); $sum += $pct; $n++; ?>
                        <td class="text-center <?= $pct < 60 ? 'text-danger fw-bold' : '' ?>"><?= $pct ?>%<br><small class="text-muted"><?= $d['ya'] ?>/<?= $d['total'] ?></small></td>
                    <?php else : ?><td class="text-center text-muted">-</td><?php endif ?>
                <?php endforeach ?>
                <td class="text-center fw-bold"><?= $n ? round($sum / $n) . '%' : '-' ?></td>
            </tr>
        <?php endforeach ?>
        </tbody>
    </table>
    <small class="text-muted">Persentase = hari terlaksana / hari tercatat. Merah = di bawah 60%.</small>
</div></div>
<?= $this->endSection() ?>
