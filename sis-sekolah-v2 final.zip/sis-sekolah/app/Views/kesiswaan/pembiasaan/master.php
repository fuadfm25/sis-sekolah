<?= $this->extend('layouts/main') ?>
<?= $this->section('actions') ?>
<?= tombol_impor('pembiasaan') ?>
<button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#modalForm" data-title="Tambah Pembiasaan" data-action="<?= site_url('pembiasaan/master/store') ?>" data-row='{"is_active":"1","pengisi":"Guru","tempat":"Sekolah","berlaku":"Sekolah","perlu_verifikasi":"1"}'><i class="bi bi-plus-lg"></i> Tambah</button>
<?= $this->endSection() ?>
<?= $this->section('content') ?>
<?php use App\Models\PembiasaanModel; ?>
<div class="row g-3 mb-1">
    <div class="col-lg-7"><div class="card h-100"><div class="card-body">
        <h6 class="mb-2">Cara kerja</h6>
        <ul class="small mb-0 ps-3">
            <li><b>Dicatat guru</b>: wali kelas/kesiswaan mencentang di halaman Pembiasaan Siswa (mis. sholat dhuha, literasi pagi).</li>
            <li><b>Diisi siswa</b>: siswa mencentang sendiri di portal siswa (cocok untuk kebiasaan di rumah). Bila <i>perlu verifikasi</i>, baru dihitung setelah disetujui wali kelas.</li>
            <li><b>Guru &amp; siswa</b>: siswa melapor, wali kelas melihatnya di tabel kelas lalu menyimpan/memverifikasi.</li>
        </ul>
    </div></div></div>
    <div class="col-lg-5"><div class="card h-100"><div class="card-body">
        <form method="post" action="<?= site_url('pembiasaan/master/pengaturan') ?>" class="mb-3"><?= csrf_field() ?>
            <label class="form-label small">Siswa boleh mengisi sampai berapa hari ke belakang?</label>
            <div class="input-group input-group-sm"><input type="number" min="0" max="7" name="pembiasaan_mundur" value="<?= $mundur ?>" class="form-control"><span class="input-group-text">hari</span><button class="btn btn-light">Simpan</button></div>
            <div class="form-text">0 = hanya hari ini.</div>
        </form>
        <?php if (! $ada7kaih) : ?>
        <form method="post" action="<?= site_url('pembiasaan/master/paket-7kaih') ?>"><?= csrf_field() ?>
            <button class="btn btn-sm btn-outline-primary w-100"><i class="bi bi-stars"></i> Tambah paket 7 Kebiasaan Anak Indonesia Hebat</button>
        </form>
        <?php endif ?>
    </div></div></div>
</div>
<div class="card"><div class="card-body table-responsive">
    <table class="table table-hover align-middle">
        <thead><tr><th>Urutan</th><th>Nama</th><th>Kategori</th><th>Pengisi</th><th>Berlaku</th><th>Status</th><th class="text-end">Aksi</th></tr></thead>
        <tbody>
        <?php foreach ($rows as $r) : $r['hari'] = $r['hari'] ? explode(',', $r['hari']) : []; $r['tingkat'] = $r['tingkat'] ? explode(',', $r['tingkat']) : []; ?>
            <tr class="<?= $r['is_active'] ? '' : 'text-muted' ?>">
                <td><?= esc($r['urutan']) ?></td>
                <td><?= esc($r['nama']) ?><br><small class="text-muted"><?= esc($r['deskripsi']) ?></small></td>
                <td><?= esc($r['kategori']) ?></td>
                <td class="small"><?= esc(PembiasaanModel::PENGISI[$r['pengisi']] ?? $r['pengisi']) ?><br><span class="text-muted"><?= esc(PembiasaanModel::TEMPAT[$r['tempat']] ?? '') ?><?= $r['tempat'] === 'Rumah' ? ' · ' . esc(mb_strtolower(PembiasaanModel::BERLAKU[$r['berlaku'] ?? 'Semua'] ?? '')) : '' ?><?= $r['pengisi'] !== 'Guru' ? ((int) $r['perlu_verifikasi'] ? ' · diverifikasi' : ' · tanpa verifikasi') : '' ?></span></td>
                <td class="small"><?= $r['hari'] ? esc(implode(', ', array_map('nama_hari', $r['hari']))) : 'Setiap hari' ?><br><span class="text-muted"><?= $r['tingkat'] ? 'Tingkat ' . esc(implode(', ', $r['tingkat'])) : 'Semua tingkat' ?></span></td>
                <td><?= $r['is_active'] ? '<span class="badge bg-success">Aktif</span>' : '<span class="badge bg-secondary">Nonaktif</span>' ?></td>
                <td class="text-end text-nowrap">
                    <button class="btn btn-sm btn-outline-warning" data-bs-toggle="modal" data-bs-target="#modalForm" data-title="Edit Pembiasaan" data-action="<?= site_url('pembiasaan/master/update/' . $r['id']) ?>" data-row='<?= esc(json_encode($r), 'attr') ?>'><i class="bi bi-pencil"></i></button>
                    <?= delete_button('pembiasaan/master/delete/' . $r['id'], '', 'Hapus pembiasaan ini beserta seluruh catatannya? Lebih aman dinonaktifkan.') ?>
                </td>
            </tr>
        <?php endforeach ?>
         <?php if (! $rows) : ?><tr><td colspan="7" class="text-center text-muted">Belum ada data.</td></tr><?php endif ?>
        </tbody>
    </table>
</div></div>
<div class="modal fade" id="modalForm" data-crud tabindex="-1">
    <div class="modal-dialog"><form method="post" class="modal-content"><?= csrf_field() ?>
        <div class="modal-header"><h5 class="modal-title"></h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
        <div class="modal-body row g-2">
            <div class="col-9"><label class="form-label">Nama kegiatan</label><input name="nama" class="form-control" required></div>
            <div class="col-3"><label class="form-label">Urutan</label><input type="number" name="urutan" class="form-control" value="0"></div>
            <div class="col-12"><label class="form-label">Kategori</label><input name="kategori" class="form-control" list="dlKat">
                <datalist id="dlKat"><option>Religius</option><option>Literasi</option><option>Kebersihan</option><option>Kedisiplinan</option><option>Nasionalisme</option><option>Kesehatan</option></datalist></div>
            <div class="col-12"><label class="form-label">Deskripsi</label><textarea name="deskripsi" class="form-control" rows="2"></textarea></div>
            <div class="col-6"><label class="form-label">Diisi oleh</label><select name="pengisi" class="form-select">
                <?php foreach (PembiasaanModel::PENGISI as $k => $v) : ?><option value="<?= $k ?>"><?= $v ?></option><?php endforeach ?></select></div>
            <div class="col-6"><label class="form-label">Tempat</label><select name="tempat" class="form-select">
                <?php foreach (PembiasaanModel::TEMPAT as $k => $v) : ?><option value="<?= $k ?>"><?= $v ?></option><?php endforeach ?></select>
</div>
            <div class="col-12" id="boxBerlaku"><label class="form-label">Kegiatan di rumah berlaku pada</label><select name="berlaku" class="form-select">
                <?php foreach (PembiasaanModel::BERLAKU as $k => $v) : ?><option value="<?= $k ?>"><?= $v ?></option><?php endforeach ?></select>
                <div class="form-text">"Hari masuk sekolah" mengikuti kalender akademik: Sabtu/Minggu (sesuai hari sekolah), libur nasional, dan libur semester tidak dihitung. Cocok untuk bangun pagi, tidur awal, belajar di rumah.</div></div>
            <div class="col-12"><div class="form-check"><input class="form-check-input" type="checkbox" name="perlu_verifikasi" value="1" id="pVer"><label class="form-check-label" for="pVer">Laporan siswa perlu diverifikasi wali kelas</label></div>
                <div class="form-check"><input class="form-check-input" type="checkbox" name="wajib_catatan" value="1" id="pCat"><label class="form-check-label" for="pCat">Siswa wajib menulis keterangan saat mencentang</label></div></div>
            <div class="col-12"><label class="form-label">Petunjuk keterangan untuk siswa</label><input name="petunjuk_catatan" class="form-control" maxlength="100" placeholder="Mis. judul buku & halaman yang dibaca"></div>
            <div class="col-12"><label class="form-label">Berlaku untuk tingkat (kosongkan = semua)</label><div class="d-flex flex-wrap gap-3">
                <?php foreach ($tingkat as $t) : ?><div class="form-check"><input class="form-check-input" type="checkbox" name="tingkat[]" value="<?= esc($t) ?>" id="t<?= esc($t) ?>"><label class="form-check-label" for="t<?= esc($t) ?>"><?= esc($t) ?></label></div><?php endforeach ?></div></div>
            <div class="col-12"><label class="form-label">Berlaku pada hari (kosongkan = setiap hari)</label><div class="d-flex flex-wrap gap-3">
                <?php foreach (hari_list() + [7 => 'Minggu'] as $h => $hn) : ?>
                    <div class="form-check"><input class="form-check-input" type="checkbox" name="hari[]" value="<?= $h ?>" id="h<?= $h ?>"><label class="form-check-label" for="h<?= $h ?>"><?= $hn ?></label></div>
                <?php endforeach ?></div></div>
            <div class="col-12"><div class="form-check"><input class="form-check-input" type="checkbox" name="is_active" value="1" id="pAktif"><label class="form-check-label" for="pAktif">Aktif</label></div></div>
        </div>
        <div class="modal-footer"><button class="btn btn-primary">Simpan</button></div>
    </form></div>
</div>
<?= $this->endSection() ?>
<?= $this->section('scripts') ?><?= $this->include('partials/modal_form_js') ?>
<script>
(function () {
    var m = document.getElementById('modalForm'), t = m.querySelector('[name=tempat]');
    function atur() { document.getElementById('boxBerlaku').style.display = t.value === 'Rumah' ? '' : 'none'; }
    t.addEventListener('change', atur); m.addEventListener('shown.bs.modal', atur);
})();
</script>
<?= $this->endSection() ?>
