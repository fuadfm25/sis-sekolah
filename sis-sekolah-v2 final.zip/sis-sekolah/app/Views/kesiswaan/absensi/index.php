<?= $this->extend('layouts/main') ?>
<?= $this->section('content') ?>
<div class="card"><div class="card-body py-3">
    <form class="d-flex flex-wrap gap-2 align-items-center filter" method="get">
        <select name="kelas_id" class="form-select w-auto" onchange="this.form.submit()">
            <?php foreach ($kelas as $k) : ?><option value="<?= $k['id'] ?>" <?= $kelasId == $k['id'] ? 'selected' : '' ?>><?= esc($k['nama_kelas']) ?><?= isset($ringkas[$k['id']]) ? ' ✓' : '' ?></option><?php endforeach ?>
        </select>
        <input type="date" name="tanggal" value="<?= $tanggal ?>" max="<?= date('Y-m-d') ?>" class="form-control w-auto" onchange="this.form.submit()">
        <strong><?= tgl_indo($tanggal, true) ?></strong>
        <?php if ($data) : ?><span class="badge bg-success ms-2">Sudah diisi</span><?php else : ?><span class="badge bg-warning ms-2">Belum diisi</span><?php endif ?>
    </form>
</div></div>

<?php if (! $status['absensi']) : ?>
    <div class="alert alert-<?= $status['warna'] === 'success' ? 'light' : $status['warna'] ?> bg-opacity-25"><i class="bi bi-calendar-x"></i> Tidak ada absensi: <?= esc($status['label']) ?>.</div>
<?php elseif ($status['agenda']) : ?>
    <div class="alert alert-info py-2 small"><i class="bi bi-calendar-event"></i> <?= esc($status['label']) ?> — absensi tetap diambil.</div>
<?php endif ?>
<?php if (! $bisaInput && $status['absensi']) : ?>
    <div class="alert alert-light border"><i class="bi bi-eye"></i> Mode lihat saja – Anda tidak berwenang mengisi absensi kelas ini pada tanggal tersebut. <?= esc($infoPiket) ?></div>
<?php elseif ($infoPiket) : ?>
    <div class="small text-muted mb-2"><?= esc($infoPiket) ?></div>
<?php endif ?>

<form method="post" action="<?= site_url('absensi-pagi/simpan') ?>">
    <fieldset <?= $bisaInput ? '' : 'disabled' ?>>
    <?= csrf_field() ?>
    <input type="hidden" name="kelas_id" value="<?= $kelasId ?>"><input type="hidden" name="tanggal" value="<?= $tanggal ?>">
    <div class="card">
        <div class="card-header d-flex flex-wrap justify-content-between gap-2">
            <h5 class="card-title mb-0"><?= count($siswa) ?> siswa</h5>
            <div class="small" id="rekap"></div>
            <?php if ($bisaInput) : ?><button type="button" class="btn btn-sm btn-outline-success" onclick="semua('H')">Semua hadir</button><?php endif ?>
        </div>
        <div class="card-body table-responsive">
            <table class="table table-sm table-hover table-presensi tabel-hp">
                <thead><tr><th>No</th><th>Nama</th><th class="text-center">Status</th><th style="width:120px">Jam datang</th><th>Keterangan</th></tr></thead>
                <tbody>
                <?php $oldAbsen = old('absen'); foreach ($siswa as $s) : $d = $data[$s['id']] ?? null; $o = $oldAbsen[$s['id']] ?? null; $st = $o['status'] ?? ($d['status'] ?? 'H'); if ($o) { $d = array_merge((array) $d, ['jam_datang' => $o['jam_datang'] ?? null, 'keterangan' => $o['keterangan'] ?? null]); } ?>
                    <tr>
                        <td class="d-none d-md-table-cell"><?= esc($s['no_absen']) ?></td>
                        <td data-label="Siswa"><b class="d-md-none"><?= esc($s['no_absen']) ?>.</b> <?= esc($s['nama_lengkap']) ?>
                            <?php if (($d['sumber'] ?? '') === 'Kiosk') : ?><i class="bi bi-upc-scan text-primary" title="Absen lewat kiosk"></i><?php endif ?>
                            <?php if (! empty($d['jam_pulang'])) : ?><small class="text-muted">· pulang <?= jam($d['jam_pulang']) ?></small><?php endif ?></td>
                        <td class="text-center text-nowrap" data-label="Status">
                            <?php foreach (['H' => 'success', 'T' => 'warning', 'S' => 'info', 'I' => 'primary', 'A' => 'danger'] as $k => $c) : ?>
                                <input type="radio" class="btn-check st" name="absen[<?= $s['id'] ?>][status]" id="a<?= $s['id'] . $k ?>" value="<?= $k ?>" <?= $st === $k ? 'checked' : '' ?>>
                                <label class="btn btn-sm btn-outline-<?= $c ?> btn-status" for="a<?= $s['id'] . $k ?>" title="<?= status_presensi()[$k] ?>"><?= $k ?></label>
                            <?php endforeach ?>
                        </td>
                        <td data-label="Jam datang"><input type="time" name="absen[<?= $s['id'] ?>][jam_datang]" class="form-control form-control-sm" value="<?= esc(jam($d['jam_datang'] ?? null) === '-' ? '' : jam($d['jam_datang'])) ?>"></td>
                        <td data-label="Keterangan"><input name="absen[<?= $s['id'] ?>][keterangan]" class="form-control form-control-sm" value="<?= esc($d['keterangan'] ?? '') ?>"></td>
                    </tr>
                <?php endforeach ?>
                <?php if (! $siswa) : ?><tr><td colspan="5" class="text-center text-muted">Belum ada siswa di kelas ini.</td></tr><?php endif ?>
                </tbody>
            </table>
            <small class="text-muted">H = Hadir · T = Terlambat · S = Sakit · I = Izin · A = Alpa. Jam datang setelah <?= esc(setting('jam_masuk', '07:00')) ?> otomatis dicatat Terlambat.</small>
        </div>
        <?php if ($bisaInput) : ?><div class="card-footer"><button class="btn btn-primary"><i class="bi bi-save"></i> Simpan Absensi</button></div><?php endif ?>
    </div>
    </fieldset>
</form>
<?= $this->endSection() ?>
<?= $this->section('scripts') ?>
<script>
function semua(v){document.querySelectorAll('input.st[value="'+v+'"]').forEach(r=>r.checked=true);hitung();}
function hitung(){var c={H:0,T:0,S:0,I:0,A:0};document.querySelectorAll('input.st:checked').forEach(r=>c[r.value]++);
 document.getElementById('rekap').innerHTML=Object.keys(c).map(k=>'<b>'+k+'</b>: '+c[k]).join(' &middot; ');}
document.querySelectorAll('input.st').forEach(r=>r.addEventListener('change',hitung));hitung();
</script>
<?= $this->endSection() ?>
