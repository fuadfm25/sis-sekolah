<?= $this->extend('layouts/main') ?>
<?= $this->section('actions') ?><button onclick="window.print()" class="btn btn-light"><i class="bi bi-printer"></i> Cetak</button><?= $this->endSection() ?>
<?= $this->section('content') ?>
<div class="card no-print"><div class="card-body py-3">
    <form class="d-flex flex-wrap gap-2 filter" method="get">
        <select name="kelas_id" class="form-select w-auto"><?php foreach ($kelas as $k) : ?><option value="<?= $k['id'] ?>" <?= $kelasId == $k['id'] ? 'selected' : '' ?>><?= esc($k['nama_kelas']) ?></option><?php endforeach ?></select>
        <select name="bulan" class="form-select w-auto"><?php foreach (bulan_list() as $n => $b) : ?><option value="<?= $n ?>" <?= $bulan == $n ? 'selected' : '' ?>><?= $b ?></option><?php endforeach ?></select>
        <input type="number" name="tahun" value="<?= $tahun ?>" class="form-control w-auto" style="max-width:100px">
        <button class="btn btn-primary">Tampilkan</button>
    </form>
</div></div>
<div class="card"><div class="card-body table-responsive">
    <?= $this->include('partials/print_header') ?>
    <h6 class="print-only text-center">Rekap Absensi Harian <?= esc($subtitle) ?></h6>
    <table class="table table-bordered rekap-mini">
        <thead class="table-light"><tr><th>No</th><th class="sticky-col">Nama</th>
            <?php for ($d = 1; $d <= $hari; $d++) : $libur = ! \App\Libraries\Kalender::absensi(sprintf('%04d-%02d-%02d', $tahun, $bulan, $d), (int) ($kelasId ?? 0) ?: null); ?>
                <th class="<?= $libur ? 'bg-light text-muted' : '' ?>"><?= $d ?></th>
            <?php endfor ?>
            <th>H</th><th>T</th><th>S</th><th>I</th><th>A</th></tr></thead>
        <tbody>
        <?php foreach ($siswa as $s) : $c = ['H' => 0, 'T' => 0, 'S' => 0, 'I' => 0, 'A' => 0]; ?>
            <tr><td><?= esc($s['no_absen']) ?></td><td class="sticky-col"><?= esc($s['nama_lengkap']) ?></td>
                <?php for ($d = 1; $d <= $hari; $d++) : $st = $matriks[$s['id']][$d] ?? ''; if ($st) { $c[$st]++; } ?>
                    <td class="<?= in_array($st, ['S', 'I', 'A', 'T'], true) ? 'fw-bold text-danger' : '' ?>"><?= $st === 'H' ? '•' : esc($st) ?></td>
                <?php endfor ?>
                <?php foreach ($c as $n) : ?><td><?= $n ?></td><?php endforeach ?>
            </tr>
        <?php endforeach ?>
        </tbody>
    </table>
    <small class="text-muted">• = hadir tepat waktu, kolom abu-abu = tidak ada absensi (bukan hari sekolah / libur menurut kalender akademik).</small>
</div></div>
<?= $this->endSection() ?>
