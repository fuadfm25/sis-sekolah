<?= $this->extend('layouts/main') ?>
<?php
use App\Libraries\IzinKeluar;

$jam = static fn ($t) => $t ? substr($t, strlen($t) > 8 ? 11 : 0, 5) : '-';
$tombolKeluar = static fn ($z) => '<form method="post" action="' . site_url('gerbang/keluar/' . $z['id']) . '" class="d-inline">' . csrf_field()
    . '<button class="btn btn-primary btn-lg"><i class="bi bi-box-arrow-right"></i> Catat KELUAR</button></form>';
$tombolKembali = static fn ($z) => '<form method="post" action="' . site_url('gerbang/kembali/' . $z['id']) . '" class="d-inline">' . csrf_field()
    . '<button class="btn btn-success btn-lg"><i class="bi bi-box-arrow-in-left"></i> Sudah KEMBALI</button></form>';
?>
<?= $this->section('content') ?>
<div class="card"><div class="card-body">
    <form method="get" class="d-flex gap-2" autocomplete="off">
        <input name="q" id="cari" class="form-control form-control-lg" value="<?= esc($q) ?>" placeholder="Tempel kartu / ketik NIS atau nama siswa" autofocus>
        <button class="btn btn-primary btn-lg px-4"><i class="bi bi-search"></i><span class="d-none d-md-inline"> Cek</span></button>
    </form>
    <div class="small text-muted mt-2">Terlambat kembali lebih dari <b><?= $toleransi ?> menit</b> setelah batas dicatat <b>membolos</b>.</div>
</div></div>

<?php if ($q !== '' && ! $hasil && ! $calon) : ?>
    <div class="alert alert-danger fs-5"><i class="bi bi-x-octagon"></i> Siswa "<?= esc($q) ?>" tidak ditemukan.</div>
<?php endif ?>

<?php if ($calon) : ?>
<div class="card"><div class="card-header"><h6 class="mb-0">Pilih siswa</h6></div><div class="list-group list-group-flush">
    <?php foreach ($calon as $c) : ?>
        <a class="list-group-item list-group-item-action" href="<?= site_url('gerbang?q=' . urlencode($c['nis'])) ?>"><?= esc($c['nama_lengkap']) ?> <span class="text-muted">· <?= esc($c['nama_kelas']) ?> · NIS <?= esc($c['nis']) ?></span></a>
    <?php endforeach ?>
</div></div>
<?php endif ?>

<?php if ($hasil) : $s = $hasil['siswa']; ?>
<div class="card border-3 <?= $hasil['keluar'] ? 'border-success' : 'border-danger' ?>">
    <div class="card-body">
        <h4 class="mb-1"><?= esc($s['nama_lengkap']) ?></h4>
        <div class="text-muted mb-3"><?= esc($hasil['kelas']['nama_kelas'] ?? '-') ?> · NIS <?= esc($s['nis']) ?></div>
        <?php if (! $hasil['keluar']) : ?>
            <div class="alert alert-danger fs-5 mb-0"><i class="bi bi-slash-circle"></i> <b>TIDAK ADA IZIN KELUAR</b> hari ini. Siswa tidak boleh meninggalkan sekolah; arahkan ke guru piket.
                <?php foreach ($hasil['sehari'] as $z) : ?><div class="fs-6 mt-2">Catatan: tercatat <?= esc(\App\Models\IzinSiswaModel::JENIS[$z['jenis']]) ?> sepanjang hari<?= $z['keterangan'] ? ' (' . esc($z['keterangan']) . ')' : '' ?>.</div><?php endforeach ?>
            </div>
        <?php endif ?>
        <?php foreach ($hasil['keluar'] as $z) : $st = IzinKeluar::status($z); ?>
            <div class="p-3 rounded bg-body-tertiary mb-2">
                <div class="fs-5 mb-1"><span class="badge text-bg-<?= $st['warna'] ?>"><?= esc(strtoupper($st['status'])) ?></span>
                    <?= IzinKeluar::sementara($z) ? 'Izin keluar <b>' . $jam($z['jam_keluar']) . '</b>, kembali paling lambat <b>' . $jam($z['batas_kembali']) . '</b>' : 'Izin <b>pulang</b> pukul <b>' . $jam($z['jam_keluar']) . '</b>' ?></div>
                <div class="small text-muted mb-2"><?= esc(\App\Models\IzinSiswaModel::JENIS[$z['jenis']]) ?><?= $z['keterangan'] ? ' · ' . esc($z['keterangan']) : '' ?><?= $z['penjemput'] ? ' · dijemput ' . esc($z['penjemput']) : '' ?>
                    <?= $z['keluar_at'] ? ' · keluar ' . $jam($z['keluar_at']) : '' ?><?= $z['kembali_at'] ? ' · kembali ' . $jam($z['kembali_at']) : '' ?><?= $st['menit'] ? ' · terlambat ' . $st['menit'] . ' menit' : '' ?></div>
                <?php if (empty($z['keluar_at']) && ! in_array($st['status'], ['Tidak jadi'], true)) : ?><?= $tombolKeluar($z) ?>
                <?php elseif (IzinKeluar::sementara($z) && empty($z['kembali_at']) && IzinKeluar::mulai($z) !== null) : ?><?= $tombolKembali($z) ?><?php endif ?>
            </div>
        <?php endforeach ?>
    </div>
</div>
<?php endif ?>

<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center"><h5 class="card-title mb-0">Izin keluar hari ini</h5><small class="text-muted">diperbarui <?= date('H:i') ?></small></div>
    <div class="card-body table-responsive">
        <table class="table table-hover align-middle tabel-hp">
            <thead><tr><th>Siswa</th><th>Izin</th><th>Keluar</th><th>Kembali</th><th>Status</th><th></th></tr></thead>
            <tbody>
            <?php foreach ($rows as $z) : $st = IzinKeluar::status($z); ?>
                <tr>
                    <td data-label="Siswa"><b><?= esc($z['nama_lengkap']) ?></b><br><small class="text-muted"><?= esc($z['nama_kelas']) ?> · <?= esc($z['keterangan'] ?? '') ?></small></td>
                    <td data-label="Izin" class="text-nowrap"><?= IzinKeluar::sementara($z) ? $jam($z['jam_keluar']) . '–' . $jam($z['batas_kembali']) : 'pulang ' . $jam($z['jam_keluar']) ?></td>
                    <td data-label="Keluar"><?= $jam($z['keluar_at']) ?><?= $z['petugas_keluar'] ? '<br><small class="text-muted">' . esc($z['petugas_keluar']) . '</small>' : '' ?></td>
                    <td data-label="Kembali"><?= IzinKeluar::sementara($z) ? $jam($z['kembali_at']) : '—' ?><?= $z['petugas_kembali'] ? '<br><small class="text-muted">' . esc($z['petugas_kembali']) . '</small>' : '' ?></td>
                    <td data-label="Status"><span class="badge text-bg-<?= $st['warna'] ?>"><?= esc($st['status']) ?></span><?= $st['menit'] ? ' <small>' . $st['menit'] . ' mnt</small>' : '' ?></td>
                    <td class="text-end text-nowrap">
                        <?php if (empty($z['keluar_at']) && $st['status'] === 'Diterbitkan') : ?>
                            <form method="post" action="<?= site_url('gerbang/keluar/' . $z['id']) ?>" class="d-inline"><?= csrf_field() ?><button class="btn btn-sm btn-outline-primary">Keluar</button></form>
                        <?php elseif (IzinKeluar::sementara($z) && empty($z['kembali_at']) && IzinKeluar::mulai($z) !== null) : ?>
                            <form method="post" action="<?= site_url('gerbang/kembali/' . $z['id']) ?>" class="d-inline"><?= csrf_field() ?><button class="btn btn-sm btn-success">Kembali</button></form>
                        <?php endif ?>
                        <?php if ($koreksi && IzinKeluar::sementara($z) && ($z['keluar_at'] || $z['kembali_at'] || $st['status'] === 'Membolos')) : ?>
                            <form method="post" action="<?= site_url('gerbang/kembali/' . $z['id']) ?>" class="d-inline-flex gap-1 mt-1" title="Koreksi jam kembali (guru piket/kesiswaan)"><?= csrf_field() ?>
                                <input type="time" name="jam" class="form-control form-control-sm" style="width:7rem" value="<?= $z['kembali_at'] ? $jam($z['kembali_at']) : '' ?>" required><button class="btn btn-sm btn-outline-secondary">Koreksi</button></form>
                        <?php endif ?>
                    </td>
                </tr>
            <?php endforeach ?>
            <?php if (! $rows) : ?><tr><td colspan="6" class="text-center text-muted">Belum ada izin keluar hari ini.</td></tr><?php endif ?>
            </tbody>
        </table>
    </div>
</div>
<?= $this->endSection() ?>
<?= $this->section('scripts') ?>
<script>
// segarkan daftar tiap 60 detik selama kolom pencarian kosong (status terlambat/membolos ikut berubah)
setInterval(function () { var c = document.getElementById('cari'); if (c && c.value === '' && !document.querySelector('form input[name=jam]:focus')) location.reload(); }, 60000);
</script>
<?= $this->endSection() ?>
