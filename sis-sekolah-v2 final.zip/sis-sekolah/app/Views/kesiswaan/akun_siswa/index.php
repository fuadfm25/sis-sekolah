<?= $this->extend('layouts/main') ?>
<?= $this->section('actions') ?>
<a href="<?= site_url('akun-siswa/kartu?kelas_id=' . $kelasId) ?>" target="_blank" class="btn btn-light"><i class="bi bi-printer me-1"></i>Cetak kartu login kelas ini</a>
<a href="<?= site_url('portal/login') ?>" target="_blank" class="btn btn-outline-primary"><i class="bi bi-box-arrow-up-right me-1"></i>Buka portal</a>
<?= $this->endSection() ?>
<?= $this->section('content') ?>
<?php if (! $aktif) : ?><div class="alert alert-warning">Portal siswa sedang <b>dinonaktifkan</b>. Aktifkan di Sistem → Pengaturan Sekolah.</div><?php endif ?>
<div class="card"><div class="card-body py-3">
    <form class="d-flex gap-2 align-items-center filter" method="get">
        <select name="kelas_id" class="form-select w-auto" onchange="this.form.submit()"><?php foreach ($kelas as $k) : ?><option value="<?= $k['id'] ?>" <?= $kelasId == $k['id'] ? 'selected' : '' ?>><?= esc($k['nama_kelas']) ?></option><?php endforeach ?></select>
        <span class="small text-muted ms-auto"><?= count(array_filter($siswa, static fn ($s) => ! empty($s['password']))) ?> dari <?= count($siswa) ?> siswa sudah membuat password sendiri</span>
    </form>
</div></div>
<form method="post" action="<?= site_url('akun-siswa/reset') ?>" onsubmit="return confirm('Kembalikan password siswa yang dicentang ke password bawaan?')"><?= csrf_field() ?>
<input type="hidden" name="kelas_id" value="<?= $kelasId ?>">
<div class="card"><div class="card-body table-responsive">
    <table class="table table-hover align-middle tabel-hp">
        <thead><tr><th><input type="checkbox" class="form-check-input" onclick="document.querySelectorAll('.cek').forEach(c=>c.checked=this.checked)"></th><th>No</th><th>Nama</th><th>Username (NISN/NIS)</th><th>Status akun</th><th>Login terakhir</th></tr></thead>
        <tbody>
        <?php foreach ($siswa as $s) : ?>
            <tr>
                <td><input type="checkbox" class="form-check-input cek" name="ids[]" value="<?= $s['id'] ?>"></td>
                <td data-label="No"><?= esc($s['no_absen']) ?></td>
                <td data-label="Nama"><?= esc($s['nama_lengkap']) ?></td>
                <td data-label="Username"><code><?= esc($s['nisn'] ?: $s['nis']) ?></code></td>
                <td data-label="Status"><?= empty($s['password']) ? '<span class="badge bg-light-warning text-dark">password bawaan</span>' : '<span class="badge bg-light-success text-success">password sendiri</span>' ?>
                    <?= empty($s['tanggal_lahir']) ? '<span class="badge bg-light-secondary text-muted" title="Tanggal lahir kosong: password bawaan = NIS">tgl lahir kosong</span>' : '' ?></td>
                <td data-label="Login terakhir" class="small"><?= $s['login_terakhir'] ? esc(tgl_indo(substr($s['login_terakhir'], 0, 10)) . ' ' . substr($s['login_terakhir'], 11, 5)) : '<span class="text-muted">belum pernah</span>' ?></td>
            </tr>
        <?php endforeach ?>
        <?php if (! $siswa) : ?><tr><td colspan="6" class="text-center text-muted">Belum ada siswa.</td></tr><?php endif ?>
        </tbody>
    </table>
    <button class="btn btn-sm btn-outline-primary"><i class="bi bi-arrow-counterclockwise me-1"></i>Reset password yang dicentang ke bawaan</button>
    <span class="small text-muted ms-2">Untuk siswa yang lupa password.</span>
</div></div>
</form>
<?= $this->endSection() ?>
