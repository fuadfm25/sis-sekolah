<?= $this->extend('layouts/cetak') ?>
<?= $this->section('isi') ?>
<style>
    .slip-wrap { display: grid; grid-template-columns: repeat(2, 1fr); }
    .slip { border: 1px dashed #777; padding: 9px 12px; page-break-inside: avoid; font-family: Arial, sans-serif; font-size: 9.5pt; }
    .slip .atas { display: flex; justify-content: space-between; border-bottom: 1px solid #ccc; padding-bottom: 4px; margin-bottom: 5px; font-weight: bold; }
    .slip .nm { font-weight: bold; font-size: 10.5pt; }
    .slip table td { padding: 1px 6px 1px 0; }
    .slip .pw { font-family: "Courier New", monospace; font-size: 12.5pt; font-weight: bold; }
    .slip .kecil { font-size: 7.8pt; color: #444; margin-top: 4px; }
    .hanya-excel { display: none; }
</style>
<!--noxls--><div class="slip-wrap">
<?php foreach ($siswa as $s) : ?>
    <div class="slip">
        <div class="atas"><span>Portal Siswa</span><span><?= esc(setting('nama_sekolah', '')) ?></span></div>
        <div class="nm"><?= esc($s['nama_lengkap']) ?></div>
        <table>
            <tr><td>Alamat</td><td>: <?= esc($alamat) ?></td></tr>
            <tr><td>Username</td><td>: <b><?= esc($s['nisn'] ?: $s['nis']) ?></b></td></tr>
            <tr><td>Password</td><td>: <?= empty($s['password']) ? '<span class="pw">' . esc(\App\Libraries\PortalSiswa::passwordBawaan($s)) . '</span>' : '<i>sudah diganti siswa</i>' ?></td></tr>
        </table>
        <div class="kecil">Ganti password saat pertama masuk. Bisa dibuka bersama orang tua/wali.</div>
    </div>
<?php endforeach ?>
</div><!--/noxls-->
<table class="data hanya-excel"><thead><tr><th>No</th><th>Nama</th><th>Username</th><th>Password awal</th></tr></thead><tbody>
<?php foreach ($siswa as $i => $s) : ?><tr><td><?= $i + 1 ?></td><td><?= esc($s['nama_lengkap']) ?></td><td><?= esc($s['nisn'] ?: $s['nis']) ?></td><td><?= empty($s['password']) ? esc(\App\Libraries\PortalSiswa::passwordBawaan($s)) : 'sudah diganti' ?></td></tr><?php endforeach ?>
</tbody></table>
<?= $this->endSection() ?>
