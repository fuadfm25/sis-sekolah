<?= $this->extend('layouts/main') ?>
<?= $this->section('actions') ?>
<a href="<?= site_url('perilaku/tambah?siswa_id=' . $siswa['id']) ?>" class="btn btn-outline-danger"><i class="bi bi-person-exclamation"></i> Catat Perilaku</a>
<?php if ($isBk) : ?><a href="<?= site_url('bk/layanan/tambah?siswa_id=' . $siswa['id']) ?>" class="btn btn-outline-primary"><i class="bi bi-chat-heart"></i> Layanan BK</a><?php endif ?>
<?php if ($aksesPenuh) : ?><a href="<?= site_url('laporan/perilaku-siswa?siswa_id=' . $siswa['id']) ?>" target="_blank" class="btn btn-light"><i class="bi bi-printer"></i> Kartu Perilaku</a><?php endif ?>
<?= $this->endSection() ?>
<?= $this->section('content') ?>
<div class="row">
    <div class="col-lg-4">
        <div class="card">
            <div class="card-body">
                <div class="text-center mb-3">
                    <div class="rounded-circle bg-primary text-white d-inline-flex align-items-center justify-content-center fw-bold fs-3" style="width:72px;height:72px"><?= esc(strtoupper(mb_substr($siswa['nama_lengkap'], 0, 1))) ?></div>
                    <h5 class="mt-2 mb-0"><?= esc($siswa['nama_lengkap']) ?></h5>
                    <small class="text-muted">NIS <?= esc($siswa['nis']) ?> · NISN <?= esc($siswa['nisn'] ?? '-') ?></small><br>
                    <?= badge_status($siswa['status']) ?>
                </div>
                <table class="table table-sm table-borderless small mb-0">
                    <tr><th>Kelas</th><td><?= esc($kelas['nama_kelas'] ?? '-') ?></td></tr>
                    <tr><th>Wali kelas</th><td><?= $wali ? esc(nama_guru($wali)) : '-' ?></td></tr>
                    <tr><th>L/P</th><td><?= esc($siswa['jenis_kelamin']) ?></td></tr>
                    <tr><th>TTL</th><td><?= esc($siswa['tempat_lahir'] ?? '-') ?>, <?= tgl_indo($siswa['tanggal_lahir']) ?></td></tr>
                    <?php if ($aksesPenuh) : ?>
                    <tr><th>Orang tua/wali</th><td><?= esc($siswa['nama_wali'] ?? '-') ?></td></tr>
                    <tr><th>No. HP</th><td><?= esc($siswa['no_hp_wali'] ?? '-') ?></td></tr>
                    <tr><th>Alamat</th><td><?= esc($siswa['alamat'] ?? '-') ?></td></tr>
                    <?php endif ?>
                </table>
            </div>
        </div>
        <div class="card">
            <div class="card-header"><h6 class="mb-0">Kehadiran Harian (TP aktif)</h6></div>
            <div class="card-body">
                <?php foreach (['H', 'T', 'S', 'I', 'A'] as $k) : ?>
                    <div class="d-flex justify-content-between"><span><?= badge_presensi($k) ?> <?= status_presensi()[$k] ?></span><strong><?= (int) ($presensi[$k] ?? 0) ?></strong></div>
                <?php endforeach ?>
            </div>
        </div>
        <?php if ($pembiasaan) : ?>
        <div class="card">
            <div class="card-header"><h6 class="mb-0">Pembiasaan</h6></div>
            <div class="card-body">
                <?php foreach ($pembiasaan as $p) : $pct = $p['total'] ? round($p['ya'] / $p['total'] * 100) : 0; ?>
                    <div class="small"><?= esc($p['nama']) ?> <span class="float-end"><?= $pct ?>%</span></div>
                    <div class="progress mb-2" style="height:6px"><div class="progress-bar bg-<?= $pct >= 80 ? 'success' : ($pct >= 60 ? 'warning' : 'danger') ?>" style="width:<?= $pct ?>%"></div></div>
                <?php endforeach ?>
            </div>
        </div>
        <?php endif ?>
    </div>
    <div class="col-lg-8">
        <div class="row">
            <div class="col-6"><div class="card"><div class="card-body text-center py-3"><div class="text-muted small">Poin positif</div><h3 class="text-success mb-0">+<?= $poin['positif'] ?></h3></div></div></div>
            <div class="col-6"><div class="card"><div class="card-body text-center py-3"><div class="text-muted small">Poin pelanggaran</div><h3 class="<?= $poin['negatif'] >= (int) setting('batas_poin_bk', 50) ? 'text-danger' : 'text-warning' ?> mb-0"><?= $poin['negatif'] ?></h3></div></div></div>
        </div>
        <div class="card">
            <div class="card-header"><h6 class="mb-0">Catatan Perilaku <?= $aksesPenuh ? '' : '<small class="text-muted">(hanya yang Anda catat)</small>' ?></h6></div>
            <div class="card-body">
                <?php if (! $perilaku) : ?><p class="text-muted mb-0">Belum ada catatan.</p><?php endif ?>
                <ul class="list-unstyled mb-0">
                <?php foreach ($perilaku as $p) : ?>
                    <li class="border-start border-3 border-<?= $p['kategori'] === 'Negatif' ? 'danger' : 'success' ?> ps-3 mb-3">
                        <div class="d-flex justify-content-between"><strong><?= esc($p['nama_jenis'] ?? 'Lainnya') ?> (<?= $p['kategori'] === 'Negatif' ? '-' : '+' ?><?= $p['poin'] ?>)</strong><small class="text-muted"><?= tgl_indo($p['tanggal']) ?></small></div>
                        <div class="small"><?= nl2br(esc($p['deskripsi'])) ?></div>
                        <?php if ($p['tindak_lanjut']) : ?><div class="small text-success"><i class="bi bi-arrow-return-right"></i> <?= esc($p['tindak_lanjut']) ?></div><?php endif ?>
                        <div class="small text-muted"><?= badge_status($p['status']) ?> dicatat oleh <?= esc($p['pencatat']) ?></div>
                    </li>
                <?php endforeach ?>
                </ul>
            </div>
        </div>
        <?php if ($isBk) : ?>
        <div class="card">
            <div class="card-header"><h6 class="mb-0"><i class="bi bi-lock"></i> Riwayat Layanan BK</h6></div>
            <div class="card-body">
                <?php if (! $bk) : ?><p class="text-muted mb-0">Belum ada layanan BK.</p><?php endif ?>
                <table class="table table-sm mb-0">
                    <?php foreach ($bk as $l) : ?>
                        <tr>
                            <td class="text-nowrap"><?= tgl_indo($l['tanggal']) ?></td>
                            <td><?= esc($l['jenis_layanan']) ?> <small class="text-muted">(<?= esc($l['bidang']) ?>)</small><br>
                                <?= $l['tersembunyi'] ? '<span class="text-muted small"><i class="bi bi-lock"></i> Rahasia – konselor: ' . esc($l['konselor']) . '</span>' : esc($l['topik']) ?></td>
                            <td><?= badge_status($l['status']) ?></td>
                            <td><?php if (! $l['tersembunyi']) : ?><a href="<?= site_url('bk/layanan/' . $l['id']) ?>" class="btn btn-sm btn-light"><i class="bi bi-eye"></i></a><?php endif ?></td>
                        </tr>
                    <?php endforeach ?>
                </table>
            </div>
        </div>
        <?php endif ?>
    </div>
</div>
<?= $this->endSection() ?>
