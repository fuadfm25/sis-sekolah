<?= $this->extend('layouts/main') ?>
<?= $this->section('actions') ?><a href="<?= site_url('perilaku') ?>" class="btn btn-light"><i class="bi bi-arrow-left"></i> Kembali</a><?= $this->endSection() ?>
<?= $this->section('content') ?>
<?php $v = static fn ($k, $d = '') => old($k, $c[$k] ?? $d); ?>
<div class="card"><div class="card-body">
<form method="post" action="<?= site_url($c ? 'perilaku/update/' . $c['id'] : 'perilaku/simpan') ?>" class="row g-3">
    <?= csrf_field() ?>
    <?php if (! $c && $siswaId) : ?><input type="hidden" name="kembali" value="<?= site_url('siswa/profil/' . $siswaId) ?>"><?php endif ?>
    <div class="col-md-8"><label class="form-label">Siswa *</label>
        <select name="siswa_id" class="form-select tom" required><option value="">Ketik nama / NIS...</option>
            <?php $grp = null; foreach ($siswa as $s) : if ($grp !== $s['nama_kelas']) : if ($grp !== null) echo '</optgroup>'; $grp = $s['nama_kelas']; ?><optgroup label="<?= esc($grp, 'attr') ?>"><?php endif ?>
                <option value="<?= $s['id'] ?>" <?= (int) $v('siswa_id', $siswaId) === (int) $s['id'] ? 'selected' : '' ?>><?= esc($s['nama_lengkap'] . ' (' . $s['nis'] . ') – ' . $s['nama_kelas']) ?></option>
            <?php endforeach; if ($grp !== null) echo '</optgroup>'; ?>
        </select></div>
    <div class="col-md-4"><label class="form-label">Tanggal *</label><input type="date" name="tanggal" class="form-control" value="<?= esc($v('tanggal', date('Y-m-d'))) ?>" max="<?= date('Y-m-d') ?>" required></div>

    <div class="col-md-8"><label class="form-label">Jenis perilaku</label>
        <select name="jenis_perilaku_id" id="jenis" class="form-select tom">
            <option value="">— Lainnya (isi kategori & poin manual) —</option>
            <?php foreach (['Negatif' => 'Pelanggaran', 'Positif' => 'Perilaku positif / prestasi'] as $kat => $label) : ?>
                <optgroup label="<?= $label ?>">
                <?php foreach ($jenis as $j) : if ($j['kategori'] !== $kat) continue; ?>
                    <option value="<?= $j['id'] ?>" data-kategori="<?= $j['kategori'] ?>" data-poin="<?= $j['poin'] ?>" <?= (int) $v('jenis_perilaku_id') === (int) $j['id'] ? 'selected' : '' ?>>
                        <?= esc($j['nama']) ?> (<?= $j['kategori'] === 'Negatif' ? '-' : '+' ?><?= $j['poin'] ?><?= $j['tingkat'] ? ', ' . $j['tingkat'] : '' ?>)</option>
                <?php endforeach ?>
                </optgroup>
            <?php endforeach ?>
        </select></div>
    <div class="col-md-2"><label class="form-label">Kategori</label>
        <select name="kategori" id="kategori" class="form-select"><option <?= $v('kategori') === 'Negatif' ? 'selected' : '' ?>>Negatif</option><option <?= $v('kategori') === 'Positif' ? 'selected' : '' ?>>Positif</option></select></div>
    <div class="col-md-2"><label class="form-label">Poin</label><input type="number" name="poin" id="poin" min="0" class="form-control" value="<?= esc($v('poin', 0)) ?>"></div>

    <div class="col-md-8"><label class="form-label">Uraian kejadian *</label><textarea name="deskripsi" class="form-control" rows="3" required><?= esc($v('deskripsi')) ?></textarea></div>
    <div class="col-md-4"><label class="form-label">Lokasi</label><input name="lokasi" class="form-control" value="<?= esc($v('lokasi')) ?>" placeholder="Kelas, kantin, lapangan..."></div>
    <div class="col-md-12"><label class="form-label">Tindak lanjut yang sudah dilakukan</label><textarea name="tindak_lanjut" class="form-control" rows="2"><?= esc($v('tindak_lanjut')) ?></textarea></div>
    <div class="col-12"><div class="form-check"><input class="form-check-input" type="checkbox" name="rujuk_bk" value="1" id="rujuk" <?= ($c['status'] ?? '') === 'Dirujuk BK' ? 'checked' : '' ?>><label class="form-check-label" for="rujuk">Rujuk ke Guru BK untuk ditangani</label></div></div>
    <div class="col-12"><button class="btn btn-primary"><i class="bi bi-save"></i> Simpan</button></div>
</form>
</div></div>
<?= $this->endSection() ?>
<?= $this->section('scripts') ?>
<script>
document.getElementById('jenis').addEventListener('change', function () {
    var o = this.options[this.selectedIndex];
    if (o && o.dataset.kategori) {
        document.getElementById('kategori').value = o.dataset.kategori;
        document.getElementById('poin').value = o.dataset.poin;
    }
});
</script>
<?= $this->endSection() ?>
