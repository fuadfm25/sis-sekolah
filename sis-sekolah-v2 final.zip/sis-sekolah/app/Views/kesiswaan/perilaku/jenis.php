<?= $this->extend('layouts/main') ?>
<?= $this->section('actions') ?>
<?= tombol_impor('perilaku') ?>
<button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#modalForm" data-title="Tambah Jenis Perilaku" data-action="<?= site_url('perilaku/jenis/store') ?>" data-row='{"is_active":"1","kategori":"Negatif","poin":"5"}'><i class="bi bi-plus-lg"></i> Tambah</button>
<?= $this->endSection() ?>
<?= $this->section('content') ?>
<div class="card"><div class="card-body table-responsive">
    <table class="table table-hover table-sm align-middle">
        <thead><tr><th>Kategori</th><th>Nama</th><th>Tingkat</th><th class="text-center">Poin</th><th>Status</th><th class="text-end">Aksi</th></tr></thead>
        <tbody>
        <?php foreach ($rows as $r) : ?>
            <tr class="<?= $r['is_active'] ? '' : 'text-muted' ?>">
                <td><?= badge_status($r['kategori']) ?></td><td><?= esc($r['nama']) ?></td><td><?= esc($r['tingkat'] ?? '-') ?></td>
                <td class="text-center fw-bold"><?= $r['poin'] ?></td>
                <td><?= $r['is_active'] ? 'Aktif' : 'Nonaktif' ?></td>
                <td class="text-end text-nowrap">
                    <button class="btn btn-sm btn-outline-warning" data-bs-toggle="modal" data-bs-target="#modalForm" data-title="Edit Jenis Perilaku" data-action="<?= site_url('perilaku/jenis/update/' . $r['id']) ?>" data-row='<?= esc(json_encode($r), 'attr') ?>'><i class="bi bi-pencil"></i></button>
                    <?= delete_button('perilaku/jenis/delete/' . $r['id']) ?>
                </td>
            </tr>
        <?php endforeach ?>
        </tbody>
    </table>
</div></div>
<div class="modal fade" id="modalForm" data-crud tabindex="-1">
    <div class="modal-dialog"><form method="post" class="modal-content"><?= csrf_field() ?>
        <div class="modal-header"><h5 class="modal-title"></h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
        <div class="modal-body row g-2">
            <div class="col-6"><label class="form-label">Kategori</label><select name="kategori" class="form-select"><option>Negatif</option><option>Positif</option></select></div>
            <div class="col-6"><label class="form-label">Tingkat (pelanggaran)</label><select name="tingkat" class="form-select"><option value="">-</option><option>Ringan</option><option>Sedang</option><option>Berat</option></select></div>
            <div class="col-9"><label class="form-label">Nama perilaku</label><input name="nama" class="form-control" required></div>
            <div class="col-3"><label class="form-label">Poin</label><input type="number" name="poin" min="0" class="form-control" required></div>
            <div class="col-12"><div class="form-check"><input class="form-check-input" type="checkbox" name="is_active" value="1" id="jAktif"><label class="form-check-label" for="jAktif">Aktif</label></div></div>
        </div>
        <div class="modal-footer"><button class="btn btn-primary">Simpan</button></div>
    </form></div>
</div>
<?= $this->endSection() ?>
<?= $this->section('scripts') ?><?= $this->include('partials/modal_form_js') ?><?= $this->endSection() ?>
