<?= $this->extend('layouts/main') ?>
<?= $this->section('actions') ?><a href="<?= site_url('perilaku/tambah') ?>" class="btn btn-primary"><i class="bi bi-plus-lg"></i> Catat Perilaku</a><?= $this->endSection() ?>
<?= $this->section('content') ?>
<div class="card"><div class="card-body">
    <form class="row g-2 mb-3 filter" method="get">
        <div class="col-md-2"><select name="kelas_id" class="form-select"><option value="">Semua kelas</option>
            <?php foreach ($kelas as $k) : ?><option value="<?= $k['id'] ?>" <?= $f['kelas_id'] == $k['id'] ? 'selected' : '' ?>><?= esc($k['nama_kelas']) ?></option><?php endforeach ?></select></div>
        <div class="col-md-2"><select name="kategori" class="form-select"><option value="">Positif & negatif</option>
            <?php foreach (['Positif', 'Negatif'] as $k) : ?><option <?= $f['kategori'] === $k ? 'selected' : '' ?>><?= $k ?></option><?php endforeach ?></select></div>
        <div class="col-md-2"><select name="status" class="form-select"><option value="">Semua status</option>
            <?php foreach (\App\Models\CatatanPerilakuModel::STATUS as $s) : ?><option <?= $f['status'] === $s ? 'selected' : '' ?>><?= $s ?></option><?php endforeach ?></select></div>
        <div class="col-md-2"><input type="date" name="dari" value="<?= esc($f['dari']) ?>" class="form-control" title="Dari"></div>
        <div class="col-md-2"><input name="q" value="<?= esc($f['q']) ?>" class="form-control" placeholder="Cari siswa / uraian"></div>
        <div class="col-md-1"><button class="btn btn-light w-100"><i class="bi bi-funnel"></i></button></div>
    </form>
    <div class="table-responsive">
    <table class="table table-sm table-hover align-middle">
        <thead><tr><th>Tanggal</th><th>Siswa</th><th>Kategori</th><th>Perilaku</th><th class="text-center">Poin</th><th>Status</th><th>Pencatat</th><th class="text-end">Aksi</th></tr></thead>
        <tbody>
        <?php foreach ($rows as $r) : ?>
            <tr>
                <td class="text-nowrap"><?= tgl_indo($r['tanggal']) ?></td>
                <td><a href="<?= site_url('siswa/profil/' . $r['siswa_id']) ?>"><?= esc($r['nama_siswa']) ?></a><br><small class="text-muted"><?= esc($r['nama_kelas'] ?? '-') ?></small></td>
                <td><?= badge_status($r['kategori']) ?></td>
                <td><strong><?= esc($r['nama_jenis'] ?? 'Lainnya') ?></strong><br><small><?= esc(character_limiter($r['deskripsi'], 90)) ?></small>
                    <?php if ($r['tindak_lanjut']) : ?><br><small class="text-success"><i class="bi bi-arrow-return-right"></i> <?= esc(character_limiter($r['tindak_lanjut'], 80)) ?></small><?php endif ?></td>
                <td class="text-center fw-bold <?= $r['kategori'] === 'Negatif' ? 'text-danger' : 'text-success' ?>"><?= $r['kategori'] === 'Negatif' ? '-' : '+' ?><?= $r['poin'] ?></td>
                <td><?= badge_status($r['status']) ?></td>
                <td class="small"><?= esc($r['pencatat']) ?></td>
                <td class="text-end text-nowrap">
                    <?php if (\App\Libraries\Akses::perilakuTindakLanjut($r)) : ?>
                    <button class="btn btn-sm btn-outline-info" data-bs-toggle="modal" data-bs-target="#modalStatus" data-action="<?= site_url('perilaku/status/' . $r['id']) ?>" data-status="<?= esc($r['status'], 'attr') ?>" data-tl="<?= esc($r['tindak_lanjut'] ?? '', 'attr') ?>" title="Tindak lanjut"><i class="bi bi-arrow-repeat"></i></button>
                    <?php endif ?>
                    <?php if (\App\Libraries\Akses::perilakuKelola($r)) : ?>
                        <a href="<?= site_url('perilaku/edit/' . $r['id']) ?>" class="btn btn-sm btn-outline-warning"><i class="bi bi-pencil"></i></a>
                        <?= delete_button('perilaku/hapus/' . $r['id']) ?>
                    <?php endif ?>
                </td>
            </tr>
        <?php endforeach ?>
        <?php if (! $rows) : ?><tr><td colspan="8" class="text-center text-muted">Belum ada catatan.</td></tr><?php endif ?>
        </tbody>
    </table>
    </div>
    <?= $this->include('partials/pager') ?>
</div></div>
<?= $this->include('kesiswaan/perilaku/_modal_status') ?>
<?= $this->endSection() ?>
