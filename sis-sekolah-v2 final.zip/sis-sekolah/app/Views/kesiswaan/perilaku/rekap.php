<?= $this->extend('layouts/main') ?>
<?= $this->section('actions') ?><button onclick="window.print()" class="btn btn-light"><i class="bi bi-printer"></i> Cetak</button><?= $this->endSection() ?>
<?= $this->section('content') ?>
<div class="card"><div class="card-body">
    <form class="d-flex gap-2 mb-3 filter" method="get">
        <select name="kelas_id" class="form-select w-auto" onchange="this.form.submit()"><option value="">Semua kelas yang dapat diakses</option>
            <?php foreach ($kelas as $k) : ?><option value="<?= $k['id'] ?>" <?= $kelasId == $k['id'] ? 'selected' : '' ?>><?= esc($k['nama_kelas']) ?></option><?php endforeach ?></select>
    </form>
    <?= $this->include('partials/print_header') ?>
    <div class="table-responsive">
    <table class="table table-sm table-hover align-middle">
        <thead><tr><th>No</th><th>Siswa</th><th>Kelas</th><th class="text-center">Catatan</th><th class="text-center">Poin positif</th><th class="text-center">Poin pelanggaran</th><th class="text-center">Selisih</th><th class="no-print"></th></tr></thead>
        <tbody>
        <?php foreach ($rows as $i => $r) : $lewat = (int) $r['poin_negatif'] >= $batas; ?>
            <tr class="<?= $lewat ? 'table-danger' : '' ?>">
                <td><?= $i + 1 ?></td>
                <td><a href="<?= site_url('siswa/profil/' . $r['siswa_id']) ?>"><?= esc($r['nama_siswa']) ?></a> <small class="text-muted"><?= esc($r['nis']) ?></small></td>
                <td><?= esc($r['nama_kelas'] ?? '-') ?></td>
                <td class="text-center"><?= $r['jumlah_catatan'] ?></td>
                <td class="text-center text-success">+<?= (int) $r['poin_positif'] ?></td>
                <td class="text-center text-danger fw-bold"><?= (int) $r['poin_negatif'] ?><?= $lewat ? ' <i class="bi bi-exclamation-triangle-fill" title="Melewati batas"></i>' : '' ?></td>
                <td class="text-center"><?= (int) $r['poin_positif'] - (int) $r['poin_negatif'] ?></td>
                <td class="no-print"><a href="<?= site_url('perilaku/tambah?siswa_id=' . $r['siswa_id']) ?>" class="btn btn-sm btn-light" title="Catat"><i class="bi bi-plus"></i></a></td>
            </tr>
        <?php endforeach ?>
        <?php if (! $rows) : ?><tr><td colspan="8" class="text-center text-muted">Belum ada catatan perilaku.</td></tr><?php endif ?>
        </tbody>
    </table>
    </div>
    <small class="text-muted">Baris merah: poin pelanggaran ≥ <?= $batas ?> (batas peringatan BK, dapat diubah di Pengaturan Sekolah).</small>
</div></div>
<?= $this->endSection() ?>
