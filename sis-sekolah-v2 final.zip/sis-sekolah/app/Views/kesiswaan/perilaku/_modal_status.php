<div class="modal fade" id="modalStatus" tabindex="-1">
    <div class="modal-dialog"><form method="post" class="modal-content"><?= csrf_field() ?>
        <div class="modal-header"><h5 class="modal-title">Status & Tindak Lanjut</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
        <div class="modal-body">
            <div class="mb-2"><label class="form-label">Status</label><select name="status" class="form-select">
                <?php foreach (\App\Models\CatatanPerilakuModel::STATUS as $s) : ?><option><?= $s ?></option><?php endforeach ?></select></div>
            <div class="mb-2"><label class="form-label">Tindak lanjut</label><textarea name="tindak_lanjut" class="form-control" rows="3" placeholder="Teguran lisan, pemanggilan orang tua, dirujuk ke BK, ..."></textarea></div>
        </div>
        <div class="modal-footer"><button class="btn btn-primary">Simpan</button></div>
    </form></div>
</div>
<script>
document.getElementById('modalStatus').addEventListener('show.bs.modal', function (e) {
    var b = e.relatedTarget, f = this.querySelector('form');
    f.action = b.dataset.action; f.status.value = b.dataset.status; f.tindak_lanjut.value = b.dataset.tl;
});
</script>
