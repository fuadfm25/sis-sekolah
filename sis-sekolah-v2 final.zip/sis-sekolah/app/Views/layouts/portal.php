<?php
$s    = $siswa ?? \App\Libraries\PortalSiswa::saya();
$menu = [['portal', 'house', 'Beranda', 'portal'], ['portal/jadwal', 'calendar-week', 'Jadwal', null], ['portal/materi', 'journal-text', 'Materi', null],
    ['portal/kehadiran', 'calendar-check', 'Kehadiran', null], ['portal/perilaku', 'award', 'Perilaku', null], ['portal/pembiasaan', 'check2-square', 'Pembiasaan', null]];
$aktif = static fn ($m) => url_is($m[3] ?? ($m[0] . '*'));
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="theme-color" content="#0f2557">
    <title><?= esc($title ?? 'Portal Siswa') ?> · Portal Siswa <?= esc(setting('nama_sekolah', '')) ?></title>
    <link rel="icon" href="<?= esc(logo_url() ?? base_url('favicon.svg')) ?>">
    <link rel="stylesheet" href="<?= aset('bootstrap-css') ?>">
    <link rel="stylesheet" href="<?= aset('bi-css') ?>">
    <link rel="stylesheet" href="<?= tema_css() ?>">
</head>
<body class="portal">
<header class="portal-top">
    <div class="portal-wrap d-flex align-items-center gap-3">
        <a href="<?= site_url('portal') ?>" class="d-flex align-items-center gap-2 text-white text-decoration-none">
            <img src="<?= esc(logo_url() ?? logo_aplikasi()) ?>" alt="" class="portal-logo">
            <div class="lh-sm"><div class="fw-bold"><?= esc(setting('nama_sekolah', nama_aplikasi())) ?></div><div class="small opacity-75">Portal Siswa</div></div>
        </a>
        <nav class="portal-nav d-none d-lg-flex ms-4">
            <?php foreach ($menu as $m) : ?><a href="<?= site_url($m[0]) ?>" class="<?= $aktif($m) ? 'active' : '' ?>"><i class="bi bi-<?= $m[1] ?>"></i><?= $m[2] ?></a><?php endforeach ?>
        </nav>
        <div class="ms-auto dropdown">
            <a href="#" class="d-flex align-items-center gap-2 text-white text-decoration-none" data-bs-toggle="dropdown">
                <div class="text-end d-none d-sm-block lh-sm"><div class="fw-semibold small"><?= esc($s['nama_lengkap'] ?? '') ?></div><div class="small opacity-75"><?= esc($s['kelas']['nama_kelas'] ?? 'Belum ada kelas') ?></div></div>
                <div class="sis-avatar"><?= esc(strtoupper(mb_substr($s['nama_lengkap'] ?? 'S', 0, 1))) ?></div>
            </a>
            <ul class="dropdown-menu dropdown-menu-end">
                <li class="px-2 py-1 d-sm-none"><div class="fw-bold small"><?= esc($s['nama_lengkap'] ?? '') ?></div><div class="small text-muted"><?= esc($s['kelas']['nama_kelas'] ?? '') ?></div></li>
                <li><a class="dropdown-item" href="<?= site_url('portal/akun') ?>"><i class="bi bi-key me-2"></i>Ganti password</a></li>
                <li><hr class="dropdown-divider"></li>
                <li><a class="dropdown-item text-danger" href="<?= site_url('portal/keluar') ?>"><i class="bi bi-box-arrow-right me-2"></i>Keluar</a></li>
            </ul>
        </div>
    </div>
</header>
<main class="portal-wrap py-4">
    <div class="page-heading"><h3><?= esc($title ?? '') ?></h3><?php if (! empty($subtitle)) : ?><p class="text-subtitle mb-0"><?= esc($subtitle) ?></p><?php endif ?></div>
    <?= $this->include('partials/flash') ?>
    <?= $this->renderSection('content') ?>
</main>
<nav class="portal-bawah d-lg-none">
    <?php foreach ($menu as $m) : ?><a href="<?= site_url($m[0]) ?>" class="<?= $aktif($m) ? 'active' : '' ?>"><i class="bi bi-<?= $m[1] ?>"></i><span><?= $m[2] ?></span></a><?php endforeach ?>
</nav>
<script src="<?= aset('bootstrap-js') ?>"></script>
</body>
</html>
