<?php
/**
 * Layout laporan cetak (A4). Variabel:
 *  $judul, $subjudul (opsional), $orientasi ('portrait'|'landscape'), $ttd (lihat laporan/_ttd.php)
 */
$orientasi = $orientasi ?? 'portrait';
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title><?= esc($judul ?? 'Laporan') ?> – <?= esc(setting('nama_sekolah', nama_aplikasi())) ?></title>
    <style>
        @page { size: A4 <?= $orientasi ?>; margin: 12mm 12mm 14mm 12mm; }
        * { box-sizing: border-box; }
        body { font-family: "Times New Roman", Times, serif; font-size: 11pt; color: #000; margin: 0; background: #e9ecef; }
        .kertas { background: #fff; margin: 16px auto; padding: 12mm; width: <?= $orientasi === 'landscape' ? '297mm' : '210mm' ?>; min-height: 100mm; box-shadow: 0 0 6px rgba(0,0,0,.2); }
        table.kop { width: 100%; border-collapse: collapse; border-bottom: 3px double #000; margin-bottom: 10px; }
        table.kop td { padding: 0 0 6px; vertical-align: middle; }
        table.kop td.kop-logo { width: 80px; }
        .kop img { height: 72px; width: auto; }
        .kop .teks { text-align: center; }
        .kop .nama { font-size: 16pt; font-weight: bold; text-transform: uppercase; line-height: 1.15; }
        .kop .sub { font-size: 10pt; }
        .kop .spacer { width: 72px; }
        h2.judul { text-align: center; font-size: 13pt; margin: 6px 0 2px; text-transform: uppercase; text-decoration: underline; }
        .subjudul { text-align: center; margin-bottom: 10px; }
        table.info td { padding: 1px 6px 1px 0; vertical-align: top; }
        table.data { width: 100%; border-collapse: collapse; margin-top: 6px; }
        table.data th, table.data td { border: 1px solid #000; padding: 3px 4px; vertical-align: top; }
        table.data th { background: #eee; text-align: center; }
        table.data.kecil th, table.data.kecil td { font-size: 8.5pt; padding: 1px 2px; text-align: center; }
        table.data.kecil td.kiri { text-align: left; white-space: nowrap; }
        .tengah { text-align: center; } .kanan { text-align: right; } .nowrap { white-space: nowrap; }
        .libur { background: #ddd !important; }
        .merah { color: #b00; font-weight: bold; }
        .ttd { margin-top: 18px; page-break-inside: avoid; }
        table.ttd-tabel { width: 100%; border-collapse: collapse; }
        table.ttd-tabel td { width: 50%; text-align: center; vertical-align: top; }
        .ttd .ruang { height: 60px; }
        .ttd .nama { font-weight: bold; text-decoration: underline; }
        .kecil-teks { font-size: 9pt; }
        .bagian { page-break-inside: avoid; margin-top: 10px; }
        .pecah { page-break-before: always; }
        .toolbar { position: sticky; top: 0; background: #0f2557; color: #fff; padding: 8px 16px; display: flex; gap: 8px; align-items: center; font-family: Arial, sans-serif; font-size: 14px; z-index: 5; }
        .toolbar button { padding: 6px 14px; border: 0; border-radius: 4px; cursor: pointer; }
        .toolbar .utama { background: #e3b23c; color: #1b2537; font-weight: 700; }
        @media print {
            body { background: #fff; }
            .toolbar, #debug-icon, #toolbarContainer { display: none !important; }
            .kertas { margin: 0; padding: 0; width: auto; box-shadow: none; }
            thead { display: table-header-group; }
            tr { page-break-inside: avoid; }
        }
    </style>
</head>
<body>
<!--toolbar--><div class="toolbar">
    <button class="utama" onclick="window.print()">🖨 Cetak / Simpan PDF</button>
    <?php if (empty($word)) : ?><button onclick="var u=new URL(location.href);u.searchParams.set('format','xlsx');location.href=u">⬇ Excel</button><?php endif ?>
    <?php if (! empty($word)) : ?><button onclick="var u=new URL(location.href);u.searchParams.set('format','doc');location.href=u">⬇ Word</button><?php endif ?>
    <button onclick="window.close()">Tutup</button>
    <span style="opacity:.8">Pilih "Save as PDF" pada dialog cetak untuk menyimpan sebagai PDF. Kertas: A4 <?= $orientasi === 'landscape' ? 'mendatar' : 'tegak' ?>.</span>
</div><!--/toolbar-->
<div class="kertas">
    <?= $this->include('laporan/_kop') ?>
    <h2 class="judul"><?= esc($judul ?? '') ?></h2>
    <?php if (! empty($subjudul)) : ?><div class="subjudul"><?= esc($subjudul) ?></div><?php endif ?>

    <?= $this->renderSection('isi') ?>

    <?php if (! empty($ttd)) : ?><?= $this->include('laporan/_ttd') ?><?php endif ?>
</div>
</body>
</html>
