<?php
/** @var \CodeIgniter\View\View $this */
use App\Libraries\Akses;
use App\Libraries\Kalender;

$tp     = tp_aktif();
$isWali = is_wali_kelas();
$isGuru = (bool) session()->get('guru_id');
$roles  = session('roles') ?? [];

/*
 * Struktur menu: item tunggal atau grup dropdown. Setiap item: [url, ikon, label, pola aktif|null, tampil(bool)].
 * Grup hanya tampil bila minimal satu itemnya tampil, dan otomatis terbuka bila memuat halaman aktif.
 */
$aktif = static fn (string $url, ?string $pola) => url_is($pola ?? (trim($url, '/') . '*'));
$menu = [
    ['item', ['dashboard', 'grid-1x2', 'Dashboard', 'dashboard', true]],
    ['grup', 'belajar', 'journal-bookmark', 'Pembelajaran', [
        ['jurnal', 'journal-check', 'Jurnal & Absensi Mapel', 'jurnal', $isGuru],
        ['jurnal/riwayat', 'clock-history', 'Riwayat Jurnal', null, $isGuru],
        ['atp', 'bullseye', 'ATP & Modul Ajar', 'atp*', $isGuru || Akses::punya('kurikulum', 'kepsek')],
        ['program', 'calendar2-range', 'Prota & Promes', 'program*', $isGuru],
        ['modul-ajar', 'journal-richtext', 'Modul Ajar', 'modul-ajar*', $isGuru],
        ['perangkat', 'folder-check', 'Perangkat Pembelajaran', 'perangkat', $isGuru],
        ['perangkat/pemeriksaan', 'clipboard-check', 'Pemeriksaan Perangkat', 'perangkat/pemeriksaan', Akses::perangkatLihatSemua()],
        ['kokurikuler', 'stars', 'Kokurikuler', 'kokurikuler*', true],
        ['jadwal', 'calendar-week', 'Lihat Jadwal', 'jadwal', true],
        ['kalender', 'calendar3-event', 'Kalender Akademik', 'kalender', true],
        ['jurnal/rekap-presensi', 'table', 'Rekap Absensi Mapel', null, Akses::rekapAbsensiMapelMenu()],
        ['jurnal/monitoring', 'binoculars', 'Monitoring Jurnal', null, Akses::jurnalMonitoring()],
    ]],
    ['grup', 'guru', 'person-badge', 'Kepegawaian', [
        ['izin-guru', 'envelope-check', 'Izin Guru', 'izin-guru*', $isGuru || Akses::izinGuruPutus()],
        ['guru-hadir', 'person-check', 'Kehadiran Guru', 'guru-hadir*', Akses::kehadiranGuruLihat()],
    ]],
    ['grup', 'siswa', 'people', 'Kesiswaan', [
        ['absensi-pagi', 'sunrise', 'Absensi Pagi', 'absensi-pagi', Akses::absensiMenu()],
        ['absensi-pagi/rekap', 'calendar3', 'Rekap Absensi Pagi', null, Akses::absensiMenu()],
        ['izin-siswa', 'envelope-paper', 'Izin & Sakit Siswa', 'izin-siswa*', Akses::absensiMenu()],
        ['gerbang', 'door-open', 'Pos Gerbang (Izin Keluar)', 'gerbang*', Akses::gerbang()],
        ['mutasi', 'arrow-left-right', 'Mutasi Siswa', 'mutasi*', Akses::mutasiLihat()],
        ['akun-siswa', 'person-badge', 'Akun Portal Siswa', 'akun-siswa*', Akses::masterData() || Akses::punya('kesiswaan') || $isWali],
        ['pembiasaan', 'check2-square', 'Pembiasaan Siswa', 'pembiasaan', Akses::pembiasaanMenu()],
        ['pembiasaan/rekap', 'bar-chart', 'Rekap Pembiasaan', null, Akses::pembiasaanMenu()],
        ['perilaku', 'person-exclamation', 'Catatan Perilaku', 'perilaku', true],
        ['perilaku/rekap', 'trophy', 'Rekap Poin Siswa', null, Akses::rekapPoin()],
    ]],
    ['grup', 'bk', 'heart-pulse', 'Bimbingan Konseling', [
        ['bk', 'speedometer2', 'Dashboard BK', 'bk', Akses::modulBk()],
        ['bk/rujukan', 'inbox', 'Rujukan Masuk', null, Akses::modulBk()],
        ['bk/layanan', 'chat-heart', 'Layanan BK', null, Akses::modulBk()],
    ]],
    ['item', ['laporan', 'printer', 'Cetak Laporan', 'laporan*', true]],
    ['item', ['excel', 'file-earmark-spreadsheet', 'Impor Data Excel', 'excel*', (bool) array_filter(array_keys(\App\Libraries\DataExcel::definisi()), [\App\Libraries\DataExcel::class, 'boleh'])]],
    ['label', 'Pengaturan'],
    ['grup', 'akademik', 'sliders', 'Pengaturan Akademik', [
        ['akademik/tahun-pelajaran', 'calendar-range', 'Tahun Pelajaran', null, Akses::pengaturanAkademik()],
        ['akademik/salin-semester', 'files', 'Salin dari Semester Lain', null, Akses::pengaturanAkademik()],
        ['akademik/kalender', 'calendar-event', 'Kalender & Libur', null, Akses::pengaturanAkademik()],
        ['akademik/jam-pelajaran', 'clock', 'Jam Pelajaran', null, Akses::pengaturanAkademik()],
        ['akademik/penugasan', 'person-workspace', 'Penugasan Guru', null, Akses::pengaturanAkademik()],
        ['akademik/jadwal', 'calendar-plus', 'Setting Jadwal', null, Akses::pengaturanAkademik()],
        ['akademik/piket', 'shield-check', 'Jadwal Guru Piket', null, Akses::pengaturanAkademik()],
        ['perangkat/jenis', 'list-task', 'Jenis Perangkat Pembelajaran', null, Akses::perangkatPeriksa()],
    ]],
    ['grup', 'referensi', 'list-check', 'Referensi Kesiswaan', [
        ['pembiasaan/master', 'list-check', 'Pengaturan Pembiasaan', null, Akses::referensiKesiswaan()],
        ['perilaku/jenis', 'list-ol', 'Jenis Perilaku & Poin', null, Akses::referensiKesiswaan()],
    ]],
    ['grup', 'master', 'database', 'Data Master', [
        ['master/siswa', 'people', 'Siswa', null, Akses::masterData()],
        ['master/guru', 'person-badge', 'Guru', null, Akses::masterData()],
        ['master/kelas', 'door-open', 'Kelas & Rombel', null, Akses::masterData()],
        ['master/mapel', 'book', 'Mata Pelajaran', null, Akses::masterData()],
        ['master/jurusan', 'diagram-3', 'Jurusan', null, Akses::masterData()],
        ['master/kenaikan-kelas/otomatis', 'lightning-charge', 'Kenaikan Kelas Otomatis', 'master/kenaikan-kelas/otomatis', Akses::masterData()],
        ['master/kenaikan-kelas', 'arrow-up-circle', 'Kenaikan Kelas Manual', 'master/kenaikan-kelas', Akses::masterData()],
    ]],
    ['grup', 'sistem', 'gear', 'Sistem', [
        ['sistem/pengguna', 'person-gear', 'Pengguna & Role', null, Akses::admin()],
        ['sistem/pengaturan', 'building-gear', 'Pengaturan Sekolah', null, Akses::admin()],
        ['sistem/backup', 'database-down', 'Backup Database', null, Akses::admin()],
        ['sistem/aset', 'wifi-off', 'Aset Offline', null, Akses::admin()],
        ['sistem/log', 'list-columns', 'Log Aktivitas', null, Akses::admin()],
    ]],
];
$link = static fn (array $i) => '<a href="' . site_url($i[0]) . '"' . (url_is($i[3] ?? (trim($i[0], '/') . '*')) ? ' class="active" aria-current="page"' : '') . '><i class="bi bi-' . $i[1] . '"></i><span>' . esc($i[2]) . '</span></a>';

$hariIni   = $tp ? Kalender::status(date('Y-m-d')) : null;
$labelRole = ['admin' => 'Admin', 'kepsek' => 'Kepala Sekolah', 'kurikulum' => 'Kurikulum', 'kesiswaan' => 'Kesiswaan', 'guru' => 'Guru', 'piket' => 'Guru Piket', 'bk' => 'Guru BK', 'tu' => 'Tata Usaha', 'satpam' => 'Satpam'];
$teksRole  = implode(', ', array_map(static fn ($r) => $labelRole[$r] ?? $r, $roles)) . ($isWali ? ', Wali Kelas' : '');
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="theme-color" content="#0f2557">
    <title><?= esc($title ?? 'Administrasi Pembelajaran') ?> · <?= esc(nama_aplikasi()) ?></title>
    <link rel="icon" href="<?= esc(logo_url() ?? base_url('favicon.svg')) ?>">
    <link rel="stylesheet" href="<?= aset('bootstrap-css') ?>">
    <link rel="stylesheet" href="<?= aset('bi-css') ?>">
    <link rel="stylesheet" href="<?= aset('tom-css') ?>">
    <link rel="stylesheet" href="<?= tema_css() ?>">
    <?= $this->renderSection('head') ?>
</head>
<body>
<aside class="sis-sidebar" id="sidebar" aria-label="Menu utama">
    <a href="<?= site_url('dashboard') ?>" class="sis-brand">
        <img src="<?= logo_aplikasi() ?>" alt="">
        <div><div class="nama"><?= esc(nama_aplikasi()) ?></div><div class="sub">Administrasi Pembelajaran</div></div>
    </a>
    <div class="sis-sekolah">
        <?php if ($lg = logo_url()) : ?><img src="<?= esc($lg) ?>" alt="Logo sekolah"><?php endif ?>
        <div class="min-w-0">
            <div class="nm"><?= esc(setting('nama_sekolah', 'Nama sekolah belum diatur')) ?></div>
            <div class="tp"><?= $tp ? 'TP ' . esc($tp['tahun_pelajaran']) . ' · ' . esc($tp['semester']) : 'TP aktif belum diatur' ?></div>
        </div>
    </div>
    <nav class="sis-nav">
        <?php foreach ($menu as $m) :
            if ($m[0] === 'item') {
                echo $m[1][4] ? $link($m[1]) : '';
                continue;
            }
            if ($m[0] === 'label') {
                // label hanya bila ada grup sesudahnya yang tampil
                $ada = false;
                foreach (array_slice($menu, array_search($m, $menu, true) + 1) as $n) {
                    $ada = $ada || ($n[0] === 'grup' && array_filter($n[4], static fn ($i) => $i[4]));
                }
                echo $ada ? '<div class="label">' . esc($m[1]) . '</div>' : '';
                continue;
            }
            [, $id, $ikon, $judul, $items] = $m;
            $items = array_values(array_filter($items, static fn ($i) => $i[4]));
            if (! $items) {
                continue;
            }
            $buka = (bool) array_filter($items, static fn ($i) => url_is($i[3] ?? (trim($i[0], '/') . '*')));
        ?>
            <button class="grup-btn" type="button" data-bs-toggle="collapse" data-bs-target="#grup-<?= $id ?>" aria-expanded="<?= $buka ? 'true' : 'false' ?>" aria-controls="grup-<?= $id ?>">
                <i class="bi bi-<?= $ikon ?>"></i><span><?= esc($judul) ?></span><i class="bi bi-chevron-right chev"></i>
            </button>
            <div class="collapse<?= $buka ? ' show' : '' ?>" id="grup-<?= $id ?>" data-grup="<?= $id ?>">
                <div class="grup-isi"><?php foreach ($items as $i) : ?><?= $link($i) ?><?php endforeach ?></div>
            </div>
        <?php endforeach ?>
    </nav>
    <div class="sis-sidebar-foot"><?= esc(nomor_sekolah() ?: 'SIS Sekolah') ?></div>
</aside>
<div class="sis-backdrop" onclick="document.body.classList.remove('sidebar-buka')"></div>

<div class="sis-main">
    <header class="sis-topbar no-print">
        <button class="burger" type="button" aria-label="Buka menu" onclick="document.body.classList.toggle('sidebar-buka')"><i class="bi bi-list"></i></button>
        <div class="d-flex align-items-center gap-2 flex-wrap">
            <span class="sis-chip abu chip-opsional"><i class="bi bi-calendar2-week"></i><?= tgl_indo(date('Y-m-d'), true) ?></span>
            <?php if ($hariIni) : ?>
                <a href="<?= site_url('kalender') ?>" class="sis-chip <?= $hariIni['kbm'] ? 'hijau' : ($hariIni['sekolah'] ? 'emas' : 'abu') ?> text-decoration-none chip-opsional" title="<?= esc($hariIni['label']) ?>">
                    <i class="bi bi-<?= $hariIni['kbm'] ? 'check-circle' : 'pause-circle' ?>"></i><?= $hariIni['kbm'] ? 'Hari efektif' : esc(mb_strimwidth($hariIni['label'], 0, 40, '…')) ?></a>
            <?php endif ?>
        </div>
        <div class="ms-auto dropdown">
            <a href="#" class="sis-user" data-bs-toggle="dropdown" aria-expanded="false">
                <div class="text-end teks"><div class="nm"><?= esc(session('nama_lengkap')) ?></div><div class="rl"><?= esc($teksRole) ?></div></div>
                <div class="sis-avatar"><?= esc(strtoupper(mb_substr(session('nama_lengkap') ?? 'U', 0, 1))) ?></div>
            </a>
            <ul class="dropdown-menu dropdown-menu-end">
                <li class="px-2 py-1 d-md-none"><div class="fw-bold small"><?= esc(session('nama_lengkap')) ?></div><div class="small text-muted"><?= esc($teksRole) ?></div></li>
                <li class="d-md-none"><hr class="dropdown-divider"></li>
                <li><a class="dropdown-item" href="<?= site_url('profil') ?>"><i class="bi bi-person-circle me-2"></i>Profil & Password</a></li>
                <li><a class="dropdown-item" href="<?= site_url('kalender') ?>"><i class="bi bi-calendar3-event me-2"></i>Kalender Akademik</a></li>
                <li><hr class="dropdown-divider"></li>
                <li><a class="dropdown-item text-danger" href="<?= site_url('logout') ?>"><i class="bi bi-box-arrow-right me-2"></i>Keluar</a></li>
            </ul>
        </div>
    </header>

    <main class="sis-content">
        <div class="page-heading">
            <div class="d-flex flex-wrap justify-content-between align-items-start gap-2">
                <div>
                    <h3><?= esc($title ?? '') ?></h3>
                    <?php if (! empty($subtitle)) : ?><p class="text-subtitle mb-0"><?= esc($subtitle) ?></p><?php endif ?>
                </div>
                <div class="no-print d-flex flex-wrap gap-2"><?= $this->renderSection('actions') ?></div>
            </div>
        </div>
        <?php if (session('password_lemah') && ! url_is('profil')) : ?>
            <div class="alert py-2 alert-warning banner-password"><i class="bi bi-shield-exclamation"></i> Password akun Anda masih bawaan/mudah ditebak. <a href="<?= site_url('profil') ?>" class="alert-link">Ganti sekarang</a>.</div>
        <?php endif ?>
        <?= $this->include('partials/flash') ?>
        <?= $this->renderSection('content') ?>
    </main>

    <footer class="sis-footer no-print">
        <span>&copy; <?= date('Y') ?> <?= esc(setting('nama_sekolah', '')) ?></span>
        <span><?= esc(nama_aplikasi()) ?></span>
    </footer>
</div>

<script src="<?= aset('bootstrap-js') ?>"></script>
<script src="<?= aset('tom-js') ?>"></script>
<script>
    document.querySelectorAll('select.tom').forEach(function (el) {
        if (window.TomSelect) new TomSelect(el, { plugins: el.multiple ? ['remove_button'] : [], maxOptions: 2000, allowEmptyOption: true });
    });
    // menu dropdown: hanya satu grup terbuka sekaligus, dan posisi gulir menu diingat
    document.querySelectorAll('.sis-nav .collapse').forEach(function (el) {
        el.addEventListener('show.bs.collapse', function () {
            document.querySelectorAll('.sis-nav .collapse.show').forEach(function (o) { if (o !== el && window.bootstrap) bootstrap.Collapse.getOrCreateInstance(o, {toggle: false}).hide(); });
        });
    });
    (function () {
        var nav = document.querySelector('.sis-nav');
        try { nav.scrollTop = +sessionStorage.getItem('sisNav') || 0; } catch (e) {}
        window.addEventListener('beforeunload', function () { try { sessionStorage.setItem('sisNav', nav.scrollTop); } catch (e) {} });
    })();
    // jaga sesi tetap hidup selama halaman berformulir terbuka (guru mengisi absensi sambil mengajar)
    if (document.querySelector('form[method="post"]')) {
        setInterval(function () { fetch('<?= site_url('ping') ?>', {headers: {'X-Requested-With': 'XMLHttpRequest'}, credentials: 'same-origin'}).catch(function () {}); }, 10 * 60 * 1000);
    }
</script>
<?= $this->renderSection('scripts') ?>
</body>
</html>
