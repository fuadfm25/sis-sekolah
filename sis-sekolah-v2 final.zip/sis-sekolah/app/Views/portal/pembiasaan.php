<?= $this->extend('layouts/portal') ?>
<?= $this->section('content') ?>
<?php $dari = $ym . '-01'; $sebelum = date('Y-m', strtotime($dari . ' -1 month')); $sesudah = date('Y-m', strtotime($dari . ' +1 month')); ?>
<div class="card"><div class="card-header"><h6 class="mb-2">Isi pembiasaan</h6>
    <div class="d-flex flex-wrap gap-1">
        <?php foreach ($pilihan as $d) : ?><a href="?tanggal=<?= $d ?>" class="btn btn-sm <?= $d === $tanggal ? 'btn-primary' : 'btn-light' ?>"><?= $d === date('Y-m-d') ? 'Hari ini' : esc(nama_hari((int) date('N', strtotime($d))) . ', ' . (int) substr($d, 8)) ?></a><?php endforeach ?>
    </div>
</div><div class="card-body">
    <?php if (! $isian) : ?>
        <p class="text-muted mb-0">Tidak ada kegiatan pembiasaan yang perlu kamu isi pada <?= tgl_indo($tanggal, true) ?>.</p>
    <?php else : ?>
    <form method="post" action="<?= site_url('portal/pembiasaan') ?>"><?= csrf_field() ?><input type="hidden" name="tanggal" value="<?= $tanggal ?>">
        <?php foreach ($isian as $p) : $r = $ada[$p['id']] ?? null; $kunci = $r && ($r['sumber'] === 'Guru' || ! empty($r['diverifikasi_oleh']));
            $centang = $r ? ($r['sumber'] === 'Siswa' ? (int) $r['lapor_siswa'] : (int) $r['terlaksana']) : 0; ?>
            <div class="border rounded p-2 mb-2 <?= $kunci ? 'bg-body-tertiary' : '' ?>">
                <div class="form-check d-flex justify-content-between gap-2">
                    <div><input class="form-check-input" type="checkbox" name="cek[<?= $p['id'] ?>]" value="1" id="pb<?= $p['id'] ?>" <?= $centang ? 'checked' : '' ?> <?= $kunci ? 'disabled' : '' ?>>
                        <label class="form-check-label fw-semibold" for="pb<?= $p['id'] ?>"><?= esc($p['nama']) ?></label>
                        <div class="small text-muted"><?= esc($p['deskripsi'] ?? '') ?> <span class="badge text-bg-light border"><?= $p['tempat'] === 'Rumah' ? 'di rumah' : 'di sekolah' ?></span></div></div>
                    <div class="text-end small text-nowrap">
                        <?php if ($r && $r['verifikasi'] === 'Menunggu') : ?><span class="badge text-bg-warning">menunggu wali kelas</span>
                        <?php elseif ($r && $r['verifikasi'] === 'Ditolak') : ?><span class="badge text-bg-danger">ditolak</span>
                        <?php elseif ($r && $kunci) : ?><span class="badge text-bg-<?= (int) $r['terlaksana'] ? 'success' : 'secondary' ?>"><?= (int) $r['terlaksana'] ? 'sah' : 'tidak terlaksana' ?></span><?php endif ?>
                    </div>
                </div>
                <?php if ($p['petunjuk_catatan'] || (int) $p['wajib_catatan']) : ?>
                    <input name="catatan[<?= $p['id'] ?>]" class="form-control form-control-sm mt-2" maxlength="150" value="<?= esc($r['keterangan'] ?? '') ?>" <?= $kunci ? 'disabled' : '' ?>
                        placeholder="<?= esc(($p['petunjuk_catatan'] ?: 'Keterangan') . ((int) $p['wajib_catatan'] ? ' (wajib)' : ' (opsional)')) ?>">
                <?php endif ?>
            </div>
        <?php endforeach ?>
        <button class="btn btn-primary w-100 mt-1"><i class="bi bi-check2-circle"></i> Simpan</button>
        <div class="small text-muted mt-2">Isi dengan jujur. Kegiatan yang perlu verifikasi baru dihitung setelah disetujui wali kelas.</div>
    </form>
    <?php endif ?>
</div></div>

<div class="card"><div class="card-header d-flex justify-content-between align-items-center">
    <a href="?bulan=<?= $sebelum ?>" class="btn btn-sm btn-light"><i class="bi bi-chevron-left"></i></a>
    <h6><?= bulan_list()[(int) substr($ym, 5)] . ' ' . substr($ym, 0, 4) ?></h6>
    <a href="?bulan=<?= $sesudah ?>" class="btn btn-sm btn-light"><i class="bi bi-chevron-right"></i></a>
</div><div class="card-body">
    <?php if (! $daftar) : ?><p class="text-muted mb-0">Belum ada daftar pembiasaan.</p><?php else : ?>
    <?php foreach ($daftar as $p) : $isi = $data[$p['id']] ?? []; $sah = array_filter($isi, 'is_int'); $n = count($sah); $ya = array_sum($sah); $pct = $n ? round($ya / $n * 100) : null; ?>
        <div class="mb-3">
            <div class="d-flex justify-content-between"><span class="fw-semibold"><?= esc($p['nama']) ?></span><span class="small text-muted"><?= $n ? "{$ya}/{$n} hari · {$pct}%" : 'belum dicatat' ?></span></div>
            <div class="progress mt-1" style="height:8px"><div class="progress-bar <?= $pct !== null && $pct < 60 ? 'bg-warning' : '' ?>" style="width:<?= (int) $pct ?>%"></div></div>
            <div class="d-flex flex-wrap gap-1 mt-2">
                <?php foreach ($tgl as $d) : $v = $isi[$d] ?? null; ?>
                    <span class="badge <?= $v === 1 ? 'bg-success' : ($v === 0 ? 'bg-light-danger text-danger' : ($v === 'm' ? 'text-bg-warning' : 'bg-light-secondary text-muted')) ?>" title="<?= $d ?>"><?= $d ?></span>
                <?php endforeach ?>
            </div>
        </div>
    <?php endforeach ?>
    <div class="small text-muted">Hijau = terlaksana · kuning = menunggu verifikasi · merah = tidak terlaksana · abu-abu = belum dicatat.</div>
    <?php endif ?>
</div></div>
<?= $this->endSection() ?>
