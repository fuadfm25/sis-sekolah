<?= $this->extend('layouts/portal') ?>
<?= $this->section('content') ?>
<?php if (empty($siswa['kelas'])) : ?>
    <div class="alert alert-light border">Anda belum terdaftar di kelas mana pun pada tahun pelajaran aktif.</div>
<?php else : ?>
<div class="card"><div class="card-body table-responsive">
    <p class="small text-muted">Kelas <b><?= esc($siswa['kelas']['nama_kelas']) ?></b> · jadwal yang berlaku hari ini.</p>
    <?= $this->setData(['edit' => false, 'mode' => 'kelas'])->include('akademik/jadwal/_grid') ?>
</div></div>
<?php endif ?>
<?= $this->endSection() ?>
