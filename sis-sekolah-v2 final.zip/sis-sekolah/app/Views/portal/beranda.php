<?= $this->extend('layouts/portal') ?>
<?= $this->section('content') ?>
<?php $jamS = (int) date('G'); $sapa = $jamS < 11 ? 'Selamat pagi' : ($jamS < 15 ? 'Selamat siang' : ($jamS < 18 ? 'Selamat sore' : 'Selamat malam')); ?>
<div class="sis-hero mb-4">
    <div>
        <div class="kecil"><?= tgl_indo(date('Y-m-d'), true) ?></div>
        <h2><?= $sapa ?>, <?= esc(explode(' ', trim($siswa['nama_lengkap']))[0]) ?>!</h2>
        <p class="mb-0">Kelas <?= esc($siswa['kelas']['nama_kelas'] ?? '-') ?><?= $tp ? ' · TP ' . esc($tp['tahun_pelajaran']) . ' ' . esc($tp['semester']) : '' ?> · NIS <?= esc($siswa['nis']) ?></p>
    </div>
</div>
<?php if ($status && ($status['agenda'] || ! $status['sekolah'])) : ?>
    <div class="alert alert-info py-2"><i class="bi bi-calendar-event me-1"></i>Hari ini: <b><?= esc($status['label']) ?></b></div>
<?php endif ?>
<div class="row g-3 mb-1">
    <?php $tot = array_sum($hadir); $h = ($hadir['H'] ?? 0) + ($hadir['T'] ?? 0); ?>
    <?php foreach ([
        ['Kehadiran bulan ini', $tot ? round($h / $tot * 100) . '%' : '–', 'calendar-check', 'hijau', 'portal/kehadiran'],
        ['Sakit / Izin / Alpa', ($hadir['S'] ?? 0) . ' / ' . ($hadir['I'] ?? 0) . ' / ' . ($hadir['A'] ?? 0), 'clipboard-x', 'merah', 'portal/kehadiran'],
        ['Poin positif / pelanggaran', (int) ($poin['Positif'] ?? 0) . ' / ' . (int) ($poin['Negatif'] ?? 0), 'award', 'emas', 'portal/perilaku'],
        ['Pembiasaan 30 hari', $pembiasaan === null ? '–' : $pembiasaan . '%', 'check2-square', 'biru', 'portal/pembiasaan'],
    ] as [$l, $v, $ik, $w, $u]) : ?>
        <div class="col-6 col-lg-3"><a href="<?= site_url($u) ?>" class="text-decoration-none"><div class="card h-100"><div class="card-body stat-card">
            <div class="stat-ikon <?= $w ?>"><i class="bi bi-<?= $ik ?>"></i></div><div><div class="small text-muted fw-semibold"><?= $l ?></div><div class="stat-angka text-body"><?= esc($v) ?></div></div>
        </div></div></a></div>
    <?php endforeach ?>
</div>
<div class="row g-3 mt-1">
    <div class="col-lg-5">
        <div class="card h-100"><div class="card-header d-flex justify-content-between"><h6>Pelajaran hari ini</h6><a href="<?= site_url('portal/jadwal') ?>" class="small">Jadwal lengkap</a></div>
            <div class="card-body">
                <?php if (! $sesi) : ?><p class="text-muted mb-0">Tidak ada pelajaran hari ini.</p><?php endif ?>
                <?php foreach ($sesi as $x) : ?>
                    <div class="d-flex gap-3 align-items-center mb-3">
                        <div class="text-center" style="min-width:58px"><div class="fw-bold"><?= jam($x['jam_mulai']) ?></div><div class="small text-muted"><?= jam($x['jam_selesai']) ?></div></div>
                        <div><div class="fw-semibold"><?= esc($x['nama_mapel']) ?></div><div class="small text-muted"><?= esc(nama_guru($x)) ?> · jam ke-<?= esc($x['jam_ke_label']) ?></div></div>
                    </div>
                <?php endforeach ?>
            </div></div>
    </div>
    <div class="col-lg-7">
        <div class="card h-100"><div class="card-header d-flex justify-content-between"><h6>Materi terbaru</h6><a href="<?= site_url('portal/materi') ?>" class="small">Semua materi</a></div>
            <div class="card-body">
                <?php if (! $materi) : ?><p class="text-muted mb-0">Belum ada materi tercatat.</p><?php endif ?>
                <?php foreach ($materi as $m) : ?>
                    <div class="materi-item"><div class="meta"><?= tgl_indo($m['tanggal'], true) ?> · <?= esc($m['nama_mapel']) ?></div><div class="fw-semibold"><?= esc($m['materi']) ?></div></div>
                <?php endforeach ?>
            </div></div>
    </div>
</div>
<?= $this->endSection() ?>
