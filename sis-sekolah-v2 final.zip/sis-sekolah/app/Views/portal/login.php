<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="theme-color" content="#0f2557">
    <title>Portal Siswa · <?= esc(setting('nama_sekolah', nama_aplikasi())) ?></title>
    <link rel="icon" href="<?= esc(logo_url() ?? base_url('favicon.svg')) ?>">
    <link rel="stylesheet" href="<?= aset('bootstrap-css') ?>">
    <link rel="stylesheet" href="<?= aset('bi-css') ?>">
    <link rel="stylesheet" href="<?= tema_css() ?>">
</head>
<body>
<div class="sis-login">
    <section class="panel">
        <div class="d-flex align-items-center gap-2">
            <img src="<?= esc(logo_url() ?? logo_aplikasi()) ?>" alt="" width="44" height="44" style="border-radius:12px;background:#fff;padding:3px;object-fit:contain">
            <div><div class="fw-bold fs-5 lh-1"><?= esc(setting('nama_sekolah', nama_aplikasi())) ?></div><div class="small" style="color:rgba(255,255,255,.6)">Portal Siswa</div></div>
        </div>
        <div class="my-4">
            <h1>Pantau <span>belajarmu</span> setiap hari.</h1>
            <p class="mt-3">Lihat jadwal pelajaran, materi yang sudah dipelajari, kehadiran, catatan perilaku, dan pembiasaan – bisa juga dibuka bersama orang tua.</p>
            <div class="fitur">
                <div><i class="bi bi-calendar-week"></i>Jadwal pelajaran kelasmu</div>
                <div><i class="bi bi-journal-text"></i>Materi & tujuan pembelajaran tiap pertemuan</div>
                <div><i class="bi bi-award"></i>Catatan perilaku & pembiasaan</div>
            </div>
        </div>
        <div class="small bawah" style="color:rgba(255,255,255,.5)">Guru/staf? <a href="<?= site_url('login') ?>" class="text-white">Masuk di sini</a></div>
    </section>
    <section class="form-sisi">
        <div class="kotak">
            <div class="card"><div class="card-body p-4">
                <h3 class="h5 fw-bold mb-1">Masuk Portal Siswa</h3>
                <p class="small text-muted mb-3">Gunakan NISN atau NIS.</p>
                <?= view('partials/flash') ?>
                <?php if (! $aktif) : ?>
                    <div class="alert alert-warning">Portal siswa sedang dinonaktifkan oleh sekolah.</div>
                <?php else : ?>
                <form method="post" action="<?= site_url('portal/login') ?>"><?= csrf_field() ?>
                    <div class="mb-3"><label class="form-label" for="u">NISN / NIS</label>
                        <div class="input-group"><span class="input-group-text"><i class="bi bi-person-vcard"></i></span>
                            <input id="u" name="username" class="form-control" inputmode="numeric" value="<?= esc(old('username')) ?>" required autofocus autocomplete="username"></div></div>
                    <div class="mb-4"><label class="form-label" for="p">Password</label>
                        <div class="input-group"><span class="input-group-text"><i class="bi bi-lock"></i></span>
                            <input id="p" type="password" name="password" class="form-control" required autocomplete="current-password"></div>
                        <div class="form-text">Pertama kali masuk? Password = tanggal lahir (ddmmyyyy), mis. <b>17052013</b>.</div></div>
                    <button class="btn btn-primary w-100">Masuk <i class="bi bi-arrow-right ms-1"></i></button>
                </form>
                <?php endif ?>
            </div></div>
            <p class="text-center small text-muted mt-3 mb-0">Lupa password? Hubungi wali kelas untuk reset.</p>
        </div>
    </section>
</div>
</body>
</html>
