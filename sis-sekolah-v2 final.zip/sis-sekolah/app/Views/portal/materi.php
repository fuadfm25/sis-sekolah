<?= $this->extend('layouts/portal') ?>
<?= $this->section('content') ?>
<div class="card"><div class="card-body py-3">
    <form method="get" class="d-flex gap-2 align-items-center filter">
        <select name="mapel" class="form-select w-auto" onchange="this.form.submit()"><option value="">Semua mata pelajaran</option>
            <?php foreach ($daftarMapel as $m) : ?><option value="<?= $m['id'] ?>" <?= $mapel == $m['id'] ? 'selected' : '' ?>><?= esc($m['nama_mapel']) ?></option><?php endforeach ?></select>
    </form>
</div></div>
<div class="card"><div class="card-body">
    <?php if (! $rows) : ?><p class="text-muted mb-0">Belum ada materi yang tercatat.</p><?php endif ?>
    <?php $badge = ['H' => ['success', 'Hadir'], 'S' => ['info', 'Sakit'], 'I' => ['primary', 'Izin'], 'A' => ['danger', 'Alpa'], 'D' => ['secondary', 'Dispensasi']]; ?>
    <?php foreach ($rows as $r) : ?>
        <div class="materi-item">
            <div class="meta"><?= tgl_indo($r['tanggal'], true) ?> · jam ke-<?= esc($r['jam_ke']) ?><?= $r['pertemuan_ke'] ? ' · pertemuan ke-' . (int) $r['pertemuan_ke'] : '' ?></div>
            <div class="d-flex flex-wrap gap-2 align-items-center"><span class="fw-bold"><?= esc($r['nama_mapel']) ?></span><span class="small text-muted"><?= esc(nama_guru($r)) ?></span>
                <?php if ($r['hadir'] && isset($badge[$r['hadir']])) : ?><span class="badge bg-<?= $badge[$r['hadir']][0] ?>"><?= $badge[$r['hadir']][1] ?></span><?php endif ?>
                <?php if ($r['status_kbm'] !== 'Terlaksana') : ?><span class="badge bg-light-warning text-dark"><?= esc($r['status_kbm']) ?></span><?php endif ?></div>
            <div class="mt-1"><b>Materi:</b> <?= esc($r['materi']) ?></div>
            <?php if ($r['tujuan_pembelajaran']) : ?><div class="small"><b>Tujuan:</b> <?= nl2br(esc($r['tujuan_pembelajaran'])) ?></div><?php endif ?>
            <?php if ($r['kegiatan']) : ?><div class="small text-muted"><b>Kegiatan:</b> <?= nl2br(esc($r['kegiatan'])) ?></div><?php endif ?>
            <?php if ($r['penilaian']) : ?><div class="small text-muted"><b>Penilaian/tugas:</b> <?= esc($r['penilaian']) ?></div><?php endif ?>
        </div>
    <?php endforeach ?>
</div></div>
<?= $this->endSection() ?>
