<?= $this->extend('layouts/portal') ?>
<?= $this->section('content') ?>
<div class="row g-3 mb-1">
    <div class="col-6"><div class="card"><div class="card-body stat-card"><div class="stat-ikon hijau"><i class="bi bi-hand-thumbs-up"></i></div><div><div class="small text-muted fw-semibold">Poin positif</div><div class="stat-angka"><?= $tot['Positif'] ?></div></div></div></div></div>
    <div class="col-6"><div class="card"><div class="card-body stat-card"><div class="stat-ikon merah"><i class="bi bi-exclamation-triangle"></i></div><div><div class="small text-muted fw-semibold">Poin pelanggaran</div><div class="stat-angka"><?= $tot['Negatif'] ?></div></div></div></div></div>
</div>
<div class="card"><div class="card-body">
    <?php if (! $rows) : ?><p class="text-muted mb-0">Belum ada catatan perilaku. Pertahankan!</p><?php endif ?>
    <?php foreach ($rows as $r) : $pos = $r['kategori'] === 'Positif'; ?>
        <div class="d-flex gap-3 mb-3 pb-3 border-bottom">
            <div class="stat-ikon <?= $pos ? 'hijau' : 'merah' ?>" style="width:40px;height:40px;font-size:1.05rem"><i class="bi bi-<?= $pos ? 'star' : 'flag' ?>"></i></div>
            <div class="flex-grow-1">
                <div class="d-flex justify-content-between gap-2"><b><?= esc($r['perilaku'] ?: $r['kategori']) ?></b><span class="badge bg-<?= $pos ? 'success' : 'danger' ?>"><?= $pos ? '+' : '−' ?><?= (int) $r['poin'] ?></span></div>
                <div class="small text-muted"><?= tgl_indo($r['tanggal'], true) ?><?= $r['pencatat'] ? ' · dicatat oleh ' . esc($r['pencatat']) : '' ?> · <?= esc($r['status']) ?></div>
                <?php if ($r['deskripsi']) : ?><div class="small mt-1"><?= nl2br(esc($r['deskripsi'])) ?></div><?php endif ?>
            </div>
        </div>
    <?php endforeach ?>
</div></div>
<?= $this->endSection() ?>
