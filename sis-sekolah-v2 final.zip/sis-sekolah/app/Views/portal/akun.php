<?= $this->extend('layouts/portal') ?>
<?= $this->section('content') ?>
<div class="row g-3">
    <div class="col-lg-6"><div class="card"><div class="card-header"><h6>Ganti password</h6></div><div class="card-body">
        <?php if ($wajib) : ?><div class="alert alert-warning small">Anda masih memakai password bawaan. Buat password baru agar data Anda aman.</div><?php endif ?>
        <form method="post" action="<?= site_url('portal/akun') ?>"><?= csrf_field() ?>
            <div class="mb-2"><label class="form-label">Password lama</label><input type="password" name="password_lama" class="form-control" required>
                <?php if ($wajib) : ?><div class="form-text">Password bawaan: <?= esc(\App\Libraries\PortalSiswa::petunjukBawaan($siswa)) ?>.</div><?php endif ?></div>
            <div class="mb-2"><label class="form-label">Password baru (min. 6 karakter)</label><input type="password" name="password_baru" class="form-control" minlength="6" required></div>
            <div class="mb-3"><label class="form-label">Ulangi password baru</label><input type="password" name="konfirmasi" class="form-control" minlength="6" required></div>
            <button class="btn btn-primary">Simpan</button>
        </form>
    </div></div></div>
    <div class="col-lg-6"><div class="card"><div class="card-header"><h6>Data saya</h6></div><div class="card-body">
        <table class="table table-sm mb-0">
            <tr><td class="text-muted">Nama</td><td><?= esc($siswa['nama_lengkap']) ?></td></tr>
            <tr><td class="text-muted">NIS / NISN</td><td><?= esc($siswa['nis']) ?> / <?= esc($siswa['nisn'] ?: '-') ?></td></tr>
            <tr><td class="text-muted">Kelas</td><td><?= esc($siswa['kelas']['nama_kelas'] ?? '-') ?></td></tr>
            <tr><td class="text-muted">Tempat, tgl lahir</td><td><?= esc($siswa['tempat_lahir'] ?: '-') ?>, <?= $siswa['tanggal_lahir'] ? tgl_indo($siswa['tanggal_lahir']) : '-' ?></td></tr>
            <tr><td class="text-muted">Wali</td><td><?= esc($siswa['nama_wali'] ?: '-') ?></td></tr>
        </table>
        <p class="small text-muted mt-2 mb-0">Data tidak sesuai? Sampaikan ke wali kelas.</p>
    </div></div></div>
</div>
<?= $this->endSection() ?>
