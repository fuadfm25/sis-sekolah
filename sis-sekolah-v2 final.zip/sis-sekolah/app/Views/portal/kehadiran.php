<?= $this->extend('layouts/portal') ?>
<?= $this->section('content') ?>
<?php
$w = ['H' => ['success', 'Hadir'], 'T' => ['warning', 'Terlambat'], 'S' => ['info', 'Sakit'], 'I' => ['primary', 'Izin'], 'A' => ['danger', 'Alpa']];
$hit = array_count_values(array_column($data, 'status'));
$sebelum = date('Y-m', strtotime($dari . ' -1 month')); $sesudah = date('Y-m', strtotime($dari . ' +1 month'));
?>
<div class="card"><div class="card-header d-flex justify-content-between align-items-center">
    <a href="?bulan=<?= $sebelum ?>" class="btn btn-sm btn-light"><i class="bi bi-chevron-left"></i></a>
    <h6><?= bulan_list()[(int) substr($ym, 5)] . ' ' . substr($ym, 0, 4) ?></h6>
    <a href="?bulan=<?= $sesudah ?>" class="btn btn-sm btn-light"><i class="bi bi-chevron-right"></i></a>
</div><div class="card-body">
    <div class="d-flex flex-wrap gap-2 mb-3"><?php foreach ($w as $k => [$c, $l]) : ?><span class="badge bg-<?= $c ?>"><?= $l ?>: <?= $hit[$k] ?? 0 ?></span><?php endforeach ?></div>
    <div class="table-responsive"><table class="table table-bordered kal-mini mb-0">
        <thead><tr><?php foreach (['Sen', 'Sel', 'Rab', 'Kam', 'Jum', 'Sab', 'Min'] as $h) : ?><th class="text-center"><?= $h ?></th><?php endforeach ?></tr></thead><tbody>
        <?php $mulai = strtotime('monday this week', strtotime($dari)); $akhir = strtotime('sunday this week', strtotime(date('Y-m-t', strtotime($dari))));
        for ($t = $mulai; $t <= $akhir; $t += 86400) : $d = date('Y-m-d', $t); if (date('N', $t) == 1) echo '<tr>';
            $st = $hari[$d] ?? null; $x = $data[$d] ?? null; ?>
            <td class="<?= ! $st ? 'text-muted bg-light' : (! $st['absensi'] ? 'bg-light' : '') ?>">
                <div class="fw-bold"><?= (int) date('j', $t) ?></div>
                <?php if ($x) : ?><span class="badge bg-<?= $w[$x['status']][0] ?? 'secondary' ?>"><?= $w[$x['status']][1] ?? $x['status'] ?></span><?= $x['jam_datang'] ? '<div class="small text-muted">' . jam($x['jam_datang']) . '</div>' : '' ?>
                <?php elseif ($st && $st['agenda'] && ! $st['absensi']) : ?><div class="small text-muted"><?= esc(mb_strimwidth($st['agenda'][0]['nama'], 0, 22, '…')) ?></div><?php endif ?>
            </td>
        <?php if (date('N', $t) == 7) echo '</tr>'; endfor ?>
        </tbody></table></div>
</div></div>
<?= $this->endSection() ?>
