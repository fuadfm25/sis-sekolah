<?= $this->extend('layouts/main') ?>
<?= $this->section('actions') ?>
<form method="post" action="<?= site_url('sistem/backup/buat') ?>"><?= csrf_field() ?><button class="btn btn-primary"><i class="bi bi-database-down"></i> Buat Backup Sekarang</button></form>
<?= $this->endSection() ?>
<?= $this->section('content') ?>
<div class="row">
    <div class="col-lg-7">
        <div class="card"><div class="card-body table-responsive">
            <table class="table table-sm align-middle">
                <thead><tr><th>File</th><th>Waktu</th><th class="text-end">Ukuran</th><th></th></tr></thead>
                <tbody>
                <?php foreach ($files as $f) : ?>
                    <tr><td><code><?= esc($f['nama']) ?></code></td><td><?= date('d-m-Y H:i', $f['waktu']) ?></td><td class="text-end"><?= number_format($f['ukuran'] / 1024, 1) ?> KB</td>
                        <td class="text-end text-nowrap"><a href="<?= site_url('sistem/backup/unduh/' . $f['nama']) ?>" class="btn btn-sm btn-outline-primary"><i class="bi bi-download"></i></a>
                            <?= delete_button('sistem/backup/hapus/' . $f['nama'], '', 'Hapus file backup ini?') ?></td></tr>
                <?php endforeach ?>
                <?php if (! $files) : ?><tr><td colspan="4" class="text-center text-muted">Belum ada backup.</td></tr><?php endif ?>
                </tbody>
            </table>
        </div></div>
    </div>
    <div class="col-lg-5">
        <div class="card"><div class="card-body small">
            <h6>Backup otomatis harian</h6>
            <p>Jadwalkan perintah berikut setiap hari (mis. pukul 15.00):</p>
            <p class="mb-1"><b>Windows (Task Scheduler)</b> – Program: <code>C:\xampp\php\php.exe</code>, Argumen: <code>spark db:backup</code>, Mulai di: <code><?= esc(rtrim(ROOTPATH, '/\\')) ?></code></p>
            <p><b>Linux (cron)</b>: <code>0 15 * * * cd <?= esc(rtrim(ROOTPATH, '/')) ?> && php spark db:backup</code></p>
            <p>Otomatis menyisakan 14 file terbaru. File tersimpan di <code>writable/backups</code> (tidak dapat diakses dari browser).</p>
            <h6>Memulihkan</h6>
            <p class="mb-0">phpMyAdmin → buat/pilih database kosong → Import → pilih file <code>.sql.gz</code>. Setelah itu sesuaikan nama database di <code>.env</code> bila berbeda.</p>
        </div></div>
    </div>
</div>
<?= $this->endSection() ?>
