<?= $this->extend('layouts/main') ?>
<?= $this->section('actions') ?>
<form method="post" action="<?= site_url('sistem/aset/unduh') ?>"><?= csrf_field() ?><button class="btn btn-primary"><i class="bi bi-cloud-download"></i> Unduh / Perbarui Semua</button></form>
<?= $this->endSection() ?>
<?= $this->section('content') ?>
<?php $semua = ! in_array(false, array_column($status, 'ada'), true); ?>
<div class="alert alert-<?= $semua ? 'success' : 'warning' ?>">
    <?= $semua ? '<i class="bi bi-check-circle"></i> Semua aset tersimpan di server – aplikasi tidak memerlukan internet untuk tampil.' : '<i class="bi bi-wifi-off"></i> Sebagian aset masih diambil dari internet (CDN). Klik "Unduh" saat server terhubung internet. Alternatif: <code>php spark aset:unduh</code>.' ?>
</div>
<div class="card"><div class="card-body table-responsive">
    <table class="table table-sm align-middle">
        <thead><tr><th>Aset</th><th>Lokasi lokal</th><th>Status</th></tr></thead>
        <tbody>
        <?php foreach ($status as $k => $s) : ?>
            <tr><td><b><?= esc($k) ?></b><br><small class="text-muted text-break"><?= esc($s['cdn']) ?></small></td><td><code><?= esc($s['lokal']) ?></code></td>
                <td><?= $s['ada'] ? '<span class="badge bg-success">tersimpan ' . number_format($s['ukuran'] / 1024, 1) . ' KB</span>' : '<span class="badge bg-secondary">CDN</span>' ?></td></tr>
        <?php endforeach ?>
        </tbody>
    </table>
    <small class="text-muted">Huruf Nunito pada tema Mazer tetap memerlukan internet; tanpa internet tampilan memakai huruf bawaan sistem (tetap rapi).</small>
</div></div>
<?= $this->endSection() ?>
