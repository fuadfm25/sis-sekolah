<?= $this->extend('layouts/main') ?>
<?= $this->section('content') ?>
<div class="card"><div class="card-body">
    <form class="row g-2 mb-3 filter" method="get">
        <div class="col-md-3"><select name="aksi" class="form-select"><option value="">Semua aksi</option><?php foreach ($aksiList as $a) : ?><option <?= $f['aksi'] === $a ? 'selected' : '' ?>><?= esc($a) ?></option><?php endforeach ?></select></div>
        <div class="col-md-3"><input type="date" name="tanggal" value="<?= esc($f['tanggal']) ?>" class="form-control"></div>
        <div class="col-md-4"><input name="q" value="<?= esc($f['q']) ?>" class="form-control" placeholder="Cari pengguna / keterangan"></div>
        <div class="col-md-2"><button class="btn btn-light w-100"><i class="bi bi-funnel"></i></button></div>
    </form>
    <div class="table-responsive">
    <table class="table table-sm align-middle">
        <thead><tr><th>Waktu</th><th>Pengguna</th><th>Aksi</th><th>Objek</th><th>Keterangan</th><th>IP</th></tr></thead>
        <tbody>
        <?php foreach ($rows as $r) : ?>
            <tr class="<?= in_array($r['aksi'], ['hapus', 'gagal_login'], true) ? 'table-warning' : '' ?>"><td class="text-nowrap small"><?= esc($r['created_at']) ?></td><td><?= esc($r['nama_user'] ?? '-') ?></td><td><span class="badge bg-light text-dark"><?= esc($r['aksi']) ?></span></td>
                <td class="small"><?= esc($r['objek'] ?? '') ?><?= $r['objek_id'] ? ' #' . $r['objek_id'] : '' ?></td><td class="small"><?= esc($r['keterangan'] ?? '') ?></td><td class="small text-muted"><?= esc($r['ip']) ?></td></tr>
        <?php endforeach ?>
        <?php if (! $rows) : ?><tr><td colspan="6" class="text-center text-muted">Belum ada log.</td></tr><?php endif ?>
        </tbody>
    </table>
    </div>
    <div class="d-flex justify-content-between small"><span><?= $total ?> entri</span>
        <span><?php for ($i = max(1, $hal - 3); $i <= min($jmlHal, $hal + 3); $i++) : ?><a class="btn btn-sm <?= $i === $hal ? 'btn-primary' : 'btn-light' ?>" href="?<?= http_build_query($f + ['page' => $i]) ?>"><?= $i ?></a> <?php endfor ?></span></div>
</div></div>
<?= $this->endSection() ?>
