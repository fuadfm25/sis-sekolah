<?php /** @var \CodeIgniter\Pager\Pager|null $pager */ ?>
<?php if (! empty($pager) && $pager->getPageCount() > 1) : ?>
    <div class="d-flex justify-content-end mt-3"><?= $pager->links('default', 'default_full') ?></div>
<?php endif ?>
