<div class="print-only mb-3">
    <div style="display:flex;align-items:center;gap:12px;border-bottom:3px double #000;padding-bottom:6px">
        <?php if ($lg = logo_url()) : ?><img src="<?= esc($lg) ?>" style="height:60px" alt=""><?php endif ?>
        <div style="flex:1;text-align:center">
            <h4 class="mb-0 text-uppercase"><?= esc(setting('nama_sekolah', '')) ?></h4>
            <?php if (nomor_sekolah()) : ?><div class="small"><?= esc(nomor_sekolah()) ?></div><?php endif ?>
            <div class="small"><?= esc(setting('alamat_sekolah', '')) ?></div>
        </div>
    </div>
</div>
