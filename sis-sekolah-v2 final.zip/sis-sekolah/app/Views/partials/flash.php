<?php foreach (['success' => 'check-circle', 'error' => 'exclamation-triangle', 'warning' => 'exclamation-circle', 'info' => 'info-circle'] as $type => $icon) : ?>
    <?php if ($msg = session()->getFlashdata($type)) : ?>
        <div class="alert alert-<?= $type === 'error' ? 'danger' : $type ?> alert-dismissible fade show" role="alert">
            <i class="bi bi-<?= $icon ?> me-1"></i> <?= esc($msg) ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif ?>
<?php endforeach ?>
<?php if ($errs = session()->getFlashdata('errors')) : ?>
    <div class="alert alert-danger alert-dismissible fade show">
        <ul class="mb-0 ps-3"><?php foreach ((array) $errs as $e) : ?><li><?= esc($e) ?></li><?php endforeach ?></ul>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif ?>
