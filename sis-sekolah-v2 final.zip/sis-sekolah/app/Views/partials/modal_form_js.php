<script>
/**
 * Modal form serbaguna untuk tambah/edit.
 * Tombol pemicu: data-bs-toggle="modal" data-bs-target="#modalForm"
 *   data-action="URL"  data-title="Judul"  data-row='{"field":"nilai"}'  (data-row kosong = tambah)
 */
document.querySelectorAll('.modal[data-crud]').forEach(function (modal) {
    modal.addEventListener('show.bs.modal', function (ev) {
        var btn = ev.relatedTarget;
        if (!btn) return;
        var form = modal.querySelector('form');
        form.reset();
        form.action = btn.dataset.action;
        modal.querySelector('.modal-title').textContent = btn.dataset.title || 'Form';
        var row = btn.dataset.row ? JSON.parse(btn.dataset.row) : {};
        form.querySelectorAll('[name]').forEach(function (el) {
            var name = el.name.replace(/\[\]$/, '');
            if (!(name in row) || el.name === 'csrf_test_name') return;
            var val = row[name];
            if (el.type === 'checkbox') {
                el.checked = Array.isArray(val) ? val.map(String).includes(el.value) : String(val) === el.value;
            } else if (el.type === 'radio') {
                el.checked = String(val) === el.value;
            } else if (el.tomselect) {
                el.tomselect.setValue(val === null ? '' : val, true);
            } else {
                el.value = val === null ? '' : val;
            }
        });
        form.querySelectorAll('select').forEach(function (el) {
            if (el.tomselect && !(el.name.replace(/\[\]$/, '') in row)) el.tomselect.clear(true);
        });
    });
});
</script>
