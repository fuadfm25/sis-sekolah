<?= $this->extend('layouts/main') ?>
<?= $this->section('content') ?>
<div class="row">
    <?php foreach (hari_list() as $h => $hn) : ?>
        <div class="col-md-6 col-xl-4">
            <div class="card">
                <div class="card-header"><h5 class="card-title mb-0"><?= $hn ?></h5></div>
                <div class="card-body">
                    <ul class="list-unstyled">
                        <?php foreach ($perHari[$h] ?? [] as $p) : ?>
                            <li class="d-flex justify-content-between align-items-center mb-1"><span><?= esc(nama_guru($p)) ?></span><?= delete_button('akademik/piket/delete/' . $p['id']) ?></li>
                        <?php endforeach ?>
                        <?php if (empty($perHari[$h])) : ?><li class="text-muted small">Belum ada.</li><?php endif ?>
                    </ul>
                    <form method="post" action="<?= site_url('akademik/piket/store') ?>" class="d-flex gap-2">
                        <?= csrf_field() ?><input type="hidden" name="hari" value="<?= $h ?>">
                        <select name="guru_ids[]" class="form-select form-select-sm tom" multiple placeholder="Tambah guru...">
                            <?php foreach ($guru as $g) : ?><option value="<?= $g['id'] ?>"><?= esc(nama_guru($g)) ?></option><?php endforeach ?>
                        </select>
                        <button class="btn btn-sm btn-primary"><i class="bi bi-plus"></i></button>
                    </form>
                </div>
            </div>
        </div>
    <?php endforeach ?>
</div>
<?= $this->endSection() ?>
