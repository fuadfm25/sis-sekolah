<?= $this->extend('layouts/main') ?>
<?= $this->section('actions') ?>
<?php if ($kelola) : ?><button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#modalForm" data-title="Tambah Kegiatan" data-action="<?= site_url('kokurikuler/store') ?>"><i class="bi bi-plus-lg"></i> Tambah Kegiatan</button><?php endif ?>
<?= $this->endSection() ?>
<?= $this->section('content') ?>
<?php $D = \App\Models\KokurikulerModel::DIMENSI; ?>
<div class="row g-3">
<?php foreach ($rows as $r) : $dim = array_filter(explode(',', (string) $r['dimensi'])); $kel = \App\Models\KalenderModel::kelasDari($r['kelas_ids']); ?>
    <div class="col-md-6 col-xl-4"><div class="card h-100"><div class="card-body">
        <h6 class="mb-1"><?= esc($r['judul']) ?></h6>
        <div class="small text-muted mb-2"><?= tgl_indo($r['tanggal_mulai']) ?><?= $r['tanggal_selesai'] !== $r['tanggal_mulai'] ? ' – ' . tgl_indo($r['tanggal_selesai']) : '' ?><?= $r['alokasi_jp'] ? ' · ' . $r['alokasi_jp'] . ' JP' : '' ?></div>
        <?php if ($r['tema']) : ?><div class="small"><b>Tema:</b> <?= esc($r['tema']) ?></div><?php endif ?>
        <?php if ($r['bentuk']) : ?><div class="small"><b>Bentuk:</b> <?= esc($r['bentuk']) ?></div><?php endif ?>
        <div class="small"><b>Kelas:</b> <?= $kel ? esc(implode(', ', array_map(static fn ($k) => $namaKelas[$k] ?? '#' . $k, $kel))) : 'Semua kelas' ?></div>
        <?php if ($r['koordinator_id']) : ?><div class="small"><b>Koordinator:</b> <?= esc($namaGuru[$r['koordinator_id']] ?? '-') ?></div><?php endif ?>
        <div class="mt-2"><?php foreach ($dim as $d) : ?><span class="badge bg-light-primary text-primary me-1 mb-1"><?= esc($D[$d] ?? $d) ?></span><?php endforeach ?></div>
        <?php if ($r['deskripsi']) : ?><p class="small mt-2 mb-1"><?= nl2br(esc($r['deskripsi'])) ?></p><?php endif ?>
        <?php if ($r['refleksi']) : ?><p class="small mb-1 text-success"><b>Refleksi:</b> <?= nl2br(esc($r['refleksi'])) ?></p><?php endif ?>
        <?php $r['dimensi'] = $dim; $r['kelas_ids'] = $kel; ?>
        <?php if ($kelola || (int) $r['koordinator_id'] === (int) session('guru_id')) : ?>
        <div class="mt-2">
            <button class="btn btn-sm btn-outline-warning" data-bs-toggle="modal" data-bs-target="#modalForm" data-title="Edit Kegiatan" data-action="<?= site_url('kokurikuler/update/' . $r['id']) ?>" data-row='<?= esc(json_encode($r), 'attr') ?>'><i class="bi bi-pencil"></i> <?= $kelola ? 'Edit' : 'Isi refleksi' ?></button>
            <?php if ($kelola) : ?><?= delete_button('kokurikuler/delete/' . $r['id'], '', 'Hapus kegiatan dan agendanya di kalender?') ?><?php endif ?>
        </div>
        <?php endif ?>
    </div></div></div>
<?php endforeach ?>
<?php if (! $rows) : ?><div class="col-12"><div class="alert alert-light border">Belum ada kegiatan kokurikuler pada semester ini.</div></div><?php endif ?>
</div>
<div class="modal fade" id="modalForm" data-crud tabindex="-1">
    <div class="modal-dialog modal-lg"><form method="post" class="modal-content"><?= csrf_field() ?>
        <div class="modal-header"><h5 class="modal-title"></h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
        <div class="modal-body row g-2">
            <?php if ($kelola) : ?>
            <div class="col-12"><label class="form-label">Judul kegiatan</label><input name="judul" class="form-control" required maxlength="200" placeholder="Bank Sampah Sekolah"></div>
            <div class="col-md-6"><label class="form-label">Tema</label><input name="tema" class="form-control" maxlength="150" placeholder="Gaya hidup berkelanjutan"></div>
            <div class="col-md-6"><label class="form-label">Bentuk</label><select name="bentuk" class="form-select"><option value="">-</option><?php foreach (\App\Models\KokurikulerModel::BENTUK as $b) : ?><option><?= $b ?></option><?php endforeach ?></select></div>
            <div class="col-md-4"><label class="form-label">Mulai</label><input type="date" name="tanggal_mulai" class="form-control" required></div>
            <div class="col-md-4"><label class="form-label">Selesai</label><input type="date" name="tanggal_selesai" class="form-control"></div>
            <div class="col-md-4"><label class="form-label">Alokasi JP</label><input type="number" name="alokasi_jp" class="form-control" min="0"></div>
            <div class="col-12"><label class="form-label">Dimensi profil lulusan</label><div class="row">
                <?php foreach ($D as $k => $v) : ?><div class="col-md-6"><div class="form-check"><input class="form-check-input" type="checkbox" name="dimensi[]" value="<?= $k ?>" id="d<?= $k ?>"><label class="form-check-label small" for="d<?= $k ?>"><?= $v ?></label></div></div><?php endforeach ?>
            </div></div>
            <div class="col-12"><label class="form-label">Kelas sasaran <small class="text-muted">(kosong = semua kelas)</small></label><div class="border rounded p-2">
                <?php foreach ($kelas as $k) : ?><div class="form-check form-check-inline"><input class="form-check-input" type="checkbox" name="kelas_ids[]" value="<?= $k['id'] ?>" id="kk<?= $k['id'] ?>"><label class="form-check-label small" for="kk<?= $k['id'] ?>"><?= esc($k['nama_kelas']) ?></label></div><?php endforeach ?>
            </div></div>
            <div class="col-md-6"><label class="form-label">Koordinator</label><select name="koordinator_id" class="form-select"><option value="">-</option><?php foreach ($guru as $g) : ?><option value="<?= $g['id'] ?>"><?= esc(nama_guru($g)) ?></option><?php endforeach ?></select></div>
            <div class="col-md-6 d-flex align-items-end"><div class="form-check"><input class="form-check-input" type="checkbox" name="ada_kbm" value="1" id="aKbm"><label class="form-check-label small" for="aKbm">Jadwal pelajaran reguler tetap berjalan (jurnal tetap wajib)</label></div></div>
            <div class="col-12"><label class="form-label">Deskripsi / rencana kegiatan</label><textarea name="deskripsi" class="form-control" rows="3"></textarea></div>
            <?php endif ?>
            <div class="col-12"><label class="form-label">Refleksi / hasil</label><textarea name="refleksi" class="form-control" rows="3"></textarea></div>
        </div>
        <div class="modal-footer"><button class="btn btn-primary">Simpan</button></div>
    </form></div>
</div>
<?= $this->endSection() ?>
<?= $this->section('scripts') ?><?= $this->include('partials/modal_form_js') ?><?= $this->endSection() ?>
