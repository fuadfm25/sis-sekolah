<?= $this->extend('layouts/main') ?>
<?php
use App\Libraries\ModulAjar;
$i = $m['isi'];
$ta = static fn (string $k, int $rows = 3, string $ph = '') => '<textarea name="' . $k . '" rows="' . $rows . '" class="form-control" placeholder="' . esc($ph) . '">' . esc($i[$k] ?? '') . '</textarea>';
?>
<?= $this->section('actions') ?>
<a href="<?= site_url('modul-ajar?mapel_id=' . $m['mapel_id'] . '&tingkat=' . urlencode($m['tingkat'])) ?>" class="btn btn-light"><i class="bi bi-arrow-left"></i> Daftar modul</a>
<a href="<?= site_url('modul-ajar/cetak/' . $m['id']) ?>" target="_blank" class="btn btn-light"><i class="bi bi-printer"></i> Pratinjau</a>
<?= $this->endSection() ?>
<?= $this->section('content') ?>
<form method="post" action="<?= site_url('modul-ajar/simpan/' . $m['id']) ?>" id="formModul"><?= csrf_field() ?>
<div class="card"><div class="card-header"><h5 class="card-title mb-0">A. Identitas</h5></div><div class="card-body row g-2">
    <div class="col-md-6"><label class="form-label">Judul modul</label><input name="judul" class="form-control" value="<?= esc($m['judul']) ?>" maxlength="200"></div>
    <div class="col-md-3"><label class="form-label">Format</label><select name="format" id="fmt" class="form-select"><?php foreach (ModulAjar::FORMAT as $k => $v) : ?><option value="<?= $k ?>" <?= $m['format'] === $k ? 'selected' : '' ?>><?= $k === 'PM' ? 'Pembelajaran Mendalam' : 'PM + Kurikulum Berbasis Cinta' ?></option><?php endforeach ?></select></div>
    <div class="col-md-3"><label class="form-label">Alokasi (JP)</label><input type="number" name="jp" min="0" max="300" class="form-control" value="<?= (int) $m['jp'] ?>"></div>
    <div class="col-12 small text-muted">Mapel <?= esc($mapel['nama_mapel'] ?? '') ?> · Kelas <?= esc($m['tingkat']) ?><?= $fase ? ' · Fase ' . $fase : '' ?> · satuan pendidikan, penyusun, dan semester terisi otomatis saat dicetak.</div>
</div></div>

<div class="card"><div class="card-header"><h5 class="card-title mb-0">B. Identifikasi</h5></div><div class="card-body row g-2">
    <div class="col-md-6"><label class="form-label">Peserta didik</label><?= $ta('identifikasi_murid', 4, 'Pengetahuan awal, minat, latar belakang, gaya/kebutuhan belajar (visual, auditori, kinestetik), peserta didik yang perlu pendampingan…') ?></div>
    <div class="col-md-6"><label class="form-label">Materi pelajaran</label><?= $ta('identifikasi_materi', 4, 'Jenis pengetahuan (faktual/konseptual/prosedural/metakognitif), relevansi dengan kehidupan nyata, tingkat kesulitan, struktur materi…') ?></div>
    <div class="col-12"><label class="form-label">Dimensi profil lulusan</label><div class="d-flex flex-wrap gap-3">
        <?php foreach (ModulAjar::DPL as $n => $d) : ?><div class="form-check"><input class="form-check-input" type="checkbox" name="dpl[]" value="<?= esc($d) ?>" id="dpl<?= $n ?>" <?= in_array($d, $i['dpl'], true) ? 'checked' : '' ?>><label class="form-check-label" for="dpl<?= $n ?>"><?= esc($d) ?></label></div><?php endforeach ?>
    </div></div>
</div></div>

<div class="card" id="boxKbc"><div class="card-header"><h5 class="card-title mb-0">Tema Kurikulum Berbasis Cinta</h5></div><div class="card-body row g-2">
    <div class="col-12"><label class="form-label">Topik Panca Cinta</label><div class="d-flex flex-wrap gap-3">
        <?php foreach (ModulAjar::PANCA_CINTA as $n => $d) : ?><div class="form-check"><input class="form-check-input" type="checkbox" name="kbc_topik[]" value="<?= esc($d) ?>" id="kbc<?= $n ?>" <?= in_array($d, $i['kbc_topik'], true) ? 'checked' : '' ?>><label class="form-check-label" for="kbc<?= $n ?>"><?= esc($d) ?></label></div><?php endforeach ?>
    </div></div>
    <div class="col-12"><label class="form-label">Materi insersi</label><?= $ta('kbc_insersi', 2, 'Nilai cinta yang disisipkan ke dalam materi, mis. mensyukuri ciptaan Allah melalui pengamatan sifat cahaya…') ?></div>
</div></div>

<div class="card"><div class="card-header"><h5 class="card-title mb-0">C. Desain Pembelajaran</h5></div><div class="card-body row g-2">
    <div class="col-md-6"><label class="form-label">Capaian pembelajaran</label><?= $ta('cp', 3) ?></div>
    <div class="col-md-6"><label class="form-label">Tujuan pembelajaran</label><?= $ta('tujuan', 3) ?></div>
    <div class="col-md-6"><label class="form-label">Topik pembelajaran</label><input name="topik" class="form-control" value="<?= esc($i['topik']) ?>"></div>
    <div class="col-md-6"><label class="form-label">Lintas disiplin ilmu</label><input name="lintas_disiplin" class="form-control" value="<?= esc($i['lintas_disiplin']) ?>" placeholder="Mis. Matematika (mengolah data), Bahasa Indonesia (laporan)"></div>
    <div class="col-md-4"><label class="form-label">Model pembelajaran</label><input name="model" id="model" list="dlModel" class="form-control" value="<?= esc($i['model']) ?>" placeholder="Pilih atau ketik">
        <datalist id="dlModel"><?php foreach (array_keys(ModulAjar::SINTAKS) as $k) : ?><option value="<?= esc($k) ?>"><?php endforeach ?></datalist></div>
    <div class="col-md-4"><label class="form-label">Metode (pisahkan dengan koma)</label><input name="metode" list="dlMetode" class="form-control" value="<?= esc(implode(', ', $i['metode'])) ?>" placeholder="Diskusi, Eksperimen/praktikum">
        <datalist id="dlMetode"><?php foreach (ModulAjar::METODE as $k) : ?><option value="<?= esc($k) ?>"><?php endforeach ?></datalist></div>
    <div class="col-md-4"><label class="form-label">Pendekatan / strategi</label><input name="strategi" class="form-control" value="<?= esc($i['strategi']) ?>" placeholder="Mis. saintifik, berdiferensiasi, kolaboratif"></div>
    <div class="col-md-4"><label class="form-label">Kemitraan pembelajaran</label><?= $ta('kemitraan', 2, 'Orang tua, komunitas, puskesmas, perpustakaan daerah…') ?></div>
    <div class="col-md-4"><label class="form-label">Lingkungan pembelajaran</label><?= $ta('lingkungan', 2, 'Ruang kelas, laboratorium, halaman, ruang virtual, budaya belajar…') ?></div>
    <div class="col-md-4"><label class="form-label">Pemanfaatan digital</label><?= $ta('digital', 2, 'Video, kuis daring, LMS, simulasi virtual…') ?></div>
    <div class="col-md-4"><label class="form-label">Alat & bahan</label><?= $ta('alat_bahan', 2) ?></div>
    <div class="col-md-4"><label class="form-label">Media pembelajaran</label><?= $ta('media', 2) ?></div>
    <div class="col-md-4"><label class="form-label">Sumber belajar</label><?= $ta('sumber_belajar', 2, 'Buku siswa, modul, laman…') ?></div>
    <div class="col-12"><label class="form-label">Pembelajaran berdiferensiasi</label><?= $ta('diferensiasi', 2, 'Konten, proses, dan produk sesuai kesiapan/minat/gaya belajar') ?></div>
</div></div>

<div class="card"><div class="card-header d-flex justify-content-between flex-wrap gap-2 align-items-center">
    <h5 class="card-title mb-0">D. Pengalaman Belajar</h5>
    <div class="d-flex gap-2"><button type="button" class="btn btn-sm btn-outline-primary" id="isiSintaks"><i class="bi bi-magic"></i> Isi langkah dari sintaks model</button>
        <button type="button" class="btn btn-sm btn-light" id="tambahPert">+ Pertemuan</button></div>
</div><div class="card-body" id="daftarPert">
    <?php foreach ($i['pertemuan'] ?: [[]] as $n => $pt) : ?>
    <div class="border rounded p-3 mb-3 pert">
        <div class="d-flex justify-content-between mb-2"><b class="judulPert">Pertemuan <?= $n + 1 ?></b><button type="button" class="btn btn-sm btn-outline-danger hapusPert">Hapus</button></div>
        <div class="row g-2">
            <div class="col-12"><label class="form-label small">Kegiatan awal <span class="text-muted">(berkesadaran, bermakna, menggembirakan)</span></label><textarea data-k="awal" rows="3" class="form-control"><?= esc($pt['awal'] ?? '') ?></textarea></div>
            <div class="col-md-4"><label class="form-label small">Inti – Memahami</label><textarea data-k="memahami" rows="5" class="form-control"><?= esc($pt['memahami'] ?? '') ?></textarea></div>
            <div class="col-md-4"><label class="form-label small">Inti – Mengaplikasi</label><textarea data-k="mengaplikasi" rows="5" class="form-control"><?= esc($pt['mengaplikasi'] ?? '') ?></textarea></div>
            <div class="col-md-4"><label class="form-label small">Inti – Merefleksi</label><textarea data-k="merefleksi" rows="5" class="form-control"><?= esc($pt['merefleksi'] ?? '') ?></textarea></div>
            <div class="col-12"><label class="form-label small">Kegiatan penutup</label><textarea data-k="penutup" rows="3" class="form-control"><?= esc($pt['penutup'] ?? '') ?></textarea></div>
        </div>
    </div>
    <?php endforeach ?>
</div></div>

<div class="card"><div class="card-header"><h5 class="card-title mb-0">E. Asesmen</h5></div><div class="card-body row g-2">
    <div class="col-md-4"><label class="form-label">Asesmen awal</label><?= $ta('asesmen_awal', 3) ?></div>
    <div class="col-md-4"><label class="form-label">Asesmen proses</label><?= $ta('asesmen_proses', 3) ?></div>
    <div class="col-md-4"><label class="form-label">Asesmen akhir</label><?= $ta('asesmen_akhir', 3) ?></div>
</div></div>

<div class="card"><div class="card-header"><h5 class="card-title mb-0">F. Lampiran</h5></div><div class="card-body row g-2">
    <div class="col-md-6"><label class="form-label">Ringkasan materi / bahan bacaan</label><?= $ta('lampiran_materi', 4) ?></div>
    <div class="col-md-6"><label class="form-label">LKPD</label><?= $ta('lampiran_lkpd', 4) ?></div>
    <div class="col-md-6"><label class="form-label">Instrumen & rubrik penilaian (KKTP)</label><?= $ta('lampiran_rubrik', 4) ?></div>
    <div class="col-md-3"><label class="form-label">Glosarium</label><?= $ta('glosarium', 4) ?></div>
    <div class="col-md-3"><label class="form-label">Daftar pustaka</label><?= $ta('pustaka', 4) ?></div>
</div></div>

<div class="card"><div class="card-body d-flex gap-2 sticky-bottom bg-body">
    <button class="btn btn-primary"><i class="bi bi-save"></i> Simpan</button>
    <button name="cetak" value="1" class="btn btn-outline-primary"><i class="bi bi-printer"></i> Simpan & lihat dokumen</button>
</div></div>
</form>
<?= $this->endSection() ?>
<?= $this->section('scripts') ?>
<script>
(function () {
    var SINTAKS = <?= json_encode(ModulAjar::SINTAKS, JSON_UNESCAPED_UNICODE) ?>;
    var box = document.getElementById('daftarPert'), form = document.getElementById('formModul');
    function nomori() {
        box.querySelectorAll('.pert').forEach(function (p, n) {
            p.querySelector('.judulPert').textContent = 'Pertemuan ' + (n + 1);
            p.querySelectorAll('textarea[data-k]').forEach(function (t) { t.name = 'pertemuan[' + n + '][' + t.dataset.k + ']'; });
        });
    }
    box.addEventListener('click', function (e) {
        if (e.target.classList.contains('hapusPert') && box.querySelectorAll('.pert').length > 1) { e.target.closest('.pert').remove(); nomori(); }
    });
    document.getElementById('tambahPert').addEventListener('click', function () {
        var c = box.querySelector('.pert:last-child').cloneNode(true);
        c.querySelectorAll('textarea').forEach(function (t) { t.value = ''; });
        box.appendChild(c); nomori();
    });
    document.getElementById('isiSintaks').addEventListener('click', function () {
        var s = SINTAKS[document.getElementById('model').value];
        if (!s) { alert('Pilih model pembelajaran dari daftar terlebih dahulu.'); return; }
        var topik = form.querySelector('[name=topik]').value || 'materi';
        var isi = function (a) { return a.map(function (x) { return '- ' + x.replace('{topik}', topik); }).join('\n'); };
        var ada = Array.prototype.some.call(box.querySelectorAll('textarea[data-k=memahami],textarea[data-k=mengaplikasi]'), function (t) { return t.value.trim(); });
        if (ada && !confirm('Langkah inti yang sudah ada akan diganti sintaks ' + document.getElementById('model').value + '. Lanjutkan?')) return;
        box.querySelectorAll('.pert').forEach(function (p) {
            p.querySelector('[data-k=memahami]').value = isi(s[0]);
            p.querySelector('[data-k=mengaplikasi]').value = isi(s[1]);
            p.querySelector('[data-k=merefleksi]').value = isi(s[2]);
        });
    });
    function kbc() { document.getElementById('boxKbc').style.display = document.getElementById('fmt').value === 'PM-KBC' ? '' : 'none'; }
    document.getElementById('fmt').addEventListener('change', kbc); kbc(); nomori();
})();
</script>
<?= $this->endSection() ?>
