<?= $this->extend('layouts/main') ?>
<?php use App\Libraries\ModulAjar; $q = 'mapel_id=' . $mapelId . '&tingkat=' . urlencode($tingkat); ?>
<?= $this->section('actions') ?>
<?php if ($modul) : ?><a href="<?= site_url('modul-ajar/cetak-semua?' . $q) ?>" target="_blank" class="btn btn-light"><i class="bi bi-printer"></i> Cetak semua</a><?php endif ?>
<a href="<?= site_url('program?' . $q) ?>" class="btn btn-light"><i class="bi bi-calendar-week"></i> Program Semester</a>
<?= $this->endSection() ?>
<?= $this->section('content') ?>
<div class="d-flex flex-wrap gap-2 mb-3">
    <?php foreach ($target as $t) : $on = (int) $mapelId === (int) $t['mapel_id'] && $tingkat === $t['tingkat']; ?>
        <a href="<?= site_url('modul-ajar?mapel_id=' . $t['mapel_id'] . '&tingkat=' . urlencode($t['tingkat'])) ?>" class="btn <?= $on ? 'btn-primary' : 'btn-light' ?>"><?= esc($t['nama_mapel']) ?> · <?= esc($t['tingkat']) ?></a>
    <?php endforeach ?>
</div>
<div class="alert alert-light border small"><i class="bi bi-info-circle"></i> Format bawaan sekolah ini: <b><?= esc(ModulAjar::FORMAT[$format]) ?></b> (mengikuti jenjang di Pengaturan Sekolah; bisa diganti per modul).</div>
<div class="row g-3">
<div class="col-lg-7">
    <div class="card"><div class="card-header"><h5 class="card-title mb-0">Modul ajar saya</h5></div><div class="card-body table-responsive">
        <table class="table align-middle tabel-hp">
            <thead><tr><th>No</th><th>Judul / topik</th><th>Alokasi</th><th>Format</th><th></th></tr></thead>
            <tbody>
            <?php foreach ($modul as $i => $m) : ?>
                <tr><td><?= $i + 1 ?></td><td data-label="Judul"><a href="<?= site_url('modul-ajar/edit/' . $m['id']) ?>"><?= esc($m['judul']) ?></a></td>
                    <td data-label="Alokasi" class="text-nowrap"><?= (int) $m['jp'] ?> JP · <?= (int) $m['pertemuan'] ?>× pertemuan</td>
                    <td data-label="Format"><span class="badge text-bg-light border"><?= $m['format'] === 'PM-KBC' ? 'PM + KBC' : 'PM' ?></span></td>
                    <td class="text-end text-nowrap">
                        <a href="<?= site_url('modul-ajar/edit/' . $m['id']) ?>" class="btn btn-sm btn-light">Ubah</a>
                        <a href="<?= site_url('modul-ajar/cetak/' . $m['id']) ?>" target="_blank" class="btn btn-sm btn-light"><i class="bi bi-printer"></i></a>
                        <form method="post" action="<?= site_url('modul-ajar/salin/' . $m['id']) ?>" class="d-inline"><?= csrf_field() ?><button class="btn btn-sm btn-light" title="Salin">⧉</button></form>
                        <form method="post" action="<?= site_url('modul-ajar/hapus/' . $m['id']) ?>" class="d-inline" onsubmit="return confirm('Hapus modul ini?')"><?= csrf_field() ?><button class="btn btn-sm btn-outline-danger">×</button></form>
                    </td></tr>
            <?php endforeach ?>
            <?php if (! $modul) : ?><tr><td colspan="5" class="text-center text-muted">Belum ada modul ajar untuk mapel & tingkat ini.</td></tr><?php endif ?>
            </tbody>
        </table>
        <?php if ($modul) : ?>
            <form method="post" action="<?= site_url('modul-ajar/ajukan') ?>" class="mt-2"><?= csrf_field() ?><input type="hidden" name="mapel_id" value="<?= $mapelId ?>"><input type="hidden" name="tingkat" value="<?= esc($tingkat) ?>">
                <button class="btn btn-outline-success btn-sm"><i class="bi bi-send"></i> Ajukan semua modul ke Waka Kurikulum</button></form>
        <?php endif ?>
    </div></div>
</div>
<div class="col-lg-5">
    <div class="card"><div class="card-header"><h5 class="card-title mb-0">Buat dari Program Semester</h5></div><div class="list-group list-group-flush">
        <?php foreach ($items as $it) : ?>
            <div class="list-group-item d-flex justify-content-between align-items-center gap-2">
                <div><?= esc($it['materi']) ?><br><small class="text-muted"><?= (int) $it['jp'] ?> JP<?= in_array((int) $it['id'], $sudah, true) ? ' · sudah ada modul' : '' ?></small></div>
                <form method="post" action="<?= site_url('modul-ajar/buat') ?>"><?= csrf_field() ?>
                    <input type="hidden" name="mapel_id" value="<?= $mapelId ?>"><input type="hidden" name="tingkat" value="<?= esc($tingkat) ?>"><input type="hidden" name="item_id" value="<?= $it['id'] ?>">
                    <button class="btn btn-sm <?= in_array((int) $it['id'], $sudah, true) ? 'btn-light' : 'btn-primary' ?>">Buat modul</button></form>
            </div>
        <?php endforeach ?>
        <?php if (! $items) : ?><div class="list-group-item text-muted small">Butir program semester belum ada. Susun dulu di <a href="<?= site_url('program?' . $q) ?>">Program Semester</a>, atau buat modul kosong.</div><?php endif ?>
        <div class="list-group-item">
            <form method="post" action="<?= site_url('modul-ajar/buat') ?>"><?= csrf_field() ?><input type="hidden" name="mapel_id" value="<?= $mapelId ?>"><input type="hidden" name="tingkat" value="<?= esc($tingkat) ?>">
                <button class="btn btn-sm btn-outline-primary w-100">+ Modul kosong</button></form>
        </div>
    </div></div>
</div>
</div>
<?= $this->endSection() ?>
