<?= $this->extend('layouts/cetak') ?>
<?= $this->section('isi') ?>
<?php
use App\Libraries\ModulAjar;
$teks = static fn ($v) => trim((string) $v) === '' ? '<span style="color:#999">–</span>' : nl2br(esc($v));
?>
<style>
    .modul h3 { font-size: 11.5pt; margin: 12px 0 4px; text-transform: uppercase; border-bottom: 1px solid #000; }
    .modul h4 { font-size: 11pt; margin: 8px 0 2px; }
    .modul table.data td.label { width: 32%; font-weight: bold; background: #f5f5f5; }
</style>
<?php foreach ($daftar as $n => $d) : $m = $d['m']; $i = $m['isi']; $kbc = $m['format'] === 'PM-KBC'; $h = 0; $huruf = static function () use (&$h) { return chr(65 + $h++); }; ?>
<div class="modul <?= $n ? 'pecah' : '' ?>">
    <?php if ($n) : ?><h2 class="judul" style="margin-top:0">Modul Ajar</h2><div class="subjudul"><?= esc(ModulAjar::FORMAT[$m['format']]) ?></div><?php endif ?>
    <h3><?= $huruf() ?>. Identitas Modul</h3>
    <table class="data">
        <tr><td class="label">Satuan pendidikan</td><td><?= esc(setting('nama_sekolah', '')) ?></td></tr>
        <tr><td class="label">Penyusun</td><td><?= esc(nama_guru($d['guru'])) ?><?= $d['guru']['nip'] ? ' (NIP ' . esc($d['guru']['nip']) . ')' : '' ?></td></tr>
        <tr><td class="label">Mata pelajaran</td><td><?= esc($d['mapel']['nama_mapel']) ?></td></tr>
        <tr><td class="label">Fase / Kelas / Semester</td><td><?= esc(($d['fase'] ? $d['fase'] . ' / ' : '') . $m['tingkat'] . ' / ' . $d['tp']['semester']) ?></td></tr>
        <tr><td class="label">Tahun pelajaran</td><td><?= esc($d['tp']['tahun_pelajaran']) ?></td></tr>
        <tr><td class="label">Judul / topik</td><td><?= esc($m['judul']) ?></td></tr>
        <tr><td class="label">Alokasi waktu</td><td><?= (int) $m['jp'] ?> JP (<?= count($i['pertemuan']) ?: (int) $m['pertemuan'] ?> pertemuan)</td></tr>
    </table>

    <h3><?= $huruf() ?>. Identifikasi</h3>
    <table class="data">
        <tr><td class="label">Peserta didik</td><td><?= $teks($i['identifikasi_murid']) ?></td></tr>
        <tr><td class="label">Materi pelajaran</td><td><?= $teks($i['identifikasi_materi']) ?></td></tr>
        <tr><td class="label">Dimensi profil lulusan</td><td><?= $i['dpl'] ? esc(implode(', ', $i['dpl'])) : $teks('') ?></td></tr>
    </table>

    <?php if ($kbc) : ?>
    <h3><?= $huruf() ?>. Tema Kurikulum Berbasis Cinta</h3>
    <table class="data">
        <tr><td class="label">Topik Panca Cinta</td><td><?= $i['kbc_topik'] ? esc(implode(', ', $i['kbc_topik'])) : $teks('') ?></td></tr>
        <tr><td class="label">Materi insersi</td><td><?= $teks($i['kbc_insersi']) ?></td></tr>
    </table>
    <?php endif ?>

    <h3><?= $huruf() ?>. Desain Pembelajaran</h3>
    <table class="data">
        <tr><td class="label">Capaian pembelajaran</td><td><?= $teks($i['cp']) ?></td></tr>
        <tr><td class="label">Lintas disiplin ilmu</td><td><?= $teks($i['lintas_disiplin']) ?></td></tr>
        <tr><td class="label">Tujuan pembelajaran</td><td><?= $teks($i['tujuan']) ?></td></tr>
        <tr><td class="label">Topik pembelajaran</td><td><?= $teks($i['topik']) ?></td></tr>
        <tr><td class="label">Praktik pedagogis</td><td><?= $i['model'] ? '<b>Model:</b> ' . esc($i['model']) . '<br>' : '' ?><?= $i['strategi'] ? '<b>Pendekatan/strategi:</b> ' . esc($i['strategi']) . '<br>' : '' ?><?= $i['metode'] ? '<b>Metode:</b> ' . esc(implode(', ', $i['metode'])) : '' ?><?= ! $i['model'] && ! $i['strategi'] && ! $i['metode'] ? $teks('') : '' ?></td></tr>
        <tr><td class="label">Kemitraan pembelajaran</td><td><?= $teks($i['kemitraan']) ?></td></tr>
        <tr><td class="label">Lingkungan pembelajaran</td><td><?= $teks($i['lingkungan']) ?></td></tr>
        <tr><td class="label">Pemanfaatan digital</td><td><?= $teks($i['digital']) ?></td></tr>
        <tr><td class="label">Alat & bahan</td><td><?= $teks($i['alat_bahan']) ?></td></tr>
        <tr><td class="label">Media pembelajaran</td><td><?= $teks($i['media']) ?></td></tr>
        <tr><td class="label">Sumber belajar</td><td><?= $teks($i['sumber_belajar']) ?></td></tr>
        <?php if (trim($i['diferensiasi']) !== '') : ?><tr><td class="label">Pembelajaran berdiferensiasi</td><td><?= $teks($i['diferensiasi']) ?></td></tr><?php endif ?>
    </table>

    <h3><?= $huruf() ?>. Pengalaman Belajar</h3>
    <?php foreach ($i['pertemuan'] as $k => $pt) : ?>
        <h4>Pertemuan <?= $k + 1 ?></h4>
        <table class="data">
            <tr><td class="label">Kegiatan awal</td><td><?= $teks($pt['awal']) ?></td></tr>
            <tr><td class="label">Inti – Memahami</td><td><?= $teks($pt['memahami']) ?></td></tr>
            <tr><td class="label">Inti – Mengaplikasi</td><td><?= $teks($pt['mengaplikasi']) ?></td></tr>
            <tr><td class="label">Inti – Merefleksi</td><td><?= $teks($pt['merefleksi']) ?></td></tr>
            <tr><td class="label">Kegiatan penutup</td><td><?= $teks($pt['penutup']) ?></td></tr>
        </table>
    <?php endforeach ?>

    <h3><?= $huruf() ?>. Asesmen</h3>
    <table class="data">
        <tr><td class="label">Asesmen awal</td><td><?= $teks($i['asesmen_awal']) ?></td></tr>
        <tr><td class="label">Asesmen proses</td><td><?= $teks($i['asesmen_proses']) ?></td></tr>
        <tr><td class="label">Asesmen akhir</td><td><?= $teks($i['asesmen_akhir']) ?></td></tr>
    </table>

    <?php $lamp = array_filter(['Ringkasan materi' => $i['lampiran_materi'], 'Lembar kerja peserta didik (LKPD)' => $i['lampiran_lkpd'], 'Instrumen & rubrik penilaian' => $i['lampiran_rubrik'], 'Glosarium' => $i['glosarium'], 'Daftar pustaka' => $i['pustaka']], static fn ($v) => trim($v) !== ''); ?>
    <?php if ($lamp) : ?>
    <h3><?= $huruf() ?>. Lampiran</h3>
    <?php $no = 0; foreach ($lamp as $jud => $v) : ?><h4><?= ++$no ?>. <?= esc($jud) ?></h4><div><?= $teks($v) ?></div><?php endforeach ?>
    <?php endif ?>
    <?= view('laporan/_ttd', ['ttd' => $ttdModul], ['saveData' => false]) ?>
</div>
<?php endforeach ?>
<?= $this->endSection() ?>
