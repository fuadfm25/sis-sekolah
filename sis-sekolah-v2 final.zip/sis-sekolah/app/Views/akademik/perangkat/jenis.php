<?= $this->extend('layouts/main') ?>
<?= $this->section('content') ?>
<div class="alert alert-info small mb-3"><i class="bi bi-info-circle"></i> Istilah dokumen perencanaan berubah mengikuti kebijakan (mis. modul ajar, RPP, rencana pembelajaran mendalam). Ubah nama, tandai wajib/opsional, atau nonaktifkan jenis yang tidak dipakai sekolah. Jenis <b>Tahunan</b> cukup dikumpulkan sekali dalam satu tahun pelajaran.</div>
<div class="card"><div class="card-body table-responsive">
    <table class="table align-middle">
        <thead><tr><th style="width:70px">Urutan</th><th>Nama</th><th style="width:120px">Periode</th><th style="width:80px">Wajib</th><th>Keterangan</th><th style="width:90px">Aktif</th><th style="width:90px"></th></tr></thead>
        <tbody>
        <?php foreach (array_merge($rows, [['id' => null, 'nama' => '', 'periode' => 'Semester', 'wajib' => 1, 'keterangan' => '', 'urutan' => count($rows) + 1, 'is_active' => 1]]) as $r) : $fid = 'j' . ($r['id'] ?? 'baru'); ?>
            <tr class="<?= $r['id'] ? '' : 'table-light' ?>">
                <td><input form="<?= $fid ?>" type="number" name="urutan" value="<?= (int) $r['urutan'] ?>" class="form-control form-control-sm"></td>
                <td><input form="<?= $fid ?>" name="nama" value="<?= esc($r['nama']) ?>" class="form-control form-control-sm" maxlength="120" placeholder="<?= $r['id'] ? '' : 'Tambah jenis baru…' ?>" <?= $r['id'] ? 'required' : '' ?>></td>
                <td><select form="<?= $fid ?>" name="periode" class="form-select form-select-sm"><?php foreach (['Semester', 'Tahunan'] as $o) : ?><option <?= $r['periode'] === $o ? 'selected' : '' ?>><?= $o ?></option><?php endforeach ?></select></td>
                <td class="text-center"><input form="<?= $fid ?>" type="checkbox" name="wajib" value="1" class="form-check-input" <?= (int) $r['wajib'] ? 'checked' : '' ?>></td>
                <td><input form="<?= $fid ?>" name="keterangan" value="<?= esc($r['keterangan'] ?? '') ?>" class="form-control form-control-sm" maxlength="255"></td>
                <td><select form="<?= $fid ?>" name="is_active" class="form-select form-select-sm"><option value="1">Ya</option><option value="0" <?= (int) $r['is_active'] ? '' : 'selected' ?>>Tidak</option></select></td>
                <td><form id="<?= $fid ?>" method="post" action="<?= site_url('perangkat/jenis/simpan' . ($r['id'] ? '/' . $r['id'] : '')) ?>"><?= csrf_field() ?><button class="btn btn-sm <?= $r['id'] ? 'btn-light' : 'btn-primary' ?>"><?= $r['id'] ? 'Simpan' : 'Tambah' ?></button></form></td>
            </tr>
        <?php endforeach ?>
        </tbody>
    </table>
</div></div>
<?= $this->endSection() ?>
