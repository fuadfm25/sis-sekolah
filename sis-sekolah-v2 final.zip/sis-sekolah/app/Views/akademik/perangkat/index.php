<?= $this->extend('layouts/main') ?>
<?php use App\Models\PerangkatModel; $W = PerangkatModel::STATUS; ?>
<?= $this->section('actions') ?>
<a href="<?= site_url('laporan/perangkat?guru_id=' . $guruId) ?>" target="_blank" class="btn btn-light"><i class="bi bi-printer"></i> Cetak Lembar Pengesahan</a>
<?= $this->endSection() ?>
<?= $this->section('content') ?>
<?php
$wajib = array_filter($jenis, static fn ($j) => (int) $j['wajib'] === 1);
$total = count($target) * count($wajib);
$sudah = 0; $acc = 0;
foreach ($target as $t) { foreach ($wajib as $j) { $p = $peta[$guruId . '|' . $t['mapel_id'] . '|' . $t['tingkat'] . '|' . $j['id']] ?? null; if ($p) { $sudah++; $acc += in_array($p['status'], PerangkatModel::SELESAI, true) ? 1 : 0; } } }
?>
<div class="row g-3 mb-3">
    <div class="col-md-4"><div class="card h-100"><div class="card-body">
        <div class="small text-muted">Perangkat wajib terkumpul</div>
        <div class="fs-3 fw-bold"><?= $sudah ?> <span class="fs-6 text-muted">/ <?= $total ?></span></div>
        <div class="progress" style="height:6px"><div class="progress-bar" style="width:<?= $total ? round($sudah / $total * 100) : 0 ?>%"></div></div>
    </div></div></div>
    <div class="col-md-4"><div class="card h-100"><div class="card-body">
        <div class="small text-muted">Disetujui / disahkan</div>
        <div class="fs-3 fw-bold text-success"><?= $acc ?> <span class="fs-6 text-muted">/ <?= $total ?></span></div>
        <div class="small"><?php foreach ($W as $s => $c) : ?><span class="badge text-bg-<?= $c ?> me-1"><?= $s ?> <?= (int) ($hitung[$s] ?? 0) ?></span><?php endforeach ?></div>
    </div></div></div>
    <div class="col-md-4"><div class="card h-100"><div class="card-body">
        <div class="small text-muted">Batas pengumpulan</div>
        <div class="fs-5 fw-bold <?= $tenggat && $tenggat < date('Y-m-d') ? 'text-danger' : '' ?>"><?= $tenggat ? tgl_indo($tenggat) : 'belum ditentukan' ?></div>
        <div class="small text-muted">Ditentukan Waka Kurikulum.</div>
    </div></div></div>
</div>
<?php if (! empty($hitung['Perlu Revisi'])) : ?>
    <div class="alert alert-warning"><i class="bi bi-exclamation-circle"></i> Ada <b><?= (int) $hitung['Perlu Revisi'] ?></b> perangkat yang perlu direvisi. Baca catatan kurikulum lalu unggah versi perbaikan.</div>
<?php endif ?>
<?php if (! $target) : ?>
    <div class="alert alert-info">Anda belum memiliki penugasan mengajar pada semester ini.</div>
<?php endif ?>

<?php foreach ($target as $t) : ?>
<div class="card">
    <div class="card-header d-flex justify-content-between flex-wrap gap-1">
        <h5 class="card-title mb-0"><?= esc($t['nama_mapel']) ?> <span class="text-muted fw-normal">· Tingkat <?= esc($t['tingkat']) ?></span></h5>
        <small class="text-muted">Kelas <?= esc(str_replace(',', ', ', $t['kelas_list'])) ?></small>
    </div>
    <div class="card-body table-responsive">
        <table class="table table-sm align-middle tabel-hp mb-0">
            <thead><tr><th>Perangkat</th><th>Status</th><th>Catatan Kurikulum</th><th class="text-end"></th></tr></thead>
            <tbody>
            <?php foreach ($jenis as $j) : $p = $peta[$guruId . '|' . $t['mapel_id'] . '|' . $t['tingkat'] . '|' . $j['id']] ?? null; $kunci = $p && in_array($p['status'], PerangkatModel::SELESAI, true); ?>
                <tr>
                    <td data-label="Perangkat"><?= esc($j['nama']) ?><?= (int) $j['wajib'] ? '' : ' <span class="badge text-bg-light border fw-normal">opsional</span>' ?>
                        <br><small class="text-muted"><?= esc($j['periode']) ?><?= ! empty($p['_semester_lain']) ? ' · dari semester lain' : '' ?></small></td>
                    <td data-label="Status"><?php if ($p) : ?><span class="badge text-bg-<?= $W[$p['status']] ?? 'secondary' ?>"><?= esc($p['status']) ?></span> <small class="text-muted">v<?= (int) $p['versi'] ?></small>
                        <br><small class="text-muted"><?= tgl_indo(substr((string) $p['diajukan_at'], 0, 10)) ?><?= $tenggat && substr((string) $p['diajukan_at'], 0, 10) > $tenggat ? ' <span class="text-danger">(lewat batas)</span>' : '' ?></small>
                        <?php else : ?><span class="text-muted">Belum diunggah</span><?php endif ?></td>
                    <td data-label="Catatan" class="small"><?= $p && $p['catatan_pemeriksa'] ? nl2br(esc($p['catatan_pemeriksa'])) : '' ?></td>
                    <td class="text-end text-nowrap">
                        <?php if ($p) : ?><a href="<?= site_url('perangkat/detail/' . $p['id']) ?>" class="btn btn-sm btn-light">Detail</a><?php endif ?>
                        <?php if (! $kunci && empty($p['_semester_lain'])) : ?>
                            <button type="button" class="btn btn-sm <?= $p && $p['status'] === 'Perlu Revisi' ? 'btn-warning' : ($p ? 'btn-outline-primary' : 'btn-primary') ?> btn-unggah"
                                data-mapel="<?= $t['mapel_id'] ?>" data-tingkat="<?= esc($t['tingkat']) ?>" data-jenis="<?= $j['id'] ?>" data-judul="<?= esc($j['nama'] . ' – ' . $t['nama_mapel'] . ' ' . $t['tingkat']) ?>">
                                <i class="bi bi-upload"></i> <?= $p ? ($p['status'] === 'Perlu Revisi' ? 'Unggah revisi' : 'Ganti') : 'Unggah' ?></button>
                        <?php endif ?>
                    </td>
                </tr>
            <?php endforeach ?>
            </tbody>
        </table>
    </div>
</div>
<?php endforeach ?>

<div class="modal fade" id="modalUnggah" tabindex="-1">
    <div class="modal-dialog"><form method="post" action="<?= site_url('perangkat/unggah') ?>" enctype="multipart/form-data" class="modal-content"><?= csrf_field() ?>
        <div class="modal-header"><h5 class="modal-title" id="judulUnggah">Unggah perangkat</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
        <div class="modal-body row g-2">
            <input type="hidden" name="mapel_id"><input type="hidden" name="tingkat"><input type="hidden" name="jenis_perangkat_id">
            <div class="col-12"><?php $iniMb = static function ($v) { $v = trim((string) $v); $n = (float) $v; $u = strtoupper(substr($v, -1)); return $u === 'G' ? $n * 1024 : ($u === 'K' ? $n / 1024 : ($u === 'M' ? $n : $n / 1048576)); };
                $maks = min(10, $iniMb(ini_get('upload_max_filesize')), $iniMb(ini_get('post_max_size'))); ?>
                <label class="form-label">Berkas (PDF, Word, Excel, PowerPoint, gambar, ZIP; maks. <?= rtrim(rtrim(number_format($maks, 1, ',', ''), '0'), ',') ?> MB)</label>
                <input type="file" name="file" class="form-control" accept=".pdf,.doc,.docx,.xls,.xlsx,.ppt,.pptx,.odt,.ods,.odp,.jpg,.jpeg,.png,.zip"></div>
            <div class="col-12"><label class="form-label">atau tautan (Google Drive, OneDrive, dsb.)</label>
                <input type="url" name="tautan" class="form-control" placeholder="https://drive.google.com/..."><div class="form-text">Pastikan tautan bisa dibuka oleh Waka Kurikulum.</div></div>
            <div class="col-12"><label class="form-label">Catatan untuk kurikulum</label><textarea name="catatan_guru" rows="2" class="form-control" placeholder="Mis. sudah diperbaiki sesuai catatan pada bagian asesmen"></textarea></div>
        </div>
        <div class="modal-footer"><button class="btn btn-primary"><i class="bi bi-send"></i> Ajukan</button></div>
    </form></div>
</div>
<?= $this->endSection() ?>
<?= $this->section('scripts') ?>
<script>
document.querySelectorAll('.btn-unggah').forEach(function (b) {
    b.addEventListener('click', function () {
        var m = document.getElementById('modalUnggah');
        m.querySelector('[name=mapel_id]').value = b.dataset.mapel;
        m.querySelector('[name=tingkat]').value = b.dataset.tingkat;
        m.querySelector('[name=jenis_perangkat_id]').value = b.dataset.jenis;
        document.getElementById('judulUnggah').textContent = b.dataset.judul;
        bootstrap.Modal.getOrCreateInstance(m).show();
    });
});
</script>
<?= $this->endSection() ?>
