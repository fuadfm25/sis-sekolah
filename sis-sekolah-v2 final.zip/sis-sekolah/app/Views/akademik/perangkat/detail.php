<?= $this->extend('layouts/main') ?>
<?php use App\Libraries\Akses; use App\Models\PerangkatModel; $W = PerangkatModel::STATUS; ?>
<?= $this->section('actions') ?>
<a href="<?= site_url(Akses::perangkatLihatSemua() ? 'perangkat/pemeriksaan' : 'perangkat') ?>" class="btn btn-light"><i class="bi bi-arrow-left"></i> Kembali</a>
<?= $this->endSection() ?>
<?= $this->section('content') ?>
<div class="row g-3">
<div class="col-lg-7">
    <div class="card"><div class="card-body">
        <table class="table table-sm mb-3">
            <tr><th style="width:170px">Status</th><td><span class="badge text-bg-<?= $W[$p['status']] ?? 'secondary' ?>"><?= esc($p['status']) ?></span> · versi <?= (int) $p['versi'] ?></td></tr>
            <tr><th>Guru</th><td><?= esc($p['nama_guru']) ?></td></tr>
            <tr><th>Mapel / tingkat</th><td><?= esc($p['nama_mapel']) ?> · <?= esc($p['tingkat']) ?></td></tr>
            <tr><th>Diajukan</th><td><?= esc(tgl_indo(substr($p['diajukan_at'], 0, 10)) . ' ' . substr($p['diajukan_at'], 11, 5)) ?>
                <?= $tenggat && substr($p['diajukan_at'], 0, 10) > $tenggat ? '<span class="badge text-bg-danger">lewat batas ' . tgl_indo($tenggat) . '</span>' : '' ?></td></tr>
            <?php if ($p['catatan_guru']) : ?><tr><th>Catatan guru</th><td><?= nl2br(esc($p['catatan_guru'])) ?></td></tr><?php endif ?>
            <?php if ($p['pemeriksa']) : ?><tr><th>Diperiksa</th><td><?= esc($p['pemeriksa']) ?>, <?= tgl_indo(substr($p['diperiksa_at'], 0, 10)) ?></td></tr><?php endif ?>
            <?php if ($p['catatan_pemeriksa']) : ?><tr><th>Catatan kurikulum</th><td class="text-warning-emphasis"><?= nl2br(esc($p['catatan_pemeriksa'])) ?></td></tr><?php endif ?>
            <?php if ($p['pengesah']) : ?><tr><th>Disahkan</th><td><?= esc($p['pengesah']) ?>, <?= tgl_indo(substr($p['disahkan_at'], 0, 10)) ?></td></tr><?php endif ?>
        </table>
        <div class="d-flex flex-wrap gap-2">
            <?php if ($p['file']) : ?>
                <a href="<?= site_url('perangkat/unduh/' . $p['id']) ?>" target="_blank" class="btn btn-primary"><i class="bi bi-eye"></i> Buka berkas</a>
                <a href="<?= site_url('perangkat/unduh/' . $p['id'] . '?unduh=1') ?>" class="btn btn-outline-primary"><i class="bi bi-download"></i> Unduh <?= esc($p['nama_file'] ?? '') ?></a>
            <?php endif ?>
            <?php if ($u = \App\Models\PerangkatModel::urlSumber($p)) : ?><a href="<?= esc($u) ?>" target="_blank" class="btn btn-primary"><i class="bi bi-file-earmark-text"></i> Buka dokumen (disusun di aplikasi)</a><?php endif ?>
            <?php if ($p['tautan']) : ?><a href="<?= esc($p['tautan']) ?>" target="_blank" rel="noopener noreferrer" class="btn btn-outline-primary"><i class="bi bi-link-45deg"></i> Buka tautan</a><?php endif ?>
            <?php if ($p['status'] === 'Diajukan' && (int) $p['versi'] === 1 && (int) $p['guru_id'] === Akses::guruId()) : ?>
                <form method="post" action="<?= site_url('perangkat/tarik/' . $p['id']) ?>" onsubmit="return confirm('Tarik pengajuan ini?')"><?= csrf_field() ?><button class="btn btn-outline-danger">Tarik pengajuan</button></form>
            <?php endif ?>
        </div>
    </div></div>

    <?php if (Akses::perangkatPeriksa()) : ?>
    <div class="card"><div class="card-header"><h5 class="card-title mb-0">Pemeriksaan Waka Kurikulum</h5></div><div class="card-body">
        <?php if ($p['status'] === 'Diajukan') : ?>
        <form method="post" action="<?= site_url('perangkat/periksa/' . $p['id']) ?>"><?= csrf_field() ?>
            <label class="form-label">Catatan / umpan balik</label>
            <textarea name="catatan" rows="4" class="form-control mb-2" placeholder="Wajib diisi bila meminta revisi. Mis.: KKTP belum memuat rubrik; asesmen formatif belum terlihat pada langkah pembelajaran."></textarea>
            <div class="form-check mb-3"><input class="form-check-input" type="checkbox" name="lanjut" value="1" id="lanjut" checked><label class="form-check-label" for="lanjut">Setelah ini buka pengajuan berikutnya</label></div>
            <button name="aksi" value="setujui" class="btn btn-success"><i class="bi bi-check2-circle"></i> Setujui</button>
            <button name="aksi" value="revisi" class="btn btn-warning"><i class="bi bi-arrow-repeat"></i> Perlu revisi</button>
        </form>
        <?php elseif (in_array($p['status'], PerangkatModel::SELESAI, true)) : ?>
        <form method="post" action="<?= site_url('perangkat/periksa/' . $p['id']) ?>" class="row g-2"><?= csrf_field() ?>
            <div class="col-12 small text-muted">Buka kembali bila perangkat perlu diganti (status menjadi Perlu Revisi, pengesahan dibatalkan).</div>
            <div class="col-md-9"><input name="catatan" class="form-control" placeholder="Alasan dibuka kembali" required></div>
            <div class="col-md-3"><button name="aksi" value="buka" class="btn btn-outline-warning w-100">Buka kembali</button></div>
        </form>
        <?php else : ?><div class="text-muted">Menunggu guru mengunggah revisi.</div><?php endif ?>
    </div></div>
    <?php endif ?>
    <?php if (Akses::perangkatSahkan() && $p['status'] === 'Disetujui') : ?>
    <div class="card"><div class="card-body d-flex justify-content-between align-items-center flex-wrap gap-2">
        <span>Perangkat sudah disetujui Waka Kurikulum.</span>
        <form method="post" action="<?= site_url('perangkat/sahkan') ?>"><?= csrf_field() ?><input type="hidden" name="ids[]" value="<?= $p['id'] ?>"><button class="btn btn-success"><i class="bi bi-patch-check"></i> Sahkan</button></form>
    </div></div>
    <?php endif ?>
</div>
<div class="col-lg-5">
    <div class="card"><div class="card-header"><h5 class="card-title mb-0">Riwayat</h5></div>
        <ul class="list-group list-group-flush">
            <?php foreach ($riwayat as $r) : ?>
                <li class="list-group-item">
                    <div class="d-flex justify-content-between"><b><?= esc($r['aksi']) ?></b><small class="text-muted"><?= tgl_indo(substr($r['created_at'], 0, 10)) ?> <?= substr($r['created_at'], 11, 5) ?></small></div>
                    <div class="small text-muted">v<?= (int) $r['versi'] ?> · <?= esc($r['nama_lengkap'] ?? '-') ?>
                        <?php if ($r['file'] && $r['file'] !== $p['file']) : ?> · <a href="<?= site_url('perangkat/unduh/' . $p['id'] . '/' . $r['id']) ?>" target="_blank">berkas versi ini</a><?php endif ?></div>
                    <?php if ($r['catatan']) : ?><div class="small mt-1"><?= nl2br(esc($r['catatan'])) ?></div><?php endif ?>
                </li>
            <?php endforeach ?>
        </ul>
    </div>
</div>
</div>
<?= $this->endSection() ?>
