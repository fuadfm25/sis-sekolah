<?= $this->extend('layouts/main') ?>
<?php use App\Libraries\Akses; use App\Models\PerangkatModel; $W = PerangkatModel::STATUS; $sahkan = Akses::perangkatSahkan(); ?>
<?= $this->section('actions') ?>
<?php if (Akses::perangkatPeriksa()) : ?><a href="<?= site_url('perangkat/jenis') ?>" class="btn btn-light"><i class="bi bi-list-task"></i> Jenis Perangkat</a><?php endif ?>
<a href="<?= site_url('laporan/perangkat') ?>" target="_blank" class="btn btn-light"><i class="bi bi-printer"></i> Cetak Rekap</a>
<?= $this->endSection() ?>
<?= $this->section('content') ?>
<div class="row g-3 mb-3">
    <?php foreach ($W as $s => $c) : ?>
        <div class="col-6 col-md-3"><a class="card h-100 text-decoration-none border-start border-4 border-<?= $c ?>" href="<?= site_url('perangkat/pemeriksaan?status=' . urlencode($s)) ?>"><div class="card-body py-3">
            <div class="small text-muted"><?= $s ?></div><div class="fs-3 fw-bold"><?= (int) ($hitung[$s] ?? 0) ?></div></div></a></div>
    <?php endforeach ?>
</div>

<ul class="nav nav-tabs mb-3" role="tablist">
    <li class="nav-item"><button class="nav-link active" data-bs-toggle="tab" data-bs-target="#tDaftar" type="button">Daftar Pengajuan</button></li>
    <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#tRekap" type="button">Kelengkapan per Guru</button></li>
</ul>
<div class="tab-content">
<div class="tab-pane fade show active" id="tDaftar">
    <div class="card"><div class="card-body py-3">
        <form class="d-flex flex-wrap gap-2 filter" method="get">
            <select name="status" class="form-select w-auto"><option value="">Semua status</option>
                <?php foreach ($W as $s => $c) : ?><option <?= $f['status'] === $s ? 'selected' : '' ?>><?= $s ?></option><?php endforeach ?></select>
            <select name="guru_id" class="form-select w-auto"><option value="">Semua guru</option>
                <?php foreach ($guru as $g) : ?><option value="<?= $g['id'] ?>" <?= $f['guru_id'] == $g['id'] ? 'selected' : '' ?>><?= esc($g['nama_lengkap']) ?></option><?php endforeach ?></select>
            <select name="jenis_perangkat_id" class="form-select w-auto"><option value="">Semua jenis</option>
                <?php foreach ($jenis as $j) : ?><option value="<?= $j['id'] ?>" <?= $f['jenis_perangkat_id'] == $j['id'] ? 'selected' : '' ?>><?= esc($j['nama']) ?></option><?php endforeach ?></select>
            <button class="btn btn-light">Tampilkan</button>
        </form>
    </div></div>
    <form method="post" action="<?= site_url('perangkat/sahkan') ?>"><?= csrf_field() ?>
    <div class="card"><div class="card-body table-responsive">
        <table class="table table-hover align-middle tabel-hp">
            <thead><tr><?php if ($sahkan) : ?><th style="width:30px"><input type="checkbox" class="form-check-input" onclick="document.querySelectorAll('.cek').forEach(c => c.checked = this.checked)"></th><?php endif ?>
                <th>Diajukan</th><th>Guru</th><th>Perangkat</th><th>Mapel / Tingkat</th><th>Status</th><th></th></tr></thead>
            <tbody>
            <?php foreach ($rows as $r) : ?>
                <tr>
                    <?php if ($sahkan) : ?><td><?php if ($r['status'] === 'Disetujui') : ?><input type="checkbox" name="ids[]" value="<?= $r['id'] ?>" class="form-check-input cek"><?php endif ?></td><?php endif ?>
                    <td data-label="Diajukan" class="text-nowrap small"><?= tgl_indo(substr((string) $r['diajukan_at'], 0, 10)) ?> <?= substr((string) $r['diajukan_at'], 11, 5) ?>
                        <?= $tenggat && substr((string) $r['diajukan_at'], 0, 10) > $tenggat ? '<br><span class="badge text-bg-danger">lewat batas</span>' : '' ?></td>
                    <td data-label="Guru"><?= esc($r['nama_guru']) ?></td>
                    <td data-label="Perangkat"><?= esc($r['nama_jenis']) ?> <small class="text-muted">v<?= (int) $r['versi'] ?></small></td>
                    <td data-label="Mapel"><?= esc($r['nama_mapel']) ?> · <?= esc($r['tingkat']) ?></td>
                    <td data-label="Status"><span class="badge text-bg-<?= $W[$r['status']] ?? 'secondary' ?>"><?= esc($r['status']) ?></span></td>
                    <td class="text-end"><a href="<?= site_url('perangkat/detail/' . $r['id']) ?>" class="btn btn-sm <?= $r['status'] === 'Diajukan' && Akses::perangkatPeriksa() ? 'btn-primary' : 'btn-light' ?>"><?= $r['status'] === 'Diajukan' && Akses::perangkatPeriksa() ? 'Periksa' : 'Lihat' ?></a></td>
                </tr>
            <?php endforeach ?>
            <?php if (! $rows) : ?><tr><td colspan="7" class="text-center text-muted">Tidak ada perangkat dengan filter ini.</td></tr><?php endif ?>
            </tbody>
        </table>
        <?php if ($sahkan && array_filter($rows, static fn ($r) => $r['status'] === 'Disetujui')) : ?>
            <button class="btn btn-success"><i class="bi bi-patch-check"></i> Sahkan yang dicentang</button>
        <?php endif ?>
    </div></div>
    </form>
</div>

<div class="tab-pane fade" id="tRekap">
    <?php if (Akses::perangkatPeriksa()) : ?>
    <div class="card"><div class="card-body py-3">
        <form method="post" action="<?= site_url('perangkat/tenggat') ?>" class="d-flex flex-wrap gap-2 align-items-center"><?= csrf_field() ?>
            <label class="form-label mb-0">Batas pengumpulan semester ini</label>
            <input type="date" name="tenggat" value="<?= esc($tenggat ?? '') ?>" class="form-control w-auto">
            <button class="btn btn-light">Simpan</button>
            <small class="text-muted">Pengajuan sesudah tanggal ini ditandai "lewat batas".</small>
        </form>
    </div></div>
    <?php endif ?>
    <div class="card"><div class="card-body table-responsive">
        <table class="table align-middle tabel-hp">
            <thead><tr><th>Guru</th><th class="text-center">Wajib</th><th class="text-center">Terkumpul</th><th class="text-center">Disetujui</th><th class="text-center">Disahkan</th><th class="text-center">Revisi</th><th style="width:22%">Kelengkapan</th><th></th></tr></thead>
            <tbody>
            <?php foreach ($rekap as $g) : $pct = $g['target'] ? round($g['disetujui'] / $g['target'] * 100) : 0; $pk = $g['target'] ? round($g['terkumpul'] / $g['target'] * 100) : 0; ?>
                <tr>
                    <td data-label="Guru"><?= esc($g['nama_guru']) ?></td>
                    <td data-label="Wajib" class="text-center"><?= $g['target'] ?></td>
                    <td data-label="Terkumpul" class="text-center"><?= $g['terkumpul'] ?></td>
                    <td data-label="Disetujui" class="text-center"><?= $g['disetujui'] ?></td>
                    <td data-label="Disahkan" class="text-center"><?= $g['disahkan'] ?></td>
                    <td data-label="Revisi" class="text-center"><?= $g['revisi'] ? '<span class="badge text-bg-warning">' . $g['revisi'] . '</span>' : '0' ?></td>
                    <td data-label="Kelengkapan"><div class="progress" style="height:8px" title="terkumpul <?= $pk ?>%, disetujui <?= $pct ?>%">
                        <div class="progress-bar bg-success" style="width:<?= $pct ?>%"></div><div class="progress-bar bg-info" style="width:<?= max(0, $pk - $pct) ?>%"></div></div>
                        <small class="text-muted"><?= $pct ?>% disetujui · <?= $pk ?>% terkumpul</small></td>
                    <td class="text-end text-nowrap"><a href="<?= site_url('perangkat/pemeriksaan?status=&guru_id=' . $g['guru_id']) ?>" class="btn btn-sm btn-light">Lihat</a>
                        <a href="<?= site_url('laporan/perangkat?guru_id=' . $g['guru_id']) ?>" target="_blank" class="btn btn-sm btn-light" title="Lembar pengesahan"><i class="bi bi-printer"></i></a></td>
                </tr>
            <?php endforeach ?>
            <?php if (! $rekap) : ?><tr><td colspan="8" class="text-center text-muted">Belum ada penugasan guru pada semester ini.</td></tr><?php endif ?>
            </tbody>
        </table>
    </div></div>
</div>
</div>
<?= $this->endSection() ?>
