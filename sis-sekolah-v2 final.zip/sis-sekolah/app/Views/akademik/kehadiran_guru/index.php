<?= $this->extend('layouts/main') ?>
<?= $this->section('actions') ?><a class="btn btn-light" target="_blank" href="<?= site_url('laporan/kehadiran-guru?bulan=' . (int) substr($tanggal, 5, 2) . '&tahun=' . substr($tanggal, 0, 4)) ?>"><i class="bi bi-printer"></i> Rekap bulan ini</a><?= $this->endSection() ?>
<?= $this->section('content') ?>
<?php $ST = \App\Models\PresensiGuruModel::STATUS; $W = \App\Models\PresensiGuruModel::WARNA; ?>
<div class="card"><div class="card-body py-3">
    <form class="d-flex gap-2 align-items-center filter" method="get">
        <input type="date" name="tanggal" value="<?= $tanggal ?>" max="<?= date('Y-m-d') ?>" class="form-control w-auto" onchange="this.form.submit()">
        <span class="badge bg-<?= $status['warna'] ?>"><?= esc($status['label']) ?></span>
    </form>
</div></div>
<?php if (! $status['sekolah']) : ?><div class="alert alert-light border">Bukan hari sekolah.</div><?php endif ?>
<form method="post" action="<?= site_url('guru-hadir/simpan') ?>"><?= csrf_field() ?><input type="hidden" name="tanggal" value="<?= $tanggal ?>">
<div class="card"><div class="card-body table-responsive">
    <table class="table align-middle tabel-hp">
        <thead><tr><th>Guru</th><th class="text-center">Status</th><th>Datang</th><th>Keterangan</th></tr></thead>
        <tbody>
        <?php foreach ($guru as $g) : $d = $data[$g['id']] ?? null; $iz = $izin[$g['id']] ?? null; $st = $d['status'] ?? ($iz['jenis'] ?? ''); ?>
            <tr>
                <td data-label="Guru"><?= esc(nama_guru($g)) ?>
                    <?php if (($d['sumber'] ?? '') === 'Kiosk') : ?><i class="bi bi-upc-scan text-primary" title="Absen lewat kiosk"></i><?php endif ?>
                    <?php if ($iz) : ?><div class="small text-primary"><i class="bi bi-envelope-check"></i> <?= \App\Models\IzinGuruModel::JENIS[$iz['jenis']] ?> (disetujui)<?= $iz['tugas_siswa'] ? ' · tugas: ' . esc(mb_strimwidth($iz['tugas_siswa'], 0, 80, '…')) : '' ?></div><?php endif ?></td>
                <td class="text-center text-nowrap" data-label="Status">
                    <?php if ($bisaInput) : foreach ($ST as $k => $v) : ?>
                        <input type="radio" class="btn-check" name="hadir[<?= $g['id'] ?>][status]" id="g<?= $g['id'] . $k ?>" value="<?= $k ?>" <?= $st === $k ? 'checked' : '' ?>>
                        <label class="btn btn-sm btn-outline-<?= $W[$k] ?> btn-status" for="g<?= $g['id'] . $k ?>" title="<?= $v ?>"><?= $k ?></label>
                    <?php endforeach; else : ?><?= $st ? '<span class="badge bg-' . $W[$st] . '">' . $ST[$st] . '</span>' : '<span class="text-muted">-</span>' ?><?php endif ?>
                </td>
                <td data-label="Datang"><?php if ($bisaInput) : ?><input type="time" name="hadir[<?= $g['id'] ?>][jam_datang]" class="form-control form-control-sm" value="<?= esc(jam($d['jam_datang'] ?? null) === '-' ? '' : jam($d['jam_datang'])) ?>"><?php else : ?><?= jam($d['jam_datang'] ?? null) ?><?php endif ?></td>
                <td data-label="Keterangan"><?php if ($bisaInput) : ?><input name="hadir[<?= $g['id'] ?>][keterangan]" class="form-control form-control-sm" value="<?= esc($d['keterangan'] ?? '') ?>"><?php else : ?><?= esc($d['keterangan'] ?? '') ?><?php endif ?></td>
            </tr>
        <?php endforeach ?>
        </tbody>
    </table>
    <?php if ($bisaInput) : ?><button class="btn btn-primary"><i class="bi bi-save"></i> Simpan kehadiran guru</button>
        <small class="text-muted ms-2">Hanya guru yang statusnya dipilih yang disimpan.</small><?php endif ?>
</div></div>
</form>
<?= $this->endSection() ?>
