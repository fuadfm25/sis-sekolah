<?= $this->extend('layouts/main') ?>
<?= $this->section('content') ?>
<?php $label = ['penugasan' => 'Penugasan guru (mapel & JP)', 'jadwal' => 'Jadwal pelajaran', 'wali' => 'Wali kelas', 'piket' => 'Guru piket', 'rombel' => 'Rombel / anggota kelas (siswa aktif)']; ?>
<div class="row">
    <div class="col-lg-7">
        <div class="card"><div class="card-body">
            <?php if (! $list) : ?>
                <div class="alert alert-info mb-0">Belum ada tahun pelajaran/semester lain sebagai sumber.</div>
            <?php else : ?>
            <form method="post" action="<?= site_url('akademik/salin-semester/proses') ?>" onsubmit="return confirm('Salin data ke TP aktif? Data yang sudah ada tidak ditimpa.')"><?= csrf_field() ?>
                <div class="mb-3"><label class="form-label fw-bold">Salin dari</label>
                    <select name="dari" class="form-select" required>
                        <?php foreach ($list as $t) : ?><option value="<?= $t['id'] ?>"><?= esc($t['tahun_pelajaran'] . ' ' . $t['semester']) ?> — <?= $t['jumlah']['penugasan'] ?> penugasan, <?= $t['jumlah']['jadwal'] ?> jadwal, <?= $t['jumlah']['rombel'] ?> siswa</option><?php endforeach ?>
                    </select></div>
                <div class="mb-3"><label class="form-label fw-bold">Ke</label>
                    <input class="form-control" disabled value="<?= esc(tp_aktif()['tahun_pelajaran'] . ' ' . tp_aktif()['semester']) ?> (aktif)"></div>
                <label class="form-label fw-bold">Data yang disalin</label>
                <?php foreach ($label as $k => $l) : ?>
                    <div class="form-check"><input class="form-check-input" type="checkbox" name="item[]" value="<?= $k ?>" id="i<?= $k ?>" <?= $k !== 'rombel' ? 'checked' : '' ?>>
                        <label class="form-check-label" for="i<?= $k ?>"><?= $l ?> <span class="text-muted small">(di TP aktif sudah ada: <?= $tujuan[$k] ?>)</span></label></div>
                <?php endforeach ?>
                <button class="btn btn-primary mt-3"><i class="bi bi-files"></i> Salin</button>
            </form>
            <?php endif ?>
        </div></div>
    </div>
    <div class="col-lg-5">
        <div class="card"><div class="card-body small">
            <h6>Catatan</h6>
            <ul class="mb-0">
                <li>Hanya <b>menambah</b> data yang belum ada di TP aktif; data yang sudah ada tidak diubah.</li>
                <li>Jadwal yang disalin adalah versi terakhir yang berlaku di semester sumber. Jadwal ikut menyalin penugasan.</li>
                <li><b>Rombel</b> cocok untuk Ganjil → Genap di tahun yang sama. Untuk tahun pelajaran baru (kenaikan kelas), atur rombel dari menu Rombel.</li>
                <li>Setelah disalin, periksa kembali penugasan dan jadwal untuk perubahan guru/mapel.</li>
            </ul>
        </div></div>
    </div>
</div>
<?= $this->endSection() ?>
