<?= $this->extend('layouts/main') ?>
<?= $this->section('actions') ?><a href="<?= site_url('jurnal?tanggal=' . $tanggal) ?>" class="btn btn-light"><i class="bi bi-arrow-left"></i> Kembali</a><?= $this->endSection() ?>
<?= $this->section('content') ?>
<?php $v = static fn ($k, $d = '') => esc(old($k, $jurnal[$k] ?? $d)); ?>
<form method="post" action="<?= site_url('jurnal/simpan/' . $sesi['id']) ?>">
    <?= csrf_field() ?>
    <input type="hidden" name="tanggal" value="<?= $tanggal ?>">
    <div class="row">
        <div class="col-xl-5">
            <div class="card">
                <div class="card-header"><h5 class="card-title mb-0"><i class="bi bi-journal-text me-1"></i> Jurnal Pembelajaran</h5></div>
                <div class="card-body">
                    <?php if (! \App\Libraries\Akses::jurnalPengampu($sesi)) : ?>
                        <div class="alert alert-warning py-2 small">Anda mengisi sebagai <b>guru pengganti / piket</b> untuk <?= esc(nama_guru($sesi)) ?>.</div>
                    <?php endif ?>
                    <?php if ($sebelum && ! $jurnal) : ?>
                        <div class="alert alert-light py-2 small mb-3"><b>Pertemuan sebelumnya</b> (<?= tgl_indo($sebelum['tanggal']) ?>): <?= esc($sebelum['materi']) ?></div>
                    <?php endif ?>
                    <div class="row g-2">
                        <div class="col-4"><label class="form-label">Pertemuan ke</label><input type="number" name="pertemuan_ke" min="1" class="form-control" value="<?= esc(old('pertemuan_ke', $pertemuan)) ?>"></div>
                        <div class="col-8"><label class="form-label">Status KBM</label>
                            <select name="status_kbm" id="statusKbm" class="form-select">
                                <?php foreach (['Terlaksana', 'Penilaian', 'Tugas Mandiri', 'Diganti Guru Lain', 'Tidak Terlaksana'] as $s) : ?>
                                    <option <?= old('status_kbm', $jurnal['status_kbm'] ?? 'Terlaksana') === $s ? 'selected' : '' ?>><?= $s ?></option>
                                <?php endforeach ?>
                            </select></div>
                        <div class="col-12"><label class="form-label">Materi / topik *</label><input name="materi" class="form-control" value="<?= $v('materi') ?>" required maxlength="255"></div>
                        <?php if ($atp) : $oldAtp = array_map('intval', (array) old('atp_ids', $atpPilih)); ?>
                        <div class="col-12"><label class="form-label">TP dari ATP yang dibahas <a href="<?= site_url('atp?mapel_id=' . $sesi['mapel_id']) ?>" class="small" target="_blank">(lihat ATP)</a></label>
                            <div class="border rounded p-2" style="max-height:180px;overflow:auto">
                            <?php foreach ($atp as $a) : ?>
                                <div class="form-check"><input class="form-check-input" type="checkbox" name="atp_ids[]" value="<?= $a['id'] ?>" id="atp<?= $a['id'] ?>" <?= in_array((int) $a['id'], $oldAtp, true) ? 'checked' : '' ?> data-tujuan="<?= esc($a['tujuan'], 'attr') ?>">
                                    <label class="form-check-label small" for="atp<?= $a['id'] ?>"><?= $a['kode'] ? '<b>' . esc($a['kode']) . '</b> ' : '' ?><?= esc($a['tujuan']) ?>
                                        <?php if (! empty($atpSudah[$a['id']])) : ?><span class="badge bg-light-success text-success"><?= $atpSudah[$a['id']] ?>× dibahas</span><?php endif ?></label></div>
                            <?php endforeach ?>
                            </div></div>
                        <?php endif ?>
                        <div class="col-12"><label class="form-label">Tujuan pembelajaran</label><textarea name="tujuan_pembelajaran" class="form-control" rows="2"><?= $v('tujuan_pembelajaran') ?></textarea></div>
                        <div class="col-12"><label class="form-label">Kegiatan pembelajaran</label><textarea name="kegiatan" class="form-control" rows="3"><?= $v('kegiatan') ?></textarea></div>
                        <div class="col-md-6"><label class="form-label">Metode / model</label><input name="metode" class="form-control" list="dlMetode" value="<?= $v('metode') ?>">
                            <datalist id="dlMetode"><option>Ceramah & tanya jawab</option><option>Diskusi kelompok</option><option>Problem Based Learning</option><option>Project Based Learning</option><option>Discovery Learning</option><option>Praktikum</option></datalist></div>
                        <div class="col-md-6"><label class="form-label">Penilaian</label><input name="penilaian" class="form-control" value="<?= $v('penilaian') ?>" placeholder="Kuis, tugas, observasi..."></div>
                        <div class="col-12"><label class="form-label">Catatan / kendala</label><textarea name="catatan" class="form-control" rows="2"><?= $v('catatan') ?></textarea></div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-xl-7">
            <div class="card" id="kartuAbsen">
                <div class="card-header d-flex flex-wrap justify-content-between align-items-center gap-2">
                    <h5 class="card-title mb-0"><i class="bi bi-person-check me-1"></i> Absensi Siswa (<?= count($siswa) ?>)</h5>
                    <div class="btn-group btn-group-sm">
                        <button type="button" class="btn btn-outline-success" onclick="semua('H')">Semua hadir</button>
                    </div>
                </div>
                <div class="card-body table-responsive">
                    <?php if (! $siswa) : ?><div class="alert alert-warning">Belum ada siswa di kelas ini.</div><?php endif ?>
                    <table class="table table-sm table-hover table-presensi tabel-hp">
                        <thead><tr><th>No</th><th>Nama</th><th class="text-center">Kehadiran</th><th>Keterangan</th></tr></thead>
                        <tbody>
                        <?php foreach ($siswa as $s) :
                            $pg = $pagi[$s['id']] ?? null;
                            $sr = $saran[$s['id']] ?? ['status' => 'H', 'alasan' => null];
                            $pm = $presensi[$s['id']] ?? null;
                            $st = $pm['status'] ?? $sr['status'];
                            $st = old('presensi.' . $s['id'] . '.status', $st);
                        ?>
                            <tr>
                                <td class="d-none d-md-table-cell"><?= esc($s['no_absen']) ?></td>
                                <td data-label="Siswa"><b class="d-md-none"><?= esc($s['no_absen']) ?>.</b> <?= esc($s['nama_lengkap']) ?>
                                    <?php if ($pg && $pg !== 'H') : ?><span class="small text-muted" title="Absensi pagi">(pagi: <?= badge_presensi($pg) ?>)</span><?php endif ?>
                                    <?php if ($sr['alasan'] && ! str_starts_with($sr['alasan'], 'absensi pagi')) : ?><br><span class="badge text-bg-warning-subtle border border-warning-subtle text-warning-emphasis fw-normal" title="Dicatat piket/wali kelas"><i class="bi bi-info-circle"></i> <?= esc($sr['alasan']) ?></span><?php endif ?>
                                    <?php if ($pm && $pm['status'] !== $sr['status'] && ($pm['sumber'] ?? '') === 'Guru' && $sr['status'] !== 'H') : ?><span class="badge text-bg-light border fw-normal" title="Status diubah guru, tidak mengikuti data piket">diubah guru</span><?php endif ?></td>
                                <td class="text-center text-nowrap" data-label="Kehadiran">
                                    <?php foreach (['H' => 'success', 'S' => 'info', 'I' => 'primary', 'A' => 'danger', 'D' => 'secondary'] as $k => $c) : ?>
                                        <input type="radio" class="btn-check st" name="presensi[<?= $s['id'] ?>][status]" id="p<?= $s['id'] . $k ?>" value="<?= $k ?>" <?= $st === $k ? 'checked' : '' ?>>
                                        <label class="btn btn-sm btn-outline-<?= $c ?> btn-status" for="p<?= $s['id'] . $k ?>" title="<?= status_presensi()[$k] ?>"><?= $k ?></label>
                                    <?php endforeach ?>
                                </td>
                                <td data-label="Keterangan"><input name="presensi[<?= $s['id'] ?>][keterangan]" class="form-control form-control-sm" value="<?= esc(old('presensi.' . $s['id'] . '.keterangan', $pm['keterangan'] ?? ($sr['status'] !== 'H' ? $sr['alasan'] : ''))) ?>"></td>
                            </tr>
                        <?php endforeach ?>
                        </tbody>
                    </table>
                    <div class="small text-muted">H = Hadir · S = Sakit · I = Izin · A = Alpa · D = Dispensasi. Status dari absensi pagi, izin pulang awal, dan dispensasi terisi otomatis dan ikut diperbarui bila piket/wali kelas mengubahnya — kecuali yang Anda ubah sendiri.</div>
                    <div class="mt-2 small" id="rekapAbsen"></div>
                </div>
            </div>
        </div>
    </div>
    <div class="card"><div class="card-body py-3 d-flex gap-2">
        <button class="btn btn-primary"><i class="bi bi-save"></i> Simpan Jurnal & Absensi</button>
        <a href="<?= site_url('jurnal?tanggal=' . $tanggal) ?>" class="btn btn-light">Batal</a>
    </div></div>
</form>
<?= $this->endSection() ?>
<?= $this->section('scripts') ?>
<script>
function semua(v){document.querySelectorAll('input.st[value="'+v+'"]').forEach(r=>r.checked=true);hitung();}
function hitung(){
    var c={H:0,S:0,I:0,A:0,D:0};
    document.querySelectorAll('input.st:checked').forEach(r=>c[r.value]++);
    document.getElementById('rekapAbsen').innerHTML=Object.keys(c).map(k=>'<b>'+k+'</b>: '+c[k]).join(' &middot; ');
}
function toggleAbsen(){
    var off=document.getElementById('statusKbm').value==='Tidak Terlaksana';
    document.getElementById('kartuAbsen').style.opacity=off?.4:1;
}
document.querySelectorAll('input.st').forEach(r=>r.addEventListener('change',hitung));
document.getElementById('statusKbm').addEventListener('change',toggleAbsen);
hitung();toggleAbsen();
</script>
<?= $this->endSection() ?>
