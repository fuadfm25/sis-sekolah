<?= $this->extend('layouts/main') ?>
<?= $this->section('content') ?>
<div class="card"><div class="card-body py-3">
    <form class="d-flex flex-wrap gap-2 align-items-center filter" method="get">
        <input type="date" name="tanggal" value="<?= $tanggal ?>" class="form-control w-auto" onchange="this.form.submit()">
        <select name="kelas_id" class="form-select w-auto" onchange="this.form.submit()"><option value="">Semua kelas</option>
            <?php foreach ($kelas as $k) : ?><option value="<?= $k['id'] ?>" <?= $kelasId == $k['id'] ? 'selected' : '' ?>><?= esc($k['nama_kelas']) ?></option><?php endforeach ?></select>
        <span class="ms-auto">Terisi: <strong><?= $terisi ?></strong> / <?= count($sesi) ?> sesi
            <?php if ($sesi) : ?><span class="badge bg-<?= $terisi == count($sesi) ? 'success' : 'warning' ?>"><?= round($terisi / count($sesi) * 100) ?>%</span><?php endif ?></span>
    </form>
</div></div>
<?php if (! $status['kbm']) : ?>
    <div class="alert alert-<?= $status['warna'] === 'success' ? 'light' : $status['warna'] ?> bg-opacity-25"><i class="bi bi-calendar-x"></i> Tidak ada KBM pada tanggal ini: <?= esc($status['label']) ?>.</div>
<?php elseif ($status['agenda']) : ?>
    <div class="alert alert-info py-2 small"><i class="bi bi-info-circle"></i> <?= esc($status['label']) ?>. Sesi kelas yang tidak ber-KBM tidak ditampilkan.</div>
<?php endif ?>
<div class="card"><div class="card-body table-responsive">
    <table class="table table-sm table-hover align-middle">
        <thead><tr><th>Kelas</th><th>Jam</th><th>Mapel</th><th>Guru</th><th>Status</th><th>Materi</th><th>H/S/I/A</th><th></th></tr></thead>
        <tbody>
        <?php foreach ($sesi as $s) : $j = $s['jurnal']; $p = $j ? ($ringkas[$j['id']] ?? []) : []; ?>
            <tr class="<?= $j ? '' : 'table-warning' ?>">
                <td><?= esc($s['nama_kelas']) ?></td>
                <td class="text-nowrap"><?= esc($s['jam_ke_label']) ?> <small class="text-muted">(<?= jam($s['jam_mulai']) ?>)</small></td>
                <td><?= esc($s['nama_mapel']) ?></td>
                <td><?= esc(nama_guru($s)) ?>
                    <?php if ($iz = $izinGuru[$s['guru_id']] ?? null) : ?><div class="small text-primary"><i class="bi bi-envelope-check"></i> <?= \App\Models\IzinGuruModel::JENIS[$iz['jenis']] ?><?= $iz['tugas_siswa'] ? '<br><span class="text-muted">Tugas: ' . nl2br(esc($iz['tugas_siswa'])) . '</span>' : '' ?></div><?php endif ?>
                    <?php if (! empty($hadirGuru[$s['guru_id']]) && in_array($hadirGuru[$s['guru_id']]['status'], ['S', 'I', 'DL', 'C', 'A'], true) && empty($izinGuru[$s['guru_id']])) : ?><div class="small text-danger">Tidak hadir (<?= esc($hadirGuru[$s['guru_id']]['status']) ?>)</div><?php endif ?></td>
                <td><?= $j ? badge_status($j['status_kbm']) : '<span class="badge bg-light text-danger">Belum diisi</span>' ?></td>
                <td><?= $j ? esc(character_limiter($j['materi'], 50)) : '' ?></td>
                <td class="small text-nowrap"><?= $j ? (($p['H'] ?? 0) . '/' . ($p['S'] ?? 0) . '/' . ($p['I'] ?? 0) . '/' . ($p['A'] ?? 0)) : '' ?></td>
                <td class="text-nowrap">
                    <?php if ($j) : ?><a href="<?= site_url('jurnal/detail/' . $j['id']) ?>" class="btn btn-sm btn-light"><i class="bi bi-eye"></i></a><?php endif ?>
                    <?php if (\App\Libraries\Akses::jurnalPengganti($tanggal) && $tanggal <= date('Y-m-d')) : ?>
                        <a href="<?= site_url('jurnal/isi/' . $s['id'] . '?tanggal=' . $tanggal) ?>" class="btn btn-sm btn-outline-secondary" title="Isi sebagai guru pengganti/piket"><i class="bi bi-pencil"></i></a>
                    <?php endif ?>
                </td>
            </tr>
        <?php endforeach ?>
        <?php if (! $sesi) : ?><tr><td colspan="8" class="text-center text-muted"><?= $status['kbm'] ? 'Tidak ada jadwal pada tanggal ini.' : 'Jurnal tidak diwajibkan.' ?></td></tr><?php endif ?>
        </tbody>
    </table>
</div></div>
<?= $this->endSection() ?>
