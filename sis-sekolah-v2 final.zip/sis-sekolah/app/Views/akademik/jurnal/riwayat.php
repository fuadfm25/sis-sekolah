<?= $this->extend('layouts/main') ?>
<?= $this->section('actions') ?><button onclick="window.print()" class="btn btn-light"><i class="bi bi-printer"></i> Cetak</button><?= $this->endSection() ?>
<?= $this->section('content') ?>
<div class="card"><div class="card-body">
    <form class="row g-2 mb-3 filter" method="get">
        <div class="col-md-2"><label class="form-label small">Dari</label><input type="date" name="dari" value="<?= esc($f['dari']) ?>" class="form-control"></div>
        <div class="col-md-2"><label class="form-label small">Sampai</label><input type="date" name="sampai" value="<?= esc($f['sampai']) ?>" class="form-control"></div>
        <div class="col-md-2"><label class="form-label small">Kelas</label><select name="kelas_id" class="form-select"><option value="">Semua</option>
            <?php foreach ($kelas as $k) : ?><option value="<?= $k['id'] ?>" <?= $f['kelas_id'] == $k['id'] ? 'selected' : '' ?>><?= esc($k['nama_kelas']) ?></option><?php endforeach ?></select></div>
        <?php if ($semua) : ?>
        <div class="col-md-3"><label class="form-label small">Guru</label><select name="guru_id" class="form-select tom"><option value="">Semua</option>
            <?php foreach ($guru as $g) : ?><option value="<?= $g['id'] ?>" <?= $f['guru_id'] == $g['id'] ? 'selected' : '' ?>><?= esc(nama_guru($g)) ?></option><?php endforeach ?></select></div>
        <?php endif ?>
        <div class="col-md-1 d-flex align-items-end"><button class="btn btn-primary w-100"><i class="bi bi-funnel"></i></button></div>
    </form>
    <?= $this->include('partials/print_header') ?>
    <div class="table-responsive">
    <table class="table table-sm table-hover align-middle">
        <thead><tr><th>Tanggal</th><th>Jam</th><th>Kelas</th><th>Mapel</th><?php if ($semua) : ?><th>Guru</th><?php endif ?><th>Pert.</th><th>Materi</th><th>Status</th><th>H/S/I/A/D</th><th class="no-print"></th></tr></thead>
        <tbody>
        <?php foreach ($rows as $r) : $p = $ringkas[$r['id']] ?? []; ?>
            <tr>
                <td class="text-nowrap"><?= tgl_indo($r['tanggal']) ?></td>
                <td><?= esc($r['jam_ke']) ?></td>
                <td><?= esc($r['nama_kelas']) ?></td>
                <td><?= esc($r['nama_mapel']) ?></td>
                <?php if ($semua) : ?><td><?= esc(nama_guru($r)) ?></td><?php endif ?>
                <td><?= esc($r['pertemuan_ke']) ?></td>
                <td><?= esc(character_limiter($r['materi'], 60)) ?></td>
                <td><?= badge_status($r['status_kbm']) ?></td>
                <td class="text-nowrap small"><?= ($p['H'] ?? 0) . '/' . ($p['S'] ?? 0) . '/' . ($p['I'] ?? 0) . '/' . ($p['A'] ?? 0) . '/' . ($p['D'] ?? 0) ?></td>
                <td class="no-print"><a href="<?= site_url('jurnal/detail/' . $r['id']) ?>" class="btn btn-sm btn-light"><i class="bi bi-eye"></i></a></td>
            </tr>
        <?php endforeach ?>
        <?php if (! $rows) : ?><tr><td colspan="10" class="text-center text-muted">Tidak ada jurnal pada periode ini.</td></tr><?php endif ?>
        </tbody>
    </table>
    </div>
    <?= $this->include('partials/pager') ?>
</div></div>
<?= $this->endSection() ?>
