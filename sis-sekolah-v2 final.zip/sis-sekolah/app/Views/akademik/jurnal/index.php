<?= $this->extend('layouts/main') ?>
<?= $this->section('content') ?>
<div class="card"><div class="card-body py-3">
    <form class="d-flex flex-wrap gap-2 align-items-center filter" method="get">
        <a class="btn btn-light" href="?tanggal=<?= date('Y-m-d', strtotime($tanggal . ' -1 day')) ?>"><i class="bi bi-chevron-left"></i></a>
        <input type="date" name="tanggal" value="<?= $tanggal ?>" max="<?= date('Y-m-d') ?>" class="form-control w-auto" onchange="this.form.submit()">
        <a class="btn btn-light" href="?tanggal=<?= date('Y-m-d', strtotime($tanggal . ' +1 day')) ?>"><i class="bi bi-chevron-right"></i></a>
        <strong class="ms-2"><?= tgl_indo($tanggal, true) ?></strong>
        <?php if ($tanggal !== date('Y-m-d')) : ?><a href="<?= site_url('jurnal') ?>" class="btn btn-sm btn-outline-primary ms-auto">Hari ini</a><?php endif ?>
    </form>
</div></div>

<div class="row">
    <div class="col-lg-8">
        <?php if (! $status['kbm']) : ?>
            <div class="alert alert-<?= $status['warna'] === 'success' ? 'light' : $status['warna'] ?> bg-opacity-25"><i class="bi bi-calendar-x"></i> <b>Tidak ada KBM.</b> <?= esc($status['label']) ?><?= $status['absensi'] ? ' — absensi harian siswa tetap diambil.' : '' ?></div>
        <?php elseif ($status['agenda']) : ?>
            <div class="alert alert-info py-2 small"><i class="bi bi-info-circle"></i> <?= esc($status['label']) ?> — KBM tetap berjalan.</div>
        <?php endif ?>
        <?php if ($status['kbm'] && ! $sesi) : ?>
            <div class="alert alert-light">Tidak ada jadwal mengajar pada hari ini.</div>
        <?php endif ?>
        <?php foreach ($sesi as $s) : ?>
            <div class="card mb-3 border-start border-4 border-<?= $s['jurnal'] ? 'success' : 'warning' ?>">
                <div class="card-body d-flex flex-wrap justify-content-between align-items-center gap-2">
                    <div>
                        <h5 class="mb-1"><?= esc($s['nama_mapel']) ?> <small class="text-muted">· <?= esc($s['nama_kelas']) ?></small></h5>
                        <div class="text-muted small">Jam ke-<?= esc($s['jam_ke_label']) ?> · <?= jam($s['jam_mulai']) ?>–<?= jam($s['jam_selesai']) ?> · <?= $s['jumlah_jp'] ?> JP</div>
                        <?php if ($s['jurnal']) : ?>
                            <div class="small mt-1"><i class="bi bi-journal-text"></i> <?= esc(character_limiter($s['jurnal']['materi'], 80)) ?> <?= badge_status($s['jurnal']['status_kbm']) ?></div>
                        <?php endif ?>
                    </div>
                    <div class="text-nowrap">
                        <?php if ($s['jurnal']) : ?>
                            <a href="<?= site_url('jurnal/detail/' . $s['jurnal']['id']) ?>" class="btn btn-sm btn-light"><i class="bi bi-eye"></i></a>
                            <a href="<?= site_url('jurnal/isi/' . $s['id'] . '?tanggal=' . $tanggal) ?>" class="btn btn-sm btn-outline-success"><i class="bi bi-pencil"></i> Edit</a>
                        <?php elseif ($tanggal <= date('Y-m-d')) : ?>
                            <a href="<?= site_url('jurnal/isi/' . $s['id'] . '?tanggal=' . $tanggal) ?>" class="btn btn-primary"><i class="bi bi-pencil-square"></i> Isi Jurnal & Absensi</a>
                        <?php else : ?>
                            <span class="badge bg-light text-muted">Akan datang</span>
                        <?php endif ?>
                    </div>
                </div>
            </div>
        <?php endforeach ?>
    </div>
    <div class="col-lg-4">
        <div class="card">
            <div class="card-header"><h6 class="mb-0"><i class="bi bi-exclamation-diamond text-warning"></i> Belum diisi minggu ini</h6></div>
            <div class="card-body">
                <?php if (! $belum) : ?>
                    <p class="text-success small mb-0"><i class="bi bi-check2-all"></i> Semua jurnal minggu ini sudah terisi.</p>
                <?php else : ?>
                    <ul class="list-unstyled small mb-0">
                    <?php foreach ($belum as $b) : ?>
                        <li class="mb-2"><a href="<?= site_url('jurnal/isi/' . $b['id'] . '?tanggal=' . $b['tanggal']) ?>"><?= tgl_indo($b['tanggal'], true) ?></a><br>
                            <span class="text-muted"><?= esc($b['nama_mapel']) ?> · <?= esc($b['nama_kelas']) ?> · jam <?= esc($b['jam_ke_label']) ?></span></li>
                    <?php endforeach ?>
                    </ul>
                <?php endif ?>
            </div>
        </div>
    </div>
</div>
<?= $this->endSection() ?>
