<?= $this->extend('layouts/main') ?>
<?= $this->section('actions') ?>
<button onclick="window.print()" class="btn btn-light"><i class="bi bi-printer"></i> Cetak</button>
<?php if ($bolehUbah && $j['jadwal_pelajaran_id']) : ?>
    <a href="<?= site_url('jurnal/isi/' . $j['jadwal_pelajaran_id'] . '?tanggal=' . $j['tanggal']) ?>" class="btn btn-warning"><i class="bi bi-pencil"></i> Edit</a>
<?php endif ?>
<?= $this->endSection() ?>
<?= $this->section('content') ?>
<?php $hit = array_count_values(array_column($presensi, 'status')); ?>
<div class="card"><div class="card-body">
    <?= $this->include('partials/print_header') ?>
    <h5 class="print-only text-center mb-3">JURNAL PEMBELAJARAN</h5>
    <div class="row">
        <div class="col-md-6">
            <table class="table table-sm table-borderless">
                <tr><th style="width:150px">Tanggal</th><td><?= tgl_indo($j['tanggal'], true) ?></td></tr>
                <tr><th>Kelas</th><td><?= esc($j['nama_kelas']) ?></td></tr>
                <tr><th>Mata pelajaran</th><td><?= esc($j['nama_mapel']) ?></td></tr>
                <tr><th>Guru</th><td><?= esc(nama_guru($j)) ?></td></tr>
                <tr><th>Jam ke / JP</th><td><?= esc($j['jam_ke']) ?> (<?= $j['jumlah_jp'] ?> JP)</td></tr>
            </table>
        </div>
        <div class="col-md-6">
            <table class="table table-sm table-borderless">
                <tr><th style="width:150px">Pertemuan ke</th><td><?= esc($j['pertemuan_ke'] ?? '-') ?></td></tr>
                <tr><th>Status KBM</th><td><?= badge_status($j['status_kbm']) ?></td></tr>
                <tr><th>Diisi oleh</th><td><?= esc($j['pengisi'] ?? '-') ?></td></tr>
                <tr><th>Kehadiran</th><td><?php foreach (['H', 'S', 'I', 'A', 'D'] as $k) : ?><span class="me-2"><?= badge_presensi($k) ?> <?= $hit[$k] ?? 0 ?></span><?php endforeach ?></td></tr>
            </table>
        </div>
    </div>
    <hr>
    <dl class="row">
        <dt class="col-md-3">Materi</dt><dd class="col-md-9"><?= esc($j['materi']) ?></dd>
        <dt class="col-md-3">Tujuan pembelajaran</dt><dd class="col-md-9"><?= nl2br(esc($j['tujuan_pembelajaran'] ?? '-')) ?></dd>
        <dt class="col-md-3">Kegiatan</dt><dd class="col-md-9"><?= nl2br(esc($j['kegiatan'] ?? '-')) ?></dd>
        <dt class="col-md-3">Metode</dt><dd class="col-md-9"><?= esc($j['metode'] ?? '-') ?></dd>
        <dt class="col-md-3">Penilaian</dt><dd class="col-md-9"><?= esc($j['penilaian'] ?? '-') ?></dd>
        <dt class="col-md-3">Catatan / kendala</dt><dd class="col-md-9"><?= nl2br(esc($j['catatan'] ?? '-')) ?></dd>
    </dl>
    <h6 class="mt-3">Siswa tidak hadir</h6>
    <table class="table table-sm">
        <thead><tr><th>No</th><th>Nama</th><th>Status</th><th>Keterangan</th></tr></thead>
        <tbody>
        <?php $ada = false; foreach ($siswa as $s) : $p = $presensi[$s['id']] ?? null; if (! $p || $p['status'] === 'H') continue; $ada = true; ?>
            <tr><td><?= esc($s['no_absen']) ?></td><td><?= esc($s['nama_lengkap']) ?></td><td><?= badge_presensi($p['status']) ?> <?= status_presensi()[$p['status']] ?></td><td><?= esc($p['keterangan']) ?></td></tr>
        <?php endforeach ?>
        <?php if (! $ada) : ?><tr><td colspan="4" class="text-muted"><?= $presensi ? 'Semua siswa hadir.' : 'Absensi tidak diisi.' ?></td></tr><?php endif ?>
        </tbody>
    </table>
    <?php if ($bolehHapus) : ?>
        <div class="no-print text-end"><?= delete_button('jurnal/hapus/' . $j['id'], 'Hapus jurnal', 'Hapus jurnal beserta absensinya?') ?></div>
    <?php endif ?>
</div></div>
<?= $this->endSection() ?>
