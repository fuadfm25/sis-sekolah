<?= $this->extend('layouts/main') ?>
<?= $this->section('actions') ?><button onclick="window.print()" class="btn btn-light"><i class="bi bi-printer"></i> Cetak</button><?= $this->endSection() ?>
<?= $this->section('content') ?>
<div class="card no-print"><div class="card-body">
    <form class="row g-2 filter" method="get">
        <div class="col-md-5"><label class="form-label small">Mapel – kelas</label>
            <select name="penugasan_id" class="form-select tom" required><option value="">- pilih -</option>
                <?php foreach ($opsi as $o) : ?><option value="<?= $o['id'] ?>" <?= $penugasanId == $o['id'] ? 'selected' : '' ?>><?= esc($o['nama_kelas'] . ' · ' . $o['nama_mapel'] . ' · ' . nama_guru($o)) ?></option><?php endforeach ?>
            </select></div>
        <div class="col-md-2"><label class="form-label small">Dari</label><input type="date" name="dari" value="<?= esc($dari) ?>" class="form-control"></div>
        <div class="col-md-2"><label class="form-label small">Sampai</label><input type="date" name="sampai" value="<?= esc($sampai) ?>" class="form-control"></div>
        <div class="col-md-2 d-flex align-items-end"><button class="btn btn-primary w-100">Tampilkan</button></div>
    </form>
</div></div>

<?php if ($pilih) : ?>
<div class="card"><div class="card-body">
    <?= $this->include('partials/print_header') ?>
    <h6 class="print-only text-center">Rekap Absensi <?= esc($subtitle) ?> (<?= tgl_indo($dari) ?> – <?= tgl_indo($sampai) ?>)</h6>
    <?php if (! $jurnal) : ?>
        <p class="text-muted mb-0">Belum ada jurnal pada periode ini.</p>
    <?php else : ?>
    <div class="table-responsive">
    <table class="table table-bordered rekap-mini">
        <thead class="table-light">
            <tr><th rowspan="2">No</th><th rowspan="2" class="sticky-col">Nama</th>
                <?php foreach ($jurnal as $j) : ?><th title="<?= tgl_indo($j['tanggal']) ?>"><?= date('d/m', strtotime($j['tanggal'])) ?></th><?php endforeach ?>
                <th colspan="5">Jumlah</th><th rowspan="2">% Hadir</th></tr>
            <tr><?php foreach ($jurnal as $j) : ?><th class="text-muted"><?= esc($j['pertemuan_ke']) ?></th><?php endforeach ?><th>H</th><th>S</th><th>I</th><th>A</th><th>D</th></tr>
        </thead>
        <tbody>
        <?php foreach ($siswa as $s) : $c = ['H' => 0, 'S' => 0, 'I' => 0, 'A' => 0, 'D' => 0]; ?>
            <tr>
                <td><?= esc($s['no_absen']) ?></td>
                <td class="sticky-col"><?= esc($s['nama_lengkap']) ?></td>
                <?php foreach ($jurnal as $j) : $st = $matriks[$s['id']][$j['id']] ?? null; if ($st) { $c[$st]++; } ?>
                    <td class="<?= $st && $st !== 'H' ? 'fw-bold text-danger' : '' ?>"><?= $st === 'H' ? '•' : esc($st ?? '') ?></td>
                <?php endforeach ?>
                <?php foreach ($c as $n) : ?><td><?= $n ?></td><?php endforeach ?>
                <?php $tot = array_sum($c); ?>
                <td><?= $tot ? round(($c['H'] + $c['D']) / $tot * 100) : '-' ?></td>
            </tr>
        <?php endforeach ?>
        </tbody>
    </table>
    </div>
    <small class="text-muted">• = hadir. Baris kedua header = pertemuan ke-.</small>
    <?php endif ?>
</div></div>
<?php endif ?>
<?= $this->endSection() ?>
