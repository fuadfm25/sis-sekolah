<?= $this->extend('layouts/main') ?>
<?= $this->section('head') ?>
<style>
    .kal { table-layout: fixed; min-width: 640px; }
    .kal td { height: 96px; vertical-align: top; padding: 6px 7px !important; font-size: .76rem; }
    .kal thead th { text-align: center; }
    .kal .tgl { font-weight: 700; font-size: .95rem; }
    .kal .lain { background: #fafbfd; color: #b5bdcc; }
    .kal .lain .tgl { font-weight: 500; }
    .kal .st-success { background: #f2faf7; }
    .kal .st-secondary { background: #eef0f4; }
    .kal .st-danger { background: #fcecec; }
    .kal .st-warning { background: #fdf6e3; }
    .kal .st-primary { background: #e8edf8; }
    .kal .st-info { background: #e5f2fb; }
    .kal .ikon i { font-size: .85rem; }
    .kal .agenda { line-height: 1.2; margin-top: 3px; font-weight: 600; overflow-wrap: anywhere; }
    .kal .hariini { box-shadow: inset 0 0 0 2px var(--sis-primary); }
    .kal .hariini .tgl { background: var(--sis-primary); color: #fff; border-radius: 6px; padding: 0 6px; }
    .legenda { display: flex; flex-wrap: wrap; gap: .5rem 1.1rem; font-size: .78rem; color: var(--sis-muted); }
    .legenda .item { display: inline-flex; align-items: center; gap: .4rem; white-space: nowrap; }
    .legenda .kotak { display: inline-block; width: 14px; height: 14px; border-radius: 4px; flex-shrink: 0; }
</style>
<?= $this->endSection() ?>
<?= $this->section('actions') ?>
<?= tombol_impor('kalender') ?>
<a href="<?= site_url('laporan/pekan-efektif') ?>" target="_blank" class="btn btn-outline-secondary"><i class="bi bi-printer"></i> Rincian Pekan Efektif</a>
<?php if ($kelola) : ?>
<button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#modalForm" data-title="Tambah Agenda" data-action="<?= site_url('akademik/kalender/store') ?>" data-row='<?= esc(json_encode(['jenis' => 'Libur Nasional', 'tanggal_mulai' => date('Y-m-d')]), 'attr') ?>'><i class="bi bi-plus-lg"></i> Tambah Agenda</button>
<?php endif ?>
<?= $this->endSection() ?>
<?= $this->section('content') ?>
<?php
$warnaJenis = array_map(static fn ($b) => $b[2], \App\Models\KalenderModel::BAWAAN);
$tp = tp_aktif();
?>
<?php if (empty($tp['tanggal_mulai'])) : ?>
    <div class="alert alert-warning">Periode tahun pelajaran aktif (tanggal mulai & selesai) belum diisi, sehingga pekan efektif tidak dapat dihitung dengan tepat.
        <?php if (\App\Libraries\Akses::punya('kurikulum')) : ?><a href="<?= site_url('akademik/tahun-pelajaran') ?>" class="alert-link">Lengkapi di sini</a>.<?php endif ?></div>
<?php endif ?>
<div class="row">
    <div class="col-xl-8">
        <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center">
                <a href="?bulan=<?= $sebelum ?>" class="btn btn-sm btn-light"><i class="bi bi-chevron-left"></i></a>
                <h5 class="mb-0"><?= bulan_list()[(int) substr($ym, 5, 2)] . ' ' . substr($ym, 0, 4) ?></h5>
                <a href="?bulan=<?= $sesudah ?>" class="btn btn-sm btn-light"><i class="bi bi-chevron-right"></i></a>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                <table class="table table-bordered kal mb-3">
                    <thead><tr><?php foreach (['Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu', 'Minggu'] as $h) : ?><th><?= $h ?></th><?php endforeach ?></tr></thead>
                    <tbody>
                    <?php
                    $mulai = strtotime('monday this week', strtotime($awal));
                    $akhir = strtotime('sunday this week', strtotime(date('Y-m-t', strtotime($awal))));
                    for ($t = $mulai; $t <= $akhir; $t += 86400) :
                        $d = date('Y-m-d', $t);
                        if (date('N', $t) == 1) echo '<tr>';
                        $s = $hari[$d] ?? null;
                    ?>
                        <td class="<?= $s ? 'st-' . $s['warna'] : 'lain' ?> <?= $d === date('Y-m-d') ? 'hariini' : '' ?>">
                            <div class="d-flex justify-content-between"><span class="tgl"><?= (int) date('j', $t) ?></span>
                                <?php if ($s && $s['sekolah']) : ?><span class="ikon text-nowrap" title="<?= $s['kbm'] ? 'KBM' : 'Tanpa KBM' ?> · <?= $s['absensi'] ? 'absensi diambil' : 'tanpa absensi' ?>"><?= $s['kbm'] ? '<i class="bi bi-book text-success"></i>' : '' ?><?= $s['absensi'] ? '<i class="bi bi-person-check text-primary ms-1"></i>' : '' ?></span><?php endif ?></div>
                            <?php if ($s) : foreach ($s['agenda'] as $a) : ?>
                                <div class="agenda text-<?= $warnaJenis[$a['jenis']] ?? 'dark' ?>"><?= esc($a['nama']) ?></div>
                            <?php endforeach; endif ?>
                        </td>
                    <?php if (date('N', $t) == 7) echo '</tr>'; endfor ?>
                    </tbody>
                </table>
                </div>
                <div class="legenda">
                    <span class="item"><span class="kotak" style="background:#dff3ea;border:1px solid #bfe5d7"></span>Hari efektif</span>
                    <?php foreach (\App\Models\KalenderModel::BAWAAN as $j => [, , $w]) : ?><span class="item"><span class="kotak bg-<?= $w ?>"></span><?= esc($j) ?></span><?php endforeach ?>
                    <span class="item"><span class="kotak" style="background:#dfe3ea"></span>Bukan hari sekolah</span>
                    <span class="item"><i class="bi bi-book text-success"></i>KBM/jurnal</span>
                    <span class="item"><i class="bi bi-person-check text-primary"></i>Absensi</span>
                </div>
            </div>
        </div>
    </div>
    <div class="col-xl-4">
        <div class="card">
            <div class="card-header"><h6 class="mb-0">Ringkasan bulan ini</h6></div>
            <div class="card-body">
                <table class="table table-sm mb-0">
                    <tr><td>Hari sekolah</td><th class="text-end"><?= $ringkas['hari_sekolah'] ?></th></tr>
                    <tr><td>Hari efektif (KBM)</td><th class="text-end text-success"><?= $ringkas['hari_efektif'] ?></th></tr>
                    <tr><td>Pekan</td><th class="text-end"><?= $ringkas['pekan'] ?></th></tr>
                    <tr><td>Pekan efektif</td><th class="text-end text-success"><?= $ringkas['pekan_efektif'] ?></th></tr>
                </table>
            </div>
        </div>
        <div class="card">
            <div class="card-header"><h6 class="mb-0">Agenda TP <?= esc($tp['tahun_pelajaran'] . ' ' . $tp['semester']) ?> (<?= count($semua) ?>)</h6></div>
            <div class="card-body p-2" style="max-height:520px;overflow:auto">
                <?php if (! $semua) : ?><p class="text-muted small p-2 mb-0">Belum ada agenda.<?= $kelola ? ' Tambahkan libur nasional, cuti bersama, libur semester, ujian, dan kegiatan sekolah.' : '' ?></p><?php endif ?>
                <?php foreach ($semua as $a) : ?>
                    <div class="border-start border-3 border-<?= $warnaJenis[$a['jenis']] ?? 'dark' ?> ps-2 mb-2">
                        <div class="d-flex justify-content-between">
                            <a href="?bulan=<?= substr($a['tanggal_mulai'], 0, 7) ?>" class="fw-semibold small text-body"><?= esc($a['nama']) ?></a>
                            <?php if ($kelola) : ?>
                            <span class="text-nowrap">
                                <a href="#" class="small" data-bs-toggle="modal" data-bs-target="#modalForm" data-title="Edit Agenda" data-action="<?= site_url('akademik/kalender/update/' . $a['id']) ?>" data-row='<?= esc(json_encode(['kelas_ids' => \App\Models\KalenderModel::kelasDari($a['kelas_ids'] ?? null)] + $a), 'attr') ?>'><i class="bi bi-pencil"></i></a>
                                <form method="post" action="<?= site_url('akademik/kalender/delete/' . $a['id']) ?>" class="d-inline" onsubmit="return confirm('Hapus agenda ini?')"><?= csrf_field() ?><button class="btn btn-link btn-sm p-0 text-danger"><i class="bi bi-x-circle"></i></button></form>
                            </span>
                            <?php endif ?>
                        </div>
                        <?php $sas = \App\Models\KalenderModel::kelasDari($a['kelas_ids'] ?? null); ?>
                        <?php if ($sas) : ?><div class="small"><i class="bi bi-people"></i> Kelas: <?= esc(implode(', ', array_map(static fn ($id) => $namaKelas[$id] ?? '#' . $id, $sas))) ?></div><?php endif ?>
                        <?php if ($a['jenis'] === 'Masuk Pengganti' && $a['hari_jadwal']) : ?><div class="small text-success"><i class="bi bi-arrow-repeat"></i> Memakai jadwal hari <?= nama_hari($a['hari_jadwal']) ?></div><?php endif ?>
                        <div class="small text-muted"><?= esc($a['jenis']) ?> · <?= $a['tanggal_mulai'] === $a['tanggal_selesai'] ? tgl_indo($a['tanggal_mulai']) : tgl_indo($a['tanggal_mulai']) . ' – ' . tgl_indo($a['tanggal_selesai']) ?></div>
                        <div class="small"><?= $a['ada_kbm'] ? '<span class="badge bg-light-success text-success">KBM jalan</span>' : '<span class="badge bg-light-secondary text-secondary">tanpa KBM</span>' ?>
                            <?= $a['ada_absensi'] ? '<span class="badge bg-light-primary text-primary">absensi diambil</span>' : '<span class="badge bg-light-secondary text-secondary">tanpa absensi</span>' ?></div>
                    </div>
                <?php endforeach ?>
            </div>
        </div>
    </div>
</div>

<?php if ($kelola) : ?>
<div class="modal fade" id="modalForm" data-crud tabindex="-1">
    <div class="modal-dialog"><form method="post" class="modal-content"><?= csrf_field() ?>
        <div class="modal-header"><h5 class="modal-title"></h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
        <div class="modal-body row g-2">
            <div class="col-12"><label class="form-label">Jenis</label>
                <select name="jenis" id="jenis" class="form-select"><?php foreach (\App\Models\KalenderModel::JENIS as $j) : ?><option><?= $j ?></option><?php endforeach ?></select></div>
            <div class="col-12"><label class="form-label">Nama agenda</label><input name="nama" class="form-control" required maxlength="150" placeholder="Hari Guru Nasional / PTS Ganjil / Class Meeting"></div>
            <div class="col-6"><label class="form-label">Tanggal mulai</label><input type="date" name="tanggal_mulai" class="form-control" required></div>
            <div class="col-6"><label class="form-label">Tanggal selesai</label><input type="date" name="tanggal_selesai" class="form-control"><small class="text-muted">Kosong = 1 hari</small></div>
            <div class="col-12" id="boxPengganti"><label class="form-label">Memakai jadwal hari</label>
                <select name="hari_jadwal" class="form-select"><option value="">- pilih -</option><?php foreach ([1 => 'Senin', 2 => 'Selasa', 3 => 'Rabu', 4 => 'Kamis', 5 => 'Jumat', 6 => 'Sabtu'] as $h => $hn) : ?><option value="<?= $h ?>"><?= $hn ?></option><?php endforeach ?></select>
                <small class="text-muted">Contoh: Sabtu masuk menggantikan Senin yang libur → pilih Senin. Jurnal & absensi mengikuti jadwal hari tsb.</small></div>
            <div class="col-12"><label class="form-label">Berlaku untuk</label>
                <div class="border rounded p-2" style="max-height:150px;overflow:auto">
                    <small class="text-muted d-block mb-1">Tidak dicentang semua = seluruh sekolah. Centang kelas tertentu bila agenda hanya untuk kelas/tingkat itu (mis. ujian kelas IX, studi wisata kelas VIII).</small>
                    <?php $tingkatLalu = null; foreach ($kelasList as $k) : ?>
                        <?php if ($tingkatLalu !== $k['tingkat']) : $tingkatLalu = $k['tingkat']; ?><div class="small fw-bold mt-1">Tingkat <?= esc($k['tingkat']) ?> <a href="#" class="pilih-tingkat fw-normal" data-t="<?= esc($k['tingkat'], 'attr') ?>">(pilih semua)</a></div><?php endif ?>
                        <div class="form-check form-check-inline"><input class="form-check-input" type="checkbox" name="kelas_ids[]" value="<?= $k['id'] ?>" data-t="<?= esc($k['tingkat'], 'attr') ?>" id="kk<?= $k['id'] ?>"><label class="form-check-label small" for="kk<?= $k['id'] ?>"><?= esc($k['nama_kelas']) ?></label></div>
                    <?php endforeach ?>
                </div></div>
            <div class="col-12"><label class="form-label">Keterangan</label><textarea name="keterangan" class="form-control" rows="2"></textarea></div>
            <div class="col-12 border rounded p-2 mt-2">
                <div class="form-check"><input class="form-check-input" type="checkbox" name="ada_kbm" value="1" id="cKbm"><label class="form-check-label" for="cKbm"><b>KBM tetap berjalan</b> – guru wajib mengisi jurnal</label></div>
                <div class="form-check"><input class="form-check-input" type="checkbox" name="ada_absensi" value="1" id="cAbs"><label class="form-check-label" for="cAbs"><b>Absensi harian tetap diambil</b> – siswa wajib hadir (absensi pagi & kiosk aktif)</label></div>
                <small class="text-muted">Bawaan: libur → tanpa KBM & tanpa absensi; ujian & kegiatan sekolah → tanpa jurnal, absensi tetap diambil.</small>
            </div>
        </div>
        <div class="modal-footer"><button class="btn btn-primary">Simpan</button></div>
    </form></div>
</div>
<?php endif ?>
<?= $this->endSection() ?>
<?= $this->section('scripts') ?>
<?php if ($kelola) : ?>
<?= $this->include('partials/modal_form_js') ?>
<script>
const BAWAAN = <?= json_encode(\App\Models\KalenderModel::BAWAAN) ?>;
function togglePengganti() { document.getElementById('boxPengganti').style.display = document.getElementById('jenis').value === 'Masuk Pengganti' ? '' : 'none'; }
document.querySelectorAll('.pilih-tingkat').forEach(a => a.addEventListener('click', function (e) { e.preventDefault(); document.querySelectorAll('input[name="kelas_ids[]"][data-t="' + this.dataset.t + '"]').forEach(c => c.checked = true); }));
document.getElementById('jenis').addEventListener('change', togglePengganti);
document.getElementById('modalForm').addEventListener('shown.bs.modal', togglePengganti);
document.getElementById('jenis').addEventListener('change', function () {
    const b = BAWAAN[this.value]; if (!b) return;
    document.getElementById('cKbm').checked = b[0] === 1; document.getElementById('cAbs').checked = b[1] === 1;
});
document.getElementById('modalForm').addEventListener('shown.bs.modal', function (e) {
    if (!e.relatedTarget || !JSON.parse(e.relatedTarget.dataset.row || '{}').id) document.getElementById('jenis').dispatchEvent(new Event('change'));
});
</script>
<?php endif ?>
<?= $this->endSection() ?>
