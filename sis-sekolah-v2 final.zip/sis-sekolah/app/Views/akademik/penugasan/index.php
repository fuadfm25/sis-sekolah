<?= $this->extend('layouts/main') ?>
<?= $this->section('actions') ?>
<?= tombol_impor('penugasan') ?>
<button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#modalTambah"><i class="bi bi-plus-lg"></i> Tambah Penugasan</button>
<?= $this->endSection() ?>
<?= $this->section('content') ?>
<div class="card"><div class="card-body">
    <form class="row g-2 mb-3 filter" method="get">
        <div class="col-md-3"><select name="kelas_id" class="form-select" onchange="this.form.submit()"><option value="">Semua kelas</option>
            <?php foreach ($kelas as $k) : ?><option value="<?= $k['id'] ?>" <?= $f['kelas_id'] == $k['id'] ? 'selected' : '' ?>><?= esc($k['nama_kelas']) ?></option><?php endforeach ?></select></div>
        <div class="col-md-4"><select name="guru_id" class="form-select" onchange="this.form.submit()"><option value="">Semua guru</option>
            <?php foreach ($guru as $g) : ?><option value="<?= $g['id'] ?>" <?= $f['guru_id'] == $g['id'] ? 'selected' : '' ?>><?= esc(nama_guru($g)) ?></option><?php endforeach ?></select></div>
    </form>
    <div class="table-responsive">
    <table class="table table-hover table-sm align-middle">
        <thead><tr><th>Kelas</th><th>Mata Pelajaran</th><th>Guru</th><th class="text-center">JP/minggu</th><th class="text-center">Terjadwal</th><th class="text-end">Aksi</th></tr></thead>
        <tbody>
        <?php $totalJp = 0; foreach ($rows as $r) : $totalJp += $r['jp_per_minggu']; ?>
            <tr>
                <td><?= esc($r['nama_kelas']) ?></td>
                <td><?= esc($r['nama_mapel']) ?> <small class="text-muted"><?= esc($r['kode_mapel']) ?></small></td>
                <td><?= esc(nama_guru($r)) ?></td>
                <td class="text-center"><?= $r['jp_per_minggu'] ?></td>
                <td class="text-center"><span class="badge bg-<?= $r['jp_terjadwal'] == $r['jp_per_minggu'] ? 'success' : ($r['jp_terjadwal'] > $r['jp_per_minggu'] ? 'danger' : 'warning') ?>"><?= $r['jp_terjadwal'] ?></span></td>
                <td class="text-end text-nowrap">
                    <button class="btn btn-sm btn-outline-warning" data-bs-toggle="modal" data-bs-target="#modalForm" data-title="Edit: <?= esc($r['nama_mapel'] . ' - ' . $r['nama_kelas'], 'attr') ?>" data-action="<?= site_url('akademik/penugasan/update/' . $r['id']) ?>" data-row='<?= esc(json_encode(['guru_id' => $r['guru_id'], 'jp_per_minggu' => $r['jp_per_minggu']]), 'attr') ?>'><i class="bi bi-pencil"></i></button>
                    <?= delete_button('akademik/penugasan/delete/' . $r['id'], '', 'Hapus penugasan? Jadwal & jurnal mapel ini di kelas tersebut ikut terhapus.') ?>
                </td>
            </tr>
        <?php endforeach ?>
        <?php if (! $rows) : ?><tr><td colspan="6" class="text-center text-muted">Belum ada penugasan.</td></tr><?php endif ?>
        </tbody>
        <?php if ($rows && ($f['kelas_id'] || $f['guru_id'])) : ?><tfoot><tr><th colspan="3" class="text-end">Total JP</th><th class="text-center"><?= $totalJp ?></th><th colspan="2"></th></tr></tfoot><?php endif ?>
    </table>
    </div>
</div></div>

<div class="modal fade" id="modalTambah" tabindex="-1">
    <div class="modal-dialog"><form method="post" action="<?= site_url('akademik/penugasan/store') ?>" class="modal-content"><?= csrf_field() ?>
        <div class="modal-header"><h5 class="modal-title">Tambah Penugasan</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
        <div class="modal-body">
            <div class="mb-2"><label class="form-label">Guru</label><select name="guru_id" class="form-select tom" required><option value="">- pilih -</option>
                <?php foreach ($guru as $g) : ?><option value="<?= $g['id'] ?>"><?= esc(nama_guru($g)) ?></option><?php endforeach ?></select></div>
            <div class="mb-2"><label class="form-label">Mata pelajaran</label><select name="mapel_id" class="form-select tom" required><option value="">- pilih -</option>
                <?php foreach ($mapel as $m) : ?><option value="<?= $m['id'] ?>"><?= esc($m['nama_mapel']) ?></option><?php endforeach ?></select></div>
            <div class="mb-2"><label class="form-label">Kelas (boleh lebih dari satu)</label><select name="kelas_ids[]" class="form-select tom" multiple required>
                <?php foreach ($kelas as $k) : ?><option value="<?= $k['id'] ?>" <?= $f['kelas_id'] == $k['id'] ? 'selected' : '' ?>><?= esc($k['nama_kelas']) ?></option><?php endforeach ?></select></div>
            <div class="mb-2"><label class="form-label">JP per minggu</label><input type="number" name="jp_per_minggu" class="form-control" value="2" min="1" max="20"></div>
        </div>
        <div class="modal-footer"><button class="btn btn-primary">Simpan</button></div>
    </form></div>
</div>
<div class="modal fade" id="modalForm" data-crud tabindex="-1">
    <div class="modal-dialog"><form method="post" class="modal-content"><?= csrf_field() ?>
        <div class="modal-header"><h5 class="modal-title"></h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
        <div class="modal-body">
            <div class="mb-2"><label class="form-label">Guru</label><select name="guru_id" class="form-select" required>
                <?php foreach ($guru as $g) : ?><option value="<?= $g['id'] ?>"><?= esc(nama_guru($g)) ?></option><?php endforeach ?></select></div>
            <div class="mb-2"><label class="form-label">JP per minggu</label><input type="number" name="jp_per_minggu" class="form-control" min="1" max="20"></div>
            <small class="text-muted">Mengganti guru akan memindahkan seluruh jadwal mapel ini ke guru baru (dicek bentrok).</small>
        </div>
        <div class="modal-footer"><button class="btn btn-primary">Simpan</button></div>
    </form></div>
</div>
<?= $this->endSection() ?>
<?= $this->section('scripts') ?><?= $this->include('partials/modal_form_js') ?><?= $this->endSection() ?>
