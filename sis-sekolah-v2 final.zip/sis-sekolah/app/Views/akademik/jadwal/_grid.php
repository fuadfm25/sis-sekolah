<?php
/**
 * Grid jadwal per jam ke × hari. Variabel: $grid [hari][jam_ke], $perHari [hari][jam_ke] slot, $maxJam, $bawaan, $khusus,
 * $edit (bool), $mode ('kelas'|'guru').
 */
$hariList  = hari_list();
$edit      = $edit ?? false;
$mode      = $mode ?? 'kelas';
$jamBawaan = [];
$istirahat = [];   // setelah jam_ke n => list slot non-KBM
$lastKe    = 0;
foreach ($bawaan as $b) {
    if ((int) $b['is_kbm'] === 1) {
        $jamBawaan[(int) $b['jam_ke']] = $b;
        $lastKe = (int) $b['jam_ke'];
    } else {
        $istirahat[$lastKe][] = $b;
    }
}
$adaKhusus = array_filter($khusus);
?>
<table class="table table-bordered grid-jadwal text-center align-middle">
    <thead class="table-light"><tr><th style="width:110px">Jam</th><?php foreach ($hariList as $h => $hn) : ?><th><?= $hn ?><?= ! empty($khusus[$h]) ? ' <i class="bi bi-clock-history text-primary" title="Hari ini memakai jam pelajaran khusus"></i>' : '' ?></th><?php endforeach ?></tr></thead>
    <tbody>
    <?php foreach ($istirahat[0] ?? [] as $b) : ?>
        <tr class="table-secondary"><td class="small"><?= jam($b['jam_mulai']) ?>–<?= jam($b['jam_selesai']) ?></td><td colspan="<?= count($hariList) ?>" class="small text-muted"><?= esc($b['keterangan'] ?: 'Kegiatan') ?></td></tr>
    <?php endforeach ?>
    <?php for ($ke = 1; $ke <= $maxJam; $ke++) : $jb = $jamBawaan[$ke] ?? null; ?>
        <tr>
            <td class="small"><strong>Ke-<?= $ke ?></strong><?php if ($jb) : ?><br><?= jam($jb['jam_mulai']) ?>–<?= jam($jb['jam_selesai']) ?><?php endif ?></td>
            <?php foreach ($hariList as $h => $hn) :
                $slot = $perHari[$h][$ke] ?? null;
                $c    = $grid[$h][$ke] ?? null;
                $beda = $slot && (! $jb || $slot['jam_mulai'] !== $jb['jam_mulai'] || $slot['jam_selesai'] !== $jb['jam_selesai']); ?>
                <?php if (! $slot) : ?>
                    <td class="bg-light text-muted small">—</td>
                <?php else : ?>
                <td>
                    <?php if ($beda) : ?><div class="small text-primary"><?= jam($slot['jam_mulai']) ?>–<?= jam($slot['jam_selesai']) ?></div><?php endif ?>
                    <?php if ($c) : ?>
                        <div class="fw-bold"><?= esc($c['nama_mapel']) ?></div>
                        <div class="small text-muted"><?= esc($mode === 'guru' ? $c['nama_kelas'] : nama_guru($c)) ?></div>
                        <?php if (! empty($c['berlaku_mulai']) || ! empty($c['berlaku_sampai'])) : ?>
                            <div class="small"><span class="badge bg-light text-dark border"><?= $c['berlaku_mulai'] ? 'mulai ' . tgl_indo($c['berlaku_mulai']) : '' ?><?= $c['berlaku_sampai'] ? ' s.d. ' . tgl_indo($c['berlaku_sampai']) : '' ?></span></div>
                        <?php endif ?>
                        <?php if ($edit) : ?>
                        <div class="mt-1 no-print">
                            <a href="#" class="small me-2" data-bs-toggle="modal" data-bs-target="#modalEdit" data-action="<?= site_url('akademik/jadwal/update/' . $c['id']) ?>" data-penugasan="<?= $c['penugasan_guru_id'] ?>" data-label="<?= esc($hn . ' jam ke-' . $ke, 'attr') ?>"><i class="bi bi-pencil"></i></a>
                            <form method="post" action="<?= site_url('akademik/jadwal/delete/' . $c['id']) ?>" class="d-inline" onsubmit="return confirm('Hapus slot ini mulai tanggal berlaku yang dipilih?')"><?= csrf_field() ?><input type="hidden" name="berlaku_mulai" value="<?= esc($berlaku) ?>"><button class="btn btn-link btn-sm p-0 text-danger"><i class="bi bi-x-circle"></i></button></form>
                        </div>
                        <?php endif ?>
                    <?php elseif ($edit) : ?>
                        <a href="#" class="slot-kosong text-decoration-none no-print" data-bs-toggle="modal" data-bs-target="#modalTambah" data-hari="<?= $h ?>" data-jam="<?= $slot['id'] ?>" data-label="<?= esc($hn . ', jam ke-' . $ke, 'attr') ?>"><i class="bi bi-plus-circle fs-5"></i></a>
                    <?php else : ?><span class="slot-kosong">–</span><?php endif ?>
                </td>
                <?php endif ?>
            <?php endforeach ?>
        </tr>
        <?php foreach ($istirahat[$ke] ?? [] as $b) : ?>
            <tr class="table-secondary"><td class="small"><?= jam($b['jam_mulai']) ?>–<?= jam($b['jam_selesai']) ?></td><td colspan="<?= count($hariList) ?>" class="small text-muted"><?= esc($b['keterangan'] ?: 'Istirahat') ?></td></tr>
        <?php endforeach ?>
    <?php endfor ?>
    </tbody>
</table>
<?php if ($adaKhusus) : ?>
    <p class="small text-muted mb-2"><i class="bi bi-clock-history text-primary"></i> Hari <?= implode(', ', array_map(static fn ($h) => $hariList[$h], array_keys($adaKhusus))) ?> memakai jam pelajaran khusus; waktu yang berbeda ditampilkan di dalam sel.</p>
<?php endif ?>
