<?= $this->extend('layouts/main') ?>
<?= $this->section('content') ?>
<?php $hariList = hari_list(); ?>
<div class="card"><div class="card-body py-3">
    <form class="d-flex flex-wrap gap-2 align-items-center filter" method="get">
        <label class="fw-bold">Kelas:</label>
        <select name="kelas_id" class="form-select w-auto" onchange="this.form.submit()">
            <?php foreach ($kelasList as $k) : ?><option value="<?= $k['id'] ?>" <?= $kelasId == $k['id'] ? 'selected' : '' ?>><?= esc($k['nama_kelas']) ?></option><?php endforeach ?>
        </select>
        <label class="fw-bold ms-md-3">Berlaku mulai:</label>
        <input type="date" name="berlaku" value="<?= esc($berlaku) ?>" class="form-control w-auto" onchange="this.form.submit()">
        <?php foreach ($tglVersi as $tv) : ?><a class="badge bg-light text-dark border text-decoration-none" href="?kelas_id=<?= $kelasId ?>&berlaku=<?= $tv ?>">versi <?= tgl_indo($tv) ?></a><?php endforeach ?>
        <a href="<?= site_url('jadwal?mode=kelas&id=' . $kelasId . '&berlaku=' . $berlaku) ?>" class="btn btn-light ms-auto"><i class="bi bi-printer"></i> Tampilan cetak</a>
    </form>
</div></div>

<?php if (! $kelasId) : ?>
    <div class="alert alert-info">Tambahkan kelas terlebih dahulu.</div>
<?php else : ?>
<div class="alert alert-light border small py-2"><i class="bi bi-info-circle"></i> Menampilkan jadwal yang berlaku pada <strong><?= tgl_indo($berlaku, true) ?></strong>. Tambah/ubah/hapus slot berlaku mulai tanggal itu; bila slot lama sudah dipakai jurnal, slot lama diakhiri (bukan dihapus) agar riwayat jurnal tetap benar.</div>
<div class="row">
    <div class="col-xl-9">
        <div class="card"><div class="card-body table-responsive">
            <?= $this->setData(['edit' => true, 'mode' => 'kelas'])->include('akademik/jadwal/_grid') ?>
            <form method="post" action="<?= site_url('akademik/jadwal/kosongkan') ?>" onsubmit="return confirm('Kosongkan jadwal kelas ini mulai tanggal berlaku yang dipilih? Jurnal yang sudah terisi tetap tersimpan.')">
                <?= csrf_field() ?><input type="hidden" name="kelas_id" value="<?= $kelasId ?>"><input type="hidden" name="berlaku_mulai" value="<?= esc($berlaku) ?>">
                <button class="btn btn-sm btn-outline-danger"><i class="bi bi-trash"></i> Kosongkan jadwal kelas</button>
            </form>
        </div></div>
    </div>
    <div class="col-xl-3">
        <div class="card">
            <div class="card-header"><h6 class="mb-0">Beban Penugasan Kelas</h6></div>
            <div class="card-body p-2">
                <?php if (! $penugasan) : ?>
                    <p class="small text-muted p-2 mb-0">Belum ada penugasan untuk kelas ini. <a href="<?= site_url('akademik/penugasan?kelas_id=' . $kelasId) ?>">Atur penugasan</a> dulu.</p>
                <?php else : ?>
                <table class="table table-sm small mb-0">
                    <?php foreach ($penugasan as $p) : ?>
                        <tr>
                            <td><?= esc($p['nama_mapel']) ?><br><span class="text-muted"><?= esc(nama_guru($p)) ?></span></td>
                            <td class="text-end text-nowrap"><span class="badge bg-<?= $p['jp_terjadwal'] == $p['jp_per_minggu'] ? 'success' : ($p['jp_terjadwal'] > $p['jp_per_minggu'] ? 'danger' : 'warning') ?>"><?= $p['jp_terjadwal'] ?>/<?= $p['jp_per_minggu'] ?></span></td>
                        </tr>
                    <?php endforeach ?>
                </table>
                <?php endif ?>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="modalTambah" tabindex="-1">
    <div class="modal-dialog"><form method="post" action="<?= site_url('akademik/jadwal/store') ?>" class="modal-content"><?= csrf_field() ?>
        <input type="hidden" name="kelas_id" value="<?= $kelasId ?>"><input type="hidden" name="hari"><input type="hidden" name="jam_pelajaran_id"><input type="hidden" name="berlaku_mulai" value="<?= esc($berlaku) ?>">
        <div class="modal-header"><h5 class="modal-title">Isi Jadwal – <span class="lbl"></span></h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
        <div class="modal-body">
            <div class="mb-2"><label class="form-label">Mata pelajaran & guru</label>
                <select name="penugasan_guru_id" class="form-select" required><option value="">- pilih -</option>
                    <?php foreach ($penugasan as $p) : ?><option value="<?= $p['id'] ?>"><?= esc($p['nama_mapel'] . ' — ' . nama_guru($p)) ?> (<?= $p['jp_terjadwal'] ?>/<?= $p['jp_per_minggu'] ?> JP)</option><?php endforeach ?>
                </select></div>
            <div class="mb-2"><label class="form-label">Jumlah JP berurutan</label>
                <select name="jumlah_slot" class="form-select"><option value="1">1 JP</option><option value="2" selected>2 JP</option><option value="3">3 JP</option><option value="4">4 JP</option></select>
                <small class="text-muted">Mengisi slot ini dan slot KBM berikutnya sekaligus.</small></div>
        </div>
        <div class="modal-footer"><button class="btn btn-primary">Simpan</button></div>
    </form></div>
</div>
<div class="modal fade" id="modalEdit" tabindex="-1">
    <div class="modal-dialog"><form method="post" class="modal-content"><?= csrf_field() ?><input type="hidden" name="berlaku_mulai" value="<?= esc($berlaku) ?>">
        <div class="modal-header"><h5 class="modal-title">Ubah Jadwal – <span class="lbl"></span></h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
        <div class="modal-body">
            <select name="penugasan_guru_id" class="form-select" required>
                <?php foreach ($penugasan as $p) : ?><option value="<?= $p['id'] ?>"><?= esc($p['nama_mapel'] . ' — ' . nama_guru($p)) ?></option><?php endforeach ?>
            </select>
        </div>
        <div class="modal-footer"><button class="btn btn-primary">Simpan</button></div>
    </form></div>
</div>
<?php endif ?>
<?= $this->endSection() ?>
<?= $this->section('scripts') ?>
<script>
document.getElementById('modalTambah')?.addEventListener('show.bs.modal', function (e) {
    var b = e.relatedTarget, f = this.querySelector('form');
    f.hari.value = b.dataset.hari; f.jam_pelajaran_id.value = b.dataset.jam;
    this.querySelector('.lbl').textContent = b.dataset.label;
});
document.getElementById('modalEdit')?.addEventListener('show.bs.modal', function (e) {
    var b = e.relatedTarget, f = this.querySelector('form');
    f.action = b.dataset.action; f.penugasan_guru_id.value = b.dataset.penugasan;
    this.querySelector('.lbl').textContent = b.dataset.label;
});
</script>
<?= $this->endSection() ?>
