<?= $this->extend('layouts/main') ?>
<?= $this->section('actions') ?><button onclick="window.print()" class="btn btn-light"><i class="bi bi-printer"></i> Cetak</button><?= $this->endSection() ?>
<?= $this->section('content') ?>
<?php $hariList = hari_list(); ?>
<div class="card no-print"><div class="card-body py-3">
    <form class="row g-2 align-items-center filter" method="get">
        <div class="col-auto"><select name="mode" class="form-select" onchange="this.form.id.value='';this.form.submit()">
            <option value="kelas" <?= $mode === 'kelas' ? 'selected' : '' ?>>Per kelas</option>
            <option value="guru" <?= $mode === 'guru' ? 'selected' : '' ?>>Per guru</option>
        </select></div>
        <div class="col-md-4"><select name="id" class="form-select tom" onchange="this.form.submit()">
            <?php foreach ($mode === 'guru' ? $guruList : $kelasList as $x) : ?>
                <option value="<?= $x['id'] ?>" <?= $id == $x['id'] ? 'selected' : '' ?>><?= esc($mode === 'guru' ? nama_guru($x) : $x['nama_kelas']) ?></option>
            <?php endforeach ?>
        </select></div>
        <div class="col-auto"><input type="date" name="berlaku" value="<?= esc($berlaku) ?>" class="form-control" onchange="this.form.submit()" title="Jadwal yang berlaku pada tanggal"></div>
    </form>
</div></div>
<div class="card"><div class="card-body table-responsive">
    <?= $this->include('partials/print_header') ?>
    <h5 class="print-only text-center">Jadwal Pelajaran – <?= esc($subtitle) ?></h5>
    <?= $this->setData(['edit' => false])->include('akademik/jadwal/_grid') ?>
</div></div>
<?= $this->endSection() ?>
