<?= $this->extend('layouts/main') ?>
<?= $this->section('actions') ?>
<?php if (session('guru_id')) : ?><button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#modalAjukan"><i class="bi bi-plus-lg"></i> Ajukan Izin</button><?php endif ?>
<?= $this->endSection() ?>
<?= $this->section('content') ?>
<?php $J = \App\Models\IzinGuruModel::JENIS; $warna = ['Diajukan' => 'warning', 'Disetujui' => 'success', 'Ditolak' => 'danger']; ?>
<?php if ($putus && $menunggu) : ?>
<div class="card border-warning"><div class="card-header"><h6 class="mb-0">Menunggu persetujuan (<?= count($menunggu) ?>)</h6></div><div class="card-body">
    <?php foreach ($menunggu as $r) : ?>
        <div class="border rounded p-2 mb-2">
            <div class="d-flex flex-wrap justify-content-between gap-2">
                <div><b><?= esc(nama_guru($r)) ?></b> · <?= $J[$r['jenis']] ?> · <?= tgl_indo($r['tanggal_mulai']) ?><?= $r['tanggal_selesai'] !== $r['tanggal_mulai'] ? ' – ' . tgl_indo($r['tanggal_selesai']) : '' ?>
                    <div class="small"><?= nl2br(esc($r['keterangan'])) ?></div>
                    <?php if ($r['tugas_siswa']) : ?><div class="small text-muted"><i class="bi bi-journal-text"></i> Tugas: <?= nl2br(esc($r['tugas_siswa'])) ?></div><?php endif ?>
                    <?php if ($r['lampiran']) : ?><a class="small" target="_blank" href="<?= site_url('izin-guru/lampiran/' . $r['id']) ?>"><i class="bi bi-paperclip"></i> Lampiran</a><?php endif ?></div>
                <form method="post" action="<?= site_url('izin-guru/putus/' . $r['id']) ?>" class="d-flex gap-1 align-items-start"><?= csrf_field() ?>
                    <input name="catatan_putusan" class="form-control form-control-sm" placeholder="Catatan (opsional)">
                    <button name="putusan" value="Disetujui" class="btn btn-sm btn-success">Setujui</button>
                    <button name="putusan" value="Ditolak" class="btn btn-sm btn-outline-danger">Tolak</button>
                </form>
            </div>
        </div>
    <?php endforeach ?>
</div></div>
<?php endif ?>
<div class="card"><div class="card-body table-responsive">
    <table class="table table-hover align-middle">
        <thead><tr><?php if ($putus) : ?><th>Guru</th><?php endif ?><th>Tanggal</th><th>Jenis</th><th>Keterangan & tugas</th><th>Status</th><th></th></tr></thead>
        <tbody>
        <?php foreach ($rows as $r) : ?>
            <tr>
                <?php if ($putus) : ?><td><?= esc(nama_guru($r)) ?></td><?php endif ?>
                <td class="text-nowrap"><?= tgl_indo($r['tanggal_mulai']) ?><?= $r['tanggal_selesai'] !== $r['tanggal_mulai'] ? '<br>s.d. ' . tgl_indo($r['tanggal_selesai']) : '' ?></td>
                <td><?= $J[$r['jenis']] ?></td>
                <td class="small"><?= nl2br(esc($r['keterangan'])) ?><?= $r['tugas_siswa'] ? '<div class="text-muted">Tugas: ' . nl2br(esc($r['tugas_siswa'])) . '</div>' : '' ?>
                    <?php if ($r['lampiran']) : ?><a target="_blank" href="<?= site_url('izin-guru/lampiran/' . $r['id']) ?>"><i class="bi bi-paperclip"></i> lampiran</a><?php endif ?></td>
                <td><span class="badge bg-<?= $warna[$r['status']] ?>"><?= $r['status'] ?></span><?= $r['pemutus'] ? '<div class="small text-muted">' . esc($r['pemutus']) . '</div>' : '' ?><?= $r['catatan_putusan'] ? '<div class="small">' . esc($r['catatan_putusan']) . '</div>' : '' ?></td>
                <td class="text-end"><?php if ((int) $r['guru_id'] === (int) session('guru_id') || $putus) : ?><?= delete_button('izin-guru/batal/' . $r['id'], '', 'Batalkan/hapus izin ini? Kehadiran yang terisi dari izin ini ikut dihapus.') ?><?php endif ?></td>
            </tr>
        <?php endforeach ?>
        <?php if (! $rows) : ?><tr><td colspan="6" class="text-center text-muted">Belum ada pengajuan izin.</td></tr><?php endif ?>
        </tbody>
    </table>
</div></div>
<?php if (session('guru_id')) : ?>
<div class="modal fade" id="modalAjukan" tabindex="-1">
    <div class="modal-dialog"><form method="post" action="<?= site_url('izin-guru/ajukan') ?>" enctype="multipart/form-data" class="modal-content"><?= csrf_field() ?>
        <div class="modal-header"><h5 class="modal-title">Ajukan Izin</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
        <div class="modal-body row g-2">
            <div class="col-12"><label class="form-label">Jenis</label><select name="jenis" class="form-select"><?php foreach ($J as $k => $v) : ?><option value="<?= $k ?>" <?= old('jenis') === $k ? 'selected' : '' ?>><?= $v ?></option><?php endforeach ?></select></div>
            <div class="col-6"><label class="form-label">Dari</label><input type="date" name="tanggal_mulai" class="form-control" value="<?= old('tanggal_mulai', date('Y-m-d')) ?>" required></div>
            <div class="col-6"><label class="form-label">Sampai</label><input type="date" name="tanggal_selesai" class="form-control" value="<?= old('tanggal_selesai') ?>"></div>
            <div class="col-12"><label class="form-label">Alasan</label><textarea name="keterangan" class="form-control" rows="2" required><?= esc(old('keterangan')) ?></textarea></div>
            <div class="col-12"><label class="form-label">Tugas untuk kelas yang ditinggalkan</label><textarea name="tugas_siswa" class="form-control" rows="3" placeholder="VII A jam 1-2: kerjakan LKS hal. 20-21"><?= esc(old('tugas_siswa')) ?></textarea>
                <small class="text-muted">Tampil di monitoring jurnal guru piket.</small></div>
            <div class="col-12"><label class="form-label">Lampiran (surat tugas/surat dokter, maks. 2 MB)</label><input type="file" name="lampiran" class="form-control" accept=".pdf,.jpg,.jpeg,.png"></div>
        </div>
        <div class="modal-footer"><button class="btn btn-primary">Ajukan</button></div>
    </form></div>
</div>
<?php endif ?>
<?= $this->endSection() ?>
