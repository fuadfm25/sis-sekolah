<?= $this->extend('layouts/main') ?>
<?= $this->section('content') ?>
<?php
$q = $p ? 'mapel_id=' . $p['mapel_id'] . '&tingkat=' . urlencode($p['tingkat']) : '';
$hid = $p ? '<input type="hidden" name="mapel_id" value="' . $p['mapel_id'] . '"><input type="hidden" name="tingkat" value="' . esc($p['tingkat']) . '">' : '';
?>
<?php if (! $target) : ?>
    <div class="alert alert-info">Anda belum memiliki penugasan mengajar pada semester ini.</div>
<?php else : ?>
<div class="d-flex flex-wrap gap-2 mb-3">
    <?php foreach ($target as $t) : $on = $p && (int) $p['mapel_id'] === (int) $t['mapel_id'] && $p['tingkat'] === $t['tingkat']; ?>
        <a href="<?= site_url('program?mapel_id=' . $t['mapel_id'] . '&tingkat=' . urlencode($t['tingkat'])) ?>" class="btn <?= $on ? 'btn-primary' : 'btn-light' ?>"><?= esc($t['nama_mapel']) ?> · <?= esc($t['tingkat']) ?></a>
    <?php endforeach ?>
</div>
<?php endif ?>

<?php if ($p) :
    $efektif = array_filter($pekan, static fn ($w) => $w['efektif']);
    $jpAda   = array_sum(array_column($efektif, 'jp'));
    $jpRenc  = array_sum(array_map('intval', array_column($items, 'jp')));
    $tanpaJadwal = (bool) array_filter($pekan, static fn ($w) => ! empty($w['tanpa_jadwal']));
    $bulanCol = [];
    foreach ($pekan as $w) { $bulanCol[$w['bulan']] = ($bulanCol[$w['bulan']] ?? 0) + 1; }
?>
<?php if ($perlu) : ?><div class="alert alert-warning">Tanggal mulai/selesai semester belum diisi kurikulum, sehingga pekan efektif belum bisa dihitung.</div><?php endif ?>
<?php if ($tanpaJadwal) : ?><div class="alert alert-warning small">Jadwal pelajaran untuk mapel ini belum diatur; JP per pekan diperkirakan dari JP per minggu (<?= $p['jp_minggu'] ?> JP) dan jumlah hari KBM.</div><?php endif ?>

<div class="row g-3 mb-3">
    <div class="col-6 col-md-3"><div class="card h-100"><div class="card-body py-3"><div class="small text-muted">Pekan efektif</div><div class="fs-3 fw-bold"><?= count($efektif) ?> <span class="fs-6 text-muted">/ <?= count($pekan) ?></span></div></div></div></div>
    <div class="col-6 col-md-3"><div class="card h-100"><div class="card-body py-3"><div class="small text-muted">JP tersedia (kelas <?= esc($p['kelas'][0]) ?>)</div><div class="fs-3 fw-bold"><?= $jpAda ?></div></div></div></div>
    <div class="col-6 col-md-3"><div class="card h-100"><div class="card-body py-3"><div class="small text-muted">JP direncanakan</div><div class="fs-3 fw-bold <?= $jpRenc > $jpAda ? 'text-danger' : '' ?>"><?= $jpRenc ?></div></div></div></div>
    <div class="col-6 col-md-3"><div class="card h-100"><div class="card-body py-3 d-flex flex-column gap-1">
        <a target="_blank" href="<?= site_url('program/cetak/promes?' . $q) ?>" class="btn btn-sm btn-primary"><i class="bi bi-printer"></i> Cetak Promes</a>
        <a target="_blank" href="<?= site_url('program/cetak/prota?' . $q) ?>" class="btn btn-sm btn-outline-primary"><i class="bi bi-printer"></i> Cetak Prota</a>
        <a href="<?= site_url('modul-ajar?' . $q) ?>" class="btn btn-sm btn-outline-success"><i class="bi bi-journal-richtext"></i> Susun Modul Ajar</a>
    </div></div></div>
</div>

<div class="card">
    <div class="card-header d-flex flex-wrap justify-content-between gap-2 align-items-center">
        <h5 class="card-title mb-0">1. Butir materi / tujuan pembelajaran</h5>
        <div class="d-flex flex-wrap gap-2">
            <?php if ($atpBaru) : ?><form method="post" action="<?= site_url('program/ambil-atp') ?>"><?= csrf_field() . $hid ?><button class="btn btn-sm btn-outline-primary"><i class="bi bi-download"></i> Ambil <?= count($atpBaru) ?> TP dari ATP</button></form><?php endif ?>
            <form method="post" action="<?= site_url('program/sebar') ?>" onsubmit="return confirm('Sebaran JP yang ada akan diganti. Lanjutkan?')"><?= csrf_field() . $hid ?><button class="btn btn-sm btn-primary" <?= $items ? '' : 'disabled' ?>><i class="bi bi-magic"></i> Sebar otomatis ke pekan efektif</button></form>
        </div>
    </div>
    <div class="card-body table-responsive">
        <table class="table table-sm align-middle">
            <thead><tr><th style="width:40px">No</th><th style="width:110px">Jenis</th><th>Materi / lingkup materi</th><th>Tujuan pembelajaran</th><th style="width:80px">JP</th><th style="width:170px"></th></tr></thead>
            <tbody>
            <?php foreach (array_merge($items, [['id' => null, 'jenis' => 'Materi', 'materi' => '', 'tujuan' => '', 'jp' => $p['jp_minggu'] * 2]]) as $i => $it) : $fid = 'b' . ($it['id'] ?? 'baru'); ?>
                <tr class="<?= $it['id'] ? '' : 'table-light' ?>">
                    <td><?= $it['id'] ? $i + 1 : '+' ?></td>
                    <td><select form="<?= $fid ?>" name="jenis" class="form-select form-select-sm"><?php foreach (['Materi', 'Asesmen', 'Cadangan'] as $o) : ?><option <?= $it['jenis'] === $o ? 'selected' : '' ?>><?= $o ?></option><?php endforeach ?></select></td>
                    <td><input form="<?= $fid ?>" name="materi" value="<?= esc($it['materi']) ?>" class="form-control form-control-sm" placeholder="<?= $it['id'] ? '' : 'Tambah butir: mis. Sumatif tengah semester / Bab 2 Zat dan perubahannya' ?>" <?= $it['id'] ? 'required' : '' ?>></td>
                    <td><textarea form="<?= $fid ?>" name="tujuan" rows="1" class="form-control form-control-sm"><?= esc($it['tujuan'] ?? '') ?></textarea></td>
                    <td><input form="<?= $fid ?>" type="number" min="0" max="200" name="jp" value="<?= (int) $it['jp'] ?>" class="form-control form-control-sm"></td>
                    <td class="text-end text-nowrap">
                        <form id="<?= $fid ?>" method="post" action="<?= site_url('program/butir/simpan' . ($it['id'] ? '/' . $it['id'] : '')) ?>" class="d-inline"><?= csrf_field() . $hid ?><button class="btn btn-sm <?= $it['id'] ? 'btn-light' : 'btn-primary' ?>"><?= $it['id'] ? 'Simpan' : 'Tambah' ?></button></form>
                        <?php if ($it['id']) : ?>
                            <form method="post" action="<?= site_url('program/butir/geser/' . $it['id'] . '/naik') ?>" class="d-inline"><?= csrf_field() . $hid ?><button class="btn btn-sm btn-light" title="Naik">↑</button></form>
                            <form method="post" action="<?= site_url('program/butir/geser/' . $it['id'] . '/turun') ?>" class="d-inline"><?= csrf_field() . $hid ?><button class="btn btn-sm btn-light" title="Turun">↓</button></form>
                            <form method="post" action="<?= site_url('program/butir/hapus/' . $it['id']) ?>" class="d-inline" onsubmit="return confirm('Hapus butir ini?')"><?= csrf_field() . $hid ?><button class="btn btn-sm btn-outline-danger" title="Hapus">×</button></form>
                        <?php endif ?>
                    </td>
                </tr>
            <?php endforeach ?>
            </tbody>
        </table>
    </div>
</div>

<?php if ($items && $pekan) : ?>
<form method="post" action="<?= site_url('program/alokasi') ?>"><?= csrf_field() . $hid ?>
<div class="card">
    <div class="card-header d-flex flex-wrap justify-content-between gap-2 align-items-center">
        <h5 class="card-title mb-0">2. Sebaran JP per pekan (Program Semester)</h5>
        <div class="d-flex gap-2 align-items-center"><small class="text-muted">Kolom abu-abu = pekan tidak efektif (libur/ujian/kegiatan).</small><button class="btn btn-sm btn-primary"><i class="bi bi-save"></i> Simpan sebaran</button></div>
    </div>
    <div class="card-body table-responsive">
        <table class="table table-sm table-bordered align-middle text-center small promes" style="min-width:<?= 260 + count($pekan) * 46 ?>px">
            <thead>
                <tr><th rowspan="2" class="text-start" style="min-width:220px">Butir</th><th rowspan="2">JP</th>
                    <?php foreach ($bulanCol as $ym => $n) : ?><th colspan="<?= $n ?>"><?= esc(bulan_list()[(int) substr($ym, 5, 2)] ?? $ym) ?></th><?php endforeach ?></tr>
                <tr><?php foreach ($pekan as $k => $w) : ?><th class="<?= $w['efektif'] ? '' : 'table-secondary' ?>" title="<?= esc(tgl_indo($k) . ($w['ket'] ? ' · ' . $w['ket'] : '') . ' · ' . $w['hari_kbm'] . ' hari KBM, ' . $w['jp'] . ' JP') ?>"><?= $w['minggu_ke'] ?><br><span class="fw-normal text-muted"><?= $w['jp'] ?></span></th><?php endforeach ?></tr>
            </thead>
            <tbody>
            <?php foreach ($items as $i => $it) : ?>
                <tr><td class="text-start"><?= $i + 1 ?>. <?= esc(mb_strimwidth($it['materi'], 0, 60, '…')) ?></td><td class="fw-bold jp-baris"><?= (int) $it['jp'] ?></td>
                    <?php foreach ($pekan as $k => $w) : $v = $alokasi[$it['id']][$k] ?? ''; ?>
                        <td class="p-0 <?= $w['efektif'] ? '' : 'table-secondary' ?>"><input type="number" min="0" max="60" name="alok[<?= $it['id'] ?>][<?= $k ?>]" value="<?= $v ?>" data-pekan="<?= $k ?>" class="form-control form-control-sm border-0 text-center px-0 sel bg-transparent" style="width:44px"></td>
                    <?php endforeach ?></tr>
            <?php endforeach ?>
            </tbody>
            <tfoot><tr class="fw-bold"><td class="text-start">Jumlah / tersedia</td><td id="totJp"></td>
                <?php foreach ($pekan as $k => $w) : ?><td class="tot <?= $w['efektif'] ? '' : 'table-secondary' ?>" data-pekan="<?= $k ?>" data-ada="<?= (int) $w['jp'] ?>"></td><?php endforeach ?></tr></tfoot>
        </table>
    </div>
</div>
</form>
<?php endif ?>

<div class="card"><div class="card-body d-flex flex-wrap gap-2 align-items-center">
    <span class="me-2">Ajukan ke Waka Kurikulum (Perangkat Pembelajaran):</span>
    <form method="post" action="<?= site_url('program/ajukan/promes') ?>"><?= csrf_field() . $hid ?><button class="btn btn-outline-success btn-sm" <?= $items ? '' : 'disabled' ?>><i class="bi bi-send"></i> Ajukan Promes</button></form>
    <form method="post" action="<?= site_url('program/ajukan/prota') ?>"><?= csrf_field() . $hid ?><button class="btn btn-outline-success btn-sm" <?= $items ? '' : 'disabled' ?>><i class="bi bi-send"></i> Ajukan Prota</button></form>
    <small class="text-muted">Prota menggabungkan program semester ganjil dan genap pada tahun pelajaran yang sama.</small>
</div></div>
<?php endif ?>
<?= $this->endSection() ?>
<?= $this->section('scripts') ?>
<script>
(function () {
    function hitung() {
        var per = {}, tot = 0;
        document.querySelectorAll('.promes tbody tr').forEach(function (tr) {
            var s = 0;
            tr.querySelectorAll('.sel').forEach(function (i) { var v = parseInt(i.value || 0, 10); s += v; per[i.dataset.pekan] = (per[i.dataset.pekan] || 0) + v; });
            tr.querySelector('.jp-baris').textContent = s; tot += s;
        });
        document.querySelectorAll('.promes .tot').forEach(function (td) {
            var v = per[td.dataset.pekan] || 0, ada = parseInt(td.dataset.ada, 10);
            td.textContent = v ? v + '/' + ada : (ada ? '0/' + ada : '');
            td.classList.toggle('text-danger', v > ada);
        });
        var t = document.getElementById('totJp'); if (t) t.textContent = tot;
    }
    document.querySelectorAll('.promes .sel').forEach(function (i) { i.addEventListener('input', hitung); });
    hitung();
})();
</script>
<?= $this->endSection() ?>
