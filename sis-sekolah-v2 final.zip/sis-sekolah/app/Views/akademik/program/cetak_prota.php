<?= $this->extend('layouts/cetak') ?>
<?= $this->section('isi') ?>
<table class="info"><?php foreach ($info as $k => $v) : ?><tr><td style="width:130px"><?= esc($k) ?></td><td>: <?= esc($v) ?></td></tr><?php endforeach ?>
    <tr><td>Alokasi waktu</td><td>: <?= (int) $jpMinggu ?> JP per minggu</td></tr></table>
<table class="data">
    <thead><tr><th style="width:28px">No</th><th style="width:80px">Semester</th><th>Materi / Lingkup Materi</th><th>Tujuan Pembelajaran</th><th style="width:60px">Alokasi (JP)</th></tr></thead>
    <tbody>
    <?php $total = 0; foreach (['Ganjil', 'Genap'] as $s) : $rows = $semester[$s] ?? []; $sub = 0; ?>
        <?php foreach ($rows as $i => $it) : $sub += (int) $it['jp']; ?>
            <tr><td class="tengah"><?= $i + 1 ?></td><?php if ($i === 0) : ?><td class="tengah" rowspan="<?= count($rows) ?>"><?= $s ?></td><?php endif ?>
                <td><?= esc($it['materi']) ?><?= $it['jenis'] !== 'Materi' ? ' <i>(' . esc(strtolower($it['jenis'])) . ')</i>' : '' ?></td><td><?= nl2br(esc($it['tujuan'] ?? '')) ?></td><td class="tengah"><?= (int) $it['jp'] ?></td></tr>
        <?php endforeach ?>
        <?php if (! $rows) : ?><tr><td></td><td class="tengah"><?= $s ?></td><td colspan="2"><i>Program semester <?= strtolower($s) ?> belum disusun.</i></td><td></td></tr><?php endif ?>
        <tr><th colspan="4" class="kanan">Jumlah semester <?= strtolower($s) ?></th><th><?= $sub ?></th></tr>
    <?php $total += $sub; endforeach ?>
    <tr><th colspan="4" class="kanan">Jumlah satu tahun</th><th><?= $total ?></th></tr>
    </tbody>
</table>
<?= $this->endSection() ?>
