<?= $this->extend('layouts/cetak') ?>
<?= $this->section('isi') ?>
<?php
$bulanCol = [];
foreach ($pekan as $w) { $bulanCol[$w['bulan']] = ($bulanCol[$w['bulan']] ?? 0) + 1; }
$perPekan = [];
?>
<table class="info"><?php foreach ($info as $k => $v) : ?><tr><td style="width:130px"><?= esc($k) ?></td><td>: <?= esc($v) ?></td></tr><?php endforeach ?></table>
<table class="data kecil">
    <thead>
        <tr><th rowspan="2" style="width:22px">No</th><th rowspan="2" style="width:30%">Materi / Tujuan Pembelajaran</th><th rowspan="2" style="width:28px">JP</th>
            <?php foreach ($bulanCol as $ym => $n) : ?><th colspan="<?= $n ?>"><?= esc(bulan_list()[(int) substr($ym, 5, 2)] ?? $ym) ?></th><?php endforeach ?></tr>
        <tr><?php foreach ($pekan as $w) : ?><th class="<?= $w['efektif'] ? '' : 'libur' ?>"><?= $w['minggu_ke'] ?></th><?php endforeach ?></tr>
    </thead>
    <tbody>
    <?php foreach ($items as $i => $it) : ?>
        <tr><td><?= $i + 1 ?></td><td class="kiri" style="white-space:normal"><b><?= esc($it['materi']) ?></b><?= $it['tujuan'] ? '<br>' . nl2br(esc($it['tujuan'])) : '' ?></td><td><?= (int) $it['jp'] ?></td>
        <?php foreach ($pekan as $k => $w) : $v = $alokasi[$it['id']][$k] ?? 0; $perPekan[$k] = ($perPekan[$k] ?? 0) + $v; ?>
            <td class="<?= $w['efektif'] ? '' : 'libur' ?>"><?= $v ?: '' ?></td>
        <?php endforeach ?></tr>
    <?php endforeach ?>
    <?php if (! $items) : ?><tr><td colspan="<?= 3 + count($pekan) ?>">Program semester belum diisi.</td></tr><?php endif ?>
    </tbody>
    <tfoot><tr><th colspan="2" style="text-align:right">Jumlah JP</th><th><?= array_sum(array_map('intval', array_column($items, 'jp'))) ?></th>
        <?php foreach ($pekan as $k => $w) : ?><th class="<?= $w['efektif'] ? '' : 'libur' ?>"><?= ($perPekan[$k] ?? 0) ?: '' ?></th><?php endforeach ?></tr></tfoot>
</table>
<?php $libur = array_filter($pekan, static fn ($w) => ! $w['efektif'] || $w['ket']); ?>
<p class="kecil-teks"><b>Pekan efektif:</b> <?= count(array_filter($pekan, static fn ($w) => $w['efektif'])) ?> dari <?= count($pekan) ?> pekan.
<?php if ($libur) : ?><b>Keterangan:</b> <?php $x = []; foreach ($libur as $k => $w) { $x[] = (bulan_list()[(int) substr($w['bulan'], 5, 2)] ?? '') . ' minggu ke-' . $w['minggu_ke'] . ($w['ket'] ? ' (' . $w['ket'] . ')' : '') . ($w['efektif'] ? '' : ' – tidak efektif'); } echo esc(implode('; ', $x)); ?>.<?php endif ?></p>
<?= $this->endSection() ?>
