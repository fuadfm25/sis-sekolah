<?= $this->extend('layouts/main') ?>
<?= $this->section('actions') ?>
<?= tombol_impor('atp') ?>
<?php if ($kelola) : ?><button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#modalForm" data-title="Tambah TP" data-action="<?= site_url('atp/store') ?>" data-row='<?= esc(json_encode(['fase' => $fase]), 'attr') ?>'><i class="bi bi-plus-lg"></i> Tambah TP</button><?php endif ?>
<?= $this->endSection() ?>
<?= $this->section('content') ?>
<div class="card"><div class="card-body py-3">
    <form class="d-flex flex-wrap gap-2 align-items-center filter" method="get">
        <select class="form-select w-auto" onchange="var v=this.value.split('|');location='?mapel_id='+v[0]+'&tingkat='+encodeURIComponent(v[1])">
            <?php foreach ($pilihan as $p) : ?><option value="<?= $p['mapel_id'] . '|' . esc($p['tingkat'], 'attr') ?>" <?= (int) $p['mapel_id'] === $mapelId && $p['tingkat'] === $tingkat ? 'selected' : '' ?>><?= esc($p['nama_mapel']) ?> · Tingkat <?= esc($p['tingkat']) ?></option><?php endforeach ?>
            <?php if (! $pilihan) : ?><option>Belum ada penugasan mengajar</option><?php endif ?>
        </select>
        <?php if ($fase) : ?><span class="badge bg-light text-dark border">Fase <?= $fase ?></span><?php endif ?>
        <span class="small text-muted ms-auto">Total alokasi: <b><?= array_sum(array_column($rows, 'alokasi_jp')) ?></b> JP</span>
    </form>
</div></div>
<div class="card"><div class="card-body table-responsive">
    <table class="table table-hover align-middle tabel-hp">
        <thead><tr><th>#</th><th>Kode</th><th>Elemen</th><th>Tujuan pembelajaran</th><th>Smt</th><th>JP</th><th>Modul</th><th></th></tr></thead>
        <tbody>
        <?php foreach ($rows as $r) : ?>
            <tr>
                <td data-label="Urutan"><?= $r['urutan'] ?></td><td data-label="Kode"><?= esc($r['kode'] ?: '-') ?></td>
                <td data-label="Elemen"><?= esc($r['elemen']) ?></td><td data-label="Tujuan"><?= nl2br(esc($r['tujuan'])) ?></td>
                <td data-label="Semester"><?= esc($r['semester'] ?: 'Semua') ?></td><td data-label="JP"><?= $r['alokasi_jp'] ?: '-' ?></td>
                <td data-label="Modul"><?php if ($r['modul_ajar']) : ?><a href="<?= site_url('atp/modul/' . $r['id']) ?>"><i class="bi bi-file-earmark-arrow-down"></i> Unduh</a><?php else : ?>-<?php endif ?></td>
                <td class="text-end text-nowrap"><?php if ($kelola) : ?>
                    <button class="btn btn-sm btn-outline-warning" data-bs-toggle="modal" data-bs-target="#modalForm" data-title="Edit TP" data-action="<?= site_url('atp/update/' . $r['id']) ?>" data-row='<?= esc(json_encode($r), 'attr') ?>'><i class="bi bi-pencil"></i></button>
                    <?= delete_button('atp/delete/' . $r['id'], '', 'Hapus TP ini?') ?><?php endif ?></td>
            </tr>
        <?php endforeach ?>
        <?php if (! $rows) : ?><tr><td colspan="8" class="text-center text-muted">Belum ada tujuan pembelajaran.</td></tr><?php endif ?>
        </tbody>
    </table>
</div></div>
<?php if ($kelola) : ?>
<div class="modal fade" id="modalForm" data-crud tabindex="-1">
    <div class="modal-dialog modal-lg"><form method="post" enctype="multipart/form-data" class="modal-content"><?= csrf_field() ?>
        <input type="hidden" name="mapel_id" value="<?= $mapelId ?>"><input type="hidden" name="tingkat" value="<?= esc($tingkat) ?>">
        <div class="modal-header"><h5 class="modal-title"></h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
        <div class="modal-body row g-2">
            <div class="col-md-2"><label class="form-label">Urutan</label><input type="number" name="urutan" class="form-control" min="0"></div>
            <div class="col-md-2"><label class="form-label">Kode</label><input name="kode" class="form-control" maxlength="20" placeholder="7.1"></div>
            <div class="col-md-2"><label class="form-label">Fase</label><input name="fase" class="form-control" maxlength="5"></div>
            <div class="col-md-3"><label class="form-label">Semester</label><select name="semester" class="form-select"><option value="">Semua</option><option>Ganjil</option><option>Genap</option></select></div>
            <div class="col-md-3"><label class="form-label">Alokasi JP</label><input type="number" name="alokasi_jp" class="form-control" min="0"></div>
            <div class="col-12"><label class="form-label">Elemen</label><input name="elemen" class="form-control" maxlength="150" placeholder="Bilangan / Membaca dan Memirsa"></div>
            <div class="col-12"><label class="form-label">Tujuan pembelajaran</label><textarea name="tujuan" class="form-control" rows="3" required></textarea></div>
            <div class="col-12"><label class="form-label">Modul ajar (PDF/Word/PPT, maks. 10 MB)</label><input type="file" name="modul_ajar" class="form-control" accept=".pdf,.doc,.docx,.ppt,.pptx"></div>
        </div>
        <div class="modal-footer"><button class="btn btn-primary">Simpan</button></div>
    </form></div>
</div>
<?php endif ?>
<?= $this->endSection() ?>
<?= $this->section('scripts') ?><?= $this->include('partials/modal_form_js') ?><?= $this->endSection() ?>
