<?= $this->extend('layouts/main') ?>
<?= $this->section('actions') ?>
<button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#modalForm" data-title="Tambah Tahun Pelajaran" data-action="<?= site_url('akademik/tahun-pelajaran/store') ?>"><i class="bi bi-plus-lg"></i> Tambah</button>
<?= $this->endSection() ?>
<?= $this->section('content') ?>
<div class="card">
    <div class="card-body table-responsive">
        <table class="table table-hover align-middle">
            <thead><tr><th>Tahun Pelajaran</th><th>Semester</th><th>Periode</th><th>Status</th><th class="text-end">Aksi</th></tr></thead>
            <tbody>
            <?php foreach ($rows as $r) : ?>
                <tr>
                    <td><?= esc($r['tahun_pelajaran']) ?></td>
                    <td><?= esc($r['semester']) ?></td>
                    <td><?= tgl_indo($r['tanggal_mulai']) ?> – <?= tgl_indo($r['tanggal_selesai']) ?><?= empty($r['tanggal_mulai']) ? ' <span class="badge bg-warning text-dark">isi periode</span>' : '' ?></td>
                    <td><?= $r['is_active'] ? '<span class="badge bg-success">Aktif</span>' : '' ?></td>
                    <td class="text-end text-nowrap">
                        <?php if (! $r['is_active']) : ?>
                            <form method="post" action="<?= site_url('akademik/tahun-pelajaran/aktifkan/' . $r['id']) ?>" class="d-inline"><?= csrf_field() ?><button class="btn btn-sm btn-outline-success">Aktifkan</button></form>
                        <?php endif ?>
                        <button class="btn btn-sm btn-outline-warning" data-bs-toggle="modal" data-bs-target="#modalForm" data-title="Edit Tahun Pelajaran"
                                data-action="<?= site_url('akademik/tahun-pelajaran/update/' . $r['id']) ?>" data-row='<?= esc(json_encode($r), 'attr') ?>'><i class="bi bi-pencil"></i></button>
                        <?php if (! $r['is_active']) : ?><?= delete_button('akademik/tahun-pelajaran/delete/' . $r['id'], '', 'Menghapus TP akan menghapus SELURUH jadwal, jurnal, absensi, dan catatan pada TP tersebut. Lanjutkan?') ?><?php endif ?>
                    </td>
                </tr>
            <?php endforeach ?>
            <?php if (! $rows) : ?><tr><td colspan="5" class="text-center text-muted">Belum ada data.</td></tr><?php endif ?>
            </tbody>
        </table>
    </div>
</div>

<div class="modal fade" id="modalForm" data-crud tabindex="-1">
    <div class="modal-dialog"><form method="post" class="modal-content"><?= csrf_field() ?>
        <div class="modal-header"><h5 class="modal-title"></h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
        <div class="modal-body">
            <div class="mb-2"><label class="form-label">Tahun Pelajaran</label><input name="tahun_pelajaran" class="form-control" placeholder="2026/2027" required pattern="\d{4}/\d{4}"></div>
            <div class="mb-2"><label class="form-label">Semester</label><select name="semester" class="form-select"><option>Ganjil</option><option>Genap</option></select></div>
            <div class="row">
                <div class="col"><label class="form-label">Tanggal mulai</label><input type="date" name="tanggal_mulai" class="form-control" required></div>
                <div class="col"><label class="form-label">Tanggal selesai</label><input type="date" name="tanggal_selesai" class="form-control" required></div>
            </div>
            <small class="text-muted d-block mt-1">Periode semester (hari pertama s.d. terakhir KBM/penerimaan rapor). Dipakai untuk menghitung pekan efektif.</small>
            <div class="form-check mt-3"><input class="form-check-input" type="checkbox" name="is_active" value="1" id="cAktif"><label class="form-check-label" for="cAktif">Jadikan aktif (hanya saat tambah)</label></div>
        </div>
        <div class="modal-footer"><button class="btn btn-primary">Simpan</button></div>
    </form></div>
</div>
<?= $this->endSection() ?>
<?= $this->section('scripts') ?><?= $this->include('partials/modal_form_js') ?><?= $this->endSection() ?>
