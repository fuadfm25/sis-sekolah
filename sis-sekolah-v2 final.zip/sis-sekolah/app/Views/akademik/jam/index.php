<?= $this->extend('layouts/main') ?>
<?= $this->section('actions') ?>
<?php if (! $hari || $khusus[$hari]) : ?>
<button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#modalForm" data-title="Tambah Slot" data-action="<?= site_url('akademik/jam-pelajaran/store') ?>" data-row='<?= esc(json_encode(['is_kbm' => '1', 'hari' => $hari ?: '']), 'attr') ?>'><i class="bi bi-plus-lg"></i> Tambah Slot</button>
<?php endif ?>
<?= $this->endSection() ?>
<?= $this->section('content') ?>
<ul class="nav nav-tabs mb-0">
    <li class="nav-item"><a class="nav-link <?= $hari ? '' : 'active' ?>" href="?">Bawaan (semua hari)</a></li>
    <?php foreach (hari_list() as $h => $hn) : ?>
        <li class="nav-item"><a class="nav-link <?= $hari === $h ? 'active' : '' ?>" href="?hari=<?= $h ?>"><?= $hn ?><?= $khusus[$h] ? ' <span class="badge bg-primary">khusus</span>' : '' ?></a></li>
    <?php endforeach ?>
</ul>
<?php if ($hari && ! $khusus[$hari]) : ?>
<div class="card"><div class="card-body">
    <p>Hari <strong><?= nama_hari($hari) ?></strong> memakai <strong>jam bawaan</strong>.</p>
    <form method="post" action="<?= site_url('akademik/jam-pelajaran/buat-khusus/' . $hari) ?>"><?= csrf_field() ?>
        <button class="btn btn-primary"><i class="bi bi-clock-history"></i> Buat jam khusus <?= nama_hari($hari) ?> (salin dari bawaan)</button>
        <small class="text-muted d-block mt-2">Jadwal hari <?= nama_hari($hari) ?> yang sudah ada otomatis dipindah ke slot baru berdasarkan nomor jam ke. Setelah itu ubah waktunya (mis. Jumat jam ke-1 07.00–07.35).</small>
    </form>
</div></div>
<?php else : ?>
<div class="card"><div class="card-body table-responsive">
    <?php if ($hari) : ?>
        <form method="post" action="<?= site_url('akademik/jam-pelajaran/hapus-khusus/' . $hari) ?>" class="mb-2" onsubmit="return confirm('Hapus jam khusus dan kembali ke jam bawaan?')"><?= csrf_field() ?>
            <span class="small text-muted">Jam khusus hari <?= nama_hari($hari) ?>.</span> <button class="btn btn-sm btn-outline-secondary"><i class="bi bi-arrow-counterclockwise"></i> Kembali ke jam bawaan</button></form>
    <?php endif ?>
    <table class="table table-hover align-middle">
        <thead><tr><th>Jam ke</th><th>Mulai</th><th>Selesai</th><th>Jenis</th><th>Keterangan</th><th class="text-end">Aksi</th></tr></thead>
        <tbody>
        <?php foreach ($rows as $r) : ?>
            <tr class="<?= $r['is_kbm'] ? '' : 'table-light text-muted' ?>">
                <td><?= $r['is_kbm'] ? esc($r['jam_ke']) : '-' ?></td>
                <td><?= jam($r['jam_mulai']) ?></td><td><?= jam($r['jam_selesai']) ?></td>
                <td><?= $r['is_kbm'] ? '<span class="badge bg-primary">KBM</span>' : '<span class="badge bg-secondary">Non-KBM</span>' ?></td>
                <td><?= esc($r['keterangan']) ?></td>
                <td class="text-end text-nowrap">
                    <?php $r['jam_mulai'] = jam($r['jam_mulai']); $r['jam_selesai'] = jam($r['jam_selesai']); ?>
                    <button class="btn btn-sm btn-outline-warning" data-bs-toggle="modal" data-bs-target="#modalForm" data-title="Edit Slot" data-action="<?= site_url('akademik/jam-pelajaran/update/' . $r['id']) ?>" data-row='<?= esc(json_encode($r), 'attr') ?>'><i class="bi bi-pencil"></i></button>
                    <?= delete_button('akademik/jam-pelajaran/delete/' . $r['id'], '', 'Hapus slot ini?') ?>
                </td>
            </tr>
        <?php endforeach ?>
        <?php if (! $rows) : ?><tr><td colspan="6" class="text-center text-muted">Belum ada slot.</td></tr><?php endif ?>
        </tbody>
    </table>
</div></div>
<?php endif ?>
<div class="modal fade" id="modalForm" data-crud tabindex="-1">
    <div class="modal-dialog"><form method="post" class="modal-content"><?= csrf_field() ?>
        <div class="modal-header"><h5 class="modal-title"></h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
        <div class="modal-body row g-2"><input type="hidden" name="hari">
            <div class="col-12"><div class="form-check"><input class="form-check-input" type="checkbox" name="is_kbm" value="1" id="jKbm"><label class="form-check-label" for="jKbm">Slot KBM (bisa diisi jadwal)</label></div></div>
            <div class="col-4"><label class="form-label">Jam ke</label><input type="number" name="jam_ke" min="0" class="form-control"></div>
            <div class="col-4"><label class="form-label">Mulai</label><input type="time" name="jam_mulai" class="form-control" required></div>
            <div class="col-4"><label class="form-label">Selesai</label><input type="time" name="jam_selesai" class="form-control" required></div>
            <div class="col-12"><label class="form-label">Keterangan</label><input name="keterangan" class="form-control" placeholder="Istirahat / Upacara"></div>
        </div>
        <div class="modal-footer"><button class="btn btn-primary">Simpan</button></div>
    </form></div>
</div>
<?= $this->endSection() ?>
<?= $this->section('scripts') ?><?= $this->include('partials/modal_form_js') ?><?= $this->endSection() ?>
