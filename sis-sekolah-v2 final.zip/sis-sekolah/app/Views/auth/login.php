<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="theme-color" content="#0f2557">
    <title>Masuk · <?= esc(nama_aplikasi()) ?></title>
    <link rel="icon" href="<?= esc(logo_url() ?? base_url('favicon.svg')) ?>">
    <link rel="stylesheet" href="<?= aset('bootstrap-css') ?>">
    <link rel="stylesheet" href="<?= aset('bi-css') ?>">
    <link rel="stylesheet" href="<?= tema_css() ?>">
</head>
<body>
<div class="sis-login">
    <section class="panel">
        <div class="d-flex align-items-center gap-2">
            <img src="<?= logo_aplikasi() ?>" alt="" width="44" height="44" style="border-radius:12px">
            <div><div class="fw-bold fs-5 lh-1"><?= esc(nama_aplikasi()) ?></div><div class="small" style="color:rgba(255,255,255,.6)">Administrasi Pembelajaran</div></div>
        </div>
        <div class="my-4">
            <h1>Satu tempat untuk <span>jurnal, absensi,</span> dan pembinaan siswa.</h1>
            <p class="mt-3">Jadwal, jurnal mengajar, absensi pagi & mapel, pembiasaan, catatan perilaku, hingga laporan cetak – tercatat rapi setiap hari.</p>
            <div class="fitur">
                <div><i class="bi bi-journal-check"></i>Jurnal & absensi mapel dalam satu formulir</div>
                <div><i class="bi bi-upc-scan"></i>Absensi kiosk dengan kartu RFID atau barcode</div>
                <div><i class="bi bi-printer"></i>Laporan siap cetak sesuai peran masing-masing</div>
            </div>
        </div>
        <div class="small bawah" style="color:rgba(255,255,255,.5)">&copy; <?= date('Y') ?> <?= esc(setting('nama_sekolah', '')) ?></div>
    </section>
    <section class="form-sisi">
        <div class="kotak">
            <div class="text-center mb-4">
                <?php if ($lg = logo_url()) : ?><img src="<?= esc($lg) ?>" alt="Logo sekolah" class="logo-sekolah mb-2"><?php endif ?>
                <h2 class="h5 mb-1"><?= esc(setting('nama_sekolah', 'Selamat datang')) ?></h2>
                <div class="text-muted small"><?= esc(nomor_sekolah() ?: 'Masuk untuk melanjutkan') ?></div>
            </div>
            <div class="card">
                <div class="card-body p-4">
                    <h3 class="h6 fw-bold mb-3">Masuk ke akun Anda</h3>
                    <?= view('partials/flash') ?>
                    <form action="<?= site_url('login') ?>" method="post">
                        <?= csrf_field() ?>
                        <div class="mb-3">
                            <label class="form-label" for="username">Username</label>
                            <div class="input-group"><span class="input-group-text"><i class="bi bi-person"></i></span>
                                <input type="text" id="username" name="username" class="form-control" value="<?= esc(old('username')) ?>" required autofocus autocomplete="username"></div>
                        </div>
                        <div class="mb-4">
                            <label class="form-label" for="password">Password</label>
                            <div class="input-group"><span class="input-group-text"><i class="bi bi-lock"></i></span>
                                <input type="password" id="password" name="password" class="form-control" required autocomplete="current-password">
                                <button class="btn btn-light border" type="button" onclick="var p=document.getElementById('password');p.type=p.type==='password'?'text':'password';this.firstElementChild.classList.toggle('bi-eye');this.firstElementChild.classList.toggle('bi-eye-slash')" aria-label="Tampilkan password"><i class="bi bi-eye"></i></button></div>
                        </div>
                        <button class="btn btn-primary w-100">Masuk <i class="bi bi-arrow-right ms-1"></i></button>
                    </form>
                </div>
            </div>
            <p class="text-center small text-muted mt-3 mb-0"><i class="bi bi-question-circle"></i> Lupa password atau akun terkunci? Hubungi admin/operator sekolah.</p>
            <a href="<?= site_url('portal/login') ?>" class="btn btn-light w-100 mt-3"><i class="bi bi-mortarboard me-1"></i>Masuk sebagai siswa / orang tua</a>
        </div>
    </section>
</div>
</body>
</html>
