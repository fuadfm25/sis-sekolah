<?= $this->extend('layouts/main') ?>
<?= $this->section('actions') ?><a href="<?= site_url('bk/layanan') ?>" class="btn btn-light"><i class="bi bi-arrow-left"></i> Kembali</a><?= $this->endSection() ?>
<?= $this->section('content') ?>
<?php
$v = static fn ($k, $d = '') => old($k, $l[$k] ?? $d);
$pesertaIds = array_map('intval', (array) old('peserta', array_column($l['peserta'] ?? [], 'id')));
?>
<?php if ($rujukan) : ?>
    <div class="alert alert-light border">
        <strong>Rujukan:</strong> <?= esc($rujukan['nama_siswa']) ?> (<?= esc($rujukan['nama_kelas']) ?>) – <?= esc($rujukan['nama_jenis'] ?? 'Catatan perilaku') ?>, <?= tgl_indo($rujukan['tanggal']) ?>.
        <br><small><?= esc($rujukan['deskripsi']) ?> — dirujuk oleh <?= esc($rujukan['pencatat']) ?></small>
    </div>
<?php endif ?>
<div class="card"><div class="card-body">
<form method="post" action="<?= site_url(isset($l['id']) ? 'bk/layanan/update/' . $l['id'] : 'bk/layanan/simpan') ?>" class="row g-3">
    <?= csrf_field() ?>
    <input type="hidden" name="catatan_perilaku_id" value="<?= esc($l['catatan_perilaku_id'] ?? '') ?>">
    <div class="col-md-3"><label class="form-label">Tanggal *</label><input type="date" name="tanggal" class="form-control" value="<?= esc($v('tanggal')) ?>" required></div>
    <?php $K = \App\Models\BkLayananModel::KATALOG; ?>
    <div class="col-md-4"><label class="form-label">Jenis layanan *</label><select name="jenis_layanan" id="jenisBk" class="form-select" required>
        <?php foreach (\App\Models\BkLayananModel::KOMPONEN as $kom) : ?>
            <optgroup label="<?= esc($kom) ?>">
            <?php foreach ($K as $j => [$kj]) : if ($kj !== $kom) { continue; } ?><option <?= $v('jenis_layanan', 'Konseling Individual') === $j ? 'selected' : '' ?>><?= esc($j) ?></option><?php endforeach ?>
            </optgroup>
        <?php endforeach ?>
        <?php if ($v('jenis_layanan') && ! isset($K[$v('jenis_layanan')])) : ?><option selected><?= esc($v('jenis_layanan')) ?></option><?php endif ?>
        </select><div class="form-text" id="ketBk"></div></div>
    <div class="col-md-2"><label class="form-label">Bidang *</label><select name="bidang" class="form-select" required>
        <?php foreach (\App\Models\BkLayananModel::BIDANG as $j) : ?><option <?= $v('bidang') === $j ? 'selected' : '' ?>><?= $j ?></option><?php endforeach ?></select></div>
    <div class="col-md-3"><label class="form-label">Status *</label><select name="status" class="form-select">
        <?php foreach (\App\Models\BkLayananModel::STATUS as $j) : ?><option <?= $v('status') === $j ? 'selected' : '' ?>><?= $j ?></option><?php endforeach ?></select></div>

    <div class="col-md-4"><label class="form-label">Komponen layanan</label><select name="komponen" id="komBk" class="form-select">
        <?php foreach (\App\Models\BkLayananModel::KOMPONEN as $j) : ?><option <?= $v('komponen') === $j ? 'selected' : '' ?>><?= esc($j) ?></option><?php endforeach ?></select></div>
    <div class="col-md-4"><label class="form-label">Format</label><select name="format" id="forBk" class="form-select">
        <?php foreach (\App\Models\BkLayananModel::FORMAT as $j) : ?><option <?= $v('format') === $j ? 'selected' : '' ?>><?= esc($j) ?></option><?php endforeach ?></select></div>
    <div class="col-md-4"><label class="form-label">Media</label><select name="media" class="form-select">
        <?php foreach (\App\Models\BkLayananModel::MEDIA as $j) : ?><option <?= $v('media', 'Tatap muka') === $j ? 'selected' : '' ?>><?= esc($j) ?></option><?php endforeach ?></select></div>

    <div class="col-md-8"><label class="form-label">Siswa peserta</label>
        <select name="peserta[]" class="form-select tom" multiple placeholder="Ketik nama siswa...">
            <?php foreach ($siswa as $s) : ?><option value="<?= $s['id'] ?>" <?= in_array((int) $s['id'], $pesertaIds, true) ? 'selected' : '' ?>><?= esc($s['nama_lengkap'] . ' – ' . $s['nama_kelas']) ?></option><?php endforeach ?>
        </select></div>
    <div class="col-md-4"><label class="form-label">Kelas (layanan klasikal)</label>
        <select name="kelas_id" class="form-select"><option value="">-</option>
            <?php foreach ($kelas as $k) : ?><option value="<?= $k['id'] ?>" <?= (int) $v('kelas_id') === (int) $k['id'] ? 'selected' : '' ?>><?= esc($k['nama_kelas']) ?></option><?php endforeach ?></select></div>

    <div class="col-12" id="boxPihak"><label class="form-label">Pihak terkait</label><input name="pihak_terkait" class="form-control" maxlength="150" value="<?= esc($v('pihak_terkait')) ?>" placeholder="Orang tua (Bapak Budi), wali kelas, psikolog Puskesmas, ..."></div>
    <div class="col-12"><label class="form-label">Topik *</label><input name="topik" class="form-control" value="<?= esc($v('topik')) ?>" required maxlength="200"></div>
    <div class="col-md-6"><label class="form-label">Permasalahan / latar belakang</label><textarea name="permasalahan" class="form-control" rows="4"><?= esc($v('permasalahan')) ?></textarea></div>
    <div class="col-md-6"><label class="form-label">Penanganan / proses layanan</label><textarea name="penanganan" class="form-control" rows="4"><?= esc($v('penanganan')) ?></textarea></div>
    <div class="col-md-6"><label class="form-label">Hasil</label><textarea name="hasil" class="form-control" rows="3"><?= esc($v('hasil')) ?></textarea></div>
    <div class="col-md-6"><label class="form-label">Rencana tindak lanjut</label><textarea name="rencana_tindak_lanjut" class="form-control" rows="3"><?= esc($v('rencana_tindak_lanjut')) ?></textarea></div>
    <div class="col-12"><div class="form-check"><input class="form-check-input" type="checkbox" name="is_rahasia" value="1" id="rhs" <?= $v('is_rahasia', 1) ? 'checked' : '' ?>><label class="form-check-label" for="rhs"><i class="bi bi-lock"></i> Rahasia (hanya dapat dibuka oleh saya sebagai konselor)</label></div></div>
    <div class="col-12"><button class="btn btn-primary"><i class="bi bi-save"></i> Simpan</button></div>
</form>
</div></div>
<?= $this->endSection() ?>
<?= $this->section('scripts') ?>
<script>
(function () {
    var K = <?= json_encode(\App\Models\BkLayananModel::KATALOG) ?>;
    var j = document.getElementById('jenisBk'), baru = <?= isset($l['id']) ? 'false' : 'true' ?>;
    function atur(awal) {
        var k = K[j.value]; if (!k) return;
        document.getElementById('ketBk').textContent = k[3];
        if (!awal || baru) { document.getElementById('komBk').value = k[0]; document.getElementById('forBk').value = k[1]; }
        document.getElementById('boxPihak').style.display = (k[2] === 'pihak' || document.querySelector('[name=pihak_terkait]').value) ? '' : 'none';
    }
    j.addEventListener('change', function () { atur(false); }); atur(true);
})();
</script>
<?= $this->endSection() ?>
