<?= $this->extend('layouts/main') ?>
<?= $this->section('actions') ?>
<button onclick="window.print()" class="btn btn-light"><i class="bi bi-printer"></i></button>
<?php if ($bisaKelola) : ?><a href="<?= site_url('bk/layanan/edit/' . $l['id']) ?>" class="btn btn-warning"><i class="bi bi-pencil"></i> Edit</a><?php endif ?>
<?= $this->endSection() ?>
<?= $this->section('content') ?>
<div class="card"><div class="card-body">
    <?= $this->include('partials/print_header') ?>
    <h5 class="print-only text-center">CATATAN LAYANAN BIMBINGAN DAN KONSELING</h5>
    <div class="row">
        <div class="col-md-6"><table class="table table-sm table-borderless">
            <tr><th style="width:150px">Tanggal</th><td><?= tgl_indo($l['tanggal'], true) ?></td></tr>
            <tr><th>Jenis layanan</th><td><?= esc($l['jenis_layanan']) ?></td></tr>
            <tr><th>Komponen</th><td><?= esc($l['komponen'] ?? '-') ?></td></tr>
            <tr><th>Bidang</th><td><?= esc($l['bidang']) ?></td></tr>
            <tr><th>Format / media</th><td><?= esc(($l['format'] ?? '-') . ' · ' . ($l['media'] ?? '-')) ?></td></tr>
            <?php if (! empty($l['pihak_terkait'])) : ?><tr><th>Pihak terkait</th><td><?= esc($l['pihak_terkait']) ?></td></tr><?php endif ?>
            <tr><th>Status</th><td><?= badge_status($l['status']) ?> <?= $l['is_rahasia'] ? '<span class="badge bg-dark"><i class="bi bi-lock"></i> Rahasia</span>' : '' ?></td></tr>
        </table></div>
        <div class="col-md-6"><table class="table table-sm table-borderless">
            <tr><th style="width:150px">Konselor</th><td><?= esc($l['konselor']) ?></td></tr>
            <tr><th>Peserta</th><td><?php foreach ($l['peserta'] as $p) : ?><a href="<?= site_url('siswa/profil/' . $p['id']) ?>"><?= esc($p['nama_lengkap']) ?></a><br><?php endforeach ?><?= $l['nama_kelas'] ? 'Kelas ' . esc($l['nama_kelas']) : '' ?></td></tr>
            <?php if ($rujukan) : ?><tr><th>Asal rujukan</th><td><?= esc($rujukan['nama_jenis'] ?? 'Catatan perilaku') ?> (<?= tgl_indo($rujukan['tanggal']) ?>) oleh <?= esc($rujukan['pencatat']) ?></td></tr><?php endif ?>
        </table></div>
    </div>
    <hr>
    <h6><?= esc($l['topik']) ?></h6>
    <dl class="row mt-3">
        <dt class="col-md-3">Permasalahan</dt><dd class="col-md-9"><?= nl2br(esc($l['permasalahan'] ?? '-')) ?></dd>
        <dt class="col-md-3">Penanganan</dt><dd class="col-md-9"><?= nl2br(esc($l['penanganan'] ?? '-')) ?></dd>
        <dt class="col-md-3">Hasil</dt><dd class="col-md-9"><?= nl2br(esc($l['hasil'] ?? '-')) ?></dd>
        <dt class="col-md-3">Rencana tindak lanjut</dt><dd class="col-md-9"><?= nl2br(esc($l['rencana_tindak_lanjut'] ?? '-')) ?></dd>
    </dl>
    <?php if ($bisaKelola) : ?>
        <div class="text-end no-print"><?= delete_button('bk/layanan/hapus/' . $l['id'], 'Hapus') ?></div>
    <?php endif ?>
</div></div>
<?= $this->endSection() ?>
