<?= $this->extend('layouts/main') ?>
<?= $this->section('actions') ?><a href="<?= site_url('bk/layanan/tambah') ?>" class="btn btn-primary"><i class="bi bi-plus-lg"></i> Catat Layanan</a><?= $this->endSection() ?>
<?= $this->section('content') ?>
<div class="card"><div class="card-body">
    <form class="row g-2 mb-3 filter" method="get">
        <div class="col-md-3"><select name="jenis_layanan" class="form-select"><option value="">Semua jenis layanan</option>
            <?php foreach (\App\Models\BkLayananModel::JENIS as $j) : ?><option <?= $f['jenis_layanan'] === $j ? 'selected' : '' ?>><?= $j ?></option><?php endforeach ?></select></div>
        <div class="col-md-2"><select name="komponen" class="form-select"><option value="">Semua komponen</option>
            <?php foreach (\App\Models\BkLayananModel::KOMPONEN as $j) : ?><option <?= ($f['komponen'] ?? '') === $j ? 'selected' : '' ?>><?= esc($j) ?></option><?php endforeach ?></select></div>
        <div class="col-md-2"><select name="bidang" class="form-select"><option value="">Semua bidang</option>
            <?php foreach (\App\Models\BkLayananModel::BIDANG as $j) : ?><option <?= $f['bidang'] === $j ? 'selected' : '' ?>><?= $j ?></option><?php endforeach ?></select></div>
        <div class="col-md-2"><select name="status" class="form-select"><option value="">Semua status</option>
            <?php foreach (\App\Models\BkLayananModel::STATUS as $j) : ?><option <?= $f['status'] === $j ? 'selected' : '' ?>><?= $j ?></option><?php endforeach ?></select></div>
        <div class="col-md-2"><input type="date" name="dari" value="<?= esc($f['dari']) ?>" class="form-control"></div>
        <div class="col-md-2"><input name="q" value="<?= esc($f['q']) ?>" class="form-control" placeholder="Cari topik"></div>
        <div class="col-md-1"><button class="btn btn-light w-100"><i class="bi bi-funnel"></i></button></div>
    </form>
    <div class="table-responsive">
    <table class="table table-sm table-hover align-middle">
        <thead><tr><th>Tanggal</th><th>Jenis / bidang</th><th>Peserta</th><th>Topik</th><th>Status</th><th>Konselor</th><th></th></tr></thead>
        <tbody>
        <?php foreach ($rows as $r) : ?>
            <tr>
                <td class="text-nowrap"><?= tgl_indo($r['tanggal']) ?></td>
                <td><?= esc($r['jenis_layanan']) ?><br><small class="text-muted"><?= esc(($r['komponen'] ? $r['komponen'] . ' · ' : '') . $r['bidang']) ?></small></td>
                <td class="small"><?php foreach ($r['peserta'] as $p) : ?><a href="<?= site_url('siswa/profil/' . $p['id']) ?>"><?= esc($p['nama_lengkap']) ?></a><br><?php endforeach ?><?= $r['nama_kelas'] ? 'Kelas ' . esc($r['nama_kelas']) : '' ?></td>
                <td><?= $r['tersembunyi'] ? '<span class="text-muted"><i class="bi bi-lock"></i> Rahasia</span>' : esc(character_limiter($r['topik'], 60)) ?></td>
                <td><?= badge_status($r['status']) ?></td>
                <td class="small"><?= esc($r['konselor']) ?></td>
                <td class="text-nowrap"><?php if (! $r['tersembunyi']) : ?><a href="<?= site_url('bk/layanan/' . $r['id']) ?>" class="btn btn-sm btn-light"><i class="bi bi-eye"></i></a> <?php if ($r['bisaKelola']) : ?><a href="<?= site_url('bk/layanan/edit/' . $r['id']) ?>" class="btn btn-sm btn-outline-warning"><i class="bi bi-pencil"></i></a><?php endif ?><?php endif ?></td>
            </tr>
        <?php endforeach ?>
        <?php if (! $rows) : ?><tr><td colspan="7" class="text-center text-muted">Belum ada layanan.</td></tr><?php endif ?>
        </tbody>
    </table>
    </div>
    <?= $this->include('partials/pager') ?>
</div></div>
<?= $this->endSection() ?>
