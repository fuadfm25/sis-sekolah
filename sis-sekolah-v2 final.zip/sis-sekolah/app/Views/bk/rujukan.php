<?= $this->extend('layouts/main') ?>
<?= $this->section('content') ?>
<div class="card"><div class="card-body">
    <div class="mb-3">
        <?php foreach (['Dirujuk BK' => 'Menunggu', 'Ditangani BK' => 'Sedang ditangani', 'Selesai' => 'Selesai'] as $s => $lbl) : ?>
            <a href="?status=<?= urlencode($s) ?>" class="btn btn-sm <?= $status === $s ? 'btn-primary' : 'btn-light' ?>"><?= $lbl ?></a>
        <?php endforeach ?>
    </div>
    <div class="table-responsive">
    <table class="table table-sm table-hover align-middle">
        <thead><tr><th>Tanggal</th><th>Siswa</th><th>Perilaku</th><th>Tindak lanjut awal</th><th>Perujuk</th><th></th></tr></thead>
        <tbody>
        <?php foreach ($rows as $r) : ?>
            <tr>
                <td class="text-nowrap"><?= tgl_indo($r['tanggal']) ?></td>
                <td><a href="<?= site_url('siswa/profil/' . $r['siswa_id']) ?>"><?= esc($r['nama_siswa']) ?></a><br><small class="text-muted"><?= esc($r['nama_kelas']) ?></small></td>
                <td><strong><?= esc($r['nama_jenis'] ?? 'Lainnya') ?></strong> (<?= $r['kategori'] === 'Negatif' ? '-' : '+' ?><?= $r['poin'] ?>)<br><small><?= esc(character_limiter($r['deskripsi'], 100)) ?></small></td>
                <td class="small"><?= esc($r['tindak_lanjut'] ?? '-') ?></td>
                <td class="small"><?= esc($r['pencatat']) ?></td>
                <td class="text-nowrap">
                    <?php if ($r['status'] === 'Dirujuk BK') : ?><a href="<?= site_url('bk/rujukan/tangani/' . $r['id']) ?>" class="btn btn-sm btn-primary">Tangani</a>
                    <?php else : ?><a href="<?= site_url('bk/layanan?siswa_id=' . $r['siswa_id']) ?>" class="btn btn-sm btn-light">Layanan</a><?php endif ?>
                </td>
            </tr>
        <?php endforeach ?>
        <?php if (! $rows) : ?><tr><td colspan="6" class="text-center text-muted">Tidak ada data.</td></tr><?php endif ?>
        </tbody>
    </table>
    </div>
    <?= $this->include('partials/pager') ?>
</div></div>
<?= $this->endSection() ?>
