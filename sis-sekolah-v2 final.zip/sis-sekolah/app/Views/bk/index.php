<?= $this->extend('layouts/main') ?>
<?= $this->section('actions') ?><a href="<?= site_url('bk/layanan/tambah') ?>" class="btn btn-primary"><i class="bi bi-plus-lg"></i> Catat Layanan</a><?= $this->endSection() ?>
<?= $this->section('content') ?>
<div class="row">
    <div class="col-lg-7">
        <div class="card">
            <div class="card-header d-flex justify-content-between"><h5 class="card-title mb-0"><i class="bi bi-inbox"></i> Rujukan Menunggu (<?= count($rujukan) ?>)</h5><a href="<?= site_url('bk/rujukan') ?>" class="small">Semua &raquo;</a></div>
            <div class="card-body">
                <?php if (! $rujukan) : ?><p class="text-muted mb-0">Tidak ada rujukan baru.</p><?php endif ?>
                <?php foreach ($rujukan as $r) : ?>
                    <div class="d-flex justify-content-between align-items-start border-bottom py-2">
                        <div>
                            <a href="<?= site_url('siswa/profil/' . $r['siswa_id']) ?>" class="fw-bold"><?= esc($r['nama_siswa']) ?></a> <small class="text-muted"><?= esc($r['nama_kelas']) ?> · <?= tgl_indo($r['tanggal']) ?></small><br>
                            <small><?= esc($r['nama_jenis'] ?? '') ?> – <?= esc(character_limiter($r['deskripsi'], 100)) ?></small><br>
                            <small class="text-muted">Dirujuk oleh <?= esc($r['pencatat']) ?></small>
                        </div>
                        <a href="<?= site_url('bk/rujukan/tangani/' . $r['id']) ?>" class="btn btn-sm btn-primary text-nowrap">Tangani</a>
                    </div>
                <?php endforeach ?>
            </div>
        </div>
        <div class="card">
            <div class="card-header"><h5 class="card-title mb-0"><i class="bi bi-calendar-event"></i> Agenda Layanan</h5></div>
            <div class="card-body">
                <?php if (! $agenda) : ?><p class="text-muted mb-0">Tidak ada layanan terjadwal.</p><?php endif ?>
                <table class="table table-sm mb-0">
                    <?php foreach ($agenda as $a) : ?>
                        <tr>
                            <td class="text-nowrap"><?= tgl_indo($a['tanggal'], true) ?></td>
                            <td><?= esc($a['jenis_layanan']) ?><br><small class="text-muted"><?= esc(implode(', ', array_column($a['peserta'], 'nama_lengkap')) ?: ($a['nama_kelas'] ?? '')) ?></small></td>
                            <td><?= badge_status($a['status']) ?></td>
                            <td><a href="<?= site_url('bk/layanan/' . $a['id']) ?>" class="btn btn-sm btn-light"><i class="bi bi-eye"></i></a></td>
                        </tr>
                    <?php endforeach ?>
                </table>
            </div>
        </div>
    </div>
    <div class="col-lg-5">
        <div class="card">
            <div class="card-header"><h5 class="card-title mb-0"><i class="bi bi-exclamation-triangle text-danger"></i> Siswa Prioritas (poin ≥ <?= $batas ?>)</h5></div>
            <div class="card-body">
                <?php if (! $prioritas) : ?><p class="text-muted mb-0">Tidak ada.</p><?php endif ?>
                <ul class="list-unstyled mb-0">
                    <?php foreach ($prioritas as $p) : ?>
                        <li class="d-flex justify-content-between mb-1"><a href="<?= site_url('siswa/profil/' . $p['siswa_id']) ?>"><?= esc($p['nama_siswa']) ?> <small class="text-muted"><?= esc($p['nama_kelas']) ?></small></a><span class="badge bg-danger"><?= $p['poin_negatif'] ?></span></li>
                    <?php endforeach ?>
                </ul>
            </div>
        </div>
        <div class="card">
            <div class="card-header"><h5 class="card-title mb-0">Statistik Layanan TP Ini</h5></div>
            <div class="card-body">
                <?php foreach (\App\Models\BkLayananModel::KOMPONEN as $kom) :
                    $jenisKom = array_keys(array_filter(\App\Models\BkLayananModel::KATALOG, static fn ($k) => $k[0] === $kom));
                    $totKom = array_sum(array_map(static fn ($j) => (int) ($statistik[$j] ?? 0), $jenisKom)); ?>
                    <div class="d-flex justify-content-between fw-semibold mt-2"><span><?= esc($kom) ?></span><span><?= $totKom ?></span></div>
                    <?php foreach ($jenisKom as $j) : if (empty($statistik[$j])) { continue; } ?>
                        <div class="d-flex justify-content-between small ps-2 text-muted"><span><?= esc($j) ?></span><span><?= (int) $statistik[$j] ?></span></div>
                    <?php endforeach ?>
                <?php endforeach ?>
            </div>
        </div>
    </div>
</div>
<?= $this->endSection() ?>
