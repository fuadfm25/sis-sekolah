<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="robots" content="noindex, nofollow">
    <title>Absensi Kiosk | <?= esc(setting('nama_sekolah', nama_aplikasi())) ?></title>
    <link rel="stylesheet" href="<?= aset('bootstrap-css') ?>">
    <link rel="stylesheet" href="<?= aset('bi-css') ?>">
    <link rel="stylesheet" href="<?= tema_css() ?>">
    <link rel="icon" href="<?= esc(logo_url() ?? base_url('favicon.svg')) ?>">
    <style>
        body { background: radial-gradient(900px 500px at 0% 0%, #1f3c88 0%, transparent 60%), linear-gradient(160deg, #0f2557, #0b1d47); color: #fff; min-height: 100vh; }
        h1, h2, h3, h4, h5, h6 { color: #fff; }
        .jam { font-size: 4.5rem; font-weight: 800; letter-spacing: -1px; line-height: 1; font-variant-numeric: tabular-nums; color: #fff; }
        .hasil { min-height: 260px; border-radius: 1rem; transition: background .2s; }
        .hasil.datang { background: #0f8a6b; } .hasil.terlambat { background: #e3b23c; color: #1b2537; }
        .hasil.pulang { background: #2a4fa8; } .hasil.info { background: #3b4763; } .hasil.error { background: #c53b3b; }
        .hasil.siap { background: rgba(255,255,255,.08); }
        .nama { font-size: 2.4rem; font-weight: 700; }
        #kode { position: absolute; left: -9999px; }
        .riwayat td, .riwayat th { color: #dfe7ef; background: transparent !important; border-color: rgba(255,255,255,.1); }
        .table { --bs-table-bg: transparent; --bs-table-color: #dfe7ef; }
        #reader { max-width: 420px; margin: auto; }
        .stat { background: rgba(255,255,255,.08); border-radius: .75rem; }
    </style>
</head>
<body>
<div class="container py-4">
    <div class="d-flex justify-content-between align-items-start mb-4">
        <div class="d-flex align-items-center gap-3">
            <img src="<?= esc(logo_url() ?? logo_aplikasi()) ?>" alt="" style="height:64px;width:auto;border-radius:14px;background:#fff;padding:4px">
            <div>
            <h3 class="mb-0"><?= esc(setting('nama_sekolah', nama_aplikasi())) ?></h3>
            <div class="opacity-75">Absensi Siswa – tempelkan kartu / pindai barcode</div>
            </div>
        </div>
        <div class="text-end">
            <div class="jam" id="jam">--:--</div>
            <div id="tgl" class="opacity-75"></div>
        </div>
    </div>

    <div class="row g-4">
        <div class="col-lg-8">
            <div class="hasil siap p-4 d-flex flex-column justify-content-center text-center" id="hasil">
                <i class="bi bi-upc-scan" style="font-size:4rem" id="ikon"></i>
                <div class="nama mt-2" id="nama">Siap memindai</div>
                <div class="fs-4" id="kelas"></div>
                <div class="fs-5 mt-2" id="pesan">Masuk &le; <?= esc($jamMasuk) ?><?= $jamPulang ? ' · Pulang &ge; ' . esc($jamPulang) : '' ?></div>
                <?php $stHari = \App\Libraries\Kalender::status(date('Y-m-d')); if ($stHari['agenda'] || ! $stHari['absensi']) : ?><div class="mt-2 badge bg-light text-dark fs-6"><?= esc($stHari['label']) ?></div><?php endif ?>
            </div>
            <form id="form" autocomplete="off" class="mt-3">
                <input type="text" id="kode" name="kode" autofocus inputmode="none">
                <div class="d-flex gap-2 justify-content-center">
                    <button type="button" class="btn btn-outline-light btn-sm" id="btnKamera"><i class="bi bi-camera"></i> Pindai pakai kamera</button>
                    <button type="button" class="btn btn-outline-light btn-sm" id="btnManual"><i class="bi bi-keyboard"></i> Ketik NIS</button>
                    <button type="button" class="btn btn-outline-light btn-sm" onclick="document.documentElement.requestFullscreen?.()"><i class="bi bi-arrows-fullscreen"></i> Layar penuh</button>
                </div>
                <div id="manualBox" class="mt-3 d-none">
                    <div class="input-group mx-auto" style="max-width:360px">
                        <input type="text" id="manual" class="form-control" placeholder="NIS / NISN">
                        <button class="btn btn-light" type="button" id="btnKirim">Kirim</button>
                    </div>
                </div>
                <div id="reader" class="mt-3 d-none"></div>
            </form>
        </div>
        <div class="col-lg-4">
            <div class="row g-2 mb-3 text-center">
                <div class="col-4"><div class="stat p-2"><div class="fs-3 fw-bold" id="sHadir"><?= $ringkas['hadir'] ?></div><small>Tepat waktu</small></div></div>
                <div class="col-4"><div class="stat p-2"><div class="fs-3 fw-bold text-warning" id="sTerlambat"><?= $ringkas['terlambat'] ?></div><small>Terlambat</small></div></div>
                <div class="col-4"><div class="stat p-2"><div class="fs-3 fw-bold" id="sTotal"><?= $ringkas['total'] ?></div><small>Siswa</small></div></div>
            </div>
            <h6 class="opacity-75">Scan terakhir</h6>
            <table class="table table-sm riwayat"><tbody id="riwayat">
                <?php foreach ($riwayat as $r) : ?>
                    <tr><td><?= esc(substr((string) ($r['jam_pulang'] ?: $r['jam_datang']), 0, 5)) ?></td><td><?= esc($r['nama_lengkap']) ?><br><small class="opacity-75"><?= esc($r['nama_kelas']) ?></small></td><td><?= $r['jam_pulang'] ? 'Pulang' : ($r['status'] === 'T' ? 'Terlambat' : 'Hadir') ?></td></tr>
                <?php endforeach ?>
            </tbody></table>
        </div>
    </div>
</div>

<script src="<?= aset('html5-qrcode') ?>"></script>
<script>
const URL_SCAN = <?= json_encode(site_url('kiosk/' . $token . '/scan')) ?>;
const HARI = ['Minggu','Senin','Selasa','Rabu','Kamis','Jumat','Sabtu'];
const BULAN = ['Januari','Februari','Maret','April','Mei','Juni','Juli','Agustus','September','Oktober','November','Desember'];
const el = id => document.getElementById(id);
const kode = el('kode');
let sibuk = false, terakhir = {kode: '', waktu: 0}, reset;

function tick() {
    const d = new Date();
    el('jam').textContent = d.toLocaleTimeString('id-ID', {hour: '2-digit', minute: '2-digit', second: '2-digit'}).replace(/\./g, ':');
    el('tgl').textContent = HARI[d.getDay()] + ', ' + d.getDate() + ' ' + BULAN[d.getMonth()] + ' ' + d.getFullYear();
}
setInterval(tick, 1000); tick();

function fokus() { if (el('manualBox').classList.contains('d-none')) kode.focus(); }
document.addEventListener('click', fokus); setInterval(fokus, 2000);

function bunyi(ok) {
    try {
        const a = new (window.AudioContext || window.webkitAudioContext)(), o = a.createOscillator(), g = a.createGain();
        o.frequency.value = ok ? 880 : 220; o.connect(g); g.connect(a.destination); g.gain.value = .2;
        o.start(); o.stop(a.currentTime + (ok ? .15 : .5));
    } catch (e) {}
}

function tampil(d) {
    const ikon = {datang: 'bi-check-circle', terlambat: 'bi-alarm', pulang: 'bi-house-door', info: 'bi-info-circle', error: 'bi-x-circle'}[d.tipe] || 'bi-upc-scan';
    el('hasil').className = 'hasil p-4 d-flex flex-column justify-content-center text-center ' + d.tipe;
    el('ikon').className = 'bi ' + ikon; el('ikon').style.fontSize = '4rem';
    el('nama').textContent = d.nama || (d.ok ? '' : 'Gagal');
    el('kelas').textContent = d.kelas ? d.kelas + ' · NIS ' + d.nis : '';
    el('pesan').textContent = d.pesan || '';
    if (d.ringkas) { el('sHadir').textContent = d.ringkas.hadir; el('sTerlambat').textContent = d.ringkas.terlambat; el('sTotal').textContent = d.ringkas.total; }
    if (d.ok && d.tipe !== 'info') {
        const tr = document.createElement('tr');
        tr.innerHTML = '<td>' + d.jam + '</td><td></td><td>' + ({datang: 'Hadir', terlambat: 'Terlambat', pulang: 'Pulang'}[d.tipe]) + '</td>';
        tr.children[1].innerHTML = '<span></span><br><small class="opacity-75"></small>';
        tr.children[1].children[0].textContent = d.nama; tr.children[1].children[2].textContent = d.kelas;
        el('riwayat').prepend(tr);
        while (el('riwayat').children.length > 10) el('riwayat').lastChild.remove();
    }
    bunyi(d.ok);
    clearTimeout(reset);
    reset = setTimeout(() => { el('hasil').className = 'hasil siap p-4 d-flex flex-column justify-content-center text-center'; el('ikon').className = 'bi bi-upc-scan'; el('nama').textContent = 'Siap memindai'; el('kelas').textContent = ''; el('pesan').textContent = ''; }, 5000);
}

async function kirim(nilai) {
    nilai = (nilai || '').trim();
    if (!nilai || sibuk) return;
    // abaikan scan ganda kode yang sama dalam 3 detik
    if (nilai === terakhir.kode && Date.now() - terakhir.waktu < 3000) return;
    terakhir = {kode: nilai, waktu: Date.now()};
    sibuk = true;
    try {
        const r = await fetch(URL_SCAN, {method: 'POST', headers: {'X-Requested-With': 'XMLHttpRequest'}, body: new URLSearchParams({kode: nilai})});
        tampil(await r.json());
    } catch (e) {
        tampil({ok: false, tipe: 'error', pesan: 'Koneksi ke server terputus.'});
    } finally { sibuk = false; }
}

el('form').addEventListener('submit', e => { e.preventDefault(); kirim(kode.value); kode.value = ''; });
kode.addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); kirim(kode.value); kode.value = ''; } });

el('btnManual').onclick = () => { el('manualBox').classList.toggle('d-none'); el('manual').focus(); };
el('btnKirim').onclick = () => { kirim(el('manual').value); el('manual').value = ''; };
el('manual').addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); el('btnKirim').click(); } });

let kamera = null;
el('btnKamera').onclick = async () => {
    const box = el('reader');
    if (kamera) { await kamera.stop(); kamera = null; box.classList.add('d-none'); return; }
    if (typeof Html5Qrcode === 'undefined') { tampil({ok: false, tipe: 'error', pesan: 'Pustaka kamera gagal dimuat (perlu internet).'}); return; }
    box.classList.remove('d-none');
    kamera = new Html5Qrcode('reader');
    try {
        await kamera.start({facingMode: 'environment'}, {fps: 10, qrbox: {width: 300, height: 140}}, txt => kirim(txt));
    } catch (e) {
        box.classList.add('d-none'); kamera = null;
        tampil({ok: false, tipe: 'error', pesan: 'Kamera tidak dapat dibuka. Gunakan HTTPS atau localhost dan izinkan kamera.'});
    }
};
</script>
</body>
</html>
