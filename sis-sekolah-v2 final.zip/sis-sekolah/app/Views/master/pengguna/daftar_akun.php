<?= $this->extend('layouts/cetak') ?>
<?= $this->section('isi') ?>
<?php
$labelRole = ['admin' => 'Admin', 'kepsek' => 'Kepala Sekolah', 'kurikulum' => 'Kurikulum', 'kesiswaan' => 'Kesiswaan', 'guru' => 'Guru', 'piket' => 'Guru Piket', 'bk' => 'Guru BK', 'tu' => 'Tata Usaha', 'satpam' => 'Satpam'];
?>
<style>
    .slip-wrap { display: grid; grid-template-columns: repeat(2, 1fr); gap: 0; }
    .slip { border: 1px dashed #777; padding: 9px 12px; page-break-inside: avoid; font-family: Arial, sans-serif; font-size: 9.5pt; }
    .slip .atas { display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid #ccc; padding-bottom: 4px; margin-bottom: 5px; }
    .slip .apl { font-weight: bold; font-size: 10pt; }
    .slip .nm { font-weight: bold; font-size: 10.5pt; }
    .slip table td { padding: 1px 6px 1px 0; vertical-align: top; }
    .slip .pw { font-family: "Courier New", monospace; font-size: 13pt; font-weight: bold; letter-spacing: 1px; }
    .slip .kecil { font-size: 7.8pt; color: #444; margin-top: 4px; }
    .hanya-excel { display: none; }
    @media print { .info-atas { display: none; } }
</style>
<!--noxls--><p class="kecil-teks info-atas">Password sementara di bawah <b>hanya tersedia 10 menit</b> dan tidak bisa ditampilkan lagi sesudahnya – cetak atau unduh Excel sekarang, lalu gunting per kartu.
    <?= count($akun) ?> akun<?= ! empty($lewat) ? ' · ' . $lewat . ' akun dilewati karena sudah memakai password buatan sendiri' : '' ?>.</p><!--/noxls-->
<!--noxls--><div class="slip-wrap">
<?php foreach ($akun as $a) : ?>
    <div class="slip">
        <div class="atas"><span class="apl"><?= esc(nama_aplikasi()) ?></span><span><?= esc(setting('nama_sekolah', '')) ?></span></div>
        <div class="nm"><?= esc($a['nama']) ?></div>
        <?php if (! empty($a['roles'])) : ?><div class="kecil" style="margin-top:0"><?= esc(implode(', ', array_map(static fn ($r) => $labelRole[$r] ?? $r, $a['roles']))) ?></div><?php endif ?>
        <table>
            <tr><td>Alamat</td><td>: <?= esc($alamat) ?></td></tr>
            <tr><td>Username</td><td>: <b><?= esc($a['username']) ?></b></td></tr>
            <tr><td>Password</td><td>: <span class="pw"><?= esc($a['password']) ?></span></td></tr>
        </table>
        <div class="kecil">Saat login pertama Anda diminta membuat password baru (min. 6 karakter). Jangan berikan password kepada orang lain.</div>
    </div>
<?php endforeach ?>
</div><!--/noxls-->
<table class="data hanya-excel">
    <thead><tr><th>No</th><th>Nama</th><th>Peran</th><th>Username</th><th>Password sementara</th></tr></thead>
    <tbody>
    <?php foreach ($akun as $i => $a) : ?>
        <tr><td><?= $i + 1 ?></td><td><?= esc($a['nama']) ?></td><td><?= esc(implode(', ', array_map(static fn ($r) => $labelRole[$r] ?? $r, $a['roles'] ?? []))) ?></td><td><?= esc($a['username']) ?></td><td><?= esc($a['password']) ?></td></tr>
    <?php endforeach ?>
    </tbody>
</table>
<?= $this->endSection() ?>
