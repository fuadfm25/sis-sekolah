<?= $this->extend('layouts/main') ?>
<?= $this->section('actions') ?>
<?php if ($guruTanpa) : ?><button class="btn btn-outline-primary" data-bs-toggle="modal" data-bs-target="#modalAkunGuru"><i class="bi bi-people"></i> Buat akun guru (<?= $guruTanpa ?>)</button><?php endif ?>
<button class="btn btn-light" data-bs-toggle="modal" data-bs-target="#modalCetakPw"><i class="bi bi-printer me-1"></i>Cetak password</button>
<a href="<?= site_url('sistem/pengguna/tambah') ?>" class="btn btn-primary"><i class="bi bi-plus-lg"></i> Tambah Pengguna</a>
<?= $this->endSection() ?>
<?= $this->section('content') ?>
<div class="card"><div class="card-body">
    <form class="d-flex flex-wrap gap-2 align-items-center filter mb-2" method="get">
        <input name="q" value="<?= esc($f['q']) ?>" class="form-control w-auto" placeholder="Cari nama / username">
        <select name="role" class="form-select w-auto"><option value="">Semua role</option>
            <?php foreach ($roles as $r) : ?><option value="<?= esc($r['nama_role']) ?>" <?= $role === $r['nama_role'] ? 'selected' : '' ?>><?= esc($r['keterangan'] ?: $r['nama_role']) ?></option><?php endforeach ?></select>
        <select name="status" class="form-select w-auto">
            <?php foreach (['' => 'Semua status', 'aktif' => 'Aktif', 'nonaktif' => 'Nonaktif', 'wajib' => 'Belum ganti password'] as $k => $v) : ?><option value="<?= $k ?>" <?= $f['status'] === $k ? 'selected' : '' ?>><?= $v ?></option><?php endforeach ?></select>
        <button class="btn btn-light"><i class="bi bi-search"></i> Tampilkan</button>
        <span class="ms-auto small text-muted"><?= count($rows) ?> akun</span>
    </form>
    <form method="post" action="<?= site_url('sistem/pengguna/reset-massal') ?>" id="fMassal" onsubmit="return confirm('Reset password semua akun yang dicentang? Password sementara akan ditampilkan sekali untuk dicetak.')"><?= csrf_field() ?></form>
    <div class="table-responsive">
    <table class="table table-hover table-sm align-middle tabel-hp">
        <thead><tr><th><input type="checkbox" class="form-check-input" id="cekSemua"></th><th>Nama</th><th>Username</th><th>Role</th><th>Status</th><th>Login terakhir</th><th class="text-end">Aksi</th></tr></thead>
        <tbody>
        <?php foreach ($rows as $u) : $diriSendiri = (int) $u['id'] === (int) session('user_id'); ?>
            <tr class="<?= $u['is_active'] ? '' : 'text-muted' ?>">
                <td><?php if (! $diriSendiri) : ?><input type="checkbox" class="form-check-input cek" name="ids[]" value="<?= $u['id'] ?>" form="fMassal"><?php endif ?></td>
                <td data-label="Nama"><?= esc($u['nama_lengkap']) ?><?= $u['guru_id'] ? ' <i class="bi bi-person-badge text-success" title="Tertaut ke data guru"></i>' : '' ?></td>
                <td data-label="Username"><code><?= esc($u['username']) ?></code></td>
                <td data-label="Role"><?php foreach ($u['roles'] as $r) : ?><span class="badge bg-light-primary text-primary me-1"><?= esc($r) ?></span><?php endforeach ?></td>
                <td data-label="Status"><?= $u['is_active'] ? '<span class="badge bg-success">Aktif</span>' : '<span class="badge bg-secondary">Nonaktif</span>' ?>
                    <?= ! empty($u['wajib_ganti_password']) ? '<span class="badge bg-warning text-dark">belum ganti password</span>' : '' ?></td>
                <td class="small" data-label="Login terakhir"><?= $u['last_login'] ? esc(tgl_indo(substr($u['last_login'], 0, 10)) . ' ' . substr($u['last_login'], 11, 5)) : '-' ?></td>
                <td class="text-end text-nowrap">
                    <a href="<?= site_url('sistem/pengguna/edit/' . $u['id']) ?>" class="btn btn-sm btn-outline-warning" title="Edit"><i class="bi bi-pencil"></i></a>
                    <?php if (! $diriSendiri) : ?>
                        <form method="post" action="<?= site_url('sistem/pengguna/reset-password/' . $u['id']) ?>" class="d-inline" onsubmit="return confirm('Reset password <?= esc($u['username'], 'js') ?>? Password sementara akan ditampilkan.')"><?= csrf_field() ?>
                            <button class="btn btn-sm btn-outline-primary" title="Reset password"><i class="bi bi-key"></i></button></form>
                        <form method="post" action="<?= site_url('sistem/pengguna/buka-kunci/' . $u['id']) ?>" class="d-inline"><?= csrf_field() ?>
                            <button class="btn btn-sm btn-outline-secondary" title="Buka kunci login (setelah salah password berkali-kali)"><i class="bi bi-unlock"></i></button></form>
                        <form method="post" action="<?= site_url('sistem/pengguna/aktif/' . $u['id']) ?>" class="d-inline"><?= csrf_field() ?>
                            <button class="btn btn-sm <?= $u['is_active'] ? 'btn-outline-dark' : 'btn-outline-success' ?>" title="<?= $u['is_active'] ? 'Nonaktifkan' : 'Aktifkan' ?>"><i class="bi bi-<?= $u['is_active'] ? 'person-slash' : 'person-check' ?>"></i></button></form>
                        <?= delete_button('sistem/pengguna/delete/' . $u['id'], '', 'Hapus akun ini? Akun yang sudah mengisi data tidak bisa dihapus; nonaktifkan saja.') ?>
                    <?php else : ?><span class="badge bg-light text-dark border">akun Anda</span><?php endif ?>
                </td>
            </tr>
        <?php endforeach ?>
        <?php if (! $rows) : ?><tr><td colspan="7" class="text-center text-muted">Tidak ada pengguna.</td></tr><?php endif ?>
        </tbody>
    </table>
    </div>
    <button class="btn btn-sm btn-outline-primary" form="fMassal"><i class="bi bi-key"></i> Reset password yang dicentang</button>
    <small class="text-muted ms-2">Password sementara ditampilkan sekali dalam daftar siap cetak; pengguna wajib menggantinya saat login.</small>
</div></div>

<div class="modal fade" id="modalCetakPw" tabindex="-1">
    <div class="modal-dialog"><form method="post" action="<?= site_url('sistem/pengguna/cetak-password') ?>" class="modal-content" onsubmit="return confirm('Password akun yang dipilih akan diganti dengan password sementara baru lalu dicetak. Lanjutkan?')"><?= csrf_field() ?>
        <div class="modal-header"><h5 class="modal-title">Cetak Password Pengguna</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
        <div class="modal-body">
            <div class="alert alert-info small py-2"><i class="bi bi-shield-lock me-1"></i>Demi keamanan, password disimpan terenkripsi sehingga password lama <b>tidak bisa ditampilkan</b>. Yang dicetak adalah <b>password sementara baru</b>; pengguna wajib menggantinya saat login pertama.</div>
            <label class="form-label">Pengguna</label>
            <select name="role" class="form-select mb-3"><option value="">Semua pengguna aktif</option>
                <?php foreach ($roles as $r) : ?><option value="<?= esc($r['nama_role']) ?>"><?= esc($r['keterangan'] ?: $r['nama_role']) ?></option><?php endforeach ?></select>
            <label class="form-label">Cakupan</label>
            <div class="form-check"><input class="form-check-input" type="radio" name="cakupan" value="belum" id="ck1" checked><label class="form-check-label" for="ck1">Hanya akun yang <b>belum</b> mengganti password (masih bawaan/sementara) <span class="text-muted">– disarankan</span></label></div>
            <div class="form-check"><input class="form-check-input" type="radio" name="cakupan" value="semua" id="ck2"><label class="form-check-label" for="ck2">Semua akun (password buatan pengguna juga diganti)</label></div>
            <div class="small text-muted mt-2">Akun Anda sendiri tidak ikut. Hasilnya berupa kartu akun siap gunting, bisa juga diunduh Excel.</div>
        </div>
        <div class="modal-footer"><button class="btn btn-primary"><i class="bi bi-printer me-1"></i>Buat & cetak</button></div>
    </form></div>
</div>

<?php if ($guruTanpa) : ?>
<div class="modal fade" id="modalAkunGuru" tabindex="-1">
    <div class="modal-dialog"><form method="post" action="<?= site_url('sistem/pengguna/akun-guru') ?>" class="modal-content"><?= csrf_field() ?>
        <div class="modal-header"><h5 class="modal-title">Buat Akun Guru Sekaligus</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
        <div class="modal-body">
            <p><?= $guruTanpa ?> guru aktif belum memiliki akun. Setiap guru dibuatkan akun dengan role <b>guru</b>, tertaut ke datanya, dan password sementara acak.</p>
            <label class="form-label">Username dari</label>
            <select name="username_dari" class="form-select">
                <option value="nama">Nama (mis. budi.santoso)</option>
                <option value="nip">NIP (bila kosong memakai nama)</option>
                <option value="nuptk">NUPTK (bila kosong memakai nama)</option>
            </select>
            <small class="text-muted">Role tambahan (wali kelas otomatis dari menu Kelas; piket, kurikulum, dll.) diatur lewat Edit pengguna.</small>
        </div>
        <div class="modal-footer"><button class="btn btn-primary">Buat akun</button></div>
    </form></div>
</div>
<?php endif ?>
<?= $this->endSection() ?>
<?= $this->section('scripts') ?>
<script>document.getElementById('cekSemua')?.addEventListener('change', function () { document.querySelectorAll('.cek').forEach(c => c.checked = this.checked); });</script>
<?= $this->endSection() ?>
