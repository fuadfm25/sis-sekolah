<?= $this->extend('layouts/main') ?>
<?= $this->section('actions') ?><a href="<?= site_url('sistem/pengguna') ?>" class="btn btn-light"><i class="bi bi-arrow-left"></i> Kembali</a><?= $this->endSection() ?>
<?= $this->section('content') ?>
<?php $oldRoles = array_map('intval', (array) old('roles', $myRoles)); ?>
<div class="card"><div class="card-body">
<form method="post" action="<?= site_url($user ? 'sistem/pengguna/update/' . $user['id'] : 'sistem/pengguna/store') ?>" class="row g-3">
    <?= csrf_field() ?>
    <div class="col-md-6"><label class="form-label">Nama lengkap</label><input name="nama_lengkap" class="form-control" value="<?= esc(old('nama_lengkap', $user['nama_lengkap'] ?? '')) ?>" required></div>
    <div class="col-md-3"><label class="form-label">Username</label><input name="username" class="form-control" value="<?= esc(old('username', $user['username'] ?? '')) ?>" required></div>
    <div class="col-md-3"><label class="form-label">Password <?= $user ? '<small class="text-muted">(kosongkan bila tetap)</small>' : '' ?></label><input type="password" name="password" class="form-control" <?= $user ? '' : 'required' ?> minlength="6"></div>
    <div class="col-md-6"><label class="form-label">Email</label><input type="email" name="email" class="form-control" value="<?= esc(old('email', $user['email'] ?? '')) ?>"></div>
    <div class="col-md-6"><label class="form-label">Tautkan ke data guru</label>
        <select name="guru_id" class="form-select tom"><option value="">- bukan guru -</option>
            <?php foreach ($guruList as $g) : ?><option value="<?= $g['id'] ?>" <?= (int) old('guru_id', $guruId) === (int) $g['id'] ? 'selected' : '' ?>><?= esc(nama_guru($g)) ?></option><?php endforeach ?>
        </select>
        <small class="text-muted">Wajib bagi guru agar dapat mengisi jurnal. Status wali kelas diatur di menu Kelas.</small></div>
    <div class="col-12"><label class="form-label">Role</label><div class="d-flex flex-wrap gap-3">
        <?php foreach ($roles as $r) : ?>
            <div class="form-check"><input class="form-check-input" type="checkbox" name="roles[]" value="<?= $r['id'] ?>" id="r<?= $r['id'] ?>" <?= in_array((int) $r['id'], $oldRoles, true) ? 'checked' : '' ?>>
                <label class="form-check-label" for="r<?= $r['id'] ?>"><strong><?= esc($r['nama_role']) ?></strong> <small class="text-muted"><?= esc($r['keterangan']) ?></small></label></div>
        <?php endforeach ?>
    </div></div>
    <div class="col-12"><div class="form-check"><input class="form-check-input" type="checkbox" name="wajib_ganti" value="1" id="uWajib" <?= old('wajib_ganti', 1) ? 'checked' : '' ?>><label class="form-check-label" for="uWajib">Wajib ganti password saat login berikutnya (berlaku bila password diisi)</label></div></div>
    <div class="col-12"><div class="form-check"><input class="form-check-input" type="checkbox" name="is_active" value="1" id="uAktif" <?= old('is_active', $user['is_active'] ?? 1) ? 'checked' : '' ?>><label class="form-check-label" for="uAktif">Akun aktif</label></div></div>
    <div class="col-12"><button class="btn btn-primary"><i class="bi bi-save"></i> Simpan</button></div>
</form>
</div></div>
<?= $this->endSection() ?>
