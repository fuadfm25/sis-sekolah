<?= $this->extend('layouts/main') ?>
<?= $this->section('actions') ?>
<?= tombol_impor('kelas') ?>
<button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#modalForm" data-title="Tambah Kelas" data-action="<?= site_url('master/kelas/store') ?>" data-row='{"is_active":"1"}'><i class="bi bi-plus-lg"></i> Tambah Kelas</button>
<?= $this->endSection() ?>
<?= $this->section('content') ?>
<div class="card"><div class="card-body table-responsive">
    <table class="table table-hover align-middle">
        <thead><tr><th>Tingkat</th><th>Nama Kelas</th><th>Jurusan</th><th>Wali Kelas</th><th class="text-center">Siswa</th><th class="text-end">Aksi</th></tr></thead>
        <tbody>
        <?php foreach ($rows as $r) : ?>
            <tr class="<?= $r['is_active'] ? '' : 'text-muted' ?>">
                <td><?= esc($r['tingkat']) ?></td>
                <td><strong><?= esc($r['nama_kelas']) ?></strong> <?= $r['is_active'] ? '' : '<span class="badge bg-secondary">nonaktif</span>' ?></td>
                <td><?= esc($r['nama_jurusan'] ?? '-') ?></td>
                <td><?= $r['wali_nama'] ? esc(nama_guru($r, 'wali_')) : '<span class="text-danger small">belum ditentukan</span>' ?></td>
                <td class="text-center"><?= $r['jumlah_siswa'] ?></td>
                <td class="text-end text-nowrap">
                    <a href="<?= site_url('master/kelas/' . $r['id']) ?>" class="btn btn-sm btn-outline-primary"><i class="bi bi-people"></i> Rombel</a>
                    <?php $r['wali_guru_id'] = $r['wali_guru_id'] ?? ''; ?>
                    <button class="btn btn-sm btn-outline-warning" data-bs-toggle="modal" data-bs-target="#modalForm" data-title="Edit Kelas" data-action="<?= site_url('master/kelas/update/' . $r['id']) ?>" data-row='<?= esc(json_encode($r), 'attr') ?>'><i class="bi bi-pencil"></i></button>
                    <?= delete_button('master/kelas/delete/' . $r['id'], '', 'Menghapus kelas akan menghapus rombel, jadwal, jurnal, dan absensi kelas ini. Lanjutkan?') ?>
                </td>
            </tr>
        <?php endforeach ?>
        <?php if (! $rows) : ?><tr><td colspan="6" class="text-center text-muted">Belum ada kelas.</td></tr><?php endif ?>
        </tbody>
    </table>
</div></div>

<div class="modal fade" id="modalForm" data-crud tabindex="-1">
    <div class="modal-dialog"><form method="post" class="modal-content"><?= csrf_field() ?>
        <div class="modal-header"><h5 class="modal-title"></h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
        <div class="modal-body">
            <div class="row">
                <div class="col-4 mb-2"><label class="form-label">Tingkat</label><input name="tingkat" class="form-control" required placeholder="VII / 10"></div>
                <div class="col-8 mb-2"><label class="form-label">Nama Kelas</label><input name="nama_kelas" class="form-control" required placeholder="VII A"></div>
            </div>
            <div class="mb-2"><label class="form-label">Jurusan (opsional)</label>
                <select name="jurusan_id" class="form-select"><option value="">-</option>
                    <?php foreach ($jurusan as $j) : ?><option value="<?= $j['id'] ?>"><?= esc($j['nama_jurusan']) ?></option><?php endforeach ?>
                </select></div>
            <?php if (tp_aktif()) : ?>
            <div class="mb-2"><label class="form-label">Wali Kelas (TP aktif)</label>
                <select name="wali_guru_id" class="form-select"><option value="">- belum ditentukan -</option>
                    <?php foreach ($guru as $g) : ?><option value="<?= $g['id'] ?>"><?= esc(nama_guru($g)) ?></option><?php endforeach ?>
                </select></div>
            <?php endif ?>
            <div class="form-check"><input class="form-check-input" type="checkbox" name="is_active" value="1" id="kAktif"><label class="form-check-label" for="kAktif">Aktif</label></div>
        </div>
        <div class="modal-footer"><button class="btn btn-primary">Simpan</button></div>
    </form></div>
</div>
<?= $this->endSection() ?>
<?= $this->section('scripts') ?><?= $this->include('partials/modal_form_js') ?><?= $this->endSection() ?>
