<?= $this->extend('layouts/main') ?>
<?= $this->section('actions') ?>
<a href="<?= site_url('master/kelas') ?>" class="btn btn-light"><i class="bi bi-arrow-left"></i> Kembali</a>
<?= $this->endSection() ?>
<?= $this->section('content') ?>
<div class="row">
    <div class="col-lg-4">
        <div class="card">
            <div class="card-header"><h5 class="card-title mb-0">Wali Kelas</h5></div>
            <div class="card-body">
                <form method="post" action="<?= site_url('master/kelas/' . $kelas['id'] . '/wali') ?>">
                    <?= csrf_field() ?>
                    <select name="guru_id" class="form-select tom mb-2">
                        <option value="">- belum ditentukan -</option>
                        <?php foreach ($guru as $g) : ?>
                            <option value="<?= $g['id'] ?>" <?= ($wali['id'] ?? null) == $g['id'] ? 'selected' : '' ?>><?= esc(nama_guru($g)) ?></option>
                        <?php endforeach ?>
                    </select>
                    <button class="btn btn-primary btn-sm">Simpan Wali Kelas</button>
                </form>
            </div>
        </div>
        <div class="card">
            <div class="card-header"><h5 class="card-title mb-0">Tambah Anggota</h5></div>
            <div class="card-body">
                <?php if (! $calon) : ?>
                    <p class="text-muted small mb-0">Semua siswa aktif sudah memiliki kelas di TP ini. Tambah siswa baru di menu <a href="<?= site_url('master/siswa') ?>">Siswa</a>.</p>
                <?php else : ?>
                    <form method="post" action="<?= site_url('master/kelas/' . $kelas['id'] . '/anggota') ?>">
                        <?= csrf_field() ?>
                        <select name="siswa_ids[]" class="form-select tom mb-2" multiple placeholder="Cari siswa belum berkelas...">
                            <?php foreach ($calon as $s) : ?><option value="<?= $s['id'] ?>"><?= esc($s['nis'] . ' - ' . $s['nama_lengkap']) ?></option><?php endforeach ?>
                        </select>
                        <button class="btn btn-success btn-sm"><i class="bi bi-person-plus"></i> Masukkan ke Kelas</button>
                    </form>
                    <small class="text-muted d-block mt-2"><?= count($calon) ?> siswa aktif belum memiliki kelas.</small>
                <?php endif ?>
            </div>
        </div>
    </div>
    <div class="col-lg-8">
        <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h5 class="card-title mb-0">Anggota Kelas (<?= count($anggota) ?>)</h5>
                <form method="post" action="<?= site_url('master/kelas/' . $kelas['id'] . '/urutkan') ?>"><?= csrf_field() ?><button class="btn btn-sm btn-outline-secondary"><i class="bi bi-sort-alpha-down"></i> Urutkan No. Absen</button></form>
            </div>
            <div class="card-body table-responsive">
                <table class="table table-sm table-hover align-middle">
                    <thead><tr><th>No</th><th>NIS</th><th>Nama</th><th>L/P</th><th>Status</th><th></th></tr></thead>
                    <tbody>
                    <?php foreach ($anggota as $s) : ?>
                        <tr>
                            <td><?= esc($s['no_absen']) ?></td>
                            <td><?= esc($s['nis']) ?></td>
                            <td><a href="<?= site_url('siswa/profil/' . $s['id']) ?>"><?= esc($s['nama_lengkap']) ?></a></td>
                            <td><?= esc($s['jenis_kelamin']) ?></td>
                            <td><?= badge_status($s['status']) ?></td>
                            <td class="text-end"><?= delete_button('master/kelas/anggota/hapus/' . $s['anggota_id'], '', 'Keluarkan siswa dari kelas ini?') ?></td>
                        </tr>
                    <?php endforeach ?>
                    <?php if (! $anggota) : ?><tr><td colspan="6" class="text-center text-muted">Belum ada anggota.</td></tr><?php endif ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?= $this->endSection() ?>
