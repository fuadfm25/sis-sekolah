<?= $this->extend('layouts/main') ?>
<?= $this->section('actions') ?>
<button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#modalForm" data-title="Tambah Jurusan" data-action="<?= site_url('master/jurusan/store') ?>"><i class="bi bi-plus-lg"></i> Tambah</button>
<?= $this->endSection() ?>
<?= $this->section('content') ?>
<div class="card"><div class="card-body table-responsive">
    <table class="table table-hover align-middle">
        <thead><tr><th style="width:60px">No</th><th>Kode</th><th>Nama Jurusan</th><th class="text-end">Aksi</th></tr></thead>
        <tbody>
        <?php foreach ($rows as $i => $r) : ?>
            <tr>
                <td><?= $i + 1 ?></td><td><?= esc($r['kode_jurusan']) ?></td><td><?= esc($r['nama_jurusan']) ?></td>
                <td class="text-end text-nowrap">
                    <button class="btn btn-sm btn-outline-warning" data-bs-toggle="modal" data-bs-target="#modalForm" data-title="Edit Jurusan" data-action="<?= site_url('master/jurusan/update/' . $r['id']) ?>" data-row='<?= esc(json_encode($r), 'attr') ?>'><i class="bi bi-pencil"></i></button>
                    <?= delete_button('master/jurusan/delete/' . $r['id']) ?>
                </td>
            </tr>
        <?php endforeach ?>
        <?php if (! $rows) : ?><tr><td colspan="4" class="text-center text-muted">Belum ada data.</td></tr><?php endif ?>
        </tbody>
    </table>
</div></div>
<div class="modal fade" id="modalForm" data-crud tabindex="-1">
    <div class="modal-dialog"><form method="post" class="modal-content"><?= csrf_field() ?>
        <div class="modal-header"><h5 class="modal-title"></h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
        <div class="modal-body">
            <div class="mb-2"><label class="form-label">Kode</label><input name="kode_jurusan" class="form-control" required maxlength="20"></div>
            <div class="mb-2"><label class="form-label">Nama Jurusan</label><input name="nama_jurusan" class="form-control" required></div>
        </div>
        <div class="modal-footer"><button class="btn btn-primary">Simpan</button></div>
    </form></div>
</div>
<?= $this->endSection() ?>
<?= $this->section('scripts') ?><?= $this->include('partials/modal_form_js') ?><?= $this->endSection() ?>
