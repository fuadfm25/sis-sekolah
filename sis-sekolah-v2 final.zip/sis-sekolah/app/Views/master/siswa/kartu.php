<?= $this->extend('layouts/main') ?>
<?= $this->section('head') ?>
<style>
    .kartu-wrap { display: flex; flex-wrap: wrap; gap: 6mm; }
    .kartu { width: 85.6mm; height: 54mm; border: 1px solid #999; border-radius: 3mm; padding: 3mm 4mm; background: #fff; color: #000;
             display: flex; flex-direction: column; justify-content: space-between; page-break-inside: avoid; }
    .kartu .sekolah { font-size: 9pt; font-weight: 700; border-bottom: 1px solid #333; padding-bottom: 1mm; }
    .kartu .nama { font-size: 10.5pt; font-weight: 700; line-height: 1.15; }
    .kartu .ket { font-size: 8.5pt; }
    .kartu svg { width: 100%; height: 16mm; }
    @media print { .page-heading { display: none; } .kartu-wrap { gap: 4mm; } }
</style>
<?= $this->endSection() ?>
<?= $this->section('actions') ?>
<?php if ($rows) : ?><button onclick="window.print()" class="btn btn-primary"><i class="bi bi-printer"></i> Cetak</button><?php endif ?>
<?= $this->endSection() ?>
<?= $this->section('content') ?>
<div class="card no-print"><div class="card-body py-3">
    <form class="d-flex gap-2 align-items-center filter" method="get">
        <label>Kelas:</label>
        <select name="kelas_id" class="form-select w-auto" onchange="this.form.submit()"><option value="">- pilih -</option>
            <?php foreach ($kelas as $k) : ?><option value="<?= $k['id'] ?>" <?= $kelasId == $k['id'] ? 'selected' : '' ?>><?= esc($k['nama_kelas']) ?></option><?php endforeach ?>
        </select>
        <small class="text-muted ms-2">Ukuran kartu ATM (85,6 × 54 mm). Barcode berisi NIS (Code 128) – bisa dibaca scanner barcode atau kamera di halaman kiosk.</small>
    </form>
</div></div>
<div class="kartu-wrap">
    <?php foreach ($rows as $r) : ?>
        <div class="kartu">
            <div class="sekolah"><?= esc(setting('nama_sekolah', '')) ?> · KARTU ABSENSI</div>
            <div>
                <div class="nama"><?= esc($r['nama_lengkap']) ?></div>
                <div class="ket">Kelas <?= esc($r['nama_kelas'] ?? '-') ?> · NIS <?= esc($r['nis']) ?></div>
            </div>
            <svg class="barcode" data-kode="<?= esc($r['nis'], 'attr') ?>"></svg>
        </div>
    <?php endforeach ?>
</div>
<?php if ($kelasId && ! $rows) : ?><div class="alert alert-light">Tidak ada siswa aktif di kelas ini.</div><?php endif ?>
<?= $this->endSection() ?>
<?= $this->section('scripts') ?>
<script src="<?= aset('jsbarcode') ?>"></script>
<script>
document.querySelectorAll('svg.barcode').forEach(function (el) {
    try { JsBarcode(el, el.dataset.kode, { format: 'CODE128', displayValue: true, fontSize: 12, height: 40, margin: 0 }); } catch (e) {}
});
</script>
<?= $this->endSection() ?>
