<?= $this->extend('layouts/main') ?>
<?= $this->section('actions') ?>
<a href="<?= site_url('master/siswa/kartu') ?>" class="btn btn-outline-secondary"><i class="bi bi-upc"></i> Cetak Kartu</a>
<?= tombol_impor('siswa') ?>
<a href="<?= site_url('master/siswa/tambah') ?>" class="btn btn-primary"><i class="bi bi-plus-lg"></i> Tambah Siswa</a>
<?= $this->endSection() ?>
<?= $this->section('content') ?>
<div class="card">
    <div class="card-body">
        <form class="row g-2 filter mb-3" method="get">
            <div class="col-md-3"><select name="kelas_id" class="form-select" onchange="this.form.submit()">
                <option value="">Semua kelas</option>
                <option value="none" <?= $f['kelas_id'] === 'none' ? 'selected' : '' ?>>— Belum berkelas —</option>
                <?php foreach ($kelas as $k) : ?><option value="<?= $k['id'] ?>" <?= $f['kelas_id'] == $k['id'] ? 'selected' : '' ?>><?= esc($k['nama_kelas']) ?></option><?php endforeach ?>
            </select></div>
            <div class="col-md-2"><select name="status" class="form-select" onchange="this.form.submit()">
                <option value="">Semua status</option>
                <?php foreach (['Aktif', 'Lulus', 'Pindah', 'Keluar'] as $s) : ?><option <?= $f['status'] === $s ? 'selected' : '' ?>><?= $s ?></option><?php endforeach ?>
            </select></div>
            <div class="col-md-4"><input name="q" class="form-control" placeholder="Cari nama / NIS / NISN" value="<?= esc($f['q']) ?>"></div>
            <div class="col-md-1"><button class="btn btn-light w-100"><i class="bi bi-search"></i></button></div>
        </form>
        <div class="table-responsive">
        <table class="table table-hover table-sm align-middle">
            <thead><tr><th>No</th><th>NIS</th><th>NISN</th><th>Nama</th><th>L/P</th><th>Kelas</th><th>Status</th><th class="text-end">Aksi</th></tr></thead>
            <tbody>
            <?php foreach ($rows as $i => $r) : ?>
                <tr>
                    <td><?= $i + 1 ?></td>
                    <td><?= esc($r['nis']) ?></td>
                    <td><?= esc($r['nisn']) ?></td>
                    <td><a href="<?= site_url('siswa/profil/' . $r['id']) ?>"><?= esc($r['nama_lengkap']) ?></a>
                        <?php if ($r['rfid']) : ?><i class="bi bi-credit-card-2-front text-success" title="Kartu RFID terdaftar"></i><?php endif ?></td>
                    <td><?= esc($r['jenis_kelamin']) ?></td>
                    <td><?= esc($r['nama_kelas'] ?? '-') ?></td>
                    <td><?= badge_status($r['status']) ?></td>
                    <td class="text-end text-nowrap">
                        <a href="<?= site_url('master/siswa/edit/' . $r['id']) ?>" class="btn btn-sm btn-outline-warning"><i class="bi bi-pencil"></i></a>
                        <?= delete_button('master/siswa/delete/' . $r['id'], '', 'Hapus siswa beserta seluruh riwayat absensi & catatannya? Untuk siswa pindah/lulus, cukup ubah statusnya.') ?>
                    </td>
                </tr>
            <?php endforeach ?>
            <?php if (! $rows) : ?><tr><td colspan="8" class="text-center text-muted">Tidak ada data.</td></tr><?php endif ?>
            </tbody>
        </table>
        </div>
        <small class="text-muted"><?= count($rows) ?> siswa ditampilkan.</small>
    </div>
</div>

<?= $this->endSection() ?>
