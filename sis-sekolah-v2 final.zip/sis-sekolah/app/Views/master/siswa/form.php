<?= $this->extend('layouts/main') ?>
<?= $this->section('actions') ?><a href="<?= site_url('master/siswa') ?>" class="btn btn-light"><i class="bi bi-arrow-left"></i> Kembali</a><?= $this->endSection() ?>
<?= $this->section('scripts') ?>
<script>
// reader RFID mengetik UID lalu Enter: cegah form terkirim tanpa sengaja
document.getElementById('rfid').addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); e.target.select(); } });
</script>
<?= $this->endSection() ?>
<?= $this->section('content') ?>
<?php $v = static fn ($k) => esc(old($k, $siswa[$k] ?? '')); ?>
<div class="card"><div class="card-body">
<form method="post" action="<?= site_url($siswa ? 'master/siswa/update/' . $siswa['id'] : 'master/siswa/store') ?>" class="row g-3">
    <?= csrf_field() ?>
    <div class="col-md-3"><label class="form-label">NIS *</label><input name="nis" class="form-control" value="<?= $v('nis') ?>" required></div>
    <div class="col-md-3"><label class="form-label">NISN</label><input name="nisn" class="form-control" value="<?= $v('nisn') ?>"></div>
    <div class="col-md-6"><label class="form-label">Nama lengkap *</label><input name="nama_lengkap" class="form-control" value="<?= $v('nama_lengkap') ?>" required></div>
    <div class="col-md-6"><label class="form-label"><i class="bi bi-credit-card-2-front"></i> Kode kartu RFID</label>
        <div class="input-group">
            <input name="rfid" id="rfid" class="form-control font-monospace" value="<?= $v('rfid') ?>" placeholder="Klik di sini lalu tempelkan kartu ke reader" autocomplete="off">
            <button type="button" class="btn btn-outline-secondary" onclick="document.getElementById('rfid').value='';document.getElementById('rfid').focus()">Kosongkan</button>
        </div>
        <small class="text-muted">Opsional. Untuk scanner barcode tidak perlu diisi — kartu barcode memakai NIS.</small></div>
    <div class="col-md-3"><label class="form-label">Jenis kelamin *</label>
        <select name="jenis_kelamin" class="form-select"><?php foreach (['L' => 'Laki-laki', 'P' => 'Perempuan'] as $k => $l) : ?><option value="<?= $k ?>" <?= old('jenis_kelamin', $siswa['jenis_kelamin'] ?? '') === $k ? 'selected' : '' ?>><?= $l ?></option><?php endforeach ?></select></div>
    <div class="col-md-3"><label class="form-label">Tempat lahir</label><input name="tempat_lahir" class="form-control" value="<?= $v('tempat_lahir') ?>"></div>
    <div class="col-md-3"><label class="form-label">Tanggal lahir</label><input type="date" name="tanggal_lahir" class="form-control" value="<?= $v('tanggal_lahir') ?>"></div>
    <div class="col-md-3"><label class="form-label">Agama</label><input name="agama" class="form-control" list="dlAgama" value="<?= $v('agama') ?>">
        <datalist id="dlAgama"><option>Islam</option><option>Kristen</option><option>Katolik</option><option>Hindu</option><option>Buddha</option><option>Konghucu</option></datalist></div>
    <div class="col-md-12"><label class="form-label">Alamat</label><textarea name="alamat" class="form-control" rows="2"><?= $v('alamat') ?></textarea></div>
    <div class="col-md-4"><label class="form-label">Nama orang tua/wali</label><input name="nama_wali" class="form-control" value="<?= $v('nama_wali') ?>"></div>
    <div class="col-md-4"><label class="form-label">No. HP orang tua/wali</label><input name="no_hp_wali" class="form-control" value="<?= $v('no_hp_wali') ?>"></div>
    <div class="col-md-2"><label class="form-label">Status</label>
        <select name="status" class="form-select"><?php foreach (['Aktif', 'Lulus', 'Pindah', 'Keluar'] as $s) : ?><option <?= old('status', $siswa['status'] ?? 'Aktif') === $s ? 'selected' : '' ?>><?= $s ?></option><?php endforeach ?></select></div>
    <div class="col-md-2"><label class="form-label">Kelas (TP aktif)</label>
        <select name="kelas_id" class="form-select" <?= tp_aktif() ? '' : 'disabled' ?>><option value="0">-</option>
            <?php foreach ($kelas as $k) : ?><option value="<?= $k['id'] ?>" <?= (int) old('kelas_id', $kelasNow) === (int) $k['id'] ? 'selected' : '' ?>><?= esc($k['nama_kelas']) ?></option><?php endforeach ?>
        </select></div>
    <div class="col-12"><button class="btn btn-primary"><i class="bi bi-save"></i> Simpan</button></div>
</form>
</div></div>
<?= $this->endSection() ?>
<?= $this->section('scripts') ?>
<script>
// reader RFID mengetik UID lalu Enter: cegah form terkirim tanpa sengaja
document.getElementById('rfid').addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); e.target.select(); } });
</script>
<?= $this->endSection() ?>
