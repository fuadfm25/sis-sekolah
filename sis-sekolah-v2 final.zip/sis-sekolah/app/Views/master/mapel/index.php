<?= $this->extend('layouts/main') ?>
<?= $this->section('actions') ?>
<?= tombol_impor('mapel') ?>
<button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#modalForm" data-title="Tambah Mata Pelajaran" data-action="<?= site_url('master/mapel/store') ?>" data-row='{"is_active":"1"}'><i class="bi bi-plus-lg"></i> Tambah</button>
<?= $this->endSection() ?>
<?= $this->section('content') ?>
<div class="card"><div class="card-body table-responsive">
    <table class="table table-hover align-middle">
        <thead><tr><th style="width:60px">No</th><th>Kode</th><th>Nama Mata Pelajaran</th><th>Kelompok</th><th>Status</th><th class="text-end">Aksi</th></tr></thead>
        <tbody>
        <?php foreach ($rows as $i => $r) : ?>
            <tr class="<?= $r['is_active'] ? '' : 'text-muted' ?>">
                <td><?= $i + 1 ?></td><td><?= esc($r['kode_mapel']) ?></td><td><?= esc($r['nama_mapel']) ?></td><td><?= esc($r['kelompok']) ?></td>
                <td><?= $r['is_active'] ? '<span class="badge bg-success">Aktif</span>' : '<span class="badge bg-secondary">Nonaktif</span>' ?></td>
                <td class="text-end text-nowrap">
                    <button class="btn btn-sm btn-outline-warning" data-bs-toggle="modal" data-bs-target="#modalForm" data-title="Edit Mata Pelajaran" data-action="<?= site_url('master/mapel/update/' . $r['id']) ?>" data-row='<?= esc(json_encode($r), 'attr') ?>'><i class="bi bi-pencil"></i></button>
                    <?= delete_button('master/mapel/delete/' . $r['id']) ?>
                </td>
            </tr>
        <?php endforeach ?>
        <?php if (! $rows) : ?><tr><td colspan="6" class="text-center text-muted">Belum ada data.</td></tr><?php endif ?>
        </tbody>
    </table>
</div></div>
<div class="modal fade" id="modalForm" data-crud tabindex="-1">
    <div class="modal-dialog"><form method="post" class="modal-content"><?= csrf_field() ?>
        <div class="modal-header"><h5 class="modal-title"></h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
        <div class="modal-body">
            <div class="mb-2"><label class="form-label">Kode</label><input name="kode_mapel" class="form-control" required maxlength="20"></div>
            <div class="mb-2"><label class="form-label">Nama Mata Pelajaran</label><input name="nama_mapel" class="form-control" required></div>
            <div class="mb-2"><label class="form-label">Kelompok</label><input name="kelompok" class="form-control" list="dlKelompok" placeholder="Umum / Muatan Lokal / Kejuruan">
                <datalist id="dlKelompok"><option>Umum</option><option>Muatan Lokal</option><option>Kejuruan</option><option>Pilihan</option></datalist></div>
            <div class="form-check"><input class="form-check-input" type="checkbox" name="is_active" value="1" id="mAktif"><label class="form-check-label" for="mAktif">Aktif</label></div>
        </div>
        <div class="modal-footer"><button class="btn btn-primary">Simpan</button></div>
    </form></div>
</div>
<?= $this->endSection() ?>
<?= $this->section('scripts') ?><?= $this->include('partials/modal_form_js') ?><?= $this->endSection() ?>
