<?= $this->extend('layouts/main') ?>
<?= $this->section('content') ?>
<div class="row g-3">
    <div class="col-xl-8">
        <div class="row g-3">
        <?php foreach ($daftar as $k => [$judul, $ikon, $ket, $kolom]) : $wajib = array_filter($kolom, static fn ($c) => $c[1]); ?>
            <div class="col-md-6" id="<?= $k ?>">
                <div class="card h-100 <?= $pilih === $k ? 'border-primary' : '' ?>" style="<?= $pilih === $k ? 'box-shadow:0 0 0 3px rgba(31,60,136,.15)' : '' ?>">
                    <div class="card-body d-flex flex-column">
                        <div class="d-flex gap-3 align-items-start mb-2">
                            <div class="stat-ikon biru"><i class="bi bi-<?= $ikon ?>"></i></div>
                            <div><h6 class="mb-1"><?= esc($judul) ?></h6><div class="small text-muted"><?= esc($ket) ?></div></div>
                        </div>
                        <div class="small text-muted mb-3">Kolom wajib: <?= esc(implode(', ', array_column($wajib, 0))) ?> · total <?= count($kolom) ?> kolom</div>
                        <form method="post" action="<?= site_url('excel/unggah') ?>" enctype="multipart/form-data" class="mt-auto"><?= csrf_field() ?>
                            <input type="hidden" name="jenis" value="<?= $k ?>">
                            <div class="input-group input-group-sm mb-2">
                                <input type="file" name="file" class="form-control" accept=".xlsx,.xls,.csv" required>
                                <button class="btn btn-primary"><i class="bi bi-upload me-1"></i>Unggah</button>
                            </div>
                            <a href="<?= site_url('excel/template/' . $k) ?>" class="btn btn-sm btn-light w-100"><i class="bi bi-file-earmark-arrow-down me-1"></i>Unduh template Excel</a>
                        </form>
                    </div>
                </div>
            </div>
        <?php endforeach ?>
        </div>
    </div>
    <div class="col-xl-4">
        <div class="card"><div class="card-header"><h6>Cara impor</h6></div><div class="card-body small">
            <ol class="ps-3 mb-3">
                <li class="mb-1"><b>Unduh template</b> jenis data yang diinginkan. Lembar <i>Petunjuk</i> menjelaskan setiap kolom beserta contohnya.</li>
                <li class="mb-1">Isi data mulai baris 2 pada lembar <i>Data</i>. Judul kolom jangan diubah.</li>
                <li class="mb-1"><b>Unggah</b> file, periksa pratinjau pemetaan kolom, lalu klik <b>Proses</b>.</li>
            </ol>
            <h6 class="small fw-bold">Aturan</h6>
            <ul class="ps-3 mb-0">
                <li>Data yang sudah ada <b>diperbarui</b>, bukan digandakan (siswa: NISN/NIS; guru: NIP/NUPTK/nama; mapel: kode; kelas: nama; penugasan: kelas+mapel).</li>
                <li>Siswa & guru juga bisa langsung dari <b>unduhan Dapodik/EMIS</b> – baris judul dilewati dan kolom dikenali otomatis.</li>
                <li>Agenda kalender yang diimpor langsung dipakai untuk <b>pekan efektif</b>, jurnal, dan absensi.</li>
                <li>Impor penugasan memerlukan kelas, mapel, dan guru yang sudah ada – impor ketiganya lebih dulu.</li>
                <li>Bila ada satu baris yang menyebabkan galat, seluruh impor dibatalkan sehingga data tidak setengah masuk.</li>
            </ul>
        </div></div>
    </div>
</div>
<?= $this->endSection() ?>
