<?= $this->extend('layouts/main') ?>
<?= $this->section('content') ?>
<form method="post" action="<?= site_url('excel/proses') ?>" onsubmit="return confirm('Proses impor sekarang?')"><?= csrf_field() ?>
<div class="card"><div class="card-body">
    <p class="mb-2">Periksa pemetaan kolom. Kolom bertanda <span class="badge bg-success">✓</span> dikenali otomatis; ubah bila keliru, pilih "— abaikan —" untuk kolom yang tidak dipakai.</p>
    <?php if (! empty($info['kelas_baru'])) : ?>
        <div class="alert alert-warning py-2 small">Kelas belum ada di aplikasi: <b><?= esc(implode(', ', array_slice($info['kelas_baru'], 0, 20))) ?></b><?= count($info['kelas_baru']) > 20 ? ' …' : '' ?></div>
    <?php endif ?>
    <div class="d-flex flex-wrap gap-3 mb-2">
        <?php if ($jenis === 'siswa') : ?>
            <div class="form-check"><input class="form-check-input" type="checkbox" name="buat_kelas" value="1" id="bk" checked><label class="form-check-label" for="bk">Buat kelas yang belum ada</label></div>
            <div class="form-check"><input class="form-check-input" type="checkbox" name="perbarui" value="1" id="pb" checked><label class="form-check-label" for="pb">Perbarui data siswa yang sudah ada</label></div>
        <?php endif ?>
    </div>
    <div class="table-responsive" style="max-height:60vh">
        <table class="table table-sm table-bordered small">
            <thead class="table-light" style="position:sticky;top:0">
                <tr><?php foreach ($hasil['label'] as $i => $l) : ?><th style="min-width:120px"><?= esc($l ?: '(kolom ' . ($i + 1) . ')') ?></th><?php endforeach ?></tr>
                <tr><?php foreach ($hasil['label'] as $i => $l) : $m = $map[$i] ?? ''; ?>
                    <th><select name="map[<?= $i ?>]" class="form-select form-select-sm <?= $m ? 'border-success' : '' ?>">
                        <option value="">— abaikan —</option>
                        <?php foreach ($field as $f => [$lbl]) : ?><option value="<?= $f ?>" <?= $m === $f ? 'selected' : '' ?>><?= esc($lbl) ?><?= in_array($f, $wajib ?? [], true) ? ' *' : '' ?></option><?php endforeach ?>
                    </select><?= $m ? '<span class="badge bg-success mt-1">✓</span>' : '' ?></th>
                <?php endforeach ?></tr>
            </thead>
            <tbody>
            <?php foreach (array_slice($hasil['data'], 0, 15) as $r) : ?>
                <tr><?php foreach ($hasil['label'] as $i => $l) : ?><td class="text-nowrap"><?= esc(\App\Libraries\ImporExcel::teks($r[$i] ?? null) ?? '') ?></td><?php endforeach ?></tr>
            <?php endforeach ?>
            </tbody>
        </table>
    </div>
    <p class="small text-muted mb-0">Menampilkan 15 dari <?= count($hasil['data']) ?> baris.</p>
</div></div>
<a href="<?= site_url('excel?jenis=' . $jenis) ?>" class="btn btn-light">Batal</a>
<button class="btn btn-primary"><i class="bi bi-check2-circle"></i> Proses impor <?= count($hasil['data']) ?> baris</button>
</form>
<?= $this->endSection() ?>
