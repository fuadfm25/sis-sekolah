<?= $this->extend('layouts/main') ?>
<?= $this->section('actions') ?><a href="<?= site_url('master/kenaikan-kelas') ?>" class="btn btn-light"><i class="bi bi-person-lines-fill me-1"></i>Kenaikan manual per siswa</a><?= $this->endSection() ?>
<?= $this->section('content') ?>
<div class="card"><div class="card-body py-3">
    <form class="d-flex flex-wrap gap-2 align-items-center filter" method="get">
        <label class="fw-semibold">Dari tahun pelajaran:</label>
        <select name="tp_asal" class="form-select w-auto" onchange="this.form.submit()">
            <?php foreach ($tpList as $t) : ?><option value="<?= $t['id'] ?>" <?= $asalId == $t['id'] ? 'selected' : '' ?>><?= esc($t['tahun_pelajaran'] . ' ' . $t['semester']) ?></option><?php endforeach ?>
            <?php if (! $tpList) : ?><option>Belum ada TP lain</option><?php endif ?>
        </select>
        <span class="text-muted">→ ke <b><?= esc(tp_aktif()['tahun_pelajaran'] . ' ' . tp_aktif()['semester']) ?></b> (aktif)</span>
    </form>
</div></div>

<?php if (! $tpList) : ?>
    <div class="alert alert-info">Buat dan aktifkan tahun pelajaran baru terlebih dahulu (menu Tahun Pelajaran), lalu kembali ke halaman ini.</div>
<?php elseif (! $rencana) : ?>
    <div class="alert alert-light border">Tidak ada siswa aktif di rombel tahun pelajaran asal.</div>
<?php else : ?>
<div class="alert alert-<?= $semester ? 'info' : 'light' ?> border small">
    <?php if ($semester) : ?><i class="bi bi-info-circle"></i> TP asal dan TP aktif berada di tahun yang sama, jadi ini <b>pergantian semester</b>: siswa tetap di kelasnya.
    <?php else : ?><i class="bi bi-lightbulb"></i> Kelas tujuan ditebak dari nama kelas (VII A → VIII A). Tingkat <b><?= $akhir ?></b> diluluskan (jenjang di Pengaturan Sekolah). Periksa lalu ubah pilihan bila perlu.<?php endif ?>
    <br>Siswa <b>tinggal kelas</b>: proses dulu lewat <a href="<?= site_url('master/kenaikan-kelas') ?>">kenaikan manual</a>; siswa yang sudah punya kelas di TP aktif otomatis dilewati.
    <?php if ($sudah) : ?><br><b><?= $sudah ?></b> siswa sudah punya kelas di TP aktif.<?php endif ?>
</div>
<form method="post" action="<?= site_url('master/kenaikan-kelas/otomatis') ?>" onsubmit="return confirm('Proses kenaikan kelas untuk semua kelas sekaligus?')"><?= csrf_field() ?>
    <input type="hidden" name="tp_asal" value="<?= $asalId ?>">
    <div class="card"><div class="card-body table-responsive">
        <table class="table align-middle tabel-hp">
            <thead><tr><th>Kelas asal</th><th class="text-center">Siswa aktif</th><th></th><th style="min-width:260px">Tujuan</th></tr></thead>
            <tbody>
            <?php foreach ($rencana as $p) : $id = $p['asal']['id']; ?>
                <tr>
                    <td data-label="Kelas asal"><b><?= esc($p['asal']['nama_kelas']) ?></b> <span class="small text-muted">tingkat <?= esc($p['asal']['tingkat']) ?></span></td>
                    <td data-label="Siswa" class="text-center"><?= $p['siswa'] ?></td>
                    <td class="text-center d-none d-md-table-cell"><i class="bi bi-arrow-right text-muted"></i></td>
                    <td data-label="Tujuan">
                        <select name="tujuan[<?= $id ?>]" class="form-select form-select-sm">
                            <option value="lulus" <?= $p['aksi'] === 'lulus' ? 'selected' : '' ?>>🎓 Lulus</option>
                            <?php if ($p['baru']) : ?><option value="baru" selected>➕ Buat kelas baru "<?= esc($p['baru']['nama_kelas']) ?>"</option><?php endif ?>
                            <?php foreach ($kelas as $k) : ?><option value="<?= $k['id'] ?>" <?= $p['aksi'] === 'kelas' && (int) $p['tujuan'] === (int) $k['id'] ? 'selected' : '' ?>><?= esc($k['nama_kelas']) ?></option><?php endforeach ?>
                            <option value="lewati" <?= $p['aksi'] === 'lewati' ? 'selected' : '' ?>>– lewati –</option>
                        </select>
                    </td>
                </tr>
            <?php endforeach ?>
            </tbody>
        </table>
        <button class="btn btn-primary btn-lg mt-2"><i class="bi bi-lightning-charge me-1"></i>Proses semua kelas (<?= array_sum(array_column($rencana, 'siswa')) ?> siswa)</button>
        <div class="small text-muted mt-2">Siswa yang lulus dicatat di Mutasi Siswa. No. absen dipertahankan lalu diurutkan ulang per kelas.</div>
    </div></div>
</form>
<?php endif ?>
<?= $this->endSection() ?>
