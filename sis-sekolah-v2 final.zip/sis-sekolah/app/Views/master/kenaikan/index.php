<?= $this->extend('layouts/main') ?>
<?= $this->section('actions') ?><a href="<?= site_url('master/kenaikan-kelas/otomatis') ?>" class="btn btn-primary"><i class="bi bi-lightning-charge me-1"></i>Kenaikan otomatis 1 klik</a><?= $this->endSection() ?>
<?= $this->section('content') ?>
<div class="card"><div class="card-body">
    <form class="row g-2 align-items-end filter" method="get">
        <div class="col-md-4"><label class="form-label">Tahun pelajaran asal</label>
            <select name="tp_asal" class="form-select" required><option value="">- pilih -</option>
                <?php foreach ($tpList as $t) : ?><option value="<?= $t['id'] ?>" <?= $asalId == $t['id'] ? 'selected' : '' ?>><?= esc($t['tahun_pelajaran'] . ' ' . $t['semester']) ?></option><?php endforeach ?>
            </select></div>
        <div class="col-md-4"><label class="form-label">Kelas asal</label>
            <select name="kelas_asal" class="form-select" required><option value="">- pilih -</option>
                <?php foreach ($kelas as $k) : ?><option value="<?= $k['id'] ?>" <?= $kelasId == $k['id'] ? 'selected' : '' ?>><?= esc($k['nama_kelas']) ?></option><?php endforeach ?>
            </select></div>
        <div class="col-md-2"><button class="btn btn-primary w-100">Tampilkan</button></div>
    </form>
</div></div>

<?php if ($asalId && $kelasId) : ?>
<form method="post" action="<?= site_url('master/kenaikan-kelas/proses') ?>">
    <?= csrf_field() ?>
    <input type="hidden" name="tp_asal" value="<?= $asalId ?>"><input type="hidden" name="kelas_asal" value="<?= $kelasId ?>">
    <div class="card">
        <div class="card-header d-flex flex-wrap gap-2 align-items-center">
            <label class="me-2">Kelas tujuan (TP aktif):</label>
            <select name="kelas_tujuan" class="form-select w-auto">
                <option value="">- pilih -</option>
                <?php foreach ($kelas as $k) : ?><option value="<?= $k['id'] ?>"><?= esc($k['nama_kelas']) ?></option><?php endforeach ?>
            </select>
            <div class="ms-auto btn-group btn-group-sm">
                <button type="button" class="btn btn-outline-primary" onclick="setAll('naik')">Semua naik</button>
                <button type="button" class="btn btn-outline-success" onclick="setAll('lulus')">Semua lulus</button>
            </div>
        </div>
        <div class="card-body table-responsive">
            <table class="table table-sm align-middle">
                <thead><tr><th>No</th><th>NIS</th><th>Nama</th><th>Di TP aktif</th><th>Aksi</th></tr></thead>
                <tbody>
                <?php foreach ($siswa as $s) : ?>
                    <tr>
                        <td><?= esc($s['no_absen']) ?></td><td><?= esc($s['nis']) ?></td><td><?= esc($s['nama_lengkap']) ?></td>
                        <td><?= $s['kelas_tujuan_sekarang'] ? '<span class="badge bg-info">sudah berkelas</span>' : '-' ?></td>
                        <td>
                            <select name="aksi[<?= $s['id'] ?>]" class="form-select form-select-sm aksi">
                                <option value="naik">Naik / pindah ke kelas tujuan</option>
                                <option value="tinggal">Tinggal di kelas yang sama</option>
                                <option value="lulus">Lulus</option>
                                <option value="lewati">Lewati</option>
                            </select>
                        </td>
                    </tr>
                <?php endforeach ?>
                <?php if (! $siswa) : ?><tr><td colspan="5" class="text-center text-muted">Tidak ada siswa di kelas tersebut pada TP asal.</td></tr><?php endif ?>
                </tbody>
            </table>
        </div>
        <?php if ($siswa) : ?><div class="card-footer"><button class="btn btn-primary" onclick="return confirm('Proses kenaikan kelas?')">Proses</button></div><?php endif ?>
    </div>
</form>
<?php endif ?>
<?= $this->endSection() ?>
<?= $this->section('scripts') ?>
<script>function setAll(v){document.querySelectorAll('select.aksi').forEach(s=>s.value=v);}</script>
<?= $this->endSection() ?>
