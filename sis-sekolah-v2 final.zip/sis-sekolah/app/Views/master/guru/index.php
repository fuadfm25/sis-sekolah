<?= $this->extend('layouts/main') ?>
<?= $this->section('actions') ?>
<?= tombol_impor('guru') ?>
<button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#modalForm" data-title="Tambah Guru" data-action="<?= site_url('master/guru/store') ?>" data-row='{"is_active":"1","buat_akun":"1","jenis_kelamin":"L","status_kepegawaian":"PNS"}'><i class="bi bi-plus-lg"></i> Tambah Guru</button>
<?= $this->endSection() ?>
<?= $this->section('content') ?>
<div class="card"><div class="card-body table-responsive">
    <table class="table table-hover align-middle" id="tbl">
        <thead><tr><th>No</th><th>Nama</th><th>NIP / NUPTK</th><th>L/P</th><th>Status</th><th>Akun</th><th class="text-end">Aksi</th></tr></thead>
        <tbody>
        <?php foreach ($rows as $i => $r) : ?>
            <tr class="<?= $r['is_active'] ? '' : 'text-muted' ?>">
                <td><?= $i + 1 ?></td>
                <td><?= esc(nama_guru($r)) ?><?= $r['is_active'] ? '' : ' <span class="badge bg-secondary">nonaktif</span>' ?><br><small class="text-muted"><?= esc($r['no_hp']) ?></small></td>
                <td><?= esc($r['nip'] ?: '-') ?><br><small class="text-muted"><?= esc($r['nuptk']) ?></small></td>
                <td><?= esc($r['jenis_kelamin']) ?></td>
                <td><?= esc($r['status_kepegawaian']) ?></td>
                <td>
                    <?php if ($r['username']) : ?>
                        <span class="badge bg-light-primary text-primary"><i class="bi bi-person-check"></i> <?= esc($r['username']) ?></span>
                    <?php else : ?>
                        <form method="post" action="<?= site_url('master/guru/buat-akun/' . $r['id']) ?>" class="d-inline"><?= csrf_field() ?><button class="btn btn-sm btn-outline-primary">Buat akun</button></form>
                    <?php endif ?>
                </td>
                <td class="text-end text-nowrap">
                    <button class="btn btn-sm btn-outline-warning" data-bs-toggle="modal" data-bs-target="#modalForm" data-title="Edit Guru" data-action="<?= site_url('master/guru/update/' . $r['id']) ?>" data-row='<?= esc(json_encode($r), 'attr') ?>'><i class="bi bi-pencil"></i></button>
                    <?= delete_button('master/guru/delete/' . $r['id'], '', 'Hapus guru? Penugasan, jadwal, dan jurnal guru ini ikut terhapus. Lebih aman menonaktifkan.') ?>
                </td>
            </tr>
        <?php endforeach ?>
        <?php if (! $rows) : ?><tr><td colspan="7" class="text-center text-muted">Belum ada data guru.</td></tr><?php endif ?>
        </tbody>
    </table>
</div></div>

<div class="modal fade" id="modalForm" data-crud tabindex="-1">
    <div class="modal-dialog modal-lg"><form method="post" class="modal-content"><?= csrf_field() ?>
        <div class="modal-header"><h5 class="modal-title"></h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
        <div class="modal-body row g-2">
            <div class="col-md-2"><label class="form-label">Gelar depan</label><input name="gelar_depan" class="form-control" placeholder="Drs."></div>
            <div class="col-md-6"><label class="form-label">Nama lengkap (tanpa gelar)</label><input name="nama_lengkap" class="form-control" required></div>
            <div class="col-md-4"><label class="form-label">Gelar belakang</label><input name="gelar_belakang" class="form-control" placeholder="S.Pd."></div>
            <div class="col-md-6"><label class="form-label">NIP</label><input name="nip" class="form-control"></div>
            <div class="col-md-6"><label class="form-label">NUPTK</label><input name="nuptk" class="form-control"></div>
            <div class="col-md-6"><label class="form-label">UID kartu RFID <small class="text-muted">(absen di kiosk)</small></label><input name="rfid" class="form-control" maxlength="50" placeholder="tempel kartu di pembaca"></div>
            <div class="col-md-4"><label class="form-label">Jenis kelamin</label><select name="jenis_kelamin" class="form-select"><option value="L">Laki-laki</option><option value="P">Perempuan</option></select></div>
            <div class="col-md-4"><label class="form-label">Status kepegawaian</label><select name="status_kepegawaian" class="form-select"><?php foreach (['PNS', 'PPPK', 'GTY', 'GTT', 'Honorer'] as $s) : ?><option><?= $s ?></option><?php endforeach ?></select></div>
            <div class="col-md-4"><label class="form-label">No. HP</label><input name="no_hp" class="form-control"></div>
            <div class="col-md-6"><label class="form-label">Email</label><input type="email" name="email" class="form-control"></div>
            <div class="col-md-6 d-flex align-items-end gap-4">
                <div class="form-check"><input class="form-check-input" type="checkbox" name="is_active" value="1" id="gAktif"><label class="form-check-label" for="gAktif">Aktif</label></div>
                <div class="form-check"><input class="form-check-input" type="checkbox" name="buat_akun" value="1" id="gAkun"><label class="form-check-label" for="gAkun">Buatkan akun login (saat tambah)</label></div>
            </div>
        </div>
        <div class="modal-footer"><button class="btn btn-primary">Simpan</button></div>
    </form></div>
</div>
<?= $this->endSection() ?>
<?= $this->section('scripts') ?><?= $this->include('partials/modal_form_js') ?><?= $this->endSection() ?>
