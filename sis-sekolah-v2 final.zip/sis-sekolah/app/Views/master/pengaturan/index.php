<?= $this->extend('layouts/main') ?>
<?= $this->section('content') ?>
<?php $v = static fn ($k, $d = '') => esc(old($k, $s[$k] ?? $d)); ?>
<form method="post" action="<?= site_url('sistem/pengaturan') ?>" enctype="multipart/form-data">
<?= csrf_field() ?>
<div class="row">
    <div class="col-lg-8">
        <div class="card">
            <div class="card-header"><h5 class="card-title mb-0"><i class="bi bi-building"></i> Identitas Sekolah</h5></div>
            <div class="card-body row g-3">
                <div class="col-md-8"><label class="form-label">Nama sekolah *</label><input name="nama_sekolah" class="form-control" value="<?= $v('nama_sekolah') ?>" required maxlength="150" placeholder="SMP Negeri 1 Contoh"></div>
                <div class="col-md-4"><label class="form-label">Jenjang</label>
                    <select name="jenjang" class="form-select"><option value="">-</option>
                        <?php foreach (['SD', 'MI', 'SMP', 'MTs', 'SMA', 'MA', 'SMK', 'MAK', 'SLB', 'Lainnya'] as $j) : ?><option <?= old('jenjang', $s['jenjang'] ?? '') === $j ? 'selected' : '' ?>><?= $j ?></option><?php endforeach ?>
                    </select></div>
                <div class="col-md-4"><label class="form-label">Jenis nomor induk</label>
                    <select name="jenis_nomor" class="form-select">
                        <option value="NPSN" <?= old('jenis_nomor', $s['jenis_nomor'] ?? 'NPSN') === 'NPSN' ? 'selected' : '' ?>>NPSN (Kemendikdasmen)</option>
                        <option value="NSM" <?= old('jenis_nomor', $s['jenis_nomor'] ?? '') === 'NSM' ? 'selected' : '' ?>>NSM (madrasah – Kemenag)</option>
                    </select></div>
                <div class="col-md-8"><label class="form-label">Nomor NPSN / NSM</label><input name="npsn" class="form-control" value="<?= $v('npsn') ?>" maxlength="20"></div>
                <div class="col-12"><label class="form-label">Alamat</label><textarea name="alamat_sekolah" class="form-control" rows="2" maxlength="255"><?= $v('alamat_sekolah') ?></textarea></div>
                <div class="col-md-4"><label class="form-label">Kota / kabupaten</label><input name="kota" class="form-control" value="<?= $v('kota') ?>" placeholder="Palembang"><small class="text-muted">Untuk tempat & tanggal tanda tangan.</small></div>
                <div class="col-md-4"><label class="form-label">Telepon</label><input name="telepon_sekolah" class="form-control" value="<?= $v('telepon_sekolah') ?>"></div>
                <div class="col-md-4"><label class="form-label">Email</label><input type="email" name="email_sekolah" class="form-control" value="<?= $v('email_sekolah') ?>"></div>
            </div>
        </div>
        <div class="card">
            <div class="card-header"><h5 class="card-title mb-0"><i class="bi bi-person-badge"></i> Kepala Sekolah</h5></div>
            <div class="card-body row g-3">
                <div class="col-md-7"><label class="form-label">Nama lengkap & gelar</label><input name="kepala_sekolah" class="form-control" value="<?= $v('kepala_sekolah') ?>" placeholder="Dra. Hj. Siti Aminah, M.Pd."></div>
                <div class="col-md-5"><label class="form-label">NIP <small class="text-muted">(opsional)</small></label><input name="nip_kepala_sekolah" class="form-control" value="<?= $v('nip_kepala_sekolah') ?>" placeholder="kosongkan bila tidak ber-NIP"></div>
                <div class="col-12"><small class="text-muted">Bila NIP kosong, baris NIP tidak ditampilkan pada tanda tangan laporan.</small></div>
            </div>
        </div>
        <div class="card">
            <div class="card-header"><h5 class="card-title mb-0"><i class="bi bi-clock"></i> Aturan Harian</h5></div>
            <div class="card-body row g-3">
                <div class="col-md-3"><label class="form-label">Jam masuk</label><input type="time" name="jam_masuk" class="form-control" value="<?= $v('jam_masuk', '07:00') ?>" required><small class="text-muted">Lewat jam ini = terlambat</small></div>
                <div class="col-md-3"><label class="form-label">Jam pulang</label><input type="time" name="jam_pulang" class="form-control" value="<?= $v('jam_pulang') ?>"><small class="text-muted">Mulai absen pulang (kiosk)</small></div>
                <div class="col-md-3"><label class="form-label">Jam masuk guru</label><input type="time" name="jam_masuk_guru" class="form-control" value="<?= $v('jam_masuk_guru') ?>"><small class="text-muted">Kosong = sama dengan siswa</small></div>
                <div class="col-md-3"><label class="form-label">Hari sekolah</label>
                    <select name="hari_sekolah" class="form-select"><option value="5" <?= ($s['hari_sekolah'] ?? '') == 5 ? 'selected' : '' ?>>5 hari</option><option value="6" <?= ($s['hari_sekolah'] ?? '') == 6 ? 'selected' : '' ?>>6 hari</option></select></div>
                <div class="col-md-3"><label class="form-label">Batas poin BK</label><input type="number" name="batas_poin_bk" min="1" class="form-control" value="<?= $v('batas_poin_bk', 50) ?>" required></div>
            </div>
        </div>
    </div>
    <div class="col-lg-4">
        <div class="card">
            <div class="card-header"><h5 class="card-title mb-0"><i class="bi bi-app-indicator"></i> Aplikasi</h5></div>
            <div class="card-body">
                <label class="form-label">Nama aplikasi *</label>
                <input name="nama_aplikasi" class="form-control mb-1" value="<?= $v('nama_aplikasi', 'SIS Sekolah') ?>" required maxlength="60">
                <small class="text-muted">Tampil di menu samping, halaman login, dan judul tab browser.</small>
            </div>
        </div>
        <div class="card">
            <div class="card-header"><h5 class="card-title mb-0"><i class="bi bi-image"></i> Logo Sekolah</h5></div>
            <div class="card-body text-center">
                <?php if ($logo) : ?>
                    <img src="<?= esc($logo) ?>" alt="Logo" class="img-fluid mb-2" style="max-height:120px">
                <?php else : ?>
                    <div class="border rounded py-4 text-muted mb-2"><i class="bi bi-image fs-1"></i><br>Belum ada logo</div>
                <?php endif ?>
                <input type="file" name="logo" class="form-control" accept="image/png,image/jpeg,image/webp">
                <small class="text-muted d-block mt-1">PNG/JPG/WEBP, maks. 1 MB, disarankan persegi berlatar transparan.</small>
            </div>
        </div>
        <div class="card">
            <div class="card-header"><h5 class="card-title mb-0"><i class="bi bi-upc-scan"></i> Absensi Kiosk</h5></div>
            <div class="card-body">
                <select name="kiosk_aktif" class="form-select mb-2">
                    <option value="1" <?= ($s['kiosk_aktif'] ?? '') === '1' ? 'selected' : '' ?>>Aktif</option>
                    <option value="0" <?= ($s['kiosk_aktif'] ?? '') !== '1' ? 'selected' : '' ?>>Nonaktif</option>
                </select>
                <?php if ($kioskUrl) : ?>
                    <div class="input-group input-group-sm mb-1">
                        <input class="form-control" id="kioskUrl" value="<?= esc($kioskUrl) ?>" readonly>
                        <button class="btn btn-outline-secondary" type="button" onclick="navigator.clipboard.writeText(document.getElementById('kioskUrl').value)" title="Salin"><i class="bi bi-clipboard"></i></button>
                        <a href="<?= esc($kioskUrl) ?>" target="_blank" class="btn btn-outline-primary" title="Buka"><i class="bi bi-box-arrow-up-right"></i></a>
                    </div>
                    <small class="text-muted">Rahasiakan alamat ini.</small>
                <?php else : ?>
                    <small class="text-danger">Token belum dibuat – klik "Ganti token kiosk" di bawah.</small>
                <?php endif ?>
            </div>
        </div>
        <div class="card">
            <div class="card-header"><h5 class="card-title mb-0"><i class="bi bi-mortarboard"></i> Portal Siswa</h5></div>
            <div class="card-body">
                <select name="portal_siswa" class="form-select mb-2">
                    <option value="1" <?= ($s['portal_siswa'] ?? '1') === '1' ? 'selected' : '' ?>>Aktif</option>
                    <option value="0" <?= ($s['portal_siswa'] ?? '1') === '0' ? 'selected' : '' ?>>Nonaktif</option>
                </select>
                <small class="text-muted">Siswa/orang tua masuk di <a href="<?= site_url('portal') ?>" target="_blank"><?= esc(site_url('portal')) ?></a> untuk melihat jadwal, materi, kehadiran, perilaku, dan pembiasaan.</small>
            </div>
        </div>
        <div class="card">
            <div class="card-header"><h5 class="card-title mb-0"><i class="bi bi-journal-richtext"></i> Format Modul Ajar</h5></div>
            <div class="card-body">
                <select name="format_modul" class="form-select mb-1">
                    <?php foreach (['otomatis' => 'Otomatis menurut jenjang (madrasah → PM + KBC)', 'PM' => 'Pembelajaran Mendalam', 'PM-KBC' => 'Pembelajaran Mendalam terintegrasi Kurikulum Berbasis Cinta'] as $k => $v) : ?>
                        <option value="<?= $k ?>" <?= ($s['format_modul'] ?? 'otomatis') === $k ? 'selected' : '' ?>><?= $v ?></option>
                    <?php endforeach ?>
                </select>
                <small class="text-muted">Format bawaan saat guru membuat modul ajar baru; guru tetap bisa menggantinya per modul.</small>
            </div>
        </div>
        <div class="card">
            <div class="card-header"><h5 class="card-title mb-0"><i class="bi bi-door-open"></i> Izin Keluar &amp; Pos Gerbang</h5></div>
            <div class="card-body">
                <label class="form-label">Verifikasi satpam</label>
                <select name="verifikasi_satpam" class="form-select mb-1">
                    <option value="1" <?= ($s['verifikasi_satpam'] ?? '1') === '1' ? 'selected' : '' ?>>Ya – izin berlaku setelah satpam mencatat siswa keluar gerbang</option>
                    <option value="0" <?= ($s['verifikasi_satpam'] ?? '1') === '0' ? 'selected' : '' ?>>Tidak – izin berlaku sejak jam keluar yang ditulis piket</option>
                </select>
                <small class="text-muted d-block mb-3">Pilih "Tidak" bila sekolah tidak memiliki satpam yang memakai aplikasi.</small>
                <label class="form-label">Terlambat kembali lebih dari (menit) = membolos</label>
                <input type="number" min="0" max="240" name="toleransi_kembali" class="form-control mb-3" value="<?= esc($s['toleransi_kembali'] ?? '30') ?>">
                <label class="form-label">Catatan perilaku otomatis</label>
                <select name="izin_keluar_perilaku" class="form-select mb-1">
                    <option value="1" <?= ($s['izin_keluar_perilaku'] ?? '1') === '1' ? 'selected' : '' ?>>Ya – terlambat kembali & membolos dicatat ke Catatan Perilaku (poin)</option>
                    <option value="0" <?= ($s['izin_keluar_perilaku'] ?? '1') === '0' ? 'selected' : '' ?>>Tidak – hanya tampil di laporan</option>
                </select>
                <small class="text-muted">Poin mengikuti Referensi → Jenis Perilaku ("Terlambat kembali dari izin keluar", "Membolos …").</small>
            </div>
        </div>
    </div>
</div>
<div class="card"><div class="card-body py-3"><button class="btn btn-primary"><i class="bi bi-save"></i> Simpan Pengaturan</button></div></div>
</form>

<div class="d-flex gap-2 mb-4">
    <?php if ($logo) : ?>
        <form method="post" action="<?= site_url('sistem/pengaturan/hapus-logo') ?>" onsubmit="return confirm('Hapus logo?')"><?= csrf_field() ?><button class="btn btn-sm btn-outline-danger"><i class="bi bi-trash"></i> Hapus logo</button></form>
    <?php endif ?>
    <form method="post" action="<?= site_url('sistem/pengaturan/token-kiosk') ?>" onsubmit="return confirm('Ganti token? Alamat kiosk lama tidak bisa dipakai lagi.')">
        <?= csrf_field() ?><button class="btn btn-sm btn-outline-danger"><i class="bi bi-arrow-repeat"></i> Ganti token kiosk</button>
    </form>
</div>
<?= $this->endSection() ?>
