<?= $this->extend('layouts/cetak') ?>
<?= $this->section('isi') ?>
<table class="info"><tr><td>Kelas</td><td>: <b><?= esc($kelas['nama_kelas']) ?></b></td><td style="width:40px"></td><td>Hari efektif absensi</td><td>: <?= $efektif ?> hari</td></tr></table>
<table class="data">
    <thead><tr><th style="width:30px">No</th><th style="width:80px">NIS</th><th style="width:100px">NISN</th><th>Nama Siswa</th><th style="width:55px">Sakit</th><th style="width:55px">Izin</th><th style="width:75px">Tanpa Keterangan</th><th style="width:60px">Terlambat</th></tr></thead>
    <tbody>
    <?php foreach ($siswa as $i => $s) : $r = $rekap[$s['id']] ?? []; ?>
        <tr><td class="tengah"><?= $i + 1 ?></td><td><?= esc($s['nis']) ?></td><td><?= esc($s['nisn'] ?? '') ?></td><td><?= esc($s['nama_lengkap']) ?></td>
            <td class="tengah"><?= $r['S'] ?? 0 ?></td><td class="tengah"><?= $r['I'] ?? 0 ?></td><td class="tengah"><?= $r['A'] ?? 0 ?></td><td class="tengah"><?= $r['T'] ?? 0 ?></td></tr>
    <?php endforeach ?>
    </tbody>
</table>
<p class="kecil-teks">Kolom Sakit, Izin, dan Tanpa Keterangan sesuai isian ketidakhadiran pada e-Rapor. Tekan "⬇ Excel" untuk menyalin angka ke e-Rapor.</p>
<?= $this->endSection() ?>
