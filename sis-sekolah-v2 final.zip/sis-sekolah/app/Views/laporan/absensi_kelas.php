<?= $this->extend('layouts/cetak') ?>
<?= $this->section('isi') ?>
<table class="info">
    <tr><td>Kelas</td><td>: <b><?= esc($kelas['nama_kelas']) ?></b></td><td style="width:40px"></td><td>Wali Kelas</td><td>: <?= esc($ttd['kanan']['nama'] ?: '-') ?></td></tr>
</table>
<table class="data kecil">
    <thead>
        <tr><th rowspan="2" style="width:22px">No</th><th rowspan="2" style="width:50px">NIS</th><th rowspan="2">Nama Siswa</th><th rowspan="2" style="width:18px">L/P</th>
            <th colspan="<?= $jml ?>">Tanggal</th><th colspan="5">Jumlah</th></tr>
        <tr><?php for ($d = 1; $d <= $jml; $d++) : ?><th class="<?= $libur[$d] ? 'libur' : '' ?>" style="width:17px"><?= $d ?></th><?php endfor ?>
            <th style="width:20px">H</th><th style="width:20px">T</th><th style="width:20px">S</th><th style="width:20px">I</th><th style="width:20px">A</th></tr>
    </thead>
    <tbody>
    <?php $tot = ['H' => 0, 'T' => 0, 'S' => 0, 'I' => 0, 'A' => 0];
    foreach ($siswa as $i => $s) : $c = ['H' => 0, 'T' => 0, 'S' => 0, 'I' => 0, 'A' => 0]; ?>
        <tr>
            <td><?= $s['no_absen'] ?: $i + 1 ?></td><td><?= esc($s['nis']) ?></td><td class="kiri"><?= esc($s['nama_lengkap']) ?></td><td><?= esc($s['jenis_kelamin']) ?></td>
            <?php for ($d = 1; $d <= $jml; $d++) : $st = $matriks[$s['id']][$d] ?? ''; if ($st) { $c[$st]++; } ?>
                <td class="<?= $libur[$d] ? 'libur' : '' ?> <?= in_array($st, ['S', 'I', 'A'], true) ? 'merah' : '' ?>"><?= $st === 'H' ? '•' : esc($st) ?></td>
            <?php endfor ?>
            <?php foreach ($c as $k => $n) : $tot[$k] += $n; ?><td><?= $n ?: '' ?></td><?php endforeach ?>
        </tr>
    <?php endforeach ?>
    <tr><th colspan="<?= 4 + $jml ?>" class="kanan">Jumlah</th><?php foreach ($tot as $n) : ?><th><?= $n ?></th><?php endforeach ?></tr>
    </tbody>
</table>
<p class="kecil-teks">Keterangan: • hadir · T terlambat · S sakit · I izin · A alpa · kolom abu-abu = tidak ada absensi (bukan hari sekolah / libur). Hari efektif absensi bulan ini: <b><?= $efektif ?></b> hari.
<?php if ($agenda) : ?><br>Kalender: <?php $x = []; foreach ($agenda as $a) { $x[] = esc($a['nama']) . ' (' . ($a['tanggal_mulai'] === $a['tanggal_selesai'] ? (int) substr($a['tanggal_mulai'], 8) : (int) substr($a['tanggal_mulai'], 8) . '–' . (int) substr($a['tanggal_selesai'], 8)) . ')'; } echo implode('; ', $x); ?><?php endif ?>
<br>Jumlah siswa: <?= count($siswa) ?>
    (L: <?= count(array_filter($siswa, static fn ($s) => $s['jenis_kelamin'] === 'L')) ?>, P: <?= count(array_filter($siswa, static fn ($s) => $s['jenis_kelamin'] === 'P')) ?>).</p>
<?= $this->endSection() ?>
