<?= $this->extend('layouts/cetak') ?>
<?= $this->section('isi') ?>
<table class="info">
    <tr><td>Nama Guru</td><td>: <b><?= esc($guru ? nama_guru($guru) : '-') ?></b></td></tr>
    <?php if (! empty($guru['nip'])) : ?><tr><td>NIP</td><td>: <?= esc($guru['nip']) ?></td></tr><?php endif ?>
    <tr><td>Periode</td><td>: <?= esc($periode) ?></td></tr>
</table>
<table class="data">
    <thead><tr><th style="width:28px">No</th><th style="width:110px">Hari, Tanggal</th><th style="width:60px">Kelas</th><th style="width:40px">Jam</th><th style="width:110px">Mapel</th><th style="width:34px">Pert.</th><th>Materi / Kegiatan</th><th style="width:85px">Status</th><th style="width:150px">Siswa Tidak Hadir</th></tr></thead>
    <tbody>
    <?php foreach ($rows as $i => $r) : ?>
        <tr>
            <td class="tengah"><?= $i + 1 ?></td>
            <td><?= tgl_indo($r['tanggal'], true) ?></td>
            <td class="tengah"><?= esc($r['nama_kelas']) ?></td>
            <td class="tengah"><?= esc($r['jam_ke']) ?></td>
            <td><?= esc($r['nama_mapel']) ?></td>
            <td class="tengah"><?= esc($r['pertemuan_ke']) ?></td>
            <td><b><?= esc($r['materi']) ?></b><?= $r['kegiatan'] ? '<br><span class="kecil-teks">' . nl2br(esc($r['kegiatan'])) . '</span>' : '' ?><?= $r['catatan'] ? '<br><i class="kecil-teks">Catatan: ' . esc($r['catatan']) . '</i>' : '' ?></td>
            <td class="tengah"><?= esc($r['status_kbm']) ?></td>
            <td class="kecil-teks"><?= esc($absen[$r['id']] ?? 'Hadir semua') ?></td>
        </tr>
    <?php endforeach ?>
    <?php if (! $rows) : ?><tr><td colspan="9" class="tengah">Tidak ada jurnal pada periode ini.</td></tr><?php endif ?>
    </tbody>
</table>
<p class="kecil-teks">Jumlah pertemuan: <?= count($rows) ?> · Jumlah JP: <?= array_sum(array_column($rows, 'jumlah_jp')) ?></p>
<?= $this->endSection() ?>
