<?= $this->extend('layouts/cetak') ?>
<?= $this->section('isi') ?>
<table class="info">
    <tr><td style="width:120px">Nama</td><td>: <b><?= esc($siswa['nama_lengkap']) ?></b></td></tr>
    <tr><td>NIS / NISN</td><td>: <?= esc($siswa['nis']) ?> / <?= esc($siswa['nisn'] ?? '-') ?></td></tr>
    <tr><td>Kelas</td><td>: <?= esc($kelas['nama_kelas'] ?? '-') ?></td></tr>
    <tr><td>Orang tua/wali</td><td>: <?= esc($siswa['nama_wali'] ?? '-') ?><?= $siswa['no_hp_wali'] ? ' (' . esc($siswa['no_hp_wali']) . ')' : '' ?></td></tr>
</table>
<table class="data" style="width:auto;margin-top:8px">
    <tr><th colspan="5">Kehadiran Harian</th><th colspan="2">Poin Perilaku</th></tr>
    <tr><th>Hadir</th><th>Terlambat</th><th>Sakit</th><th>Izin</th><th>Alpa</th><th>Positif</th><th>Pelanggaran</th></tr>
    <tr class="tengah"><td><?= (int) ($hadir['H'] ?? 0) ?></td><td><?= (int) ($hadir['T'] ?? 0) ?></td><td><?= (int) ($hadir['S'] ?? 0) ?></td><td><?= (int) ($hadir['I'] ?? 0) ?></td><td><?= (int) ($hadir['A'] ?? 0) ?></td>
        <td>+<?= $poin['positif'] ?></td><td class="<?= $poin['negatif'] >= (int) setting('batas_poin_bk', 50) ? 'merah' : '' ?>"><?= $poin['negatif'] ?></td></tr>
</table>
<table class="data">
    <thead><tr><th style="width:28px">No</th><th style="width:85px">Tanggal</th><th style="width:65px">Kategori</th><th>Perilaku & Uraian</th><th style="width:40px">Poin</th><th style="width:160px">Tindak Lanjut</th><th style="width:100px">Pencatat</th></tr></thead>
    <tbody>
    <?php foreach ($rows as $i => $c) : ?>
        <tr>
            <td class="tengah"><?= $i + 1 ?></td><td><?= tgl_indo($c['tanggal']) ?></td><td class="tengah"><?= esc($c['kategori']) ?></td>
            <td><b><?= esc($c['nama_jenis'] ?? 'Lainnya') ?></b><br><span class="kecil-teks"><?= esc($c['deskripsi']) ?><?= $c['lokasi'] ? ' · Lokasi: ' . esc($c['lokasi']) : '' ?></span></td>
            <td class="tengah"><?= $c['kategori'] === 'Negatif' ? '-' : '+' ?><?= $c['poin'] ?></td>
            <td class="kecil-teks"><?= esc($c['tindak_lanjut'] ?? '-') ?><br><i><?= esc($c['status']) ?></i></td>
            <td class="kecil-teks"><?= esc($c['pencatat']) ?></td>
        </tr>
    <?php endforeach ?>
    <?php if (! $rows) : ?><tr><td colspan="7" class="tengah">Belum ada catatan perilaku.</td></tr><?php endif ?>
    </tbody>
</table>
<?= $this->endSection() ?>
