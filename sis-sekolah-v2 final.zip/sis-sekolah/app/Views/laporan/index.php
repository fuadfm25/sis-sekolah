<?= $this->extend('layouts/main') ?>
<?= $this->section('content') ?>
<?php
use App\Libraries\Akses;

$bulanSelect = static function (): string {
    $h = '<div class="col-7"><select name="bulan" class="form-select form-select-sm">';
    foreach (bulan_list() as $n => $b) {
        $h .= '<option value="' . $n . '"' . ($n == date('n') ? ' selected' : '') . '>' . $b . '</option>';
    }
    return $h . '</select></div><div class="col-5"><input type="number" name="tahun" value="' . date('Y') . '" class="form-control form-control-sm"></div>';
};
$rentang = static fn (string $dari, string $sampai): string => '<div class="col-6"><label class="small text-muted">Dari</label><input type="date" name="dari" value="' . $dari . '" class="form-control form-control-sm"></div>'
    . '<div class="col-6"><label class="small text-muted">Sampai</label><input type="date" name="sampai" value="' . $sampai . '" class="form-control form-control-sm"></div>';
$kelasSelect = static function (array $kelas, bool $wajib = true, string $kosong = '- pilih kelas -'): string {
    $h = '<div class="col-12"><select name="kelas_id" class="form-select form-select-sm" ' . ($wajib ? 'required' : '') . '><option value="">' . $kosong . '</option>';
    foreach ($kelas as $k) {
        $h .= '<option value="' . $k['id'] . '"' . (count($kelas) === 1 ? ' selected' : '') . '>' . esc($k['nama_kelas']) . '</option>';
    }
    return $h . '</select></div>';
};
$kartu = static function (string $judul, string $ikon, string $ket, string $url, string $isi, string $warna = 'primary'): string {
    return '<div class="col-md-6 col-xl-4"><div class="card h-100 border-start border-4 border-' . $warna . '"><div class="card-body">'
        . '<h6 class="mb-1"><i class="bi bi-' . $ikon . ' text-' . $warna . ' me-1"></i>' . $judul . '</h6><p class="small text-muted mb-2">' . $ket . '</p>'
        . '<form method="get" action="' . site_url($url) . '" target="_blank" class="row g-2">' . $isi
        . '<div class="col-12"><button class="btn btn-sm btn-' . $warna . ' w-100"><i class="bi bi-printer"></i> Cetak</button></div>'
        . '<div class="col-12"><button name="format" value="xlsx" class="btn btn-sm btn-outline-secondary w-100"><i class="bi bi-file-earmark-excel"></i> Unduh Excel</button></div></form></div></div></div>';
};
$ada = false;
?>

<?php if ($guru) : $ada = true; ?>
<h5 class="mt-2">Guru</h5>
<div class="row g-3 mb-4">
    <?php
    $optGuru = '<div class="col-12"><select name="guru_id" class="form-select form-select-sm' . (count($guru) > 1 ? ' tom' : '') . '">';
    foreach ($guru as $g) {
        $optGuru .= '<option value="' . $g['id'] . '"' . ((int) $g['id'] === (int) session('guru_id') ? ' selected' : '') . '>' . esc(nama_guru($g)) . '</option>';
    }
    $optGuru .= '</select></div>';
    echo $kartu('Jurnal Pembelajaran', 'journal-text', 'Agenda mengajar: tanggal, kelas, jam, materi, dan siswa tidak hadir.', 'laporan/jurnal-guru', $optGuru . $rentang($awalBulan, $hariIni));
    ?>
    <?php if ($penugasan) :
        $opt = '<div class="col-12"><select name="penugasan_id" class="form-select form-select-sm tom" required><option value="">- mapel & kelas -</option>';
        foreach ($penugasan as $p) {
            $opt .= '<option value="' . $p['id'] . '">' . esc($p['nama_kelas'] . ' · ' . $p['nama_mapel'] . (Akses::jurnalSemua() || ! session('guru_id') || (int) $p['guru_id'] !== (int) session('guru_id') ? ' · ' . nama_guru($p) : '')) . '</option>';
        }
        $opt .= '</select></div>';
        echo $kartu('Ketercapaian Tujuan Pembelajaran', 'bullseye', 'TP dari ATP yang sudah/belum dibahas di jurnal, tanggal, dan JP terpakai.', 'laporan/ketercapaian-atp', $opt);
        echo $kartu('Rekap Kehadiran Mapel', 'table', 'Matriks kehadiran siswa per pertemuan untuk satu mapel di satu kelas.', 'laporan/rekap-mapel', $opt . $rentang(tp_aktif()['tanggal_mulai'] ?: $awalBulan, $hariIni));
    endif ?>
</div>
<?php endif ?>

<?php if ($kelas['absensi'] || $kelas['jurnal'] || $kelas['perilaku'] || $kelas['pembiasaan'] || $kelas['siswa']) : $ada = true; ?>
<h5>Kelas <?= is_wali_kelas() && ! Akses::laporanSemuaKelas('absensi') ? '<small class="text-muted">(kelas perwalian)</small>' : '' ?></h5>
<div class="row g-3 mb-4">
    <?php
    if ($kelas['absensi']) {
        echo $kartu('Absensi Kelas (Bulanan)', 'calendar3', 'Matriks kehadiran: baris nama siswa, kolom tanggal 1–akhir bulan, beserta jumlah H/T/S/I/A.', 'laporan/absensi-kelas', $kelasSelect($kelas['absensi']) . $bulanSelect(), 'success');
    }
    if ($kelas['jurnal']) {
        echo $kartu('Rekap Semester (e-Rapor)', 'clipboard-data', 'Jumlah sakit, izin, tanpa keterangan per siswa selama semester untuk diisikan ke e-Rapor.', 'laporan/rekap-semester', $kelasSelect($kelas['absensi']), 'success');
        echo $kartu('Jurnal Kelas', 'journal-bookmark', 'Seluruh kegiatan belajar di kelas: semua mapel & guru, materi, dan ketidakhadiran.', 'laporan/jurnal-kelas', $kelasSelect($kelas['jurnal']) . $rentang($awalBulan, $hariIni), 'success');
    }
    if ($kelas['perilaku']) {
        echo $kartu('Catatan Perilaku Kelas', 'person-exclamation', 'Catatan perilaku positif & pelanggaran per siswa beserta total poin.', 'laporan/perilaku-kelas', $kelasSelect($kelas['perilaku']) . $rentang(tp_aktif()['tanggal_mulai'] ?: $awalBulan, $hariIni), 'danger');
        $opt = '<div class="col-12"><select name="siswa_id" class="form-select form-select-sm tom" required><option value="">- cari siswa -</option>';
        foreach ($siswaPerilaku as $s) {
            $opt .= '<option value="' . $s['id'] . '">' . esc($s['nama_lengkap'] . ' – ' . $s['nama_kelas']) . '</option>';
        }
        $opt .= '</select></div>';
        echo $kartu('Kartu Perilaku Siswa', 'person-vcard', 'Riwayat lengkap satu siswa: kehadiran, poin, catatan & tindak lanjut.', 'laporan/perilaku-siswa', $opt, 'danger');
    }
    if ($kelas['pembiasaan']) {
        echo $kartu('Rekap Pembiasaan', 'check2-square', 'Persentase keterlaksanaan pembiasaan per siswa.', 'laporan/pembiasaan', $kelasSelect($kelas['pembiasaan']) . $rentang($awalBulan, $hariIni), 'info');
    }
    if ($kelas['siswa']) {
        echo $kartu('Daftar Siswa', 'people', 'Daftar siswa per kelas (NIS, NISN, L/P, TTL, orang tua).', 'laporan/daftar-siswa', $kelasSelect($kelas['siswa']), 'secondary');
    }
    ?>
</div>
<?php endif ?>

<?php if (Akses::perangkatLihatSemua() || Akses::mutasiLihat() || Akses::kehadiranGuruLihat() || Akses::rekapPoin() || Akses::laporanRekapKehadiran() || Akses::laporanBk() || Akses::laporanKeterisianJurnal() || Akses::laporanPiket()) : $ada = true; ?>
<h5>Rekap Sekolah</h5>
<div class="row g-3 mb-4">
    <?php
    if (Akses::laporanRekapKehadiran()) {
        echo $kartu('Rekap Kehadiran Semua Kelas', 'bar-chart', 'Jumlah H/T/S/I/A dan persentase kehadiran tiap kelas dalam satu bulan.', 'laporan/rekap-kehadiran', $bulanSelect(), 'success');
    }
    if (Akses::perangkatLihatSemua()) {
        $gs = '<div class="col-12"><select name="guru_id" class="form-select form-select-sm"><option value="">Rekap semua guru</option>';
        foreach (model(\App\Models\GuruModel::class)->where('is_active', 1)->orderBy('nama_lengkap')->findAll() as $g) {
            $gs .= '<option value="' . $g['id'] . '">Lembar pengesahan: ' . esc($g['nama_lengkap']) . '</option>';
        }
        echo $kartu('Perangkat Pembelajaran', 'folder-check', 'Kelengkapan perangkat tiap guru per jenis, atau lembar pengesahan per guru.', 'laporan/perangkat', $gs . '</select></div>', 'info');
    }
    if (Akses::mutasiLihat()) {
        echo $kartu('Mutasi Siswa', 'arrow-left-right', 'Siswa masuk, keluar, pindah kelas, dan lulus beserta rekap L/P.', 'laporan/mutasi', $rentang(tp_aktif()['tanggal_mulai'] ?: $awalBulan, $hariIni), 'secondary');
    }
    if (Akses::kehadiranGuruLihat()) {
        echo $kartu('Daftar Hadir Guru', 'person-badge', 'Matriks kehadiran guru per tanggal (H/T/S/I/DL/C/A) dalam satu bulan.', 'laporan/kehadiran-guru', $bulanSelect(), 'primary');
    }
    if (Akses::rekapPoin()) {
        $kp = Akses::perilakuLihatSemua() ? model(\App\Models\KelasModel::class)->listAktif() : $kelas['perilaku'];
        echo $kartu('Rekap Poin Perilaku', 'trophy', 'Akumulasi poin positif & pelanggaran tiap siswa; yang melewati batas BK ditandai.', 'laporan/rekap-poin', $kelasSelect($kp, false, Akses::perilakuLihatSemua() ? 'Semua kelas' : 'Semua kelas perwalian'), 'danger');
    }
    if (Akses::laporanKeterisianJurnal()) {
        echo $kartu('Keterisian Jurnal Guru', 'clipboard-check', 'Sesi terjadwal vs jurnal yang diisi tiap guru.', 'laporan/keterisian-jurnal', $rentang($awalBulan, $hariIni), 'warning');
    }
    if (Akses::laporanBk()) {
        echo $kartu('Layanan BK', 'chat-heart', 'Daftar layanan BK. Isi layanan rahasia hanya tercetak untuk konselornya.', 'laporan/layanan-bk', $rentang($awalBulan, $hariIni), 'primary');
    }
    if (Akses::laporanPiket()) {
        echo $kartu('Laporan Harian Piket', 'shield-check', 'Kehadiran semua kelas, siswa tidak hadir/terlambat, dan jurnal yang belum terisi.', 'laporan/harian-piket', '<div class="col-12"><input type="date" name="tanggal" value="' . $hariIni . '" max="' . $hariIni . '" class="form-control form-control-sm"></div>', 'warning');
    }
    ?>
</div>
<?php endif ?>

<h5>Kalender Akademik</h5>
<div class="row g-3 mb-4">
    <?php
    $ada = true;
    $isi = '';
    if (Akses::jurnalSemua()) {
        $isi = '<div class="col-12"><select name="guru_id" class="form-select form-select-sm tom"><option value="">- tanpa rincian JP guru -</option>';
        foreach (model(\App\Models\GuruModel::class)->listAktif() as $g) {
            $isi .= '<option value="' . $g['id'] . '">' . esc(nama_guru($g)) . '</option>';
        }
        $isi .= '</select></div>';
    } elseif (session('guru_id')) {
        $isi = '<div class="col-12 small text-muted">Termasuk JP efektif mata pelajaran yang Anda ampu.</div>';
    }
    echo $kartu('Rincian Pekan & Hari Efektif', 'calendar-range', 'Pekan efektif per bulan, hari efektif per hari, dan JP efektif per mapel untuk program tahunan/semester.', 'laporan/pekan-efektif', $isi, 'primary');
    ?>
</div>

<?php if (! $ada) : ?>
    <div class="alert alert-light">Belum ada laporan yang dapat Anda cetak. Laporan tersedia untuk guru (akun tertaut data guru), wali kelas, kurikulum, kesiswaan, BK, piket, kepala sekolah, dan TU.</div>
<?php endif ?>
<?= $this->endSection() ?>
