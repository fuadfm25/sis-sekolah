<?= $this->extend('layouts/cetak') ?>
<?= $this->section('isi') ?>
<table class="info">
    <tr><td>Kelas</td><td>: <b><?= esc($kelas['nama_kelas']) ?></b></td><td style="width:40px"></td><td>Periode</td><td>: <?= esc($periode) ?></td></tr>
</table>
<table class="data">
    <thead><tr><th style="width:28px">No</th><th style="width:110px">Hari, Tanggal</th><th style="width:40px">Jam</th><th style="width:110px">Mata Pelajaran</th><th style="width:140px">Guru</th><th>Materi</th><th style="width:80px">Status</th><th style="width:160px">Siswa Tidak Hadir</th><th style="width:60px">Paraf</th></tr></thead>
    <tbody>
    <?php $tglLalu = null; foreach ($rows as $i => $r) : ?>
        <tr>
            <td class="tengah"><?= $i + 1 ?></td>
            <td><?= $r['tanggal'] !== $tglLalu ? tgl_indo($r['tanggal'], true) : '' ?></td>
            <td class="tengah"><?= esc($r['jam_ke']) ?></td>
            <td><?= esc($r['nama_mapel']) ?></td>
            <td><?= esc(nama_guru($r)) ?><?= $r['pengisi'] && $r['status_kbm'] === 'Diganti Guru Lain' ? '<br><i class="kecil-teks">diisi: ' . esc($r['pengisi']) . '</i>' : '' ?></td>
            <td><?= esc($r['materi']) ?></td>
            <td class="tengah"><?= esc($r['status_kbm']) ?></td>
            <td class="kecil-teks"><?= esc($absen[$r['id']] ?? '-') ?></td>
            <td></td>
        </tr>
    <?php $tglLalu = $r['tanggal']; endforeach ?>
    <?php if (! $rows) : ?><tr><td colspan="9" class="tengah">Tidak ada jurnal pada periode ini.</td></tr><?php endif ?>
    </tbody>
</table>
<?= $this->endSection() ?>
