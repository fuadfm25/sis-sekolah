<?= $this->extend('layouts/cetak') ?>
<?= $this->section('isi') ?>
<table class="data">
    <thead><tr><th style="width:30px">No</th><th style="width:70px">NIS</th><th style="width:90px">NISN</th><th>Nama Siswa</th><th style="width:30px">L/P</th><th style="width:150px">Tempat, Tgl Lahir</th><th style="width:140px">Orang Tua/Wali</th></tr></thead>
    <tbody>
    <?php foreach ($siswa as $i => $s) : ?>
        <tr><td class="tengah"><?= $s['no_absen'] ?: $i + 1 ?></td><td><?= esc($s['nis']) ?></td><td><?= esc($s['nisn']) ?></td><td><?= esc($s['nama_lengkap']) ?></td><td class="tengah"><?= esc($s['jenis_kelamin']) ?></td>
            <td><?= esc($s['tempat_lahir'] ?? '') ?><?= $s['tanggal_lahir'] ? ', ' . tgl_indo($s['tanggal_lahir']) : '' ?></td><td><?= esc($s['nama_wali'] ?? '') ?></td></tr>
    <?php endforeach ?>
    </tbody>
</table>
<p class="kecil-teks">Jumlah: <?= count($siswa) ?> siswa (L: <?= count(array_filter($siswa, static fn ($s) => $s['jenis_kelamin'] === 'L')) ?>, P: <?= count(array_filter($siswa, static fn ($s) => $s['jenis_kelamin'] === 'P')) ?>)</p>
<?= $this->endSection() ?>
