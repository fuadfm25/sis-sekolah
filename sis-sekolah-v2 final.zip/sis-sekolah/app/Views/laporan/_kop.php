<?php $lg = logo_url(); ?>
<table class="kop"><tr>
    <td class="kop-logo"><?php if ($lg) : ?><img src="<?= esc($lg) ?>" alt="Logo"><?php endif ?></td>
    <td class="teks">
        <div class="nama"><?= esc(setting('nama_sekolah', 'Nama Sekolah')) ?></div>
        <?php if ($n = nomor_sekolah()) : ?><div class="sub"><b><?= esc($n) ?></b><?= setting('jenjang') ? ' · Jenjang ' . esc(setting('jenjang')) : '' ?></div><?php endif ?>
        <?php if ($a = setting('alamat_sekolah')) : ?><div class="sub"><?= esc($a) ?><?= setting('kota') ? ', ' . esc(setting('kota')) : '' ?></div><?php endif ?>
        <?php
        $kontak = array_filter([setting('telepon_sekolah') ? 'Telp. ' . setting('telepon_sekolah') : '', setting('email_sekolah') ? 'Email: ' . setting('email_sekolah') : '']);
        if ($kontak) : ?><div class="sub"><?= esc(implode(' · ', $kontak)) ?></div><?php endif ?>
    </td>
    <td class="kop-logo"></td>
</tr></table>
