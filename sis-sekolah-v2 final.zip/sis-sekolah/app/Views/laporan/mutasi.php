<?= $this->extend('layouts/cetak') ?>
<?= $this->section('isi') ?>
<?php $J = \App\Models\MutasiSiswaModel::JENIS; ?>
<table class="info"><tr><td>Periode</td><td>: <?= esc($periode) ?></td></tr></table>
<table class="data">
    <thead><tr><th style="width:28px">No</th><th style="width:80px">Tanggal</th><th>Nama Siswa</th><th style="width:70px">NIS</th><th style="width:85px">NISN</th><th style="width:25px">L/P</th><th style="width:110px">Jenis Mutasi</th><th style="width:70px">Kelas Asal</th><th style="width:70px">Kelas Tujuan</th><th>Sekolah Asal/Tujuan</th><th>Alasan</th><th style="width:80px">No. Surat</th></tr></thead>
    <tbody>
    <?php foreach ($rows as $i => $r) : ?>
        <tr><td class="tengah"><?= $i + 1 ?></td><td class="nowrap"><?= tgl_indo($r['tanggal']) ?></td><td><?= esc($r['nama_lengkap']) ?></td><td><?= esc($r['nis']) ?></td><td><?= esc($r['nisn']) ?></td>
            <td class="tengah"><?= esc($r['jenis_kelamin']) ?></td><td><?= esc($J[$r['jenis']][0] ?? $r['jenis']) ?></td><td><?= esc($r['kelas_asal']) ?></td><td><?= esc($r['kelas_tujuan']) ?></td>
            <td><?= esc($r['sekolah']) ?></td><td><?= esc($r['alasan']) ?></td><td><?= esc($r['no_surat']) ?></td></tr>
    <?php endforeach ?>
    <?php if (! $rows) : ?><tr><td colspan="12" class="tengah">Tidak ada mutasi pada periode ini.</td></tr><?php endif ?>
    </tbody>
</table>
<?php $rek = []; foreach ($rows as $r) { $rek[$r['jenis']][$r['jenis_kelamin']] = ($rek[$r['jenis']][$r['jenis_kelamin']] ?? 0) + 1; } ?>
<?php if ($rek) : ?><p class="kecil-teks">Rekap: <?= esc(implode('; ', array_map(static fn ($j, $n) => ($J[$j][0] ?? $j) . ' ' . array_sum($n) . ' (L ' . ($n['L'] ?? 0) . ', P ' . ($n['P'] ?? 0) . ')', array_keys($rek), $rek))) ?>.</p><?php endif ?>
<?= $this->endSection() ?>
