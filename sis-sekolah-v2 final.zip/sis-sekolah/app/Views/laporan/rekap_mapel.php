<?= $this->extend('layouts/cetak') ?>
<?= $this->section('isi') ?>
<table class="info">
    <tr><td>Mata Pelajaran</td><td>: <b><?= esc($p['nama_mapel']) ?></b></td><td style="width:40px"></td><td>Kelas</td><td>: <b><?= esc($p['nama_kelas']) ?></b></td></tr>
    <tr><td>Guru</td><td>: <?= esc(nama_guru($p)) ?></td><td></td><td>Periode</td><td>: <?= esc($periode) ?></td></tr>
</table>
<table class="data kecil">
    <thead>
        <tr><th rowspan="2">No</th><th rowspan="2">Nama Siswa</th><?php foreach ($jurnal as $j) : ?><th><?= date('d/m', strtotime($j['tanggal'])) ?></th><?php endforeach ?><th colspan="5">Jumlah</th><th rowspan="2">%</th></tr>
        <tr><?php foreach ($jurnal as $j) : ?><th><?= esc($j['pertemuan_ke']) ?></th><?php endforeach ?><th>H</th><th>S</th><th>I</th><th>A</th><th>D</th></tr>
    </thead>
    <tbody>
    <?php foreach ($siswa as $i => $s) : $c = ['H' => 0, 'S' => 0, 'I' => 0, 'A' => 0, 'D' => 0]; ?>
        <tr><td><?= $i + 1 ?></td><td class="kiri"><?= esc($s['nama_lengkap']) ?></td>
            <?php foreach ($jurnal as $j) : $st = $matriks[$s['id']][$j['id']] ?? ''; if ($st) { $c[$st]++; } ?>
                <td class="<?= $st && $st !== 'H' ? 'merah' : '' ?>"><?= $st === 'H' ? '•' : esc($st) ?></td>
            <?php endforeach ?>
            <?php foreach ($c as $n) : ?><td><?= $n ?></td><?php endforeach ?>
            <td><?= array_sum($c) ? round(($c['H'] + $c['D']) / array_sum($c) * 100) : '-' ?></td>
        </tr>
    <?php endforeach ?>
    </tbody>
</table>
<p class="kecil-teks">Keterangan: • hadir, S sakit, I izin, A alpa, D dispensasi. Baris kedua kepala tabel = pertemuan ke-. <?= ! $jurnal ? '<b>Belum ada jurnal pada periode ini.</b>' : '' ?></p>
<?= $this->endSection() ?>
