<?= $this->extend('layouts/cetak') ?>
<?= $this->section('isi') ?>
<table class="info">
    <tr><td>Kelas</td><td>: <b><?= esc($kelas['nama_kelas']) ?></b></td><td style="width:40px"></td><td>Periode</td><td>: <?= esc($periode) ?></td></tr>
</table>
<?php if (! $per) : ?><p class="tengah">Tidak ada catatan perilaku pada periode ini.</p><?php endif ?>
<?php $no = 0; foreach ($per as $p) :
    $pos = array_sum(array_map(static fn ($c) => $c['kategori'] === 'Positif' ? (int) $c['poin'] : 0, $p['catatan']));
    $neg = array_sum(array_map(static fn ($c) => $c['kategori'] === 'Negatif' ? (int) $c['poin'] : 0, $p['catatan'])); ?>
    <div class="bagian">
        <b><?= ++$no ?>. <?= esc($p['nama']) ?></b> (NIS <?= esc($p['nis']) ?>) — poin positif <b>+<?= $pos ?></b>, pelanggaran <b class="<?= $neg >= $batas ? 'merah' : '' ?>"><?= $neg ?></b><?= $neg >= $batas ? ' <span class="merah">(melewati batas ' . $batas . ')</span>' : '' ?>
        <table class="data">
            <thead><tr><th style="width:80px">Tanggal</th><th style="width:65px">Kategori</th><th>Perilaku & Uraian</th><th style="width:40px">Poin</th><th style="width:150px">Tindak Lanjut</th><th style="width:80px">Status</th></tr></thead>
            <tbody>
            <?php foreach ($p['catatan'] as $c) : ?>
                <tr>
                    <td><?= tgl_indo($c['tanggal']) ?></td><td class="tengah"><?= esc($c['kategori']) ?></td>
                    <td><b><?= esc($c['nama_jenis'] ?? 'Lainnya') ?></b><br><span class="kecil-teks"><?= esc($c['deskripsi']) ?></span></td>
                    <td class="tengah"><?= $c['kategori'] === 'Negatif' ? '-' : '+' ?><?= $c['poin'] ?></td>
                    <td class="kecil-teks"><?= esc($c['tindak_lanjut'] ?? '-') ?></td><td class="tengah kecil-teks"><?= esc($c['status']) ?></td>
                </tr>
            <?php endforeach ?>
            </tbody>
        </table>
    </div>
<?php endforeach ?>
<?= $this->endSection() ?>
