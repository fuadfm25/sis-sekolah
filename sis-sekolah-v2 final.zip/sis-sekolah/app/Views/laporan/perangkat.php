<?= $this->extend('layouts/cetak') ?>
<?= $this->section('isi') ?>
<?php
$kode = ['Disahkan' => '✓', 'Disetujui' => 'S', 'Diajukan' => 'P', 'Perlu Revisi' => 'R'];
$sel  = static fn (?array $p) => $p ? ($kode[$p['status']] ?? '?') : '–';
?>
<?php if ($guru) : ?>
<table class="info">
    <tr><td style="width:140px">Nama Guru</td><td>: <?= esc(nama_guru($guru)) ?></td></tr>
    <?php if ($guru['nip']) : ?><tr><td>NIP</td><td>: <?= esc($guru['nip']) ?></td></tr><?php endif ?>
</table>
<table class="data">
    <thead><tr><th style="width:26px">No</th><th>Perangkat Pembelajaran</th><th style="width:150px">Mata Pelajaran</th><th style="width:45px">Tingkat</th><th style="width:85px">Status</th><th style="width:80px">Tgl. Disahkan</th></tr></thead>
    <tbody>
    <?php $no = 0; foreach ($target as $t) : foreach ($jenis as $j) : $p = $peta[$t['guru_id'] . '|' . $t['mapel_id'] . '|' . $t['tingkat'] . '|' . $j['id']] ?? null;
        if (! $p && ! (int) $j['wajib']) { continue; } ?>
        <tr><td class="tengah"><?= ++$no ?></td><td><?= esc($j['nama']) ?></td><td><?= esc($t['nama_mapel']) ?></td><td class="tengah"><?= esc($t['tingkat']) ?></td>
            <td class="tengah"><?= $p ? esc($p['status']) . ' (v' . (int) $p['versi'] . ')' : 'Belum' ?></td><td class="tengah"><?= $p && $p['disahkan_at'] ? tgl_indo(substr($p['disahkan_at'], 0, 10)) : '' ?></td></tr>
    <?php endforeach; endforeach ?>
    <?php if (! $no) : ?><tr><td colspan="6" class="tengah">Tidak ada penugasan pada semester ini.</td></tr><?php endif ?>
    </tbody>
</table>
<p class="kecil-teks">Perangkat pembelajaran di atas telah diperiksa oleh Wakil Kepala Bidang Kurikulum dan dinyatakan layak digunakan pada <?= esc($subjudul) ?> apabila berstatus <i>Disahkan</i>.</p>
<?php else : ?>
<table class="data">
    <thead><tr><th style="width:24px">No</th><th>Nama Guru</th><th style="width:120px">Mata Pelajaran</th><th style="width:38px">Tkt</th>
        <?php foreach ($jenis as $i => $j) : ?><th style="width:34px" title="<?= esc($j['nama']) ?>"><?= $i + 1 ?><?= (int) $j['wajib'] ? '' : '*' ?></th><?php endforeach ?><th style="width:60px">Wajib Disetujui</th></tr></thead>
    <tbody>
    <?php foreach ($target as $n => $t) : $ok = 0; $wj = 0; ?>
        <tr><td class="tengah"><?= $n + 1 ?></td><td><?= esc($t['nama_guru']) ?></td><td><?= esc($t['nama_mapel']) ?></td><td class="tengah"><?= esc($t['tingkat']) ?></td>
        <?php foreach ($jenis as $j) : $p = $peta[$t['guru_id'] . '|' . $t['mapel_id'] . '|' . $t['tingkat'] . '|' . $j['id']] ?? null;
            if ((int) $j['wajib']) { $wj++; $ok += $p && in_array($p['status'], \App\Models\PerangkatModel::SELESAI, true) ? 1 : 0; } ?>
            <td class="tengah"><?= $sel($p) ?></td>
        <?php endforeach ?>
            <td class="tengah"><?= $ok ?>/<?= $wj ?></td></tr>
    <?php endforeach ?>
    <?php if (! $target) : ?><tr><td colspan="<?= 5 + count($jenis) ?>" class="tengah">Belum ada penugasan guru.</td></tr><?php endif ?>
    </tbody>
</table>
<p class="kecil-teks"><b>Keterangan kolom:</b> <?php $x = []; foreach ($jenis as $i => $j) { $x[] = ($i + 1) . '. ' . esc($j['nama']) . ((int) $j['wajib'] ? '' : '*'); } echo implode('; ', $x); ?> (* opsional).
<br><b>Kode:</b> ✓ disahkan kepala sekolah · S disetujui kurikulum · P diajukan, menunggu pemeriksaan · R perlu revisi · – belum dikumpulkan.</p>
<?php endif ?>
<?= $this->endSection() ?>
