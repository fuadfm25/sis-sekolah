<?= $this->extend('layouts/cetak') ?>
<?= $this->section('isi') ?>
<h4 style="margin:6px 0">A. Rekap Kehadiran per Kelas</h4>
<table class="data">
    <thead><tr><th style="width:30px">No</th><th>Kelas</th><th style="width:55px">Siswa</th><th style="width:45px">H</th><th style="width:45px">T</th><th style="width:45px">S</th><th style="width:45px">I</th><th style="width:45px">A</th><th style="width:110px">Keterangan</th></tr></thead>
    <tbody>
    <?php foreach ($kelas as $i => $k) : $r = $ringkas[$k['id']] ?? null; ?>
        <tr><td class="tengah"><?= $i + 1 ?></td><td><?= esc($k['nama_kelas']) ?></td><td class="tengah"><?= $k['jumlah_siswa'] ?></td>
            <?php foreach (['H', 'T', 'S', 'I', 'A'] as $st) : ?><td class="tengah"><?= $r ? (int) ($r[$st] ?? 0) : '' ?></td><?php endforeach ?>
            <td class="tengah <?= $r ? '' : 'merah' ?>"><?= $r ? '' : 'Belum diabsen' ?></td></tr>
    <?php endforeach ?>
    </tbody>
</table>

<h4 style="margin:12px 0 6px">B. Siswa Terlambat / Tidak Hadir</h4>
<table class="data">
    <thead><tr><th style="width:30px">No</th><th>Nama Siswa</th><th style="width:70px">Kelas</th><th style="width:80px">Status</th><th style="width:60px">Jam</th><th>Keterangan</th></tr></thead>
    <tbody>
    <?php foreach ($tidak as $i => $t) : ?>
        <tr><td class="tengah"><?= $i + 1 ?></td><td><?= esc($t['nama_lengkap']) ?></td><td class="tengah"><?= esc($t['nama_kelas']) ?></td><td class="tengah"><?= status_presensi()[$t['status']] ?></td><td class="tengah"><?= $t['jam_datang'] ? jam($t['jam_datang']) : '' ?></td><td><?= esc($t['keterangan'] ?? '') ?></td></tr>
    <?php endforeach ?>
    <?php if (! $tidak) : ?><tr><td colspan="6" class="tengah">Nihil.</td></tr><?php endif ?>
    </tbody>
</table>

<h4 style="margin:12px 0 6px">C. Siswa Izin Keluar, Pulang Awal &amp; Dispensasi</h4>
<table class="data">
    <thead><tr><th style="width:24px">No</th><th>Nama Siswa</th><th style="width:55px">Kelas</th><th style="width:75px">Jenis</th><th style="width:70px">Izin</th><th style="width:70px">Keluar / Kembali</th><th style="width:80px">Status</th><th>Keterangan</th></tr></thead>
    <tbody>
    <?php $no = 0; foreach (array_merge($pulang, $dispen) as $t) : ?>
        <tr><td class="tengah"><?= ++$no ?></td><td><?= esc($t['nama_lengkap']) ?></td><td class="tengah"><?= esc($t['nama_kelas']) ?></td>
            <td class="tengah"><?= esc(\App\Models\IzinSiswaModel::JENIS[$t['jenis']] ?? $t['jenis']) ?></td>
            <td class="tengah"><?= ! $t['jam_keluar'] ? 'sehari' : (! empty($t['batas_kembali']) ? jam($t['jam_keluar']) . '–' . jam($t['batas_kembali']) : 'pulang ' . jam($t['jam_keluar'])) ?></td>
            <td class="tengah"><?= ! empty($t['keluar_at']) ? substr($t['keluar_at'], 11, 5) : '-' ?><?= ! empty($t['batas_kembali']) ? ' / ' . (! empty($t['kembali_at']) ? substr($t['kembali_at'], 11, 5) : '-') : '' ?></td>
            <td class="tengah"><?php $sk = $t['jam_keluar'] ? \App\Libraries\IzinKeluar::status($t) : null; ?><?= $sk ? esc($sk['status']) . ($sk['menit'] ? ' (' . $sk['menit'] . ' mnt)' : '') : '-' ?></td>
            <td><?= esc(trim(($t['keterangan'] ?? '') . (! empty($t['penjemput']) ? ' · dijemput ' . $t['penjemput'] : ''), ' ·')) ?></td></tr>
    <?php endforeach ?>
    <?php if (! $no) : ?><tr><td colspan="8" class="tengah">Nihil.</td></tr><?php endif ?>
    </tbody>
</table>

<h4 style="margin:12px 0 6px">D. Jurnal Mengajar Belum Diisi (<?= count($belum) ?> dari <?= $sesi ?> sesi)</h4>
<table class="data">
    <thead><tr><th style="width:30px">No</th><th style="width:70px">Kelas</th><th style="width:60px">Jam</th><th>Mata Pelajaran</th><th>Guru</th><th style="width:120px">Keterangan</th></tr></thead>
    <tbody>
    <?php foreach ($belum as $i => $b) : ?>
        <tr><td class="tengah"><?= $i + 1 ?></td><td class="tengah"><?= esc($b['nama_kelas']) ?></td><td class="tengah"><?= esc($b['jam_ke_label']) ?></td><td><?= esc($b['nama_mapel']) ?></td><td><?= esc(nama_guru($b)) ?></td><td></td></tr>
    <?php endforeach ?>
    <?php if (! $belum) : ?><tr><td colspan="6" class="tengah"><?= $sesi ? 'Semua jurnal sudah terisi.' : 'Tidak ada KBM terjadwal.' ?></td></tr><?php endif ?>
    </tbody>
</table>
<p class="kecil-teks">Catatan kejadian lain: ...........................................................................................................................................................</p>
<?= $this->endSection() ?>
