<?= $this->extend('layouts/cetak') ?>
<?= $this->section('isi') ?>
<h4 style="margin:6px 0">A. Rincian per Bulan</h4>
<table class="data">
    <thead><tr><th style="width:30px">No</th><th>Bulan</th><th style="width:70px">Jumlah Pekan</th><th style="width:80px">Pekan Tidak Efektif</th><th style="width:70px">Pekan Efektif</th><th style="width:70px">Hari Sekolah</th><th style="width:70px">Hari Efektif</th><th>Keterangan (kalender akademik)</th></tr></thead>
    <tbody>
    <?php foreach ($data['bulan'] as $i => $b) : ?>
        <tr><td class="tengah"><?= $i + 1 ?></td><td><?= bulan_list()[(int) substr($b['ym'], 5, 2)] . ' ' . substr($b['ym'], 0, 4) ?></td>
            <td class="tengah"><?= $b['pekan'] ?></td><td class="tengah"><?= $b['pekan'] - $b['pekan_efektif'] ?></td><td class="tengah"><b><?= $b['pekan_efektif'] ?></b></td>
            <td class="tengah"><?= $b['hari_sekolah'] ?></td><td class="tengah"><b><?= $b['hari_efektif'] ?></b></td>
            <td class="kecil-teks"><?php $x = []; foreach ($b['agenda'] as $a) { $x[] = esc($a['nama']) . ' (' . ($a['tanggal_mulai'] === $a['tanggal_selesai'] ? date('j/n', strtotime($a['tanggal_mulai'])) : date('j/n', strtotime($a['tanggal_mulai'])) . '–' . date('j/n', strtotime($a['tanggal_selesai']))) . ')'; } echo implode('; ', $x); ?></td></tr>
    <?php endforeach ?>
    <tr><th colspan="2" class="kanan">Jumlah</th><th><?= $data['total']['pekan'] ?></th><th><?= $data['total']['pekan'] - $data['total']['pekan_efektif'] ?></th><th><?= $data['total']['pekan_efektif'] ?></th><th><?= $data['total']['hari_sekolah'] ?></th><th><?= $data['total']['hari_efektif'] ?></th><th></th></tr>
    </tbody>
</table>

<h4 style="margin:12px 0 6px">B. Hari Efektif per Hari</h4>
<table class="data" style="width:auto">
    <tr><?php foreach ($data['per_hari'] as $h => $n) : ?><th style="width:70px"><?= nama_hari($h) ?></th><?php endforeach ?><th style="width:70px">Jumlah</th></tr>
    <tr class="tengah"><?php foreach ($data['per_hari'] as $n) : ?><td><?= $n ?></td><?php endforeach ?><td><b><?= array_sum($data['per_hari']) ?></b></td></tr>
</table>

<?php if ($guru) : ?>
<h4 style="margin:12px 0 6px">C. Jam Pelajaran Efektif – <?= esc(nama_guru($guru)) ?></h4>
<table class="data">
    <thead><tr><th style="width:30px">No</th><th>Mata Pelajaran</th><th style="width:70px">Kelas</th><th style="width:60px">JP/Pekan</th><th style="width:110px">JP Efektif (pekan efektif × JP)</th><th style="width:110px">JP Efektif (menurut jadwal & kalender)</th><th>Rincian jadwal</th></tr></thead>
    <tbody>
    <?php foreach ($mapel as $i => $m) : ?>
        <tr><td class="tengah"><?= $i + 1 ?></td><td><?= esc($m['nama_mapel']) ?></td><td class="tengah"><?= esc($m['nama_kelas']) ?></td><td class="tengah"><?= $m['jp_per_minggu'] ?></td>
            <td class="tengah"><?= $m['jp_prota'] ?></td><td class="tengah"><b><?= $m['jp_efektif'] ?></b></td><td class="kecil-teks"><?= esc($m['rinci'] ?: 'belum dijadwalkan') ?></td></tr>
    <?php endforeach ?>
    <?php if (! $mapel) : ?><tr><td colspan="7" class="tengah">Belum ada penugasan mengajar.</td></tr><?php endif ?>
    </tbody>
</table>
<?php endif ?>
<p class="kecil-teks">Pekan dihitung Senin–Minggu dan masuk ke bulan tempat hari sekolah pertamanya. Pekan efektif = pekan yang memiliki minimal satu hari KBM.
Hari efektif = hari sekolah yang tidak ditandai libur/ujian/kegiatan tanpa KBM pada kalender akademik. Kolom "menurut jadwal & kalender" menghitung slot jadwal pada hari yang benar-benar efektif, sehingga lebih tepat daripada perkalian pekan efektif.</p>
<?= $this->endSection() ?>
