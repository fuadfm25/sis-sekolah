<?= $this->extend('layouts/cetak') ?>
<?= $this->section('isi') ?>
<table class="info"><tr><td>Periode</td><td>: <?= esc($periode) ?></td></tr></table>
<table class="data">
    <thead><tr><th style="width:28px">No</th><th style="width:85px">Tanggal</th><th style="width:130px">Jenis Layanan / Komponen</th><th style="width:60px">Bidang</th><th style="width:150px">Peserta</th><th>Topik / Permasalahan</th><th>Hasil & Tindak Lanjut</th><th style="width:70px">Status</th><th style="width:100px">Konselor</th></tr></thead>
    <tbody>
    <?php foreach ($rows as $i => $l) : ?>
        <tr>
            <td class="tengah"><?= $i + 1 ?></td><td><?= tgl_indo($l['tanggal']) ?></td><td><?= esc($l['jenis_layanan']) ?><br><span class="kecil-teks"><?= esc(($l['komponen'] ?? '') . ($l['format'] ? ' · ' . $l['format'] : '')) ?></span></td><td><?= esc($l['bidang']) ?></td>
            <td class="kecil-teks"><?= esc(implode(', ', array_column($l['peserta'], 'nama_lengkap'))) ?><?= $l['nama_kelas'] ? ($l['peserta'] ? '; ' : '') . 'Kelas ' . esc($l['nama_kelas']) : '' ?></td>
            <?php if ($l['tersembunyi']) : ?>
                <td colspan="2" class="tengah"><i>Rahasia – hanya dapat dibuka konselor</i></td>
            <?php else : ?>
                <td><b><?= esc($l['topik']) ?></b><?= $l['permasalahan'] ? '<br><span class="kecil-teks">' . esc($l['permasalahan']) . '</span>' : '' ?></td>
                <td class="kecil-teks"><?= esc($l['hasil'] ?? '') ?><?= $l['rencana_tindak_lanjut'] ? '<br><i>RTL: ' . esc($l['rencana_tindak_lanjut']) . '</i>' : '' ?></td>
            <?php endif ?>
            <td class="tengah"><?= esc($l['status']) ?></td><td class="kecil-teks"><?= esc($l['konselor']) ?></td>
        </tr>
    <?php endforeach ?>
    <?php if (! $rows) : ?><tr><td colspan="9" class="tengah">Tidak ada layanan pada periode ini.</td></tr><?php endif ?>
    </tbody>
</table>
<?php if ($statistik) : ?>
<p class="kecil-teks"><b>Per komponen:</b> <?php $x = []; foreach ($perKomponen as $j => $n) { $x[] = esc($j) . ' ' . $n; } echo implode(' · ', $x); ?>.
<b>Per bidang:</b> <?php $x = []; foreach ($perBidang as $j => $n) { $x[] = esc($j) . ' ' . $n; } echo implode(' · ', $x); ?>.</p>
<p class="kecil-teks"><b>Per jenis:</b> <?php $x = []; foreach ($statistik as $j => $n) { $x[] = esc($j) . ' ' . $n; } echo implode(' · ', $x); ?> · Total <?= count($rows) ?> layanan.</p>
<?php endif ?>
<?= $this->endSection() ?>
