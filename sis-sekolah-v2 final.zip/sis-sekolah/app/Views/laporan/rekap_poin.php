<?= $this->extend('layouts/cetak') ?>
<?= $this->section('isi') ?>
<table class="data">
    <thead><tr><th style="width:30px">No</th><th>Nama Siswa</th><th style="width:70px">NIS</th><th style="width:70px">Kelas</th><th style="width:60px">Catatan</th><th style="width:70px">Positif</th><th style="width:80px">Pelanggaran</th><th style="width:60px">Selisih</th></tr></thead>
    <tbody>
    <?php foreach ($rows as $i => $r) : $lewat = (int) $r['poin_negatif'] >= $batas; ?>
        <tr><td class="tengah"><?= $i + 1 ?></td><td><?= esc($r['nama_siswa']) ?><?= $lewat ? ' <span class="merah">*</span>' : '' ?></td><td><?= esc($r['nis']) ?></td><td class="tengah"><?= esc($r['nama_kelas'] ?? '-') ?></td>
            <td class="tengah"><?= $r['jumlah_catatan'] ?></td><td class="tengah">+<?= (int) $r['poin_positif'] ?></td><td class="tengah <?= $lewat ? 'merah' : '' ?>"><?= (int) $r['poin_negatif'] ?></td><td class="tengah"><?= (int) $r['poin_positif'] - (int) $r['poin_negatif'] ?></td></tr>
    <?php endforeach ?>
    <?php if (! $rows) : ?><tr><td colspan="8" class="tengah">Belum ada catatan perilaku.</td></tr><?php endif ?>
    </tbody>
</table>
<p class="kecil-teks">* poin pelanggaran ≥ <?= $batas ?> (batas peringatan BK).</p>
<?= $this->endSection() ?>
