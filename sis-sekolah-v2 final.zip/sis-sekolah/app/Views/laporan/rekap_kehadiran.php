<?= $this->extend('layouts/cetak') ?>
<?= $this->section('isi') ?>
<table class="data">
    <thead><tr><th style="width:30px">No</th><th>Kelas</th><th>Wali Kelas</th><th style="width:50px">Siswa</th><th style="width:45px">H</th><th style="width:45px">T</th><th style="width:45px">S</th><th style="width:45px">I</th><th style="width:45px">A</th><th style="width:70px">% Hadir</th></tr></thead>
    <tbody>
    <?php $tot = ['H' => 0, 'T' => 0, 'S' => 0, 'I' => 0, 'A' => 0]; $siswa = 0;
    foreach ($rows as $i => $r) : $siswa += $r['jumlah_siswa']; ?>
        <tr><td class="tengah"><?= $i + 1 ?></td><td><?= esc($r['nama_kelas']) ?></td><td><?= $r['wali_nama'] ? esc(nama_guru($r, 'wali_')) : '-' ?></td><td class="tengah"><?= $r['jumlah_siswa'] ?></td>
            <?php foreach ($tot as $k => $_) : $n = $r['h'][$k] ?? 0; $tot[$k] += $n; ?><td class="tengah"><?= $n ?></td><?php endforeach ?>
            <td class="tengah"><?= $r['persen'] === null ? 'belum diisi' : $r['persen'] . '%' ?></td></tr>
    <?php endforeach ?>
    <?php $all = array_sum($tot); ?>
    <tr><th colspan="3" class="kanan">Jumlah</th><th><?= $siswa ?></th><?php foreach ($tot as $n) : ?><th><?= $n ?></th><?php endforeach ?><th><?= $all ? round(($tot['H'] + $tot['T']) / $all * 100, 1) . '%' : '-' ?></th></tr>
    </tbody>
</table>
<p class="kecil-teks">Angka = jumlah catatan absensi harian (siswa × hari). % hadir = (H + T) ÷ seluruh catatan.</p>
<?= $this->endSection() ?>
