<?= $this->extend('layouts/cetak') ?>
<?= $this->section('isi') ?>
<?php $tuntas = count(array_filter($rows, static fn ($r) => $r['pertemuan'] > 0)); ?>
<table class="info">
    <tr><td>Mata pelajaran</td><td>: <b><?= esc($pilih['nama_mapel']) ?></b></td><td style="width:40px"></td><td>Kelas</td><td>: <?= esc($kelas['nama_kelas']) ?></td></tr>
    <tr><td>Guru</td><td>: <?= esc(nama_guru($guru)) ?></td><td></td><td>TP dibahas</td><td>: <?= $tuntas ?> dari <?= count($rows) ?> (<?= count($rows) ? round($tuntas / count($rows) * 100) : 0 ?>%)</td></tr>
</table>
<table class="data">
    <thead><tr><th style="width:28px">No</th><th style="width:50px">Kode</th><th>Tujuan Pembelajaran</th><th style="width:45px">Alokasi JP</th><th style="width:45px">JP terpakai</th><th style="width:45px">Pertemuan</th><th style="width:130px">Tanggal</th></tr></thead>
    <tbody>
    <?php foreach ($rows as $i => $r) : ?>
        <tr><td class="tengah"><?= $i + 1 ?></td><td><?= esc($r['kode']) ?></td><td><?= esc($r['tujuan']) ?><?= $r['elemen'] ? '<br><i class="kecil-teks">' . esc($r['elemen']) . '</i>' : '' ?></td>
            <td class="tengah"><?= $r['alokasi_jp'] ?: '-' ?></td><td class="tengah <?= $r['alokasi_jp'] && $r['jp'] > $r['alokasi_jp'] ? 'merah' : '' ?>"><?= $r['jp'] ?: '-' ?></td>
            <td class="tengah <?= $r['pertemuan'] ? '' : 'merah' ?>"><?= $r['pertemuan'] ?: 'belum' ?></td>
            <td class="nowrap"><?= $r['awal'] ? tgl_indo($r['awal']) . ($r['akhir'] !== $r['awal'] ? ' – ' . tgl_indo($r['akhir']) : '') : '' ?></td></tr>
    <?php endforeach ?>
    <?php if (! $rows) : ?><tr><td colspan="7" class="tengah">Belum ada ATP untuk mapel & tingkat ini.</td></tr><?php endif ?>
    </tbody>
</table>
<p class="kecil-teks">Sumber: TP yang dicentang guru pada jurnal pembelajaran. JP terpakai merah = melebihi alokasi.</p>
<?= $this->endSection() ?>
