<?= $this->extend('layouts/cetak') ?>
<?= $this->section('isi') ?>
<table class="info"><tr><td>Kelas</td><td>: <b><?= esc($kelas['nama_kelas']) ?></b></td><td style="width:40px"></td><td>Periode</td><td>: <?= esc($periode) ?></td></tr></table>
<table class="data kecil">
    <thead><tr><th style="width:24px">No</th><th>Nama Siswa</th><?php foreach ($pembiasaan as $p) : ?><th><?= esc($p['nama']) ?></th><?php endforeach ?><th>Rata-rata</th></tr></thead>
    <tbody>
    <?php foreach ($siswa as $i => $s) : $sum = 0; $n = 0; ?>
        <tr><td><?= $i + 1 ?></td><td class="kiri"><?= esc($s['nama_lengkap']) ?></td>
            <?php foreach ($pembiasaan as $p) : $d = $data[$s['id']][$p['id']] ?? null; ?>
                <?php if ($d && $d['total']) : $pct = round($d['ya'] / $d['total'] * 100); $sum += $pct; $n++; ?>
                    <td class="<?= $pct < 60 ? 'merah' : '' ?>"><?= $pct ?>%</td>
                <?php else : ?><td>-</td><?php endif ?>
            <?php endforeach ?>
            <td><b><?= $n ? round($sum / $n) . '%' : '-' ?></b></td></tr>
    <?php endforeach ?>
    </tbody>
</table>
<p class="kecil-teks">Persentase = hari terlaksana ÷ hari tercatat. Merah = di bawah 60%.</p>
<?= $this->endSection() ?>
