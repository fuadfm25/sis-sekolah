<?php
/**
 * $ttd = [
 *   'kiri'  => ['atas' => 'Mengetahui,', 'jabatan' => 'Kepala Sekolah', 'nama' => '...', 'nip' => '...'|null] | null,
 *   'kanan' => ['jabatan' => 'Wali Kelas', 'nama' => '...', 'nip' => ...],
 * ]
 * Bila nama kosong, dicetak titik-titik. Bila nip kosong/null, baris NIP tidak dicetak.
 */
$blok = static function (?array $b, bool $tanggal) {
    if (! $b) {
        return '<div></div>';
    }
    $h  = '<div>';
    $h .= $tanggal ? esc(setting('kota', '') ? setting('kota') . ', ' : '') . tgl_indo(date('Y-m-d')) . '<br>' : (isset($b['atas']) ? esc($b['atas']) . '<br>' : '<br>');
    $h .= esc($b['jabatan'] ?? '') . '<div class="ruang"></div>';
    $h .= '<div class="nama">' . (trim((string) ($b['nama'] ?? '')) !== '' ? esc($b['nama']) : '.................................................') . '</div>';
    if (! empty($b['nip'])) {
        $h .= '<div>NIP. ' . esc($b['nip']) . '</div>';
    }
    return $h . '</div>';
};
?>
<div class="ttd"><table class="ttd-tabel"><tr>
    <td><?= $blok($ttd['kiri'] ?? null, false) ?></td>
    <td><?= $blok($ttd['kanan'] ?? null, true) ?></td>
</tr></table></div>
