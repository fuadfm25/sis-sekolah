<?= $this->extend('layouts/cetak') ?>
<?= $this->section('isi') ?>
<table class="info"><tr><td>Periode</td><td>: <?= esc($periode) ?></td></tr></table>
<table class="data">
    <thead><tr><th style="width:30px">No</th><th>Nama Guru</th><th style="width:80px">Sesi Terjadwal</th><th style="width:60px">JP</th><th style="width:80px">Jurnal Terisi</th><th style="width:80px">Belum Diisi</th><th style="width:70px">%</th></tr></thead>
    <tbody>
    <?php $no = 0; $ts = $ti = 0; foreach ($guru as $g) : $ts += $g['sesi']; $ti += $g['isi']; $p = $g['sesi'] ? round($g['isi'] / $g['sesi'] * 100) : 0; ?>
        <tr><td class="tengah"><?= ++$no ?></td><td><?= esc($g['nama']) ?></td><td class="tengah"><?= $g['sesi'] ?></td><td class="tengah"><?= $g['jp'] ?></td><td class="tengah"><?= $g['isi'] ?></td>
            <td class="tengah <?= $g['sesi'] - $g['isi'] ? 'merah' : '' ?>"><?= $g['sesi'] - $g['isi'] ?></td><td class="tengah"><?= $p ?>%</td></tr>
    <?php endforeach ?>
    <?php if (! $guru) : ?><tr><td colspan="7" class="tengah">Tidak ada jadwal pada periode ini.</td></tr><?php endif ?>
    <tr><th colspan="2" class="kanan">Jumlah</th><th><?= $ts ?></th><th></th><th><?= $ti ?></th><th><?= $ts - $ti ?></th><th><?= $ts ? round($ti / $ts * 100) : 0 ?>%</th></tr>
    </tbody>
</table>
<p class="kecil-teks">Sesi = blok jam berurutan untuk mapel yang sama di satu kelas pada satu hari (satu sesi = satu jurnal). Hari tanpa KBM menurut kalender akademik (libur, ujian, kegiatan) tidak dihitung.</p>
<?= $this->endSection() ?>
