<?= $this->extend('layouts/cetak') ?>
<?= $this->section('isi') ?>
<?php $kode = array_keys(\App\Models\PresensiGuruModel::STATUS); ?>
<table class="data kecil">
    <thead>
        <tr><th rowspan="2" style="width:22px">No</th><th rowspan="2">Nama Guru</th><th rowspan="2">NIP</th>
            <th colspan="<?= $jml ?>">Tanggal</th><th colspan="<?= count($kode) ?>">Jumlah</th></tr>
        <tr><?php for ($d = 1; $d <= $jml; $d++) : ?><th class="<?= $libur[$d] ? 'libur' : '' ?>" style="width:17px"><?= $d ?></th><?php endfor ?>
            <?php foreach ($kode as $k) : ?><th style="width:20px"><?= $k ?></th><?php endforeach ?></tr>
    </thead>
    <tbody>
    <?php foreach ($guru as $i => $g) : $c = array_fill_keys($kode, 0); ?>
        <tr><td><?= $i + 1 ?></td><td class="kiri"><?= esc(nama_guru($g)) ?></td><td class="kiri"><?= esc($g['nip'] ?: '-') ?></td>
            <?php for ($d = 1; $d <= $jml; $d++) : $st = $matriks[$g['id']][$d] ?? ''; if ($st) { $c[$st]++; } ?>
                <td class="<?= $libur[$d] ? 'libur' : '' ?> <?= in_array($st, ['A', 'S', 'I'], true) ? 'merah' : '' ?>"><?= $st === 'H' ? '•' : esc($st) ?></td>
            <?php endfor ?>
            <?php foreach ($c as $n) : ?><td><?= $n ?: '' ?></td><?php endforeach ?></tr>
    <?php endforeach ?>
    </tbody>
</table>
<p class="kecil-teks">Keterangan: • hadir · T terlambat · S sakit · I izin · DL dinas luar · C cuti · A tanpa keterangan · kolom abu-abu = bukan hari sekolah. Hari sekolah bulan ini: <b><?= $efektif ?></b> hari.</p>
<?= $this->endSection() ?>
