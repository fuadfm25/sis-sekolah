<?= $this->extend('layouts/main') ?>
<?= $this->section('content') ?>
<?php $jamS = (int) date('G'); $sapa = $jamS < 11 ? 'Selamat pagi' : ($jamS < 15 ? 'Selamat siang' : ($jamS < 18 ? 'Selamat sore' : 'Selamat malam')); ?>
<div class="sis-hero mb-4">
    <div>
        <div class="kecil"><?= tgl_indo(date('Y-m-d'), true) ?></div>
        <h2><?= $sapa ?>, <?= esc(strtok((string) session('nama_lengkap'), ',')) ?></h2>
        <p class="mb-0"><?= $tp ? 'Tahun Pelajaran ' . esc($tp['tahun_pelajaran']) . ' · Semester ' . esc($tp['semester']) : 'Tahun pelajaran aktif belum diatur' ?><?= setting('nama_sekolah') ? ' · ' . esc(setting('nama_sekolah')) : '' ?></p>
    </div>
    <img src="<?= logo_url() ?? logo_aplikasi() ?>" alt="" class="d-none d-md-block">
</div>

<?php if (! $tp) : ?>
    <div class="alert alert-warning">
        <i class="bi bi-exclamation-triangle me-1"></i> Belum ada Tahun Pelajaran aktif.
        <?php if (\App\Libraries\Akses::punya('kurikulum')) : ?><a href="<?= site_url('akademik/tahun-pelajaran') ?>" class="alert-link">Atur sekarang</a>.<?php endif ?>
    </div>
<?php endif ?>

<?php if ($statusHari && ($statusHari['agenda'] || ! $statusHari['sekolah'])) : ?>
    <div class="alert alert-<?= $statusHari['warna'] === 'success' ? 'light' : $statusHari['warna'] ?> bg-opacity-25 d-flex justify-content-between align-items-center">
        <span><i class="bi bi-calendar-event"></i> <b>Hari ini:</b> <?= esc($statusHari['label']) ?>
            <?= $statusHari['sekolah'] ? ' · ' . ($statusHari['kbm'] ? 'KBM berjalan' : 'tanpa KBM/jurnal') . ' · ' . ($statusHari['absensi'] ? 'absensi diambil' : 'tanpa absensi') : '' ?></span>
        <a href="<?= site_url('kalender') ?>" class="small">Kalender &raquo;</a>
    </div>
<?php endif ?>

<?php if (! empty($perangkatInfo)) : ?>
    <div class="alert alert-info d-flex flex-wrap gap-3 align-items-center"><i class="bi bi-folder-check"></i>
        <?php if (! empty($perangkatInfo['revisi'])) : ?><a class="alert-link" href="<?= site_url('perangkat') ?>"><?= $perangkatInfo['revisi'] ?> perangkat pembelajaran Anda perlu revisi</a><?php endif ?>
        <?php if (! empty($perangkatInfo['diajukan'])) : ?><a class="alert-link" href="<?= site_url('perangkat/pemeriksaan?status=Diajukan') ?>"><?= $perangkatInfo['diajukan'] ?> perangkat menunggu pemeriksaan</a><?php endif ?>
        <?php if (! empty($perangkatInfo['sahkan'])) : ?><a class="alert-link" href="<?= site_url('perangkat/pemeriksaan?status=Disetujui') ?>"><?= $perangkatInfo['sahkan'] ?> perangkat siap disahkan</a><?php endif ?>
    </div>
<?php endif ?>

<?php if (! empty($stat)) : ?>
<div class="row">
    <?php foreach ([
        ['Siswa Aktif', $stat['siswa'], 'people-fill', 'biru'],
        ['Guru', $stat['guru'], 'person-badge-fill', 'hijau'],
        ['Kelas', $stat['kelas'], 'door-open-fill', 'emas'],
        ['Jurnal Hari Ini', $stat['jurnal_terisi'] . ' / ' . $stat['sesi_hari_ini'], 'journal-check', 'merah'],
    ] as [$label, $val, $icon, $color]) : ?>
        <div class="col-6 col-lg-3">
            <div class="card">
                <div class="card-body stat-card">
                    <div class="stat-ikon <?= $color ?>"><i class="bi bi-<?= $icon ?>"></i></div>
                    <div><div class="text-muted small fw-semibold"><?= $label ?></div><div class="stat-angka"><?= esc($val) ?></div></div>
                </div>
            </div>
        </div>
    <?php endforeach ?>
</div>
<div class="card">
    <div class="card-body py-3">
        <strong>Absensi pagi hari ini</strong> <span class="text-muted small">(<?= $kelasTerabsen ?> kelas sudah diabsen)</span>:
        <?php foreach ($presensiHariIni as $st => $n) : ?>
            <span class="ms-3"><?= badge_presensi($st) ?> <?= status_presensi()[$st] ?>: <strong><?= $n ?></strong></span>
        <?php endforeach ?>
        <?php if (\App\Libraries\Akses::jurnalMonitoring()) : ?>
            <a href="<?= site_url('jurnal/monitoring') ?>" class="btn btn-sm btn-outline-primary float-end">Monitoring Jurnal</a>
        <?php endif ?>
    </div>
</div>
<?php endif ?>

<div class="row">
    <?php if (isset($sesiSaya)) : ?>
    <div class="col-lg-7">
        <div class="card">
            <div class="card-header d-flex justify-content-between">
                <h5 class="card-title mb-0"><i class="bi bi-calendar-day me-1"></i> Jadwal Mengajar Hari Ini</h5>
                <a href="<?= site_url('jurnal') ?>" class="small">Semua &raquo;</a>
            </div>
            <div class="card-body">
                <?php if (! $sesiSaya) : ?>
                    <p class="text-muted mb-0"><?= $statusHari && ! $statusHari['kbm'] ? 'Tidak ada KBM hari ini (' . esc($statusHari['label']) . ').' : 'Tidak ada jadwal mengajar hari ini.' ?></p>
                <?php else : ?>
                    <div class="list-group">
                    <?php foreach ($sesiSaya as $s) : ?>
                        <div class="list-group-item d-flex justify-content-between align-items-center">
                            <div>
                                <strong><?= esc($s['nama_mapel']) ?></strong> &middot; <?= esc($s['nama_kelas']) ?><br>
                                <small class="text-muted">Jam ke-<?= esc($s['jam_ke_label']) ?> (<?= jam($s['jam_mulai']) ?>–<?= jam($s['jam_selesai']) ?>)</small>
                            </div>
                            <?php if ($s['jurnal']) : ?>
                                <a href="<?= site_url('jurnal/isi/' . $s['id'] . '?tanggal=' . $today) ?>" class="btn btn-sm btn-success"><i class="bi bi-check2-circle"></i> Terisi</a>
                            <?php else : ?>
                                <a href="<?= site_url('jurnal/isi/' . $s['id'] . '?tanggal=' . $today) ?>" class="btn btn-sm btn-primary"><i class="bi bi-pencil-square"></i> Isi Jurnal</a>
                            <?php endif ?>
                        </div>
                    <?php endforeach ?>
                    </div>
                <?php endif ?>
            </div>
        </div>
    </div>
    <?php endif ?>

    <?php if (! empty($kelasWali)) : ?>
    <div class="col-lg-5">
        <?php foreach ($kelasWali as $k) : ?>
        <div class="card">
            <div class="card-header"><h5 class="card-title mb-0"><i class="bi bi-house-heart me-1"></i> Kelas Perwalian: <?= esc($k['nama_kelas']) ?></h5></div>
            <div class="card-body">
                <p class="mb-2"><?= $k['jumlah_siswa'] ?> siswa aktif.</p>
                <?php if ($k['presensi']) : ?>
                    <p class="mb-3">Absensi pagi:
                        <?php foreach ($k['presensi'] as $st => $n) : ?><span class="me-2"><?= badge_presensi($st) ?> <?= $n ?></span><?php endforeach ?>
                    </p>
                <?php else : ?>
                    <p class="text-danger small mb-3"><i class="bi bi-exclamation-circle"></i> Absensi pagi hari ini belum diisi.</p>
                <?php endif ?>
                <a href="<?= site_url('absensi-pagi?kelas_id=' . $k['id']) ?>" class="btn btn-sm btn-outline-primary">Absensi Pagi</a>
                <a href="<?= site_url('pembiasaan?kelas_id=' . $k['id']) ?>" class="btn btn-sm btn-outline-success">Pembiasaan</a>
                <a href="<?= site_url('perilaku?kelas_id=' . $k['id']) ?>" class="btn btn-sm btn-outline-danger">Perilaku</a>
            </div>
        </div>
        <?php endforeach ?>
    </div>
    <?php endif ?>
</div>

<?php if ($agendaNanti) : ?>
<div class="card">
    <div class="card-header d-flex justify-content-between"><h5 class="card-title mb-0"><i class="bi bi-calendar3-event me-1"></i> Agenda Akademik Mendatang</h5><a href="<?= site_url('kalender') ?>" class="small">Kalender &raquo;</a></div>
    <div class="card-body">
        <div class="row g-2">
        <?php foreach ($agendaNanti as $a) : $w = \App\Models\KalenderModel::BAWAAN[$a['jenis']][2] ?? 'info'; ?>
            <div class="col-md-6 col-xl-4"><div class="border-start border-3 border-<?= $w ?> ps-2">
                <div class="fw-semibold"><?= esc($a['nama']) ?></div>
                <small class="text-muted"><?= esc($a['jenis']) ?> · <?= $a['tanggal_mulai'] === $a['tanggal_selesai'] ? tgl_indo($a['tanggal_mulai'], true) : tgl_indo($a['tanggal_mulai']) . ' – ' . tgl_indo($a['tanggal_selesai']) ?></small>
            </div></div>
        <?php endforeach ?>
        </div>
    </div>
</div>
<?php endif ?>

<?php if (isset($perilakuTerbaru)) : ?>
<div class="row">
    <div class="col-lg-7">
        <div class="card">
            <div class="card-header d-flex justify-content-between">
                <h5 class="card-title mb-0">Catatan Perilaku Terbaru</h5>
                <a href="<?= site_url('perilaku') ?>" class="small">Semua &raquo;</a>
            </div>
            <div class="card-body">
                <table class="table table-sm mb-0">
                    <?php foreach ($perilakuTerbaru as $p) : ?>
                        <tr>
                            <td class="text-nowrap"><?= tgl_indo($p['tanggal']) ?></td>
                            <td><a href="<?= site_url('siswa/profil/' . $p['siswa_id']) ?>"><?= esc($p['nama_siswa']) ?></a> <small class="text-muted"><?= esc($p['nama_kelas']) ?></small></td>
                            <td><?= badge_status($p['kategori']) ?></td>
                            <td><?= esc(character_limiter($p['nama_jenis'] ?: $p['deskripsi'], 40)) ?></td>
                        </tr>
                    <?php endforeach ?>
                    <?php if (! $perilakuTerbaru) : ?><tr><td class="text-muted">Belum ada catatan.</td></tr><?php endif ?>
                </table>
            </div>
        </div>
    </div>
    <div class="col-lg-5">
        <div class="card">
            <div class="card-body">
                <h6>Rujukan BK menunggu: <span class="badge bg-warning fs-6"><?= $rujukanBaru ?></span></h6>
                <?php if (has_role('bk')) : ?><a href="<?= site_url('bk/rujukan') ?>" class="small">Lihat rujukan &raquo;</a><?php endif ?>
                <hr>
                <h6>Siswa dengan poin pelanggaran &ge; <?= $batasPoin ?></h6>
                <?php if (! $siswaMelewati) : ?>
                    <p class="text-muted small mb-0">Tidak ada.</p>
                <?php else : ?>
                    <ul class="mb-0 ps-3">
                        <?php foreach (array_slice($siswaMelewati, 0, 10) as $s) : ?>
                            <li><a href="<?= site_url('siswa/profil/' . $s['siswa_id']) ?>"><?= esc($s['nama_siswa']) ?></a> (<?= esc($s['nama_kelas']) ?>) – <strong class="text-danger"><?= $s['poin_negatif'] ?></strong></li>
                        <?php endforeach ?>
                    </ul>
                <?php endif ?>
            </div>
        </div>
    </div>
</div>
<?php endif ?>

<?= $this->endSection() ?>
