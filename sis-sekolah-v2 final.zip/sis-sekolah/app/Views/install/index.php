<?= view('install/_layout_atas') ?>
<div class="card">
    <h1>Pemasangan SIS Sekolah</h1>
    <div>Isi formulir sekali saja. Pemasang akan membuat database, tabel, data awal, akun admin, dan file konfigurasi <code>.env</code>.</div>
</div>
<?php if ($e = session('errors')) : ?><div class="alert alert-danger"><?php foreach ((array) $e as $x) : ?><div><?= esc($x) ?></div><?php endforeach ?></div><?php endif ?>

<div class="card">
    <h2>1. Pemeriksaan server</h2>
    <table>
        <?php foreach ($cek as [$nama, $ok, $ket]) : ?>
            <tr><td><?= esc($nama) ?></td><td class="<?= $ok ? 'ok' : 'no' ?>"><?= $ok ? '✔' : '✘' ?></td><td><small><?= esc($ket) ?></small></td></tr>
        <?php endforeach ?>
    </table>
    <?php if (! $siap) : ?><div class="alert alert-danger" style="margin-top:12px">Perbaiki item bertanda ✘ (selain yang "disarankan"), lalu muat ulang halaman ini.</div><?php endif ?>
</div>

<form method="post" action="<?= site_url('install/proses') ?>">
<?= csrf_field() ?>
<div class="card">
    <h2>2. Database MySQL / MariaDB</h2>
    <div class="grid">
        <div><label>Host</label><input name="hostname" value="<?= esc(old('hostname', 'localhost')) ?>" required></div>
        <div><label>Port</label><input name="port" value="<?= esc(old('port', '3306')) ?>"></div>
        <div><label>Username</label><input name="username" value="<?= esc(old('username', 'root')) ?>" required></div>
        <div><label>Password</label><input type="password" name="password" value=""><small>XAMPP bawaan: kosong</small></div>
        <div class="full"><label>Nama database (dibuat otomatis bila belum ada)</label><input name="database" value="<?= esc(old('database', 'db_sis_sekolah')) ?>" required pattern="[A-Za-z0-9_]+"><small>Harus kosong. Untuk memindahkan data dari versi lama, gunakan nama baru lalu ikuti panduan bagian 4 Cara C.</small></div>
    </div>
</div>
<div class="card">
    <h2>3. Alamat & waktu</h2>
    <div class="grid">
        <div class="full"><label>Alamat aplikasi</label>
            <div class="cek"><input type="radio" name="alamat_otomatis" value="1" id="ao1" <?= old('alamat_otomatis', '1') !== '0' ? 'checked' : '' ?>><label for="ao1" style="margin:0"><b>Otomatis (disarankan)</b> – mengikuti alamat yang dibuka: localhost di server, IP server di laptop/HP/kiosk lain, tanpa mengubah .env</label></div>
            <div class="cek"><input type="radio" name="alamat_otomatis" value="0" id="ao0" <?= old('alamat_otomatis') === '0' ? 'checked' : '' ?>><label for="ao0" style="margin:0">Tetapkan satu alamat:</label></div>
            <input name="base_url" value="<?= esc(old('base_url', $baseUrl)) ?>">
            <small>Hanya dipakai bila memilih "Tetapkan satu alamat" (mis. di balik reverse proxy/HTTPS). Alamat terdeteksi saat ini: <?= esc($baseUrl) ?></small></div>
        <div><label>Zona waktu sekolah</label><select name="zona">
            <?php foreach (['Asia/Jakarta' => 'WIB (Asia/Jakarta)', 'Asia/Makassar' => 'WITA (Asia/Makassar)', 'Asia/Jayapura' => 'WIT (Asia/Jayapura)'] as $k => $v) : ?><option value="<?= $k ?>" <?= old('zona') === $k ? 'selected' : '' ?>><?= $v ?></option><?php endforeach ?></select></div>
        <div><label>Mode</label><select name="mode"><option value="production">Produksi (dipakai sekolah)</option><option value="development" <?= old('mode') === 'development' ? 'selected' : '' ?>>Pengembangan (tampilkan error detail)</option></select></div>
        <div class="full cek"><input type="checkbox" name="tanpa_index" value="1" id="ti" <?= old('tanpa_index') ? 'checked' : '' ?>><label for="ti" style="margin:0">URL tanpa "index.php" (hanya bila mod_rewrite Apache aktif)</label></div>
    </div>
</div>
<div class="card">
    <h2>4. Identitas sekolah</h2>
    <div class="grid">
        <div class="full"><label>Nama sekolah</label><input name="nama_sekolah" value="<?= esc(old('nama_sekolah')) ?>" required></div>
        <div><label>Nama aplikasi</label><input name="nama_aplikasi" value="<?= esc(old('nama_aplikasi', 'SIS Sekolah')) ?>"></div>
        <div><label>Jenjang</label><select name="jenjang"><option value="">-</option><?php foreach (['SD', 'MI', 'SMP', 'MTs', 'SMA', 'MA', 'SMK', 'MAK', 'SLB', 'Lainnya'] as $j) : ?><option <?= old('jenjang') === $j ? 'selected' : '' ?>><?= $j ?></option><?php endforeach ?></select></div>
        <div><label>Jenis nomor</label><select name="jenis_nomor"><option value="NPSN">NPSN</option><option value="NSM" <?= old('jenis_nomor') === 'NSM' ? 'selected' : '' ?>>NSM (madrasah)</option></select></div>
        <div><label>Nomor NPSN/NSM</label><input name="npsn" value="<?= esc(old('npsn')) ?>"></div>
    </div>
</div>
<div class="card">
    <h2>5. Akun administrator</h2>
    <div class="grid">
        <div><label>Username</label><input name="admin_user" value="<?= esc(old('admin_user', 'admin')) ?>" required></div>
        <div><label>Nama</label><input name="admin_nama" value="<?= esc(old('admin_nama', 'Administrator')) ?>" required></div>
        <div><label>Password (min. 8 karakter)</label><input type="password" name="admin_pass" required minlength="8"></div>
        <div><label>Ulangi password</label><input type="password" name="admin_pass2" required minlength="8"></div>
        <div class="full cek"><input type="checkbox" name="demo" value="1" id="demo"><label for="demo" style="margin:0">Isi data contoh (guru, kelas, siswa, jadwal) – hanya untuk latihan, JANGAN untuk data sungguhan</label></div>
    </div>
</div>
<div class="card"><button class="btn" <?= $siap ? '' : 'disabled' ?>>Pasang Sekarang</button> <small>Proses biasanya kurang dari satu menit.</small></div>
</form>
</div></body></html>
