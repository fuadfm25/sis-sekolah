<?= view('install/_layout_atas') ?>
<div class="card">
    <h1>✔ Pemasangan selesai</h1>
    <div class="alert alert-success">Database, tabel, data awal, dan akun administrator <b><?= esc($in['admin_user']) ?></b> sudah dibuat.</div>
    <?php if ($tulisOk) : ?>
        <p>File <code>.env</code> sudah ditulis. Pemasang kini terkunci (file <code>writable/installed.lock</code>).</p>
    <?php else : ?>
        <div class="alert alert-warning">Folder aplikasi tidak dapat ditulisi, jadi <code>.env</code> belum tersimpan. Buat file bernama <b>.env</b> di folder utama aplikasi (sejajar dengan folder <code>app</code>) dengan isi berikut, lalu lanjutkan:</div>
        <pre><?= esc($env) ?></pre>
    <?php endif ?>
    <h2>Langkah berikutnya</h2>
    <ol>
        <li>Login sebagai administrator.</li>
        <li><b>Sistem → Aset Offline</b>: unduh file tampilan agar aplikasi tetap rapi tanpa internet (perlu internet sekali saat mengunduh).</li>
        <li><b>Pengaturan Sekolah</b>: alamat, logo, kepala sekolah, jam masuk/pulang.</li>
        <li>Wakil kurikulum: Tahun Pelajaran (dengan tanggal semester) & Kalender Akademik.</li>
        <li><b>Sistem → Backup</b>: jadwalkan backup harian (lihat panduan).</li>
    </ol>
    <a class="btn" href="<?= esc($in['alamat_otomatis'] ? base_url(($in['tanpa_index'] ? '' : 'index.php/') . 'login') : rtrim($in['base_url'], '/') . '/' . ($in['tanpa_index'] ? '' : 'index.php/') . 'login') ?>">Ke halaman login</a>
</div>
</div></body></html>
