<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pemasangan SIS Sekolah</title>
    <link rel="icon" href="<?= base_url('favicon.svg') ?>">
    <style>
        @font-face { font-family: "Plus Jakarta Sans"; font-weight: 200 800; font-display: swap;
            src: url("<?= base_url('assets/vendor/fonts/plus-jakarta-sans-latin-wght-normal.woff2') ?>") format("woff2"),
                 url("https://cdn.jsdelivr.net/npm/@fontsource-variable/plus-jakarta-sans@5/files/plus-jakarta-sans-latin-wght-normal.woff2") format("woff2"); }
        body { font-family: "Plus Jakarta Sans", Inter, "Segoe UI", system-ui, Roboto, Arial, sans-serif; background: #f3f5fa; margin: 0; color: #1b2537; font-size: 15px; }
        .atas { background: linear-gradient(160deg, #163273, #0b1d47); color: #fff; padding: 34px 16px 70px; }
        .atas .in { max-width: 920px; margin: auto; display: flex; gap: 14px; align-items: center; }
        .atas img { width: 52px; height: 52px; border-radius: 14px; }
        .atas .t { font-weight: 800; font-size: 1.35rem; letter-spacing: -.02em; } .atas .s { color: rgba(255,255,255,.65); font-size: .9rem; }
        .wrap { max-width: 920px; margin: -46px auto 30px; padding: 0 16px; }
        .card { background: #fff; border-radius: 14px; border: 1px solid #e3e8f1; box-shadow: 0 4px 14px rgba(16,32,72,.05); padding: 22px 26px; margin-bottom: 18px; }
        h1 { font-size: 1.45rem; margin: 0 0 4px; letter-spacing: -.02em; } h2 { font-size: 1.05rem; margin: 0 0 14px; color: #1f3c88; }
        .grid { display: grid; grid-template-columns: 1fr 1fr; gap: 12px 18px; } .full { grid-column: 1 / -1; }
        label { display: block; font-weight: 600; font-size: .83rem; margin-bottom: 5px; color: #39445a; }
        input, select { width: 100%; padding: 9px 11px; border: 1px solid #d9dfea; border-radius: 9px; font-size: .93rem; box-sizing: border-box; font-family: inherit; }
        input:focus, select:focus { outline: none; border-color: #6f86c4; box-shadow: 0 0 0 3px rgba(31,60,136,.13); }
        small { color: #67728a; } table { width: 100%; border-collapse: collapse; font-size: .9rem; }
        td { padding: 7px 6px; border-bottom: 1px solid #edf0f6; } .ok { color: #0f8a6b; font-weight: 700; } .no { color: #c53b3b; font-weight: 700; }
        .btn { background: #1f3c88; color: #fff; border: 0; padding: 11px 24px; border-radius: 10px; font-size: .95rem; font-weight: 700; cursor: pointer; font-family: inherit; }
        .btn:hover { background: #19316f; } .btn:disabled { background: #9aa8cc; }
        .alert { padding: 11px 14px; border-radius: 9px; margin-bottom: 14px; border: 1px solid transparent; }
        .alert-danger { background: #fcecec; color: #8a2525; border-color: #f2c6c6; } .alert-success { background: #e8f6f1; color: #0b5c48; border-color: #bfe5d7; }
        .alert-warning { background: #fdf6e3; color: #6e4e06; border-color: #f1dca4; }
        .cek { display: flex; gap: 8px; align-items: center; } .cek input { width: auto; accent-color: #1f3c88; }
        pre { background: #0b1d47; color: #e6ebf7; padding: 12px; border-radius: 9px; overflow: auto; font-size: .85rem; }
        @media (max-width: 640px) { .grid { grid-template-columns: 1fr; } }
    </style>
</head>
<body>
<div class="atas"><div class="in"><img src="<?= base_url('assets/img/logo-sis.svg') ?>" alt=""><div><div class="t">SIS Sekolah</div><div class="s">Pemasangan aplikasi administrasi pembelajaran</div></div></div></div>
<div class="wrap">
