<?= $this->extend('layouts/main') ?>
<?= $this->section('content') ?>
<div class="row">
    <div class="col-md-6">
        <div class="card">
            <div class="card-header"><h5 class="card-title mb-0">Akun</h5></div>
            <div class="card-body">
                <table class="table table-borderless mb-0">
                    <tr><th style="width:140px">Nama</th><td><?= esc($user['nama_lengkap']) ?></td></tr>
                    <tr><th>Username</th><td><?= esc($user['username']) ?></td></tr>
                    <tr><th>Role</th><td><?= esc(implode(', ', session('roles') ?? [])) ?></td></tr>
                    <tr><th>Login terakhir</th><td><?= esc($user['last_login'] ?? '-') ?></td></tr>
                </table>
            </div>
        </div>
    </div>
    <div class="col-md-6">
        <div class="card">
            <div class="card-header"><h5 class="card-title mb-0">Ganti Password</h5></div>
            <div class="card-body">
                <form method="post" action="<?= site_url('profil/password') ?>">
                    <?= csrf_field() ?>
                    <div class="mb-2"><label class="form-label">Password lama</label><input type="password" name="password_lama" class="form-control" required></div>
                    <div class="mb-2"><label class="form-label">Password baru (min. 6 karakter)</label><input type="password" name="password_baru" class="form-control" required minlength="6"></div>
                    <div class="mb-3"><label class="form-label">Ulangi password baru</label><input type="password" name="konfirmasi" class="form-control" required></div>
                    <button class="btn btn-primary">Simpan</button>
                </form>
            </div>
        </div>
    </div>
</div>
<?= $this->endSection() ?>
