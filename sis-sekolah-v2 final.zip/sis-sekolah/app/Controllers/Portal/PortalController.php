<?php

namespace App\Controllers\Portal;

use App\Controllers\Akademik\JadwalController;
use App\Controllers\BaseController;
use App\Libraries\Kalender;
use App\Libraries\PortalSiswa;
use App\Models\JadwalModel;
use App\Models\SiswaModel;

/**
 * Portal siswa: jadwal pelajaran, materi yang sudah diajarkan, kehadiran, catatan perilaku, dan pembiasaan milik siswa
 * yang login. Siswa dapat mencentang sendiri pembiasaan yang diatur kesiswaan untuk diisi siswa (diverifikasi wali kelas).
 * Layanan BK dan catatan internal guru tidak ditampilkan.
 */
class PortalController extends BaseController
{
    private function s(): array
    {
        return PortalSiswa::saya();
    }

    private function kelasId(): int
    {
        return (int) ($this->s()['kelas']['id'] ?? 0);
    }

    private function tampil(string $view, array $data)
    {
        return view('portal/' . $view, $data + ['siswa' => $this->s(), 'tp' => $this->tp]);
    }

    private function bulan(): array
    {
        $ym = (string) $this->request->getGet('bulan');
        if (! preg_match('/^\d{4}-\d{2}$/', $ym)) {
            $ym = date('Y-m');
        }
        return [$ym, $ym . '-01', date('Y-m-t', strtotime($ym . '-01'))];
    }

    // ------------------------------------------------------------------ masuk / keluar
    public function login()
    {
        if (PortalSiswa::saya()) {
            return redirect()->to('/portal');
        }
        return view('portal/login', ['aktif' => PortalSiswa::aktif()]);
    }

    public function masuk()
    {
        if (! PortalSiswa::aktif()) {
            return redirect()->to('/portal/login')->with('error', 'Portal siswa sedang dinonaktifkan sekolah.');
        }
        $id    = trim((string) $this->request->getPost('username'));
        $pw    = (string) $this->request->getPost('password');
        $kunci = 'portal_kunci_' . md5(strtolower($id));
        if (cache($kunci)) {
            return redirect()->back()->withInput()->with('error', 'Terlalu banyak percobaan gagal. Coba lagi 5 menit lagi.');
        }
        $s = PortalSiswa::cari($id);
        if (! $s || ! PortalSiswa::cocok($s, $pw)) {
            if (service('throttler')->check('portal_' . md5($this->request->getIPAddress() . '|' . $id), 5, MINUTE * 5) === false) {
                cache()->save($kunci, 1, MINUTE * 5);
            }
            return redirect()->back()->withInput()->with('error', 'NISN/NIS atau password salah.');
        }
        if ($s['status'] !== 'Aktif') {
            return redirect()->back()->with('error', 'Akun siswa tidak aktif (status: ' . $s['status'] . ').');
        }
        session()->regenerate(true);
        session()->set(['siswa_id' => (int) $s['id'], 'siswa_wajib_ganti' => empty($s['password'])]);
        model(SiswaModel::class)->update($s['id'], ['login_terakhir' => date('Y-m-d H:i:s')]);
        if (empty($s['password'])) {
            return redirect()->to('/portal/akun')->with('warning', 'Selamat datang! Buat password baru untuk akun Anda terlebih dahulu.');
        }
        return redirect()->to('/portal');
    }

    public function keluar()
    {
        session()->remove(['siswa_id', 'siswa_wajib_ganti']);
        return redirect()->to('/portal/login')->with('success', 'Anda telah keluar.');
    }

    // ------------------------------------------------------------------ halaman
    public function beranda()
    {
        $s     = $this->s();
        $kelas = $this->kelasId();
        $today = date('Y-m-d');
        $db    = db_connect();
        $sesi  = ($this->tp && $kelas) ? model(JadwalModel::class)->sesiTanggal($this->tpId(), $today, ['kelas_id' => $kelas]) : [];
        [, $dari, $sampai] = $this->bulan();
        $hadir = array_column($db->table('presensi_harian')->select('status, COUNT(*) AS n')->where('siswa_id', $s['id'])
            ->where('tanggal >=', $dari)->where('tanggal <=', $sampai)->groupBy('status')->get()->getResultArray(), 'n', 'status');
        $poin  = array_column($db->table('catatan_perilaku')->select('kategori, SUM(poin) AS p')->where(['siswa_id' => $s['id'], 'tahun_pelajaran_id' => $this->tpId()])
            ->groupBy('kategori')->get()->getResultArray(), 'p', 'kategori');
        $pb    = $db->table('pembiasaan_siswa')->select('SUM(terlaksana) AS ya, COUNT(*) AS n')->where('siswa_id', $s['id'])->where('verifikasi !=', 'Menunggu')
            ->where('tanggal >=', date('Y-m-d', strtotime('-30 days')))->get()->getRowArray();
        return $this->tampil('beranda', [
            'title'   => 'Beranda',
            'status'  => $this->tp ? Kalender::status($today, $kelas ?: null) : null,
            'sesi'    => $sesi,
            'hadir'   => $hadir,
            'poin'    => $poin,
            'pembiasaan' => (int) ($pb['n'] ?? 0) ? round($pb['ya'] / $pb['n'] * 100) : null,
            'materi'  => $this->materiQuery($kelas)->limit(5)->get()->getResultArray(),
        ]);
    }

    public function jadwal()
    {
        $kelas = $this->kelasId();
        return $this->tampil('jadwal', JadwalController::dataJam(hari_list()) + [
            'title'   => 'Jadwal Pelajaran',
            'grid'    => ($kelas && $this->tp) ? model(JadwalModel::class)->grid($this->tpId(), ['kelas_id' => $kelas, 'tanggal' => date('Y-m-d')]) : [],
            'berlaku' => date('Y-m-d'),
        ]);
    }

    /** Query materi (jurnal) kelas siswa, beserta kehadiran siswa di pertemuan itu. Catatan internal guru tidak diambil. */
    private function materiQuery(int $kelas)
    {
        $sid = (int) $this->s()['id'];
        return db_connect()->table('jurnal_pembelajaran j')
            ->select('j.id, j.tanggal, j.jam_ke, j.pertemuan_ke, j.materi, j.tujuan_pembelajaran, j.kegiatan, j.penilaian, j.status_kbm, m.nama_mapel, m.id AS mapel_id,
                g.nama_lengkap, g.gelar_depan, g.gelar_belakang, pm.status AS hadir', false)
            ->join('penugasan_guru p', 'p.id = j.penugasan_guru_id')
            ->join('mata_pelajaran m', 'm.id = p.mapel_id')
            ->join('guru g', 'g.id = COALESCE(j.guru_id, p.guru_id)', '', false)
            ->join('presensi_mapel pm', 'pm.jurnal_id = j.id AND pm.siswa_id = ' . $sid, 'left')
            ->where(['j.kelas_id' => $kelas, 'j.tahun_pelajaran_id' => $this->tpId()])
            ->orderBy('j.tanggal', 'DESC')->orderBy('j.jam_ke', 'ASC');
    }

    public function materi()
    {
        $kelas = $this->kelasId();
        $mapel = (int) $this->request->getGet('mapel');
        $b     = $this->materiQuery($kelas);
        if ($mapel) {
            $b->where('m.id', $mapel);
        }
        $daftarMapel = db_connect()->table('penugasan_guru p')->select('m.id, m.nama_mapel')->join('mata_pelajaran m', 'm.id = p.mapel_id')
            ->where(['p.kelas_id' => $kelas, 'p.tahun_pelajaran_id' => $this->tpId()])->orderBy('m.nama_mapel')->get()->getResultArray();
        return $this->tampil('materi', [
            'title' => 'Materi Pelajaran',
            'rows'  => $kelas ? $b->limit(200)->get()->getResultArray() : [],
            'mapel' => $mapel,
            'daftarMapel' => $daftarMapel,
        ]);
    }

    public function kehadiran()
    {
        [$ym, $dari, $sampai] = $this->bulan();
        $rows = db_connect()->table('presensi_harian')->select('tanggal, status, jam_datang, keterangan')->where('siswa_id', $this->s()['id'])
            ->where('tanggal >=', $dari)->where('tanggal <=', $sampai)->get()->getResultArray();
        $hari = [];
        foreach (Kalender::tanggal($dari, $sampai) as $d) {
            $hari[$d] = Kalender::status($d, $this->kelasId() ?: null);
        }
        return $this->tampil('kehadiran', [
            'title' => 'Kehadiran',
            'ym'    => $ym, 'dari' => $dari,
            'data'  => array_column($rows, null, 'tanggal'),
            'hari'  => $hari,
        ]);
    }

    public function perilaku()
    {
        $rows = db_connect()->table('catatan_perilaku c')
            ->select('c.tanggal, c.kategori, c.poin, c.deskripsi, c.status, jp.nama AS perilaku, u.nama_lengkap AS pencatat')
            ->join('jenis_perilaku jp', 'jp.id = c.jenis_perilaku_id', 'left')
            ->join('users u', 'u.id = c.dicatat_oleh', 'left')
            ->where(['c.siswa_id' => $this->s()['id'], 'c.tahun_pelajaran_id' => $this->tpId()])
            ->orderBy('c.tanggal', 'DESC')->get()->getResultArray();
        $tot = ['Positif' => 0, 'Negatif' => 0];
        foreach ($rows as $r) {
            $tot[$r['kategori']] += (int) $r['poin'];
        }
        return $this->tampil('perilaku', ['title' => 'Catatan Perilaku', 'rows' => $rows, 'tot' => $tot]);
    }

    /** Tanggal yang boleh diisi siswa: hari ini sampai N hari ke belakang (pengaturan kesiswaan). */
    private function tanggalIsian(): array
    {
        $n   = max(0, min(7, (int) setting('pembiasaan_mundur', 1)));
        $out = [];
        for ($i = 0; $i <= $n; $i++) {
            $d = date('Y-m-d', strtotime("-{$i} days"));
            if (! $this->tp || empty($this->tp['tanggal_mulai']) || $d >= $this->tp['tanggal_mulai']) {
                $out[] = $d;
            }
        }
        return $out;
    }

    private function isian(string $tanggal): array
    {
        $kelasId = $this->kelasId();
        $tingkat = (string) ($this->s()['kelas']['tingkat'] ?? '');
        $daftar  = model(\App\Models\PembiasaanModel::class)->untukSiswa($tanggal, $tingkat, $kelasId && Kalender::absensi($tanggal, $kelasId));
        $ada     = [];
        foreach (db_connect()->table('pembiasaan_siswa')->where(['siswa_id' => $this->s()['id'], 'tanggal' => $tanggal])->get()->getResultArray() as $r) {
            $ada[$r['pembiasaan_id']] = $r;
        }
        return [$daftar, $ada];
    }

    /** Baris boleh diubah siswa bila belum diputuskan guru. */
    private static function terkunci(?array $r): bool
    {
        return $r && ($r['sumber'] === 'Guru' || ! empty($r['diverifikasi_oleh']));
    }

    public function pembiasaan()
    {
        [$ym, $dari, $sampai] = $this->bulan();
        $db    = db_connect();
        $daftar = $db->table('pembiasaan')->where('is_active', 1)->orderBy('urutan')->orderBy('nama')->get()->getResultArray();
        $data  = [];
        foreach ($db->table('pembiasaan_siswa')->where('siswa_id', $this->s()['id'])->where('tanggal >=', $dari)->where('tanggal <=', $sampai)->get()->getResultArray() as $r) {
            $data[$r['pembiasaan_id']][(int) substr($r['tanggal'], 8)] = $r['verifikasi'] === 'Menunggu' ? 'm' : (int) $r['terlaksana'];
        }
        $tgl = [];
        foreach (Kalender::tanggal($dari, $sampai) as $d) {
            if (Kalender::absensi($d, $this->kelasId() ?: null) || array_filter(array_column($data, (int) substr($d, 8)), static fn ($v) => $v !== null)) {
                $tgl[] = (int) substr($d, 8);
            }
        }
        $pilihan = $this->tanggalIsian();
        $tanggal = in_array($this->request->getGet('tanggal'), $pilihan, true) ? $this->request->getGet('tanggal') : ($pilihan[0] ?? date('Y-m-d'));
        [$isian, $ada] = $this->isian($tanggal);
        return $this->tampil('pembiasaan', ['title' => 'Pembiasaan', 'ym' => $ym, 'daftar' => $daftar, 'data' => $data, 'tgl' => $tgl,
            'pilihan' => $pilihan, 'tanggal' => $tanggal, 'isian' => $isian, 'ada' => $ada]);
    }

    public function pembiasaanSimpan()
    {
        $s       = $this->s();
        $tanggal = (string) $this->request->getPost('tanggal');
        if (! $this->tp || ! $this->kelasId() || ! in_array($tanggal, $this->tanggalIsian(), true)) {
            return redirect()->to('/portal/pembiasaan')->with('error', 'Tanggal tidak bisa diisi lagi.');
        }
        [$isian, $ada] = $this->isian($tanggal);
        $cek   = (array) $this->request->getPost('cek');
        $cat   = (array) $this->request->getPost('catatan');
        $model = model(\App\Models\PembiasaanSiswaModel::class);
        $now   = date('Y-m-d H:i:s');
        $n     = 0;
        foreach ($isian as $p) {
            $pid = (int) $p['id'];
            if (self::terkunci($ada[$pid] ?? null)) {
                continue;
            }
            $ya      = isset($cek[$pid]) ? 1 : 0;
            $catatan = mb_substr(trim((string) ($cat[$pid] ?? '')), 0, 150) ?: null;
            if ($ya && (int) $p['wajib_catatan'] && ! $catatan) {
                return redirect()->to('/portal/pembiasaan?tanggal=' . $tanggal)->with('error', 'Isi keterangan untuk "' . $p['nama'] . '"' . ($p['petunjuk_catatan'] ? ' (' . $p['petunjuk_catatan'] . ')' : '') . '.');
            }
            if (! $ya && ! isset($ada[$pid])) {
                continue;   // tidak dicentang dan belum pernah diisi: tidak perlu dicatat
            }
            $verif = (int) $p['perlu_verifikasi'] ? 'Menunggu' : 'Disetujui';
            $model->simpanUnik(['tanggal' => $tanggal, 'siswa_id' => (int) $s['id'], 'pembiasaan_id' => $pid], [
                'tahun_pelajaran_id' => $this->tpId(), 'kelas_id' => $this->kelasId(), 'sumber' => 'Siswa', 'lapor_siswa' => $ya, 'lapor_at' => $now,
                'keterangan' => $catatan, 'verifikasi' => $verif, 'terlaksana' => $verif === 'Disetujui' ? $ya : 0, 'dicatat_oleh' => null,
            ]);
            $n++;
        }
        return redirect()->to('/portal/pembiasaan?tanggal=' . $tanggal)->with('success', $n ? 'Pembiasaan tersimpan. Terima kasih sudah jujur mengisi!' : 'Tidak ada perubahan.');
    }

    // ------------------------------------------------------------------ akun
    public function akun()
    {
        return $this->tampil('akun', ['title' => 'Akun Saya', 'wajib' => (bool) session('siswa_wajib_ganti')]);
    }

    public function gantiPassword()
    {
        $s    = $this->s();
        $lama = (string) $this->request->getPost('password_lama');
        $baru = (string) $this->request->getPost('password_baru');
        if (! PortalSiswa::cocok($s, $lama)) {
            return redirect()->back()->with('error', 'Password lama salah.');
        }
        if (mb_strlen($baru) < 6 || $baru !== (string) $this->request->getPost('konfirmasi')) {
            return redirect()->back()->with('error', 'Password baru minimal 6 karakter dan harus sama dengan konfirmasinya.');
        }
        if ($baru === PortalSiswa::passwordBawaan($s) || in_array($baru, ['123456', '12345678', (string) $s['nis'], (string) $s['nisn']], true) || $baru === $lama) {
            return redirect()->back()->with('error', 'Password terlalu mudah ditebak atau sama dengan yang lama. Gunakan kombinasi lain.');
        }
        model(SiswaModel::class)->update($s['id'], ['password' => password_hash($baru, PASSWORD_DEFAULT)]);
        session()->remove('siswa_wajib_ganti');
        return redirect()->to('/portal')->with('success', 'Password berhasil diganti.');
    }
}
