<?php

namespace App\Controllers\Master;

use App\Controllers\BaseController;
use App\Models\AnggotaKelasModel;
use App\Models\KelasModel;
use App\Models\SiswaModel;

class SiswaController extends BaseController
{
    private SiswaModel $model;

    public function __construct()
    {
        $this->model = new SiswaModel();
    }

    public function index()
    {
        $f = [
            'kelas_id' => $this->request->getGet('kelas_id'),
            'status'   => $this->request->getGet('status') ?? 'Aktif',
            'q'        => trim((string) $this->request->getGet('q')),
        ];
        return view('master/siswa/index', [
            'title'  => 'Data Siswa',
            'rows'   => $this->model->listWithKelas($this->tpId(), $f),
            'kelas'  => model(KelasModel::class)->listAktif(),
            'f'      => $f,
        ]);
    }

    public function create()
    {
        return $this->form();
    }

    public function edit($id)
    {
        $siswa = $this->model->find($id);
        if (! $siswa) {
            return redirect()->to('/master/siswa')->with('error', 'Siswa tidak ditemukan.');
        }
        return $this->form($siswa);
    }

    private function form(?array $siswa = null)
    {
        $kelasNow = ($siswa && $this->tp) ? model(AnggotaKelasModel::class)->kelasSiswa((int) $siswa['id'], $this->tpId()) : null;
        return view('master/siswa/form', [
            'title'    => $siswa ? 'Edit Siswa' : 'Tambah Siswa',
            'siswa'    => $siswa,
            'kelasNow' => $kelasNow['id'] ?? null,
            'kelas'    => model(KelasModel::class)->listAktif(),
        ]);
    }

    private function rules(?int $id = null): array
    {
        return [
            'nis'           => 'required|max_length[20]|is_unique[siswa.nis,id,' . ($id ?? 0) . ']',
            'nama_lengkap'  => 'required|max_length[100]',
            'jenis_kelamin' => 'required|in_list[L,P]',
            'status'        => 'required|in_list[Aktif,Lulus,Pindah,Keluar]',
            'tanggal_lahir' => 'permit_empty|valid_date[Y-m-d]',
            'rfid'          => 'permit_empty|max_length[50]|is_unique[siswa.rfid,id,' . ($id ?? 0) . ']',
        ];
    }

    private function pesanRfid(): array
    {
        return ['rfid' => ['is_unique' => 'Kartu RFID ini sudah dipakai siswa lain.']];
    }

    private function input(): array
    {
        $data = [];
        foreach (['nis', 'nisn', 'rfid', 'nama_lengkap', 'jenis_kelamin', 'tempat_lahir', 'tanggal_lahir', 'agama', 'alamat', 'nama_wali', 'no_hp_wali', 'status'] as $f) {
            $v        = trim((string) $this->request->getPost($f));
            $data[$f] = $v === '' ? null : $v;
        }
        return $data;
    }

    public function store()
    {
        if (! $this->validate($this->rules(), $this->pesanRfid())) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }
        $id = (int) $this->model->insert($this->input());
        $this->aturKelas($id, (int) $this->request->getPost('kelas_id'));
        return redirect()->to('/master/siswa')->with('success', 'Siswa ditambahkan.');
    }

    public function update($id)
    {
        if (! $this->validate($this->rules((int) $id), $this->pesanRfid())) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }
        $this->model->update($id, $this->input());
        $this->aturKelas((int) $id, (int) $this->request->getPost('kelas_id'));
        return redirect()->to('/master/siswa')->with('success', 'Data siswa diperbarui.');
    }

    /** Tempatkan / pindahkan siswa ke kelas pada TP aktif. kelasId 0 = keluarkan dari rombel. */
    private function aturKelas(int $siswaId, int $kelasId): void
    {
        if (! $this->tp) {
            return;
        }
        $ak  = model(AnggotaKelasModel::class);
        $row = $ak->where(['tahun_pelajaran_id' => $this->tpId(), 'siswa_id' => $siswaId])->first();
        if (! $kelasId) {
            if ($row) {
                $ak->delete($row['id']);
            }
            return;
        }
        if ($row && (int) $row['kelas_id'] === $kelasId) {
            return;
        }
        $row ? $ak->update($row['id'], ['kelas_id' => $kelasId, 'no_absen' => null])
             : $ak->insert(['tahun_pelajaran_id' => $this->tpId(), 'kelas_id' => $kelasId, 'siswa_id' => $siswaId, 'status' => 'Aktif']);
        $ak->urutkanAbsen($kelasId, $this->tpId());
    }

    public function delete($id)
    {
        $w = ['siswa_id' => (int) $id];
        if ($pesan = $this->masihDipakai(['absensi harian' => ['presensi_harian', $w], 'absensi mapel' => ['presensi_mapel', $w], 'catatan perilaku' => ['catatan_perilaku', $w],
            'layanan BK' => ['bk_peserta', $w], 'pembiasaan' => ['pembiasaan_siswa', $w]], 'Untuk siswa pindah/lulus, ubah statusnya saja.')) {
            return redirect()->back()->with('error', $pesan);
        }
        $s = $this->model->find($id);
        $this->model->delete($id);
        catat_log('hapus', 'siswa', (int) $id, ($s['nis'] ?? '') . ' ' . ($s['nama_lengkap'] ?? ''));
        return redirect()->to('/master/siswa')->with('success', 'Siswa dihapus.');
    }

    /** Cetak kartu siswa dengan barcode NIS (untuk scanner barcode). */
    public function kartu()
    {
        $kelasId = $this->request->getGet('kelas_id');
        return view('master/siswa/kartu', [
            'title'   => 'Cetak Kartu Absensi',
            'kelas'   => model(KelasModel::class)->listAktif(),
            'kelasId' => $kelasId,
            'rows'    => $kelasId ? $this->model->listWithKelas($this->tpId(), ['kelas_id' => $kelasId, 'status' => 'Aktif']) : [],
        ]);
    }
}
