<?php

namespace App\Controllers\Master;

use App\Controllers\BaseController;
use App\Libraries\Berkas;
use App\Libraries\DataExcel;
use App\Libraries\ImporExcel;
use App\Models\AnggotaKelasModel;
use App\Models\GuruModel;
use App\Models\KelasModel;
use App\Models\SiswaModel;

/**
 * Impor data dari Excel: unduh template → isi → unggah → pratinjau pemetaan kolom → proses.
 * Jenis data & kolom didefinisikan di App\Libraries\DataExcel. Data yang sudah ada diperbarui, bukan digandakan.
 */
class ImporController extends BaseController
{
    /** Pusat impor: daftar jenis data yang boleh diimpor pengguna ini. */
    public function index()
    {
        $daftar = array_filter(DataExcel::definisi(), static fn ($k) => DataExcel::boleh($k), ARRAY_FILTER_USE_KEY);
        if (! $daftar) {
            return redirect()->to('/dashboard')->with('error', 'Anda tidak memiliki akses impor data.');
        }
        return view('master/impor/index', [
            'title'    => 'Impor Data dari Excel',
            'subtitle' => 'Unduh template, isi di Excel, lalu unggah. Kolom dikenali otomatis dan bisa diperiksa sebelum disimpan.',
            'daftar'   => $daftar,
            'pilih'    => (string) $this->request->getGet('jenis'),
        ]);
    }

    /** Template Excel: lembar "Data" (judul kolom) + lembar "Petunjuk". */
    public function template($jenis)
    {
        if (! DataExcel::boleh($jenis)) {
            return redirect()->to('/excel')->with('error', 'Akses ditolak.');
        }
        [$judul, , $ket, $kolom] = DataExcel::definisi()[$jenis];
        $ss  = new \PhpOffice\PhpSpreadsheet\Spreadsheet();
        $sh  = $ss->getActiveSheet()->setTitle('Data');
        $i   = 1;
        foreach ($kolom as $f => [$label, $wajib, $contoh]) {
            $c = \PhpOffice\PhpSpreadsheet\Cell\Coordinate::stringFromColumnIndex($i);
            $sh->setCellValue($c . '1', $label);
            $sh->getColumnDimension($c)->setWidth(max(14, min(48, mb_strlen($label) + 6, $f === 'tujuan' ? 60 : 48)));
            // kolom nomor & tanggal sebagai teks agar nol di depan tidak hilang
            if (in_array($f, ['nis', 'nisn', 'nip', 'nuptk', 'no_hp', 'no_hp_wali', 'rfid', 'tanggal_lahir', 'tanggal_mulai', 'tanggal_selesai', 'kode'], true)) {
                $sh->getStyle($c . '2:' . $c . '2000')->getNumberFormat()->setFormatCode('@');
            }
            $i++;
        }
        $akhir = \PhpOffice\PhpSpreadsheet\Cell\Coordinate::stringFromColumnIndex(count($kolom));
        $sh->getStyle('A1:' . $akhir . '1')->applyFromArray([
            'font' => ['bold' => true, 'color' => ['rgb' => 'FFFFFF']],
            'fill' => ['fillType' => 'solid', 'startColor' => ['rgb' => '1F3C88']],
        ]);
        $sh->freezePane('A2');
        // pilihan tetap (dropdown) untuk kolom tertentu
        $pilihan = ['jenis_kelamin' => 'L,P', 'kategori' => $jenis === 'perilaku' ? 'Positif,Negatif' : null, 'tingkat' => $jenis === 'perilaku' ? 'Ringan,Sedang,Berat' : null,
            'semester' => 'Ganjil,Genap', 'aktif' => 'Ya,Tidak', 'ada_kbm' => 'Ya,Tidak', 'ada_absensi' => 'Ya,Tidak', 'status_kepegawaian' => 'PNS,PPPK,GTY,GTT,Honorer'];
        $i = 1;
        foreach (array_keys($kolom) as $f) {
            if (! empty($pilihan[$f])) {
                $c = \PhpOffice\PhpSpreadsheet\Cell\Coordinate::stringFromColumnIndex($i);
                $v = $sh->getCell($c . '2')->getDataValidation();
                $v->setType('list')->setAllowBlank(true)->setShowDropDown(true)->setFormula1('"' . $pilihan[$f] . '"');
                $sh->setDataValidation($c . '2:' . $c . '2000', $v);
            }
            $i++;
        }
        $pt = $ss->createSheet()->setTitle('Petunjuk');
        $pt->setCellValue('A1', 'Template impor: ' . $judul);
        $pt->setCellValue('A2', $ket . ' Isi data mulai baris 2 pada lembar "Data". Jangan mengubah judul kolom. Kolom bertanda * wajib.');
        $pt->fromArray(['Kolom', 'Wajib', 'Contoh isian', 'Keterangan'], null, 'A4');
        $r = 5;
        foreach ($kolom as [$label, $wajib, $contoh, $keterangan]) {
            $pt->fromArray([$label . ($wajib ? ' *' : ''), $wajib ? 'Ya' : '', (string) $contoh, $keterangan], null, 'A' . $r++);
        }
        $pt->getStyle('A1')->getFont()->setBold(true)->setSize(13);
        $pt->getStyle('A4:D4')->getFont()->setBold(true);
        foreach (['A' => 26, 'B' => 8, 'C' => 34, 'D' => 70] as $c => $w) {
            $pt->getColumnDimension($c)->setWidth($w);
        }
        $pt->getStyle('C5:C' . $r)->getNumberFormat()->setFormatCode('@');
        $ss->setActiveSheetIndex(0);

        $tmp = tempnam(sys_get_temp_dir(), 'tpl');
        (new \PhpOffice\PhpSpreadsheet\Writer\Xlsx($ss))->save($tmp);
        return $this->response->download($tmp, null)->setFileName('Template_Impor_' . str_replace(' ', '_', preg_replace('/[^A-Za-z ]/', '', $judul)) . '.xlsx');
    }

    public function unggah()
    {
        $jenis = (string) $this->request->getPost('jenis');
        if (! DataExcel::boleh($jenis)) {
            return $this->back('error', 'Jenis data tidak dikenal atau Anda tidak berhak mengimpornya.');
        }
        $file = $this->request->getFile('file');
        [$nama, $err] = Berkas::simpan($file, 'impor', ['xlsx', 'xls', 'csv'], 10240);
        if ($err || ! $nama) {
            return $this->back('error', $err ?: 'Pilih file Excel terlebih dahulu.');
        }
        session()->set('impor', ['jenis' => $jenis, 'file' => $nama, 'asli' => $file->getClientName()]);
        return redirect()->to('/excel/pratinjau');
    }

    private function sesi(): ?array
    {
        $s = session('impor');
        return $s && DataExcel::boleh($s['jenis']) && Berkas::path('impor', $s['file']) ? $s : null;
    }

    public function pratinjau()
    {
        if (! ($s = $this->sesi())) {
            return redirect()->to('/excel')->with('error', 'Unggah file terlebih dahulu.');
        }
        try {
            $hasil = ImporExcel::baca(Berkas::path('impor', $s['file']), $s['jenis']);
        } catch (\Throwable $e) {
            return redirect()->to('/excel?jenis=' . $s['jenis'])->with('error', 'File tidak dapat dibaca: ' . $e->getMessage());
        }
        if (! $hasil['data']) {
            return redirect()->to('/excel?jenis=' . $s['jenis'])->with('error', 'Tidak ada baris data yang terbaca. Pastikan data diisi mulai baris 2 lembar "Data".');
        }
        $map  = ImporExcel::tebak($hasil['label'], $s['jenis']);
        $info = [];
        if ($s['jenis'] === 'siswa') {
            $kelas = [];
            foreach (model(KelasModel::class)->findAll() as $k) {
                $kelas[ImporExcel::kunciKelas($k['nama_kelas'])] = $k['nama_kelas'];
            }
            $col  = array_search('kelas', $map, true);
            $baru = [];
            if ($col !== false) {
                foreach ($hasil['data'] as $r) {
                    $nk = trim((string) ($r[$col] ?? ''));
                    if ($nk !== '' && ! isset($kelas[ImporExcel::kunciKelas($nk)])) {
                        $baru[$nk] = true;
                    }
                }
            }
            $info['kelas_baru'] = array_keys($baru);
        }
        $def   = DataExcel::definisi()[$s['jenis']];
        $wajib = array_keys(array_filter($def[3], static fn ($k) => $k[1]));
        return view('master/impor/pratinjau', [
            'title'    => 'Pratinjau Impor ' . $def[0],
            'subtitle' => esc($s['asli']) . ' · ' . ($hasil['sumber'] !== 'Excel' ? 'format ' . $hasil['sumber'] . ' · ' : '') . 'judul kolom di baris ' . $hasil['baris_header'] . ($hasil['dua_baris'] ? ' (dua baris)' : '') . ' · ' . count($hasil['data']) . ' baris data',
            'jenis'    => $s['jenis'],
            'hasil'    => $hasil,
            'map'      => $map,
            'field'    => DataExcel::field($s['jenis']),
            'wajib'    => $wajib,
            'info'     => $info,
        ]);
    }

    public function proses()
    {
        if (! ($s = $this->sesi())) {
            return redirect()->to('/excel')->with('error', 'Sesi impor berakhir. Unggah ulang file.');
        }
        $hasil = ImporExcel::baca(Berkas::path('impor', $s['file']), $s['jenis']);
        $field = DataExcel::field($s['jenis']);
        $map   = [];
        foreach ((array) $this->request->getPost('map') as $i => $f) {
            if ($f !== '' && isset($field[$f]) && ! in_array($f, $map, true)) {
                $map[(int) $i] = $f;
            }
        }
        $def    = DataExcel::definisi()[$s['jenis']][3];
        $kurang = array_filter(array_keys($def), static fn ($f) => $def[$f][1] && ! in_array($f, $map, true) && ! in_array($f, ['nis', 'jenis_kelamin'], true));
        if ($kurang) {
            return $this->back('error', 'Kolom wajib belum dipetakan: ' . implode(', ', array_map(static fn ($f) => $def[$f][0], $kurang)) . '.');
        }
        $db = db_connect();
        $db->transStart();
        $r = match ($s['jenis']) {
            'siswa'      => $this->prosesSiswa($hasil['data'], $map, $hasil['label'], (bool) $this->request->getPost('buat_kelas'), (bool) $this->request->getPost('perbarui')),
            'guru'       => $this->prosesGuru($hasil['data'], $map),
            default      => $this->{'proses' . ucfirst($s['jenis'])}($hasil['data'], $map),
        };
        $db->transComplete();
        if (! $db->transStatus()) {
            return $this->back('error', 'Impor gagal; tidak ada data yang disimpan. Periksa isian file.');
        }
        Berkas::hapus('impor', $s['file']);
        session()->remove('impor');
        catat_log('impor', $s['jenis'], null, $s['asli'] . ': ' . json_encode(array_diff_key($r, ['catatan' => 1])));
        $msg = "Impor selesai: {$r['baru']} baru, {$r['ubah']} diperbarui, {$r['lewat']} dilewati.";
        if (! empty($r['kelas_dibuat'])) {
            $msg .= ' Kelas dibuat: ' . implode(', ', $r['kelas_dibuat']) . '.';
        }
        if (! empty($r['catatan'])) {
            $msg .= ' Catatan: ' . implode('; ', array_slice(array_values($r['catatan']), 0, 8)) . (count($r['catatan']) > 8 ? '; …' : '') . '.';
        }
        $tujuan = ['siswa' => '/master/siswa', 'guru' => '/master/guru', 'mapel' => '/master/mapel', 'kelas' => '/master/kelas', 'penugasan' => '/akademik/penugasan',
            'kalender' => '/akademik/kalender', 'atp' => '/atp', 'perilaku' => '/perilaku/jenis', 'pembiasaan' => '/pembiasaan/master'][$s['jenis']];
        return redirect()->to($tujuan)->with(! empty($r['catatan']) ? 'warning' : 'success', $msg);
    }

    private function ambil(array $row, array $map): array
    {
        $out = [];
        foreach ($map as $i => $f) {
            $out[$f] = $row[$i] ?? null;
        }
        return $out;
    }

    private function prosesSiswa(array $data, array $map, array $label, bool $buatKelas, bool $perbarui): array
    {
        // kolom cadangan nama wali (mis. ayah kosong → ibu)
        $cadangan = [];
        foreach (ImporExcel::FIELD['siswa']['nama_wali'][1] as $sin) {
            foreach ($label as $i => $l) {
                if (ImporExcel::norm($l) === $sin && ! isset($map[$i])) {
                    $cadangan[] = $i;
                }
            }
        }
        $model = model(SiswaModel::class);
        $res   = ['baru' => 0, 'ubah' => 0, 'lewat' => 0, 'kelas_dibuat' => [], 'catatan' => []];
        $kelas = [];
        foreach (model(KelasModel::class)->findAll() as $k) {
            $kelas[ImporExcel::kunciKelas($k['nama_kelas'])] = (int) $k['id'];
        }
        $penempatan = [];
        foreach ($data as $no => $row) {
            $v    = $this->ambil($row, $map);
            $nama = ImporExcel::teks($v['nama_lengkap'] ?? null);
            if (! $nama || is_numeric($nama)) {
                continue;   // baris kosong / nomor urut / baris total
            }
            foreach ($cadangan as $ci) {
                if (ImporExcel::teks($v['nama_wali'] ?? null) === null) {
                    $v['nama_wali'] = $row[$ci] ?? null;
                }
            }
            $nisn = ImporExcel::teks($v['nisn'] ?? null);
            if ($nisn && ctype_digit($nisn) && strlen($nisn) < 10) {
                $nisn = str_pad($nisn, 10, '0', STR_PAD_LEFT);   // nol di depan hilang karena sel angka
            }
            $nis = ImporExcel::teks($v['nis'] ?? null) ?: $nisn;
            if (! $nis) {
                $res['lewat']++;
                $res['catatan'][] = "{$nama}: tanpa NIS/NISN";
                continue;
            }
            $rec = array_filter([
                'nis' => $nis, 'nisn' => $nisn, 'nama_lengkap' => mb_substr($nama, 0, 150),
                'jenis_kelamin' => ImporExcel::jk($v['jenis_kelamin'] ?? null),
                'tempat_lahir' => ImporExcel::teks($v['tempat_lahir'] ?? null), 'tanggal_lahir' => ImporExcel::tanggal($v['tanggal_lahir'] ?? null),
                'agama' => ImporExcel::teks($v['agama'] ?? null), 'alamat' => ImporExcel::teks($v['alamat'] ?? null),
                'nama_wali' => ImporExcel::teks($v['nama_wali'] ?? null), 'no_hp_wali' => ImporExcel::teks($v['no_hp_wali'] ?? null),
                'rfid' => ImporExcel::teks($v['rfid'] ?? null),
            ], static fn ($x) => $x !== null);
            $ada = ($nisn ? $model->where('nisn', $nisn)->first() : null) ?: $model->where('nis', $nis)->first();
            if ($ada) {
                if ($perbarui) {
                    unset($rec['nis']);   // NIS lama dipertahankan
                    $model->update($ada['id'], $rec);
                    $res['ubah']++;
                } else {
                    $res['lewat']++;
                }
                $id = (int) $ada['id'];
            } else {
                $id = (int) $model->insert($rec + ['jenis_kelamin' => 'L', 'status' => 'Aktif']);
                $res['baru']++;
            }
            $nk = ImporExcel::teks($v['kelas'] ?? null);
            if ($nk && $this->tp) {
                $key = ImporExcel::kunciKelas($nk);
                if (! isset($kelas[$key]) && $buatKelas) {
                    $kelas[$key]            = (int) model(KelasModel::class)->insert(['nama_kelas' => mb_substr($nk, 0, 50), 'tingkat' => ImporExcel::tingkat($nk), 'is_active' => 1]);
                    $res['kelas_dibuat'][] = $nk;
                }
                if (isset($kelas[$key])) {
                    $penempatan[$id] = $kelas[$key];
                } else {
                    $res['catatan']["k{$nk}"] = "kelas {$nk} belum ada";
                }
            }
        }
        // tempatkan ke rombel TP aktif
        $ak   = model(AnggotaKelasModel::class);
        $sent = [];
        foreach ($penempatan as $sid => $kid) {
            $row = $ak->where(['tahun_pelajaran_id' => $this->tpId(), 'siswa_id' => $sid])->first();
            if (! $row) {
                $ak->insert(['tahun_pelajaran_id' => $this->tpId(), 'kelas_id' => $kid, 'siswa_id' => $sid, 'status' => 'Aktif']);
            } elseif ((int) $row['kelas_id'] !== $kid) {
                $ak->update($row['id'], ['kelas_id' => $kid, 'no_absen' => null]);
            }
            $sent[$kid] = true;
        }
        foreach (array_keys($sent) as $kid) {
            $ak->urutkanAbsen($kid, $this->tpId());
        }
        $res['catatan'] = array_values($res['catatan']);
        return $res;
    }

    private function prosesGuru(array $data, array $map): array
    {
        $model = model(GuruModel::class);
        $res   = ['baru' => 0, 'ubah' => 0, 'lewat' => 0, 'catatan' => []];
        foreach ($data as $row) {
            $v    = $this->ambil($row, $map);
            $nama = ImporExcel::teks($v['nama_lengkap'] ?? null);
            if (! $nama || is_numeric($nama)) {
                continue;
            }
            $rec = array_filter([
                'nama_lengkap' => mb_substr($nama, 0, 150),
                'nip' => ($n = ImporExcel::teks($v['nip'] ?? null)) ? preg_replace('/\D/', '', $n) ?: null : null,
                'nuptk' => ImporExcel::teks($v['nuptk'] ?? null), 'jenis_kelamin' => ImporExcel::jk($v['jenis_kelamin'] ?? null),
                'no_hp' => ImporExcel::teks($v['no_hp'] ?? null), 'email' => ImporExcel::teks($v['email'] ?? null),
                'status_kepegawaian' => ImporExcel::statusPegawai($v['status_kepegawaian'] ?? null),
                'gelar_depan' => ImporExcel::teks($v['gelar_depan'] ?? null), 'gelar_belakang' => ImporExcel::teks($v['gelar_belakang'] ?? null),
                'rfid' => ImporExcel::teks($v['rfid'] ?? null),
            ], static fn ($x) => $x !== null);
            $ada = null;
            if (! empty($rec['nip'])) {
                $ada = $model->where('nip', $rec['nip'])->first();
            }
            if (! $ada && ! empty($rec['nuptk'])) {
                $ada = $model->where('nuptk', $rec['nuptk'])->first();
            }
            if (! $ada) {
                $ada = $model->where('nama_lengkap', $rec['nama_lengkap'])->first();
            }
            if ($ada) {
                $model->update($ada['id'], $rec);
                $res['ubah']++;
            } else {
                $model->insert($rec + ['jenis_kelamin' => 'L', 'is_active' => 1]);
                $res['baru']++;
            }
        }
        return $res;
    }

    // ------------------------------------------------------------------ pembantu pencarian
    private static function yaTidak($v, ?int $bawaan = null): ?int
    {
        $n = ImporExcel::norm($v);
        if ($n === '') {
            return $bawaan;
        }
        return in_array($n, ['ya', 'y', '1', 'aktif', 'iya', 'yes', 'true', 'ada'], true) ? 1 : 0;
    }

    private function cariKelas(?string $nama): ?int
    {
        static $peta = null;
        if ($peta === null) {
            $peta = [];
            foreach (model(KelasModel::class)->findAll() as $k) {
                $peta[ImporExcel::kunciKelas($k['nama_kelas'])] = (int) $k['id'];
            }
        }
        return $nama ? ($peta[ImporExcel::kunciKelas($nama)] ?? null) : null;
    }

    private function cariMapel(?string $v): ?int
    {
        if (! $v) {
            return null;
        }
        $m = model(\App\Models\MapelModel::class);
        $r = $m->where('kode_mapel', strtoupper($v))->first() ?: $m->where('LOWER(nama_mapel)', mb_strtolower($v))->first();
        return $r ? (int) $r['id'] : null;
    }

    private function cariGuru(?string $v): ?int
    {
        if (! $v) {
            return null;
        }
        $g     = model(GuruModel::class);
        $angka = preg_replace('/\D/', '', $v);
        $r     = null;
        if (strlen($angka) >= 8) {
            $r = $g->where('nip', $angka)->first() ?: $g->where('nuptk', $angka)->first();
        }
        if (! $r) {
            $nama = trim(preg_replace('/,.*$/', '', $v));          // buang gelar belakang
            $nama = trim(preg_replace('/^((Drs?|Dra|Hj?|Ir|Prof)\.?\s+)+/i', '', $nama));
            $r    = $g->where('LOWER(nama_lengkap)', mb_strtolower($nama))->first();
        }
        return $r ? (int) $r['id'] : null;
    }

    private function hasil(): array
    {
        return ['baru' => 0, 'ubah' => 0, 'lewat' => 0, 'catatan' => []];
    }

    // ------------------------------------------------------------------ prosesor per jenis
    private function prosesMapel(array $data, array $map): array
    {
        $m   = model(\App\Models\MapelModel::class);
        $res = $this->hasil();
        foreach ($data as $row) {
            $v    = $this->ambil($row, $map);
            $kode = strtoupper((string) ImporExcel::teks($v['kode_mapel'] ?? null));
            $nama = ImporExcel::teks($v['nama_mapel'] ?? null);
            if (! $kode || ! $nama) {
                $res['lewat'] += ($kode || $nama) ? 1 : 0;
                continue;
            }
            $rec = ['kode_mapel' => mb_substr($kode, 0, 20), 'nama_mapel' => mb_substr($nama, 0, 100), 'kelompok' => ImporExcel::teks($v['kelompok'] ?? null), 'is_active' => self::yaTidak($v['aktif'] ?? null, 1)];
            $ada = $m->where('kode_mapel', $rec['kode_mapel'])->first();
            $ada ? $m->update($ada['id'], $rec) : $m->insert($rec);
            $res[$ada ? 'ubah' : 'baru']++;
        }
        return $res;
    }

    private function prosesKelas(array $data, array $map): array
    {
        $m   = model(KelasModel::class);
        $res = $this->hasil();
        foreach ($data as $row) {
            $v    = $this->ambil($row, $map);
            $nama = ImporExcel::teks($v['nama_kelas'] ?? null);
            if (! $nama) {
                continue;
            }
            $rec = ['nama_kelas' => mb_substr($nama, 0, 50), 'tingkat' => ImporExcel::teks($v['tingkat'] ?? null) ?: ImporExcel::tingkat($nama), 'is_active' => 1];
            if ($j = ImporExcel::teks($v['jurusan'] ?? null)) {
                $jm  = model(\App\Models\JurusanModel::class);
                $jur = $jm->where('kode_jurusan', strtoupper($j))->first() ?: $jm->where('LOWER(nama_jurusan)', mb_strtolower($j))->first();
                $rec['jurusan_id'] = $jur ? (int) $jur['id'] : (int) $jm->insert(['kode_jurusan' => strtoupper(mb_substr(preg_replace('/\s+/', '', $j), 0, 10)), 'nama_jurusan' => $j]);
            }
            $id = $this->cariKelas($nama);
            if ($id) {
                unset($rec['nama_kelas']);     // "VII-A" di Excel = kelas "VII A" yang sudah ada; nama tidak diubah
                $m->update($id, $rec);
                $res['ubah']++;
            } else {
                $id = (int) $m->insert($rec);
                $res['baru']++;
            }
            if (($w = ImporExcel::teks($v['wali'] ?? null)) && $this->tp) {
                $gid = $this->cariGuru($w);
                if ($gid) {
                    model(\App\Models\WaliKelasModel::class)->tetapkan($this->tpId(), $id, $gid);
                } else {
                    $res['catatan'][] = "wali {$w} tidak ditemukan ({$nama})";
                }
            }
        }
        return $res;
    }

    private function prosesPenugasan(array $data, array $map): array
    {
        $db  = db_connect();
        $res = $this->hasil();
        foreach ($data as $n => $row) {
            $v = $this->ambil($row, $map);
            if (! array_filter($v, static fn ($x) => ImporExcel::teks($x) !== null)) {
                continue;
            }
            $kid = $this->cariKelas(ImporExcel::teks($v['kelas'] ?? null));
            $mid = $this->cariMapel(ImporExcel::teks($v['mapel'] ?? null));
            $gid = $this->cariGuru(ImporExcel::teks($v['guru'] ?? null));
            $jp  = (int) ImporExcel::teks($v['jp'] ?? null);
            if (! $kid || ! $mid || ! $gid || $jp < 1) {
                $res['lewat']++;
                $res['catatan'][] = 'baris ' . ($n + 2) . ': ' . (! $kid ? 'kelas' : (! $mid ? 'mapel' : (! $gid ? 'guru' : 'JP'))) . ' tidak dikenali';
                continue;
            }
            $ada = $db->table('penugasan_guru')->where(['tahun_pelajaran_id' => $this->tpId(), 'mapel_id' => $mid, 'kelas_id' => $kid])->get()->getRowArray();
            $now = date('Y-m-d H:i:s');
            if ($ada) {
                $db->table('penugasan_guru')->where('id', $ada['id'])->update(['guru_id' => $gid, 'jp_per_minggu' => $jp, 'updated_at' => $now]);
                $res['ubah']++;
            } else {
                $db->table('penugasan_guru')->insert(['tahun_pelajaran_id' => $this->tpId(), 'guru_id' => $gid, 'mapel_id' => $mid, 'kelas_id' => $kid, 'jp_per_minggu' => $jp, 'created_at' => $now, 'updated_at' => $now]);
                $res['baru']++;
            }
        }
        return $res;
    }

    private function prosesKalender(array $data, array $map): array
    {
        $m    = model(\App\Models\KalenderModel::class);
        $res  = $this->hasil();
        $hari = ['senin' => 1, 'selasa' => 2, 'rabu' => 3, 'kamis' => 4, 'jumat' => 5, 'sabtu' => 6];
        foreach ($data as $n => $row) {
            $v     = $this->ambil($row, $map);
            $mulai = ImporExcel::tanggal($v['tanggal_mulai'] ?? null);
            $nama  = ImporExcel::teks($v['nama'] ?? null);
            if (! $mulai && ! $nama) {
                continue;
            }
            $jenis = null;
            $jn    = ImporExcel::norm($v['jenis'] ?? '');
            foreach (\App\Models\KalenderModel::JENIS as $j) {
                if ($jn === ImporExcel::norm($j) || ($jn !== '' && str_contains(ImporExcel::norm($j), $jn))) {
                    $jenis = $j;
                    break;
                }
            }
            if (! $mulai || ! $nama || ! $jenis) {
                $res['lewat']++;
                $res['catatan'][] = 'baris ' . ($n + 2) . ': ' . (! $mulai ? 'tanggal' : (! $nama ? 'nama' : 'jenis')) . ' tidak valid';
                continue;
            }
            $selesai = ImporExcel::tanggal($v['tanggal_selesai'] ?? null) ?: $mulai;
            [$kbm, $abs] = \App\Models\KalenderModel::BAWAAN[$jenis];
            $kelas = [];
            foreach (array_filter(array_map('trim', explode(',', (string) ImporExcel::teks($v['kelas'] ?? null)))) as $kn) {
                if ($kid = $this->cariKelas($kn)) {
                    $kelas[] = $kid;
                } else {
                    $res['catatan'][] = "kelas {$kn} tidak dikenal";
                }
            }
            $rec = [
                'tahun_pelajaran_id' => $this->tpId(), 'tanggal_mulai' => $mulai, 'tanggal_selesai' => max($mulai, $selesai), 'jenis' => $jenis, 'nama' => mb_substr($nama, 0, 150),
                'keterangan' => ImporExcel::teks($v['keterangan'] ?? null), 'ada_kbm' => self::yaTidak($v['ada_kbm'] ?? null, $kbm), 'ada_absensi' => self::yaTidak($v['ada_absensi'] ?? null, $abs),
                'kelas_ids' => $kelas ? implode(',', $kelas) : null,
                'hari_jadwal' => $jenis === 'Masuk Pengganti' ? ($hari[ImporExcel::norm($v['hari_jadwal'] ?? '')] ?? null) : null,
            ];
            if ($jenis === 'Masuk Pengganti' && ! $rec['hari_jadwal']) {
                $res['lewat']++;
                $res['catatan'][] = "{$nama}: isi kolom Jadwal hari";
                continue;
            }
            if ($rec['ada_kbm'] && ! $rec['ada_absensi']) {
                $rec['ada_absensi'] = 1;
            }
            $ada = $m->where(['tahun_pelajaran_id' => $this->tpId(), 'tanggal_mulai' => $mulai, 'nama' => $rec['nama']])->first();
            $ada ? $m->update($ada['id'], $rec) : $m->insert($rec);
            $res[$ada ? 'ubah' : 'baru']++;
        }
        return $res;
    }

    private function prosesAtp(array $data, array $map): array
    {
        $m   = model(\App\Models\AtpModel::class);
        $res = $this->hasil();
        foreach ($data as $n => $row) {
            $v      = $this->ambil($row, $map);
            $tujuan = ImporExcel::teks($v['tujuan'] ?? null);
            if (! $tujuan) {
                continue;
            }
            $mid = $this->cariMapel(ImporExcel::teks($v['mapel'] ?? null));
            $tkt = ImporExcel::teks($v['tingkat'] ?? null);
            if (! $mid || ! $tkt) {
                $res['lewat']++;
                $res['catatan'][] = 'baris ' . ($n + 2) . ': ' . (! $mid ? 'mapel' : 'tingkat') . ' tidak dikenali';
                continue;
            }
            $tkt = strtoupper(preg_replace('/^kelas\s+/i', '', $tkt));
            $smt = ucfirst(strtolower((string) ImporExcel::teks($v['semester'] ?? null)));
            $rec = ['mapel_id' => $mid, 'tingkat' => $tkt, 'fase' => \App\Models\AtpModel::faseDari($tkt), 'semester' => in_array($smt, ['Ganjil', 'Genap'], true) ? $smt : null,
                'elemen' => ImporExcel::teks($v['elemen'] ?? null), 'kode' => ImporExcel::teks($v['kode'] ?? null), 'tujuan' => $tujuan,
                'alokasi_jp' => (int) ImporExcel::teks($v['alokasi_jp'] ?? null) ?: null, 'urutan' => (int) ImporExcel::teks($v['urutan'] ?? null)];
            $b   = $m->where(['mapel_id' => $mid, 'tingkat' => $tkt]);
            $ada = $rec['kode'] ? $b->where('kode', $rec['kode'])->first() : $b->where('tujuan', $tujuan)->first();
            if ($ada) {
                $m->update($ada['id'], $rec);
                $res['ubah']++;
            } else {
                $m->insert($rec + ['dibuat_oleh' => $this->userId()]);
                $res['baru']++;
            }
        }
        return $res;
    }

    private function prosesPerilaku(array $data, array $map): array
    {
        $db  = db_connect();
        $res = $this->hasil();
        foreach ($data as $n => $row) {
            $v    = $this->ambil($row, $map);
            $nama = ImporExcel::teks($v['nama'] ?? null);
            if (! $nama) {
                continue;
            }
            $kat = str_starts_with(ImporExcel::norm($v['kategori'] ?? ''), 'pos') ? 'Positif' : (str_starts_with(ImporExcel::norm($v['kategori'] ?? ''), 'neg') || str_contains(ImporExcel::norm($v['kategori'] ?? ''), 'langgar') ? 'Negatif' : null);
            if (! $kat) {
                $res['lewat']++;
                $res['catatan'][] = "{$nama}: kategori harus Positif/Negatif";
                continue;
            }
            $tk  = ucfirst(strtolower((string) ImporExcel::teks($v['tingkat'] ?? null)));
            $rec = ['kategori' => $kat, 'nama' => mb_substr($nama, 0, 150), 'tingkat' => in_array($tk, ['Ringan', 'Sedang', 'Berat'], true) ? $tk : null,
                'poin' => abs((int) ImporExcel::teks($v['poin'] ?? null)), 'is_active' => 1, 'updated_at' => date('Y-m-d H:i:s')];
            $ada = $db->table('jenis_perilaku')->where(['kategori' => $kat, 'nama' => $rec['nama']])->get()->getRowArray();
            $ada ? $db->table('jenis_perilaku')->where('id', $ada['id'])->update($rec) : $db->table('jenis_perilaku')->insert($rec + ['created_at' => $rec['updated_at']]);
            $res[$ada ? 'ubah' : 'baru']++;
        }
        return $res;
    }

    private function prosesPembiasaan(array $data, array $map): array
    {
        $db  = db_connect();
        $res = $this->hasil();
        foreach ($data as $row) {
            $v    = $this->ambil($row, $map);
            $nama = ImporExcel::teks($v['nama'] ?? null);
            if (! $nama) {
                continue;
            }
            $rec = ['nama' => mb_substr($nama, 0, 150), 'kategori' => ImporExcel::teks($v['kategori'] ?? null), 'deskripsi' => ImporExcel::teks($v['deskripsi'] ?? null),
                'urutan' => (int) ImporExcel::teks($v['urutan'] ?? null), 'is_active' => 1, 'updated_at' => date('Y-m-d H:i:s')];
            $ada = $db->table('pembiasaan')->where('nama', $rec['nama'])->get()->getRowArray();
            $ada ? $db->table('pembiasaan')->where('id', $ada['id'])->update($rec) : $db->table('pembiasaan')->insert($rec + ['created_at' => $rec['updated_at']]);
            $res[$ada ? 'ubah' : 'baru']++;
        }
        return $res;
    }
}
