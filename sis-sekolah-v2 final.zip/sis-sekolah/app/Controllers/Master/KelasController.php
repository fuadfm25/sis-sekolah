<?php

namespace App\Controllers\Master;

use App\Controllers\BaseController;
use App\Models\AnggotaKelasModel;
use App\Models\GuruModel;
use App\Models\JurusanModel;
use App\Models\KelasModel;
use App\Models\WaliKelasModel;

class KelasController extends BaseController
{
    private KelasModel $model;

    public function __construct()
    {
        $this->model = new KelasModel();
    }

    public function index()
    {
        return view('master/kelas/index', [
            'title'    => 'Kelas & Rombongan Belajar',
            'subtitle' => $this->tp ? 'Wali kelas & jumlah siswa untuk TP ' . $this->tp['tahun_pelajaran'] . ' ' . $this->tp['semester'] : 'TP aktif belum diatur.',
            'rows'     => $this->model->detailList($this->tpId()),
            'jurusan'  => model(JurusanModel::class)->orderBy('nama_jurusan')->findAll(),
            'guru'     => model(GuruModel::class)->listAktif(),
        ]);
    }

    public function store()
    {
        return $this->simpan();
    }

    public function update($id)
    {
        return $this->simpan((int) $id);
    }

    private function simpan(?int $id = null)
    {
        $rules = [
            'tingkat'    => 'required|max_length[5]',
            'nama_kelas' => 'required|max_length[50]|is_unique[kelas.nama_kelas,id,' . ($id ?? 0) . ']',
        ];
        if (! $this->validate($rules)) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }
        $data = [
            'tingkat'    => trim($this->request->getPost('tingkat')),
            'nama_kelas' => trim($this->request->getPost('nama_kelas')),
            'jurusan_id' => $this->request->getPost('jurusan_id') ?: null,
            'is_active'  => $this->request->getPost('is_active') ? 1 : 0,
        ];
        if ($id) {
            $this->model->update($id, $data);
        } else {
            $id = (int) $this->model->insert($data);
        }
        if ($this->tp && $this->request->getPost('wali_guru_id') !== null) {
            model(WaliKelasModel::class)->tetapkan($this->tpId(), $id, (int) $this->request->getPost('wali_guru_id') ?: null);
        }
        return redirect()->to('/master/kelas')->with('success', 'Data kelas disimpan.');
    }

    public function delete($id)
    {
        $w = ['kelas_id' => (int) $id];
        if ($pesan = $this->masihDipakai(['anggota rombel' => ['anggota_kelas', $w], 'jadwal' => ['jadwal_pelajaran', $w], 'jurnal' => ['jurnal_pembelajaran', $w],
            'absensi harian' => ['presensi_harian', $w], 'penugasan' => ['penugasan_guru', $w]], 'Hapus centang "Aktif" pada kelas untuk menyembunyikannya.')) {
            return redirect()->back()->with('error', $pesan);
        }
        $k = $this->model->find($id);
        $this->model->delete($id);
        catat_log('hapus', 'kelas', (int) $id, $k['nama_kelas'] ?? null);
        return redirect()->to('/master/kelas')->with('success', 'Kelas dihapus.');
    }

    /** Halaman rombel: wali kelas & anggota kelas pada TP aktif. */
    public function detail($id)
    {
        if ($r = $this->wajibTp()) {
            return $r;
        }
        $kelas = $this->model->find($id);
        if (! $kelas) {
            return redirect()->to('/master/kelas')->with('error', 'Kelas tidak ditemukan.');
        }
        $ak = model(AnggotaKelasModel::class);

        return view('master/kelas/detail', [
            'title'      => 'Rombel ' . $kelas['nama_kelas'],
            'subtitle'   => 'TP ' . $this->tp['tahun_pelajaran'] . ' ' . $this->tp['semester'],
            'kelas'      => $kelas,
            'wali'       => model(WaliKelasModel::class)->waliDari((int) $id, $this->tpId()),
            'guru'       => model(GuruModel::class)->listAktif(),
            'anggota'    => $ak->siswaKelas((int) $id, $this->tpId(), false),
            'calon'      => $ak->siswaBelumBerkelas($this->tpId()),
        ]);
    }

    public function wali($id)
    {
        if ($r = $this->wajibTp()) {
            return $r;
        }
        model(WaliKelasModel::class)->tetapkan($this->tpId(), (int) $id, (int) $this->request->getPost('guru_id') ?: null);
        return redirect()->to('/master/kelas/' . $id)->with('success', 'Wali kelas disimpan.');
    }

    public function tambahAnggota($id)
    {
        if ($r = $this->wajibTp()) {
            return $r;
        }
        $ak     = model(AnggotaKelasModel::class);
        $ids    = (array) $this->request->getPost('siswa_ids');
        $jumlah = 0;
        foreach ($ids as $sid) {
            if (! $ak->where(['tahun_pelajaran_id' => $this->tpId(), 'siswa_id' => (int) $sid])->first()) {
                $ak->insert(['tahun_pelajaran_id' => $this->tpId(), 'kelas_id' => (int) $id, 'siswa_id' => (int) $sid, 'status' => 'Aktif']);
                $jumlah++;
            }
        }
        $ak->urutkanAbsen((int) $id, $this->tpId());
        return redirect()->to('/master/kelas/' . $id)->with('success', "$jumlah siswa ditambahkan ke kelas.");
    }

    public function urutkan($id)
    {
        model(AnggotaKelasModel::class)->urutkanAbsen((int) $id, (int) $this->tpId());
        return redirect()->to('/master/kelas/' . $id)->with('success', 'Nomor absen diurutkan berdasarkan nama.');
    }

    public function hapusAnggota($anggotaId)
    {
        $ak  = model(AnggotaKelasModel::class);
        $row = $ak->find($anggotaId);
        if ($row) {
            $ak->delete($anggotaId);
        }
        return redirect()->to('/master/kelas/' . ($row['kelas_id'] ?? ''))->with('success', 'Siswa dikeluarkan dari rombel.');
    }
}
