<?php

namespace App\Controllers\Master;

use App\Controllers\BaseController;
use App\Models\AnggotaKelasModel;
use App\Models\KelasModel;
use App\Models\SiswaModel;
use App\Models\TahunPelajaranModel;

/**
 * Memindahkan siswa dari rombel TP asal ke rombel TP aktif (naik kelas / tinggal kelas / lulus).
 * Juga dipakai untuk pergantian semester (Ganjil -> Genap): pilih kelas tujuan yang sama.
 */
class KenaikanKelasController extends BaseController
{
    public function index()
    {
        if ($r = $this->wajibTp()) {
            return $r;
        }
        $tpModel = model(TahunPelajaranModel::class);
        $asalId  = (int) $this->request->getGet('tp_asal');
        $kelasId = (int) $this->request->getGet('kelas_asal');

        $siswa = [];
        if ($asalId && $kelasId) {
            $siswa = model(AnggotaKelasModel::class)->siswaKelas($kelasId, $asalId);
            $sudah = array_column(model(AnggotaKelasModel::class)->select('siswa_id, kelas_id')->where('tahun_pelajaran_id', $this->tpId())->findAll(), 'kelas_id', 'siswa_id');
            foreach ($siswa as &$s) {
                $s['kelas_tujuan_sekarang'] = $sudah[$s['id']] ?? null;
            }
        }

        return view('master/kenaikan/index', [
            'title'    => 'Kenaikan Kelas / Pindah Semester',
            'subtitle' => 'Salin rombel dari tahun pelajaran sebelumnya ke TP aktif (' . $this->tp['tahun_pelajaran'] . ' ' . $this->tp['semester'] . ').',
            'tpList'   => $tpModel->where('id !=', $this->tpId())->orderBy('tahun_pelajaran', 'DESC')->orderBy('semester', 'DESC')->findAll(),
            'kelas'    => model(KelasModel::class)->listAktif(),
            'asalId'   => $asalId,
            'kelasId'  => $kelasId,
            'siswa'    => $siswa,
        ]);
    }

    public function proses()
    {
        if ($r = $this->wajibTp()) {
            return $r;
        }
        $asalId  = (int) $this->request->getPost('tp_asal');
        $kelasId = (int) $this->request->getPost('kelas_asal');
        $tujuan  = (int) $this->request->getPost('kelas_tujuan');
        $aksi    = (array) $this->request->getPost('aksi'); // [siswa_id => naik|tinggal|lulus|lewati]

        $ak    = model(AnggotaKelasModel::class);
        $siswa = model(SiswaModel::class);
        $hit   = ['naik' => 0, 'tinggal' => 0, 'lulus' => 0];

        $db = db_connect();
        $db->transStart();
        foreach ($aksi as $sid => $a) {
            $sid  = (int) $sid;
            $asal = $ak->where(['tahun_pelajaran_id' => $asalId, 'siswa_id' => $sid])->first();
            if (! $asal || $a === 'lewati') {
                continue;
            }
            if ($a === 'lulus') {
                $ak->update($asal['id'], ['status' => 'Lulus']);
                $siswa->update($sid, ['status' => 'Lulus']);
                model(\App\Models\MutasiSiswaModel::class)->insert(['tahun_pelajaran_id' => $asalId, 'siswa_id' => $sid, 'jenis' => 'Lulus', 'tanggal' => $this->tp['tanggal_mulai'] ?: date('Y-m-d'),
                    'kelas_asal_id' => $kelasId, 'status_sebelum' => 'Aktif', 'dicatat_oleh' => $this->userId(), 'alasan' => 'Kenaikan kelas manual']);
                $hit['lulus']++;
                continue;
            }
            $ke = $a === 'tinggal' ? $kelasId : $tujuan;
            if (! $ke) {
                continue;
            }
            $ak->update($asal['id'], ['status' => $a === 'tinggal' ? 'Tinggal Kelas' : 'Naik Kelas']);
            $now = $ak->where(['tahun_pelajaran_id' => $this->tpId(), 'siswa_id' => $sid])->first();
            $now ? $ak->update($now['id'], ['kelas_id' => $ke, 'status' => 'Aktif'])
                 : $ak->insert(['tahun_pelajaran_id' => $this->tpId(), 'kelas_id' => $ke, 'siswa_id' => $sid, 'status' => 'Aktif']);
            $hit[$a]++;
        }
        $db->transComplete();
        if ($tujuan) {
            $ak->urutkanAbsen($tujuan, $this->tpId());
        }
        if ($hit['tinggal']) {
            $ak->urutkanAbsen($kelasId, $this->tpId());
        }

        return redirect()->to("/master/kenaikan-kelas?tp_asal={$asalId}&kelas_asal={$kelasId}")
            ->with('success', "Selesai: {$hit['naik']} naik/pindah, {$hit['tinggal']} tinggal kelas, {$hit['lulus']} lulus.");
    }

    // ================================================================ OTOMATIS (1 klik)
    /** Tingkat akhir menurut jenjang (SD/MI 6, SMP/MTs 9, SMA/MA/SMK/MAK 12), selain itu tingkat terbesar yang ada. */
    private function tingkatAkhir(array $kelas): int
    {
        $j = strtoupper((string) setting('jenjang', ''));
        if (in_array($j, ['SD', 'MI'], true)) {
            return 6;
        }
        if (in_array($j, ['SMP', 'MTS'], true)) {
            return 9;
        }
        if (in_array($j, ['SMA', 'MA', 'SMK', 'MAK'], true)) {
            return 12;
        }
        return max(array_map(fn ($k) => $this->angkaTingkat((string) $k['tingkat']), $kelas) ?: [0]);
    }

    private function angkaTingkat(string $t): int
    {
        $r = ['XII' => 12, 'XI' => 11, 'X' => 10, 'IX' => 9, 'VIII' => 8, 'VII' => 7, 'VI' => 6, 'V' => 5, 'IV' => 4, 'III' => 3, 'II' => 2, 'I' => 1];
        $t = strtoupper(trim($t));
        return ctype_digit($t) ? (int) $t : ($r[$t] ?? 0);
    }

    /** Nama kelas tingkat berikutnya dengan format yang sama: "VII A" → "VIII A", "7-B" → "8-B", "X IPA 1" → "XI IPA 1". */
    private function namaBerikut(array $k): ?string
    {
        $n    = $this->angkaTingkat((string) $k['tingkat']);
        $nama = trim($k['nama_kelas']);
        $romawi = [1 => 'I', 'II', 'III', 'IV', 'V', 'VI', 'VII', 'VIII', 'IX', 'X', 'XI', 'XII'];
        if (! $n || $n >= 12) {
            return null;
        }
        if (preg_match('/^(XII|XI|IX|X|VIII|VII|VI|IV|V|III|II|I)(?![IVX])(.*)$/i', $nama, $m) && $this->angkaTingkat($m[1]) === $n) {
            return $romawi[$n + 1] . $m[2];
        }
        if (preg_match('/^(\d{1,2})(?!\d)(.*)$/', $nama, $m) && (int) $m[1] === $n) {
            return ($n + 1) . $m[2];
        }
        return null;
    }

    private function tingkatTeks(string $asal, int $n): string
    {
        $romawi = [1 => 'I', 'II', 'III', 'IV', 'V', 'VI', 'VII', 'VIII', 'IX', 'X', 'XI', 'XII'];
        return ctype_digit(trim($asal)) ? (string) $n : $romawi[$n];
    }

    /** Rencana: setiap kelas asal → kelas tujuan / lulus / tetap (pergantian semester). */
    private function rencana(int $asalId): array
    {
        $tpAsal = model(TahunPelajaranModel::class)->find($asalId);
        $semua  = model(KelasModel::class)->findAll();
        $kunci  = [];
        foreach ($semua as $k) {
            $kunci[\App\Libraries\ImporExcel::kunciKelas($k['nama_kelas'])] = $k;
        }
        $akhir    = $this->tingkatAkhir($semua);
        $semester = $tpAsal && $tpAsal['tahun_pelajaran'] === $this->tp['tahun_pelajaran'];   // Ganjil → Genap
        $jumlah   = db_connect()->table('anggota_kelas a')->select('a.kelas_id, COUNT(*) AS n')->join('siswa s', 's.id = a.siswa_id')
            ->where(['a.tahun_pelajaran_id' => $asalId, 's.status' => 'Aktif'])->groupBy('a.kelas_id')->get()->getResultArray();
        $out = [];
        foreach ($jumlah as $j) {
            $k = null;
            foreach ($semua as $x) {
                if ((int) $x['id'] === (int) $j['kelas_id']) {
                    $k = $x;
                }
            }
            if (! $k) {
                continue;
            }
            $n    = $this->angkaTingkat((string) $k['tingkat']);
            $baru = null;
            if ($semester) {
                $aksi = 'kelas';
                $tuju = (int) $k['id'];
            } elseif ($n && $n >= $akhir) {
                $aksi = 'lulus';
                $tuju = null;
            } else {
                $nm   = $this->namaBerikut($k);
                $ada  = $nm ? ($kunci[\App\Libraries\ImporExcel::kunciKelas($nm)] ?? null) : null;
                $aksi = $ada || $nm ? 'kelas' : 'lewati';
                $tuju = $ada ? (int) $ada['id'] : null;
                $baru = ! $ada && $nm ? ['nama_kelas' => $nm, 'tingkat' => $this->tingkatTeks((string) $k['tingkat'], $n + 1), 'jurusan_id' => $k['jurusan_id']] : null;
            }
            $out[] = ['asal' => $k, 'siswa' => (int) $j['n'], 'aksi' => $aksi, 'tujuan' => $tuju, 'baru' => $baru, 'n' => $n];
        }
        usort($out, static fn ($a, $b) => [$a['n'], $a['asal']['nama_kelas']] <=> [$b['n'], $b['asal']['nama_kelas']]);
        return ['rencana' => $out, 'semester' => $semester, 'akhir' => $akhir, 'tpAsal' => $tpAsal];
    }

    public function otomatis()
    {
        if ($r = $this->wajibTp()) {
            return $r;
        }
        $tpList = model(TahunPelajaranModel::class)->where('id !=', $this->tpId())->orderBy('tahun_pelajaran', 'DESC')->orderBy('semester', 'DESC')->findAll();
        $asalId = (int) ($this->request->getGet('tp_asal') ?: ($tpList[0]['id'] ?? 0));
        $sudah  = db_connect()->table('anggota_kelas')->where('tahun_pelajaran_id', $this->tpId())->countAllResults();
        return view('master/kenaikan/otomatis', ($asalId ? $this->rencana($asalId) : ['rencana' => [], 'semester' => false, 'akhir' => 0, 'tpAsal' => null]) + [
            'title'    => 'Kenaikan Kelas Otomatis',
            'subtitle' => 'Semua kelas dinaikkan sekaligus ke TP aktif (' . $this->tp['tahun_pelajaran'] . ' ' . $this->tp['semester'] . '); kelas tingkat akhir diluluskan.',
            'tpList'   => $tpList,
            'asalId'   => $asalId,
            'kelas'    => model(KelasModel::class)->listAktif(),
            'sudah'    => $sudah,
        ]);
    }

    public function prosesOtomatis()
    {
        if ($r = $this->wajibTp()) {
            return $r;
        }
        $asalId = (int) $this->request->getPost('tp_asal');
        if (! $asalId || $asalId === $this->tpId()) {
            return $this->back('error', 'Pilih tahun pelajaran asal.');
        }
        $info     = $this->rencana($asalId);
        $plan     = $info['rencana'];
        $semester = $info['semester'];
        $pilih = (array) $this->request->getPost('tujuan');   // [kelas_asal_id => kelas_id | 'lulus' | 'lewati' | 'baru']
        $ak    = model(AnggotaKelasModel::class);
        $sm    = model(SiswaModel::class);
        $km    = model(KelasModel::class);
        $mut   = model(\App\Models\MutasiSiswaModel::class);
        $hit   = ['naik' => 0, 'lulus' => 0, 'lewat' => 0, 'kelas_baru' => []];
        $urut  = [];
        $db    = db_connect();
        $db->transStart();
        foreach ($plan as $p) {
            $asalK = (int) $p['asal']['id'];
            $v     = (string) ($pilih[$asalK] ?? '');
            if ($v === '' || $v === 'lewati') {
                continue;
            }
            $tujuan = null;
            if ($v === 'baru' && $p['baru']) {
                $ada    = $km->where('nama_kelas', $p['baru']['nama_kelas'])->first();
                $tujuan = $ada ? (int) $ada['id'] : (int) $km->insert($p['baru'] + ['is_active' => 1]);
                if (! $ada) {
                    $hit['kelas_baru'][] = $p['baru']['nama_kelas'];
                }
            } elseif (ctype_digit($v)) {
                $tujuan = (int) $v;
            } elseif ($v !== 'lulus') {
                continue;
            }
            foreach ($ak->siswaKelas($asalK, $asalId) as $s) {
                if ($ak->where(['tahun_pelajaran_id' => $this->tpId(), 'siswa_id' => $s['id']])->first()) {
                    $hit['lewat']++;      // sudah ditempatkan (mis. tinggal kelas lewat proses manual)
                    continue;
                }
                if ($v === 'lulus') {
                    $ak->update($s['anggota_id'], ['status' => 'Lulus']);
                    $sm->update($s['id'], ['status' => 'Lulus']);
                    $mut->insert(['tahun_pelajaran_id' => $asalId, 'siswa_id' => $s['id'], 'jenis' => 'Lulus', 'tanggal' => $this->tp['tanggal_mulai'] ?: date('Y-m-d'),
                        'kelas_asal_id' => $asalK, 'status_sebelum' => 'Aktif', 'dicatat_oleh' => $this->userId(), 'alasan' => 'Kenaikan kelas otomatis']);
                    $hit['lulus']++;
                    continue;
                }
                if (! $semester) {
                    $ak->update($s['anggota_id'], ['status' => $tujuan === $asalK ? 'Tinggal Kelas' : 'Naik Kelas']);
                }
                $ak->insert(['tahun_pelajaran_id' => $this->tpId(), 'kelas_id' => $tujuan, 'siswa_id' => $s['id'], 'status' => 'Aktif', 'no_absen' => $s['no_absen']]);
                $urut[$tujuan] = true;
                $hit['naik']++;
            }
        }
        $db->transComplete();
        foreach (array_keys($urut) as $k) {
            $ak->urutkanAbsen($k, $this->tpId());
        }
        catat_log('kenaikan_otomatis', 'anggota_kelas', $asalId, json_encode($hit));
        return redirect()->to('/master/kenaikan-kelas/otomatis?tp_asal=' . $asalId)->with('success',
            "Selesai: {$hit['naik']} siswa ditempatkan di kelas baru, {$hit['lulus']} lulus" . ($hit['lewat'] ? ", {$hit['lewat']} dilewati karena sudah punya kelas di TP aktif" : '') . '.'
            . ($hit['kelas_baru'] ? ' Kelas dibuat: ' . implode(', ', $hit['kelas_baru']) . '.' : ''));
    }
}
