<?php

namespace App\Controllers\Master;

use App\Controllers\BaseController;
use App\Models\GuruModel;
use App\Models\UserModel;

class GuruController extends BaseController
{
    private GuruModel $model;

    public function __construct()
    {
        $this->model = new GuruModel();
    }

    public function index()
    {
        return view('master/guru/index', [
            'title'    => 'Data Guru',
            'subtitle' => 'Guru yang memiliki akun login dapat mengisi jurnal, absensi, dan catatan siswa.',
            'rows'     => $this->model->withUser(),
        ]);
    }

    private function input(): array
    {
        $p = fn ($k) => trim((string) $this->request->getPost($k)) ?: null;
        return [
            'nip' => $p('nip'), 'nuptk' => $p('nuptk'), 'rfid' => $p('rfid'), 'nama_lengkap' => $p('nama_lengkap'),
            'gelar_depan' => $p('gelar_depan'), 'gelar_belakang' => $p('gelar_belakang'),
            'jenis_kelamin' => $p('jenis_kelamin') ?? 'L', 'no_hp' => $p('no_hp'), 'email' => $p('email'),
            'status_kepegawaian' => $p('status_kepegawaian') ?? 'Honorer',
            'is_active' => $this->request->getPost('is_active') ? 1 : 0,
        ];
    }

    public function store()
    {
        if (! $this->validate(['nama_lengkap' => 'required|max_length[100]', 'jenis_kelamin' => 'required|in_list[L,P]'])) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }
        $id  = (int) $this->model->insert($this->input());
        $msg = 'Data guru ditambahkan.';
        if ($this->request->getPost('buat_akun')) {
            $msg .= ' ' . $this->akunUntuk($id);
        }
        return redirect()->to('/master/guru')->with('success', $msg);
    }

    public function update($id)
    {
        if (! $this->validate(['nama_lengkap' => 'required|max_length[100]', 'jenis_kelamin' => 'required|in_list[L,P]'])) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }
        $data = $this->input();
        $this->model->update($id, $data);

        // sinkronkan nama & status akun
        $guru = $this->model->find($id);
        if ($guru['user_id']) {
            model(UserModel::class)->update($guru['user_id'], ['nama_lengkap' => nama_guru($guru), 'is_active' => $data['is_active']]);
        }
        return redirect()->to('/master/guru')->with('success', 'Data guru diperbarui.');
    }

    public function delete($id)
    {
        $guru = $this->model->find($id);
        $w    = ['guru_id' => (int) $id];
        if ($pesan = $this->masihDipakai(['penugasan mengajar' => ['penugasan_guru', $w], 'jurnal' => ['jurnal_pembelajaran', $w], 'perwalian' => ['wali_kelas', $w],
            'kehadiran guru' => ['presensi_guru', $w]], 'Untuk guru yang pindah/pensiun, edit lalu hapus centang "Aktif".')) {
            return redirect()->back()->with('error', $pesan);
        }
        $this->model->delete($id);
        catat_log('hapus', 'guru', (int) $id, $guru['nama_lengkap'] ?? null);
        return redirect()->to('/master/guru')->with('success', 'Data guru dihapus.');
    }

    public function buatAkun($id)
    {
        return redirect()->to('/master/guru')->with('success', $this->akunUntuk((int) $id));
    }

    /** Membuat akun login untuk guru; mengembalikan pesan berisi username & password awal. */
    private function akunUntuk(int $guruId): string
    {
        $guru = $this->model->find($guruId);
        if (! $guru || $guru['user_id']) {
            return 'Guru sudah memiliki akun.';
        }
        $users = model(UserModel::class);
        $base  = $guru['nip'] ?: strtolower(url_title(convert_accented_characters($guru['nama_lengkap']), '.', true));
        $base  = substr($base ?: 'guru', 0, 40);
        $uname = $base;
        for ($i = 2; $users->where('username', $uname)->first(); $i++) {
            $uname = $base . $i;
        }
        $password = substr(str_shuffle('abcdefghjkmnpqrstuvwxyz23456789'), 0, 8);

        $userId = (int) $users->insert([
            'username' => $uname, 'password' => password_hash($password, PASSWORD_DEFAULT),
            'nama_lengkap' => nama_guru($guru), 'email' => $guru['email'], 'is_active' => 1,
        ]);
        $users->addRole($userId, 'guru');
        $this->model->update($guruId, ['user_id' => $userId]);

        return "Akun dibuat → username: {$uname} | password awal: {$password} (catat & minta guru menggantinya).";
    }
}
