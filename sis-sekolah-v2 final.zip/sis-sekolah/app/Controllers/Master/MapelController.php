<?php

namespace App\Controllers\Master;

use App\Controllers\BaseController;
use App\Models\MapelModel;

class MapelController extends BaseController
{
    private MapelModel $model;

    public function __construct()
    {
        $this->model = new MapelModel();
    }

    public function index()
    {
        return view('master/mapel/index', [
            'title' => 'Mata Pelajaran',
            'rows'  => $this->model->orderBy('kelompok')->orderBy('nama_mapel')->findAll(),
        ]);
    }

    public function store()
    {
        return $this->simpan();
    }

    public function update($id)
    {
        return $this->simpan((int) $id);
    }

    private function simpan(?int $id = null)
    {
        $rules = [
            'kode_mapel' => 'required|max_length[20]|is_unique[mata_pelajaran.kode_mapel,id,' . ($id ?? 0) . ']',
            'nama_mapel' => 'required|max_length[100]',
        ];
        $data = [
            'kode_mapel' => strtoupper(trim((string) $this->request->getPost('kode_mapel'))),
            'nama_mapel' => trim((string) $this->request->getPost('nama_mapel')),
            'kelompok'   => trim((string) $this->request->getPost('kelompok')) ?: null,
            'is_active'  => $this->request->getPost('is_active') ? 1 : 0,
        ];
        if (! $this->validateData($data, $rules)) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }
        $id ? $this->model->update($id, $data) : $this->model->insert($data);
        return redirect()->to('/master/mapel')->with('success', 'Mata pelajaran disimpan.');
    }

    public function delete($id)
    {
        if ($pesan = $this->masihDipakai(['penugasan' => ['penugasan_guru', ['mapel_id' => (int) $id]], 'ATP' => ['atp', ['mapel_id' => (int) $id]]], 'Nonaktifkan saja.')) {
            return redirect()->back()->with('error', $pesan);
        }
        $this->model->delete($id);
        catat_log('hapus', 'mata_pelajaran', (int) $id);
        return redirect()->to('/master/mapel')->with('success', 'Mata pelajaran dihapus.');
    }
}
