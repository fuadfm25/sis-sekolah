<?php

namespace App\Controllers\Master;

use App\Controllers\BaseController;
use App\Models\JurusanModel;

class JurusanController extends BaseController
{
    private JurusanModel $model;

    public function __construct()
    {
        $this->model = new JurusanModel();
    }

    public function index()
    {
        return view('master/jurusan/index', [
            'title'    => 'Jurusan',
            'subtitle' => 'Opsional – isi bila sekolah memiliki jurusan/peminatan (SMA/SMK).',
            'rows'     => $this->model->orderBy('kode_jurusan')->findAll(),
        ]);
    }

    public function store()
    {
        return $this->simpan();
    }

    public function update($id)
    {
        return $this->simpan((int) $id);
    }

    private function simpan(?int $id = null)
    {
        $rules = [
            'kode_jurusan' => 'required|max_length[20]|is_unique[jurusan.kode_jurusan,id,' . ($id ?? 0) . ']',
            'nama_jurusan' => 'required|max_length[100]',
        ];
        $data = ['kode_jurusan' => strtoupper(trim((string) $this->request->getPost('kode_jurusan'))), 'nama_jurusan' => trim((string) $this->request->getPost('nama_jurusan'))];
        if (! $this->validateData($data, $rules)) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }
        $id ? $this->model->update($id, $data) : $this->model->insert($data);
        return redirect()->to('/master/jurusan')->with('success', 'Data jurusan disimpan.');
    }

    public function delete($id)
    {
        catat_log('hapus', 'jurusan', (int) $id);
        $this->model->delete($id);
        return redirect()->to('/master/jurusan')->with('success', 'Jurusan dihapus.');
    }
}
