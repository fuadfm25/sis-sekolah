<?php

namespace App\Controllers\Master;

use App\Controllers\BaseController;
use App\Models\GuruModel;
use App\Models\RoleModel;
use App\Models\UserModel;

/**
 * Pengguna & role (admin): tambah/ubah, reset password (satuan & massal), aktif/nonaktif,
 * buka kunci login, dan pembuatan akun guru secara massal dengan daftar akun siap cetak.
 */
class PenggunaController extends BaseController
{
    private UserModel $model;

    public function __construct()
    {
        $this->model = new UserModel();
    }

    public function index()
    {
        $role   = $this->request->getGet('role');
        $f      = ['q' => trim((string) $this->request->getGet('q')), 'status' => (string) $this->request->getGet('status')];
        $tanpa  = model(GuruModel::class)->where('user_id', null)->where('is_active', 1)->countAllResults();
        return view('master/pengguna/index', [
            'title'     => 'Pengguna & Role',
            'subtitle'  => 'Kelola akun, role, reset password, dan buat akun guru sekaligus.',
            'rows'      => $this->model->withRoles($role ?: null, $f),
            'roles'     => model(RoleModel::class)->findAll(),
            'role'      => $role,
            'f'         => $f,
            'guruTanpa' => $tanpa,
        ]);
    }

    public function create()
    {
        return $this->form();
    }

    public function edit($id)
    {
        $user = $this->model->find($id);
        return $user ? $this->form($user) : redirect()->to('/sistem/pengguna');
    }

    private function form(?array $user = null)
    {
        $guruModel = model(GuruModel::class);
        return view('master/pengguna/form', [
            'title'    => $user ? 'Edit Pengguna' : 'Tambah Pengguna',
            'user'     => $user,
            'roles'    => model(RoleModel::class)->findAll(),
            'myRoles'  => $user ? $this->model->roleIds((int) $user['id']) : [],
            'guruList' => $guruModel->groupStart()->where('user_id', null)->orWhere('user_id', $user['id'] ?? 0)->groupEnd()->orderBy('nama_lengkap')->findAll(),
            'guruId'   => $user ? ($guruModel->byUser((int) $user['id'])['id'] ?? null) : null,
        ]);
    }

    public function store()
    {
        return $this->simpan();
    }

    public function update($id)
    {
        return $this->simpan((int) $id);
    }

    private function simpan(?int $id = null)
    {
        $rules = [
            'username'     => 'required|alpha_numeric_punct|min_length[3]|max_length[50]|is_unique[users.username,id,' . ($id ?? 0) . ']',
            'nama_lengkap' => 'required|max_length[100]',
            'password'     => $id ? 'permit_empty|min_length[6]' : 'required|min_length[6]',
            'roles'        => 'required',
        ];
        if (! $this->validate($rules, ['roles' => ['required' => 'Pilih minimal satu role.']])) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }
        $data = [
            'username'     => trim($this->request->getPost('username')),
            'nama_lengkap' => trim($this->request->getPost('nama_lengkap')),
            'email'        => trim((string) $this->request->getPost('email')) ?: null,
            'is_active'    => $this->request->getPost('is_active') ? 1 : 0,
        ];
        if ($pw = $this->request->getPost('password')) {
            $data['password']             = password_hash($pw, PASSWORD_DEFAULT);
            $data['wajib_ganti_password'] = $this->request->getPost('wajib_ganti') ? 1 : 0;
            $data['password_sendiri_at']  = null;
        }
        $roleIds  = array_map('intval', (array) $this->request->getPost('roles'));
        $adminId  = (int) (model(RoleModel::class)->where('nama_role', 'admin')->first()['id'] ?? 0);
        $tetapAdm = in_array($adminId, $roleIds, true) && $data['is_active'];
        if ($id === $this->userId() && ! $data['is_active']) {
            return $this->back('error', 'Anda tidak dapat menonaktifkan akun sendiri.');
        }
        if ($id === $this->userId() && ! in_array($adminId, $roleIds, true)) {
            return $this->back('error', 'Anda tidak dapat mencabut role admin dari akun sendiri.');
        }
        if ($id && ! $tetapAdm && in_array('admin', $this->model->roleNames($id), true) && $this->model->jumlahAdminAktif($id) === 0) {
            return $this->back('error', 'Harus ada minimal satu admin aktif.');
        }

        if ($id) {
            $this->model->update($id, $data);
        } else {
            $id = (int) $this->model->insert($data);
        }
        $this->model->syncRoles($id, $roleIds);
        catat_log('ubah', 'users', $id, 'Akun ' . $data['username'] . ' – role: ' . implode(',', $this->model->roleNames($id)));

        // tautkan ke data guru
        $guruModel = model(GuruModel::class);
        $guruModel->builder()->where('user_id', $id)->update(['user_id' => null]);
        if ($gid = (int) $this->request->getPost('guru_id')) {
            $guruModel->update($gid, ['user_id' => $id]);
        }

        return redirect()->to('/sistem/pengguna')->with('success', 'Pengguna disimpan. Perubahan role langsung berlaku.');
    }

    /** Reset password satu akun → password sementara, wajib diganti saat login. */
    public function resetPassword($id)
    {
        $user = $this->model->find($id);
        if (! $user) {
            return $this->back('error', 'Pengguna tidak ditemukan.');
        }
        $akun = $this->resetAkun($user);
        session()->setTempdata('akun_baru', [$akun], 600);
        session()->setTempdata('akun_lewat', 0, 600);
        return redirect()->to('/sistem/pengguna/daftar-akun');
    }

    private function resetAkun(array $user): array
    {
        $pw = UserModel::passwordSementara();
        $this->model->update($user['id'], ['password' => password_hash($pw, PASSWORD_DEFAULT), 'wajib_ganti_password' => 1, 'password_sendiri_at' => null]);
        cache()->delete('login_kunci_' . md5(strtolower($user['username'])));
        catat_log('reset_password', 'users', (int) $user['id'], $user['username']);
        return ['nama' => $user['nama_lengkap'], 'username' => $user['username'], 'password' => $pw];
    }

    /** Reset massal akun yang dicentang → halaman daftar akun siap cetak. */
    public function resetMassal()
    {
        $ids = array_filter(array_map('intval', (array) $this->request->getPost('ids')));
        $ids = array_values(array_diff($ids, [$this->userId()]));
        if (! $ids) {
            return $this->back('error', 'Centang minimal satu pengguna (akun sendiri tidak ikut direset).');
        }
        $akun = [];
        foreach ($this->model->whereIn('id', $ids)->orderBy('nama_lengkap')->findAll() as $u) {
            $akun[] = $this->resetAkun($u);
        }
        session()->setTempdata('akun_baru', $akun, 600);
        session()->setTempdata('akun_lewat', 0, 600);
        return redirect()->to('/sistem/pengguna/daftar-akun');
    }

    /**
     * Cetak password untuk banyak pengguna sekaligus. Password tersimpan sebagai hash (tidak bisa dibaca kembali),
     * sehingga yang dicetak adalah password sementara baru; pemilik akun wajib menggantinya saat login.
     * cakupan: belum = hanya akun yang masih memakai password bawaan/sementara; semua = seluruh akun aktif.
     */
    public function cetakPassword()
    {
        $role    = (string) $this->request->getPost('role');
        $cakupan = $this->request->getPost('cakupan') === 'semua' ? 'semua' : 'belum';
        $users   = $this->model->withRoles($role ?: null, ['status' => 'aktif']);
        $lemah   = ['123456', 'admin123'];
        $akun    = [];
        set_time_limit(300);
        $lewat   = 0;
        foreach ($users as $u) {
            if ((int) $u['id'] === $this->userId()) {
                continue;
            }
            if ($cakupan === 'belum') {
                // cepat: sudah pernah login/ganti dengan password sendiri → lewati; sementara → cetak; lainnya diperiksa
                $bawaan = (int) ($u['wajib_ganti_password'] ?? 0) === 1;
                if (! $bawaan && empty($u['password_sendiri_at'])) {
                    $bawaan = password_verify($u['username'], $u['password']);
                    foreach ($lemah as $pw) {
                        $bawaan = $bawaan || password_verify($pw, $u['password']);
                    }
                }
                if (! $bawaan) {
                    $lewat++;
                    continue;
                }
            }
            $akun[] = $this->resetAkun($u) + ['roles' => $u['roles']];
        }
        if (! $akun) {
            return $this->back('info', 'Tidak ada akun yang perlu dicetak' . ($lewat ? " ({$lewat} akun sudah memakai password buatan sendiri)." : '.'));
        }
        catat_log('cetak_password', 'users', null, count($akun) . ' akun' . ($role ? ' role ' . $role : ''));
        session()->setTempdata('akun_baru', $akun, 600);
        session()->setTempdata('akun_lewat', $lewat, 600);
        return redirect()->to('/sistem/pengguna/daftar-akun');
    }

    public function toggleAktif($id)
    {
        $user = $this->model->find($id);
        if (! $user || (int) $id === $this->userId()) {
            return $this->back('error', 'Tidak dapat mengubah status akun sendiri.');
        }
        $baru = (int) $user['is_active'] ? 0 : 1;
        if (! $baru && in_array('admin', $this->model->roleNames((int) $id), true) && $this->model->jumlahAdminAktif((int) $id) === 0) {
            return $this->back('error', 'Harus ada minimal satu admin aktif.');
        }
        $this->model->update($id, ['is_active' => $baru]);
        catat_log($baru ? 'aktifkan' : 'nonaktifkan', 'users', (int) $id, $user['username']);
        return redirect()->back()->with('success', "Akun {$user['username']} " . ($baru ? 'diaktifkan.' : 'dinonaktifkan; pengguna langsung keluar dari aplikasi.'));
    }

    public function bukaKunci($id)
    {
        $user = $this->model->find($id);
        if ($user) {
            cache()->delete('login_kunci_' . md5(strtolower($user['username'])));
            catat_log('buka_kunci', 'users', (int) $id, $user['username']);
        }
        return redirect()->back()->with('success', 'Kunci login dibuka. Pengguna bisa mencoba login lagi.');
    }

    /** Buat akun untuk semua guru aktif yang belum punya akun (role guru), username dari nama/NIP/NUPTK. */
    public function akunGuru()
    {
        $dari  = (string) $this->request->getPost('username_dari');
        $guru  = model(GuruModel::class)->where('user_id', null)->where('is_active', 1)->orderBy('nama_lengkap')->findAll();
        if (! $guru) {
            return $this->back('info', 'Semua guru aktif sudah memiliki akun.');
        }
        $akun = [];
        $db   = db_connect();
        $db->transStart();
        foreach ($guru as $g) {
            $dasar = match ($dari) {
                'nip'   => $g['nip'] ?: $g['nama_lengkap'],
                'nuptk' => $g['nuptk'] ?: $g['nama_lengkap'],
                default => $g['nama_lengkap'],
            };
            $username = ctype_digit((string) $dasar) && ! $this->model->where('username', $dasar)->countAllResults() ? (string) $dasar : $this->model->usernameUnik((string) $dasar);
            $pw       = UserModel::passwordSementara();
            $uid      = (int) $this->model->insert(['username' => $username, 'nama_lengkap' => nama_guru($g), 'email' => $g['email'] ?: null,
                'password' => password_hash($pw, PASSWORD_DEFAULT), 'is_active' => 1, 'wajib_ganti_password' => 1]);
            $this->model->addRole($uid, 'guru');
            model(GuruModel::class)->update($g['id'], ['user_id' => $uid]);
            $akun[] = ['nama' => nama_guru($g), 'username' => $username, 'password' => $pw];
        }
        $db->transComplete();
        catat_log('tambah', 'users', null, 'akun guru massal: ' . count($akun));
        session()->setTempdata('akun_baru', $akun, 600);
        session()->setTempdata('akun_lewat', 0, 600);
        return redirect()->to('/sistem/pengguna/daftar-akun');
    }

    /** Daftar akun + password sementara (hanya tampil sekali, siap cetak/potong). */
    public function daftarAkun()
    {
        $akun = session()->getTempdata('akun_baru');
        if (! $akun) {
            return redirect()->to('/sistem/pengguna')->with('info', 'Daftar password sementara hanya tersedia 10 menit setelah dibuat/direset. Reset ulang bila perlu mencetak lagi.');
        }
        return view('master/pengguna/daftar_akun', [
            'judul'     => 'Daftar Akun Pengguna',
            'subjudul'  => 'Password sementara – wajib diganti saat login pertama',
            'orientasi' => 'portrait',
            'akun'      => $akun,
            'lewat'     => (int) session()->getTempdata('akun_lewat'),
            'alamat'    => base_url(),
        ]);
    }

    public function delete($id)
    {
        if ((int) $id === $this->userId()) {
            return redirect()->back()->with('error', 'Tidak dapat menghapus akun sendiri.');
        }
        if (in_array('admin', $this->model->roleNames((int) $id), true) && $this->model->jumlahAdminAktif((int) $id) === 0) {
            return redirect()->back()->with('error', 'Harus ada minimal satu admin aktif.');
        }
        $w = ['diisi_oleh' => (int) $id];
        if ($pesan = $this->masihDipakai(['jurnal' => ['jurnal_pembelajaran', $w], 'absensi harian' => ['presensi_harian', ['dicatat_oleh' => (int) $id]],
            'catatan perilaku' => ['catatan_perilaku', ['dicatat_oleh' => (int) $id]]], 'Nonaktifkan akun ini agar riwayat pencatat tetap tersimpan.')) {
            return redirect()->back()->with('error', $pesan);
        }
        catat_log('hapus', 'users', (int) $id);
        $this->model->delete($id);
        return redirect()->to('/sistem/pengguna')->with('success', 'Pengguna dihapus.');
    }
}
