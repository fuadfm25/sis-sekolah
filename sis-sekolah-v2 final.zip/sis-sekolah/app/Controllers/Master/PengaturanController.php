<?php

namespace App\Controllers\Master;

use App\Controllers\BaseController;
use App\Models\PengaturanModel;

class PengaturanController extends BaseController
{
    /** Kunci yang boleh diubah lewat form, beserta aturan validasinya. */
    private const FIELD = [
        'nama_aplikasi'      => 'required|max_length[60]',
        'nama_sekolah'       => 'required|max_length[150]',
        'jenjang'            => 'permit_empty|in_list[SD,MI,SMP,MTs,SMA,MA,SMK,MAK,SLB,Lainnya]',
        'jenis_nomor'        => 'required|in_list[NPSN,NSM]',
        'npsn'               => 'permit_empty|max_length[20]|alpha_numeric',
        'alamat_sekolah'     => 'permit_empty|max_length[255]',
        'kota'               => 'permit_empty|max_length[60]',
        'telepon_sekolah'    => 'permit_empty|max_length[30]',
        'email_sekolah'      => 'permit_empty|valid_email',
        'kepala_sekolah'     => 'permit_empty|max_length[100]',
        'nip_kepala_sekolah' => 'permit_empty|max_length[30]',
        'jam_masuk'          => 'required|regex_match[/^\d{2}:\d{2}$/]',
        'jam_pulang'         => 'permit_empty|regex_match[/^\d{2}:\d{2}$/]',
        'jam_masuk_guru'     => 'permit_empty|regex_match[/^\d{2}:\d{2}$/]',
        'hari_sekolah'       => 'required|in_list[5,6]',
        'batas_poin_bk'      => 'required|is_natural_no_zero',
        'kiosk_aktif'        => 'required|in_list[0,1]',
        'portal_siswa'       => 'required|in_list[0,1]',
        'verifikasi_satpam'  => 'required|in_list[0,1]',
        'toleransi_kembali'  => 'required|is_natural|less_than_equal_to[240]',
        'izin_keluar_perilaku' => 'required|in_list[0,1]',
        'format_modul'       => 'permit_empty|in_list[otomatis,PM,PM-KBC]',
    ];

    private const LABEL = [
        'nama_aplikasi' => 'Nama aplikasi', 'nama_sekolah' => 'Nama sekolah', 'npsn' => 'NPSN/NSM',
        'email_sekolah' => 'Email sekolah', 'jam_masuk' => 'Jam masuk', 'jam_pulang' => 'Jam pulang', 'jam_masuk_guru' => 'Jam masuk guru',
        'batas_poin_bk' => 'Batas poin BK', 'toleransi_kembali' => 'Toleransi terlambat kembali',
    ];

    public function index()
    {
        return view('master/pengaturan/index', [
            'title'    => 'Pengaturan Sekolah',
            'subtitle' => 'Identitas ini dipakai pada tampilan aplikasi dan kop seluruh laporan cetak.',
            's'        => model(PengaturanModel::class)->allKeyValue(),
            'kioskUrl' => setting('kiosk_token') ? site_url('kiosk/' . setting('kiosk_token')) : null,
            'logo'     => logo_url(),
        ]);
    }

    public function simpan()
    {
        $data = [];
        foreach (array_keys(self::FIELD) as $k) {
            $data[$k] = trim((string) $this->request->getPost($k));
        }
        $rules = [];
        foreach (self::FIELD as $k => $r) {
            $rules[$k] = ['label' => self::LABEL[$k] ?? $k, 'rules' => $r];
        }
        if (! $this->validateData($data, $rules)) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }

        // logo
        $file = $this->request->getFile('logo');
        if ($file && $file->getError() !== UPLOAD_ERR_NO_FILE) {
            $ok = $this->validateData([], ['logo' => [
                'label' => 'Logo',
                'rules' => 'uploaded[logo]|is_image[logo]|mime_in[logo,image/png,image/jpeg,image/webp]|max_size[logo,1024]',
            ]]);
            if (! $ok) {
                return redirect()->back()->withInput()->with('error', 'Logo harus gambar PNG/JPG/WEBP maksimal 1 MB.');
            }
            $nama = 'logo_' . date('YmdHis') . '.' . $file->guessExtension();
            $file->move(FCPATH . 'uploads/logo', $nama, true);
            $this->hapusFileLogo();
            $data['logo'] = $nama;
        }

        $model = model(PengaturanModel::class);
        foreach ($data as $k => $v) {
            $model->simpan($k, $v);
        }
        catat_log('ubah', 'pengaturan', null, 'Pengaturan sekolah diperbarui');
        return redirect()->to('/sistem/pengaturan')->with('success', 'Pengaturan disimpan.');
    }

    public function hapusLogo()
    {
        $this->hapusFileLogo();
        model(PengaturanModel::class)->simpan('logo', '');
        return redirect()->to('/sistem/pengaturan')->with('success', 'Logo dihapus.');
    }

    private function hapusFileLogo(): void
    {
        $lama = (string) setting('logo', '');
        if ($lama !== '' && basename($lama) === $lama && is_file(FCPATH . 'uploads/logo/' . $lama)) {
            @unlink(FCPATH . 'uploads/logo/' . $lama);
        }
    }

    /** Buat token kiosk baru: alamat kiosk lama otomatis tidak berlaku. */
    public function tokenKiosk()
    {
        model(PengaturanModel::class)->simpan('kiosk_token', bin2hex(random_bytes(12)));
        return redirect()->to('/sistem/pengaturan')->with('success', 'Token kiosk diganti. Perbarui alamat di perangkat kiosk.');
    }
}
