<?php

namespace App\Controllers\Sistem;

use App\Controllers\BaseController;
use App\Libraries\AsetOffline;
use App\Libraries\Backup;

/**
 * Halaman sistem admin: aset offline, backup database, log aktivitas.
 */
class SistemController extends BaseController
{
    public function aset()
    {
        return view('sistem/aset', ['title' => 'Aset Offline', 'subtitle' => 'Simpan file tampilan di server agar aplikasi tetap rapi tanpa internet.', 'status' => AsetOffline::status()]);
    }

    public function unduhAset()
    {
        $hasil = AsetOffline::unduh();
        $gagal = array_filter($hasil, static fn ($h) => ! $h['ok']);
        catat_log('unduh_aset', null, null, (count($hasil) - count($gagal)) . ' berhasil, ' . count($gagal) . ' gagal');
        return redirect()->to('/sistem/aset')->with($gagal ? 'warning' : 'success', $gagal
            ? count($gagal) . ' file gagal diunduh: ' . implode(', ', array_map(static fn ($k, $h) => $k . ' (' . $h['pesan'] . ')', array_keys($gagal), $gagal)) . '. Periksa koneksi internet server.'
            : 'Semua aset berhasil diunduh. Aplikasi kini dapat dipakai tanpa internet.');
    }

    public function backup()
    {
        return view('sistem/backup', ['title' => 'Backup Database', 'subtitle' => 'Cadangan seluruh data. Simpan salinannya juga di luar server (flashdisk / Google Drive).', 'files' => Backup::daftar()]);
    }

    public function buatBackup()
    {
        try {
            $path = Backup::buat();
            Backup::rapikan(30);
        } catch (\Throwable $e) {
            return redirect()->back()->with('error', 'Backup gagal: ' . $e->getMessage());
        }
        catat_log('backup', null, null, basename($path));
        return redirect()->to('/sistem/backup')->with('success', 'Backup dibuat: ' . basename($path));
    }

    public function unduhBackup(string $nama)
    {
        $nama = basename($nama);
        $path = Backup::folder() . $nama;
        if (! preg_match('/^backup_[\w.-]+\.sql(\.gz)?$/', $nama) || ! is_file($path)) {
            return redirect()->to('/sistem/backup')->with('error', 'File tidak ditemukan.');
        }
        catat_log('unduh_backup', null, null, $nama);
        return $this->response->download($path, null);
    }

    public function hapusBackup(string $nama)
    {
        $nama = basename($nama);
        if (preg_match('/^backup_[\w.-]+\.sql(\.gz)?$/', $nama) && is_file(Backup::folder() . $nama)) {
            unlink(Backup::folder() . $nama);
            catat_log('hapus_backup', null, null, $nama);
        }
        return redirect()->to('/sistem/backup')->with('success', 'Backup dihapus.');
    }

    public function log()
    {
        $f = ['aksi' => $this->request->getGet('aksi'), 'q' => trim((string) $this->request->getGet('q')), 'tanggal' => $this->request->getGet('tanggal')];
        $b = db_connect()->table('log_aktivitas');
        if ($f['aksi']) {
            $b->where('aksi', $f['aksi']);
        }
        if ($f['tanggal']) {
            $b->like('created_at', $f['tanggal'], 'after');
        }
        if ($f['q'] !== '') {
            $b->groupStart()->like('nama_user', $f['q'])->orLike('keterangan', $f['q'])->orLike('objek', $f['q'])->groupEnd();
        }
        $hal   = max(1, (int) $this->request->getGet('page'));
        $total = $b->countAllResults(false);
        $rows  = $b->orderBy('id', 'DESC')->limit(50, ($hal - 1) * 50)->get()->getResultArray();
        $aksi  = array_column(db_connect()->table('log_aktivitas')->select('aksi')->distinct()->orderBy('aksi')->get()->getResultArray(), 'aksi');

        return view('sistem/log', ['title' => 'Log Aktivitas', 'subtitle' => 'Jejak login, perubahan, dan penghapusan data.', 'rows' => $rows, 'f' => $f,
            'aksiList' => $aksi, 'hal' => $hal, 'jmlHal' => (int) ceil($total / 50), 'total' => $total]);
    }
}
