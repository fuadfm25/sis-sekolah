<?php

namespace App\Controllers;

use App\Libraries\Kalender;
use App\Models\AnggotaKelasModel;
use App\Models\KelasModel;
use App\Models\PresensiHarianModel;
use App\Models\SiswaModel;

/**
 * Absensi mandiri (tanpa login) untuk perangkat kiosk di gerbang / kelas.
 * Pembaca RFID & scanner barcode USB bekerja seperti keyboard: mengetik kode lalu Enter.
 *
 * Keamanan: alamat memuat token rahasia (Pengaturan Sekolah). Tanpa token yang benar → 404.
 * Kode yang diterima: UID kartu RFID (siswa.rfid), NIS, atau NISN.
 */
class KioskController extends BaseController
{
    private function cekToken(string $token): bool
    {
        $asli = (string) setting('kiosk_token', '');
        return setting('kiosk_aktif', '0') === '1' && $asli !== '' && hash_equals($asli, $token);
    }

    public function index(string $token = '')
    {
        if (! $this->cekToken($token)) {
            throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();
        }
        return view('kiosk/index', [
            'token'     => $token,
            'riwayat'   => $this->riwayat(),
            'ringkas'   => $this->ringkas(),
            'jamMasuk'  => (string) setting('jam_masuk', '07:00'),
            'jamPulang' => (string) setting('jam_pulang', ''),
        ]);
    }

    public function scan(string $token = '')
    {
        if (! $this->cekToken($token)) {
            return $this->response->setStatusCode(404)->setJSON(['ok' => false, 'pesan' => 'Kiosk tidak aktif.']);
        }
        $kode    = substr(trim((string) $this->request->getPost('kode')), 0, 50);
        $tanggal = date('Y-m-d');
        $jamNow  = date('H:i:s');
        $balas   = fn (array $d) => $this->response->setJSON($d + ['ringkas' => $this->ringkas(), 'jam' => substr($jamNow, 0, 5)]);

        if ($kode === '') {
            return $balas(['ok' => false, 'tipe' => 'error', 'pesan' => 'Kode kosong.']);
        }
        if (! $this->tp) {
            return $balas(['ok' => false, 'tipe' => 'error', 'pesan' => 'Tahun pelajaran aktif belum diatur.']);
        }

        // kartu guru (UID RFID di data guru)
        $guru = model(\App\Models\GuruModel::class)->where('is_active', 1)->where('rfid', $kode)->first();
        if ($guru) {
            return $balas($this->scanGuru($guru, $tanggal, $jamNow));
        }

        $siswa = model(SiswaModel::class)->cariKartu($kode);
        if (! $siswa) {
            return $balas(['ok' => false, 'tipe' => 'error', 'pesan' => 'Kartu tidak terdaftar: ' . $kode]);
        }
        $kelas = model(AnggotaKelasModel::class)->kelasSiswa((int) $siswa['id'], $this->tpId());
        if (! $kelas) {
            return $balas(['ok' => false, 'tipe' => 'error', 'nama' => $siswa['nama_lengkap'], 'pesan' => 'Siswa belum terdaftar di kelas mana pun.']);
        }
        if (! Kalender::absensi($tanggal, (int) $kelas['id'])) {
            return $balas(['ok' => false, 'tipe' => 'error', 'nama' => $siswa['nama_lengkap'],
                'pesan' => 'Tidak ada absensi hari ini untuk kelas ' . $kelas['nama_kelas'] . ': ' . Kalender::status($tanggal, (int) $kelas['id'])['label'] . '.']);
        }

        $model    = model(PresensiHarianModel::class);
        $ada      = $model->where(['siswa_id' => $siswa['id'], 'tanggal' => $tanggal])->first();
        $jamMasuk = (string) setting('jam_masuk', '07:00');
        $jamPlg   = (string) setting('jam_pulang', '');
        $info     = ['nama' => $siswa['nama_lengkap'], 'kelas' => $kelas['nama_kelas'], 'nis' => $siswa['nis']];

        // 1) Belum absen datang (atau sebelumnya ditandai S/I/A tetapi ternyata hadir)
        if (! $ada || ! in_array($ada['status'], ['H', 'T'], true)) {
            $status = substr($jamNow, 0, 5) <= $jamMasuk ? 'H' : 'T';
            $model->simpanUnik(['tanggal' => $tanggal, 'siswa_id' => (int) $siswa['id']], [
                'tahun_pelajaran_id' => $this->tpId(), 'kelas_id' => $kelas['id'], 'status' => $status, 'jam_datang' => $jamNow, 'sumber' => 'Kiosk',
                'keterangan' => $ada ? trim(($ada['keterangan'] ? $ada['keterangan'] . '; ' : '') . 'semula ' . $ada['status'] . ', hadir via kiosk') : null,
            ]);
            if ($ada) {
                \App\Libraries\SinkronAbsensi::terapkan([(int) $siswa['id']], $tanggal);
            }
            return $balas($info + ['ok' => true, 'tipe' => $status === 'H' ? 'datang' : 'terlambat', 'status' => $status,
                'pesan' => $status === 'H' ? 'Selamat datang, tepat waktu.' : 'Tercatat TERLAMBAT (lewat ' . $jamMasuk . ').']);
        }

        // 2) Absen pulang
        if ($jamPlg !== '' && substr($jamNow, 0, 5) >= $jamPlg) {
            if (empty($ada['jam_pulang'])) {
                $model->update($ada['id'], ['jam_pulang' => $jamNow]);
                return $balas($info + ['ok' => true, 'tipe' => 'pulang', 'status' => $ada['status'], 'pesan' => 'Absen pulang tercatat. Hati-hati di jalan.']);
            }
            return $balas($info + ['ok' => true, 'tipe' => 'info', 'status' => $ada['status'], 'pesan' => 'Sudah absen pulang pukul ' . substr($ada['jam_pulang'], 0, 5) . '.']);
        }

        // 3) Scan ulang
        return $balas($info + ['ok' => true, 'tipe' => 'info', 'status' => $ada['status'],
            'pesan' => ($ada['jam_datang'] ? 'Sudah absen datang pukul ' . substr((string) $ada['jam_datang'], 0, 5) . '.' : 'Sudah tercatat hadir hari ini (diabsen manual).')
                . ($jamPlg ? ' Absen pulang mulai ' . $jamPlg . '.' : '')]);
    }

    /** 10 scan kiosk terakhir hari ini. */
    private function riwayat(): array
    {
        return model(PresensiHarianModel::class)
            ->select('presensi_harian.status, presensi_harian.jam_datang, presensi_harian.jam_pulang, siswa.nama_lengkap, kelas.nama_kelas')
            ->join('siswa', 'siswa.id = presensi_harian.siswa_id')
            ->join('kelas', 'kelas.id = presensi_harian.kelas_id')
            ->where(['presensi_harian.tanggal' => date('Y-m-d'), 'presensi_harian.sumber' => 'Kiosk'])
            ->orderBy('presensi_harian.updated_at', 'DESC')->limit(10)->findAll();
    }

    private function ringkas(): array
    {
        if (! $this->tp) {
            return ['hadir' => 0, 'terlambat' => 0, 'total' => 0];
        }
        $rows = model(PresensiHarianModel::class)->select('status, COUNT(*) AS n')
            ->where(['tanggal' => date('Y-m-d'), 'tahun_pelajaran_id' => $this->tpId()])->whereIn('status', ['H', 'T'])
            ->groupBy('status')->findAll();
        $map   = array_column($rows, 'n', 'status');
        $total = model(AnggotaKelasModel::class)->join('siswa', 'siswa.id = anggota_kelas.siswa_id')
            ->where(['anggota_kelas.tahun_pelajaran_id' => $this->tpId(), 'siswa.status' => 'Aktif'])->countAllResults();
        return ['hadir' => (int) ($map['H'] ?? 0), 'terlambat' => (int) ($map['T'] ?? 0), 'total' => $total];
    }

    /** Absen datang/pulang guru lewat kiosk. */
    private function scanGuru(array $guru, string $tanggal, string $jamNow): array
    {
        $info = ['nama' => nama_guru($guru), 'kelas' => 'Guru', 'nis' => $guru['nip'] ?? ''];
        if (! Kalender::status($tanggal)['sekolah']) {
            return $info + ['ok' => false, 'tipe' => 'error', 'pesan' => 'Bukan hari sekolah: ' . Kalender::status($tanggal)['label'] . '.'];
        }
        $pg       = model(\App\Models\PresensiGuruModel::class);
        $ada      = $pg->where(['guru_id' => $guru['id'], 'tanggal' => $tanggal])->first();
        $jamMasuk = (string) setting('jam_masuk_guru', setting('jam_masuk', '07:00'));
        $jamPlg   = (string) setting('jam_pulang', '');
        if (! $ada || ! in_array($ada['status'], ['H', 'T'], true)) {
            $status = substr($jamNow, 0, 5) <= $jamMasuk ? 'H' : 'T';
            $pg->simpanUnik(['tanggal' => $tanggal, 'guru_id' => (int) $guru['id']], [
                'tahun_pelajaran_id' => $this->tpId(), 'status' => $status, 'jam_datang' => $jamNow, 'sumber' => 'Kiosk',
                'keterangan' => $ada ? 'semula ' . $ada['status'] . ', hadir via kiosk' : null, 'izin_guru_id' => $ada['izin_guru_id'] ?? null,
            ]);
            return $info + ['ok' => true, 'tipe' => $status === 'H' ? 'datang' : 'terlambat', 'status' => $status,
                'pesan' => $status === 'H' ? 'Selamat datang, Bapak/Ibu.' : 'Tercatat terlambat (lewat ' . $jamMasuk . ').'];
        }
        if ($jamPlg !== '' && substr($jamNow, 0, 5) >= $jamPlg && empty($ada['jam_pulang'])) {
            $pg->update($ada['id'], ['jam_pulang' => $jamNow]);
            return $info + ['ok' => true, 'tipe' => 'pulang', 'status' => $ada['status'], 'pesan' => 'Absen pulang tercatat. Terima kasih.'];
        }
        return $info + ['ok' => true, 'tipe' => 'info', 'status' => $ada['status'],
            'pesan' => 'Sudah absen' . ($ada['jam_datang'] ? ' pukul ' . substr((string) $ada['jam_datang'], 0, 5) : '') . '.'];
    }
}
