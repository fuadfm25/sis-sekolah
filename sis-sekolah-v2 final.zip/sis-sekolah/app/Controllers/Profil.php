<?php

namespace App\Controllers;

use App\Models\UserModel;

class Profil extends BaseController
{
    public function index()
    {
        return view('profil/index', [
            'title' => 'Profil Saya',
            'user'  => model(UserModel::class)->find($this->userId()),
        ]);
    }

    public function password()
    {
        $rules = [
            'password_lama' => 'required',
            'password_baru' => 'required|min_length[6]',
            'konfirmasi'    => 'required|matches[password_baru]',
        ];
        if (! $this->validate($rules, ['konfirmasi' => ['matches' => 'Konfirmasi password tidak sama.']])) {
            return redirect()->back()->with('errors', $this->validator->getErrors());
        }

        $users = model(UserModel::class);
        $user  = $users->find($this->userId());
        if (! password_verify((string) $this->request->getPost('password_lama'), $user['password'])) {
            return redirect()->back()->with('error', 'Password lama salah.');
        }
        $baru = (string) $this->request->getPost('password_baru');
        if (in_array($baru, ['admin123', '123456', '12345678', 'password'], true) || strcasecmp($baru, $user['username']) === 0) {
            return redirect()->back()->with('error', 'Password terlalu mudah ditebak. Gunakan kombinasi lain.');
        }
        if (password_verify($baru, $user['password'])) {
            return redirect()->back()->with('error', 'Password baru harus berbeda dari password lama/sementara.');
        }
        $users->update($user['id'], ['password' => password_hash($baru, PASSWORD_DEFAULT), 'wajib_ganti_password' => 0, 'password_sendiri_at' => date('Y-m-d H:i:s')]);
        session()->remove(['password_lemah', 'wajib_ganti']);
        catat_log('ganti_password', 'users', (int) $user['id']);

        return redirect()->to('/profil')->with('success', 'Password berhasil diganti.');
    }
}
