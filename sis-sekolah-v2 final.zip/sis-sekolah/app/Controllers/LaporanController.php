<?php

namespace App\Controllers;

use App\Libraries\Akses;
use App\Libraries\Kalender;
use App\Models\AnggotaKelasModel;
use App\Models\BkLayananModel;
use App\Models\CatatanPerilakuModel;
use App\Models\GuruModel;
use App\Models\JadwalModel;
use App\Models\JurnalModel;
use App\Models\KelasModel;
use App\Models\PembiasaanModel;
use App\Models\PembiasaanSiswaModel;
use App\Models\PenugasanGuruModel;
use App\Models\PresensiHarianModel;
use App\Models\PresensiMapelModel;
use App\Models\SiswaModel;
use App\Models\WaliKelasModel;
use CodeIgniter\HTTP\RedirectResponse;

/**
 * Laporan cetak (A4, kop sekolah, tanda tangan). Hak akses: App\Libraries\Akses::laporan*.
 */
class LaporanController extends BaseController
{
    // ================================================================ util
    private function tgl(string $nama, string $default): string
    {
        $v = (string) $this->request->getGet($nama);
        return preg_match('/^\d{4}-\d{2}-\d{2}$/', $v) ? $v : $default;
    }

    private function tolak(string $pesan = 'Anda tidak berwenang mencetak laporan ini.'): RedirectResponse
    {
        return redirect()->to('/laporan')->with('error', $pesan);
    }

    private function kepala(): array
    {
        $madrasah = in_array(setting('jenjang'), ['MI', 'MTs', 'MA', 'MAK'], true) || setting('jenis_nomor') === 'NSM';
        return [
            'atas'    => 'Mengetahui,',
            'jabatan' => $madrasah ? 'Kepala Madrasah' : 'Kepala Sekolah',
            'nama'    => setting('kepala_sekolah', ''),
            'nip'     => setting('nip_kepala_sekolah', '') ?: null,
        ];
    }

    private function waliTtd(int $kelasId): array
    {
        $w = $this->tp ? model(WaliKelasModel::class)->waliDari($kelasId, $this->tpId()) : null;
        return ['jabatan' => 'Wali Kelas', 'nama' => $w ? nama_guru($w) : '', 'nip' => $w['nip'] ?? null];
    }

    private function userTtd(string $jabatan): array
    {
        return ['jabatan' => $jabatan] + penanda_tangan_user();
    }

    private function kelas(int $id): ?array
    {
        return $id ? model(KelasModel::class)->find($id) : null;
    }

    private function periode(string $dari, string $sampai): string
    {
        return $dari === $sampai ? tgl_indo($dari, true) : tgl_indo($dari) . ' s.d. ' . tgl_indo($sampai);
    }

    private function tpLabel(): string
    {
        return $this->tp ? 'Tahun Pelajaran ' . $this->tp['tahun_pelajaran'] . ' Semester ' . $this->tp['semester'] : '';
    }

    /** Daftar siswa tidak hadir per jurnal: [jurnal_id => "Nama (S), Nama (A)"] */
    private function tidakHadir(array $jurnalIds): array
    {
        if (! $jurnalIds) {
            return [];
        }
        $out = [];
        foreach (db_connect()->table('presensi_mapel p')->select('p.jurnal_id, p.status, s.nama_lengkap')
            ->join('siswa s', 's.id = p.siswa_id')->whereIn('p.jurnal_id', $jurnalIds)->where('p.status !=', 'H')
            ->orderBy('s.nama_lengkap')->get()->getResultArray() as $r) {
            $out[$r['jurnal_id']][] = $r['nama_lengkap'] . ' (' . $r['status'] . ')';
        }
        return array_map(static fn ($a) => implode(', ', $a), $out);
    }

    private function opsiKelas(string $jenis): array
    {
        return $this->daftarKelas(Akses::laporanSemuaKelas($jenis));
    }

    /** Penugasan (mapel-kelas) yang boleh direkap user ini. */
    private function opsiPenugasan(): array
    {
        $pm = model(PenugasanGuruModel::class);
        if (Akses::jurnalSemua()) {
            return $pm->daftar($this->tpId());
        }
        $opsi = $this->guruId() ? $pm->daftar($this->tpId(), ['guru_id' => $this->guruId()]) : [];
        foreach (wali_kelas_ids() as $kid) {
            $opsi = array_merge($opsi, $pm->daftar($this->tpId(), ['kelas_id' => $kid]));
        }
        return array_values(array_column($opsi, null, 'id'));
    }

    // ================================================================ halaman pilihan
    public function index()
    {
        if ($r = $this->wajibTp()) {
            return $r;
        }
        $guru = Akses::jurnalSemua() ? model(GuruModel::class)->listAktif()
            : ($this->guruId() ? [model(GuruModel::class)->find($this->guruId())] : []);

        $siswaPerilaku = [];
        $kelasPerilaku = $this->opsiKelas('perilaku');
        if ($kelasPerilaku) {
            $siswaPerilaku = model(SiswaModel::class)->dropdownAktif($this->tpId(), Akses::laporanSemuaKelas('perilaku') ? null : array_column($kelasPerilaku, 'id'));
        }

        return view('laporan/index', [
            'title'    => 'Cetak Laporan',
            'subtitle' => 'Laporan yang tersedia menyesuaikan peran Anda. Hasil cetak terbuka di tab baru dan bisa disimpan sebagai PDF.',
            'guru'     => array_filter($guru),
            'kelas'    => [
                'absensi'    => $this->opsiKelas('absensi'),
                'jurnal'     => $this->opsiKelas('jurnal'),
                'perilaku'   => $kelasPerilaku,
                'pembiasaan' => $this->opsiKelas('pembiasaan'),
                'siswa'      => $this->opsiKelas('siswa'),
            ],
            'penugasan'     => $this->opsiPenugasan(),
            'siswaPerilaku' => $siswaPerilaku,
            'awalBulan'     => date('Y-m-01'),
            'hariIni'       => date('Y-m-d'),
        ]);
    }

    // ================================================================ GURU
    /** Jurnal pembelajaran / agenda mengajar guru. */
    public function jurnalGuru()
    {
        if ($r = $this->wajibTp()) {
            return $r;
        }
        $guruId = (int) ($this->request->getGet('guru_id') ?: $this->guruId());
        if (! Akses::laporanJurnalGuru($guruId)) {
            return $this->tolak();
        }
        $guru = $guruId ? model(GuruModel::class)->find($guruId) : null;
        if (! $guru) {
            return $this->tolak('Pilih guru terlebih dahulu.');
        }
        $dari   = $this->tgl('dari', date('Y-m-01'));
        $sampai = $this->tgl('sampai', date('Y-m-d'));
        $rows   = model(JurnalModel::class)->base()
            ->where('jurnal_pembelajaran.tahun_pelajaran_id', $this->tpId())
            ->where('COALESCE(jurnal_pembelajaran.guru_id, penugasan_guru.guru_id)', $guruId)
            ->where('jurnal_pembelajaran.tanggal >=', $dari)->where('jurnal_pembelajaran.tanggal <=', $sampai)
            ->orderBy('jurnal_pembelajaran.tanggal')->orderBy('jurnal_pembelajaran.jam_ke')->findAll();

        return view('laporan/jurnal_guru', [
            'judul'     => 'Jurnal Pembelajaran Guru',
            'subjudul'  => $this->tpLabel(),
            'orientasi' => 'landscape',
            'guru'      => $guru,
            'periode'   => $this->periode($dari, $sampai),
            'rows'      => $rows,
            'absen'     => $this->tidakHadir(array_column($rows, 'id')),
            'ttd'       => ['kiri' => $this->kepala(), 'kanan' => ['jabatan' => 'Guru Mata Pelajaran', 'nama' => $guru ? nama_guru($guru) : '', 'nip' => $guru['nip'] ?? null]],
        ]);
    }

    /** Rekap kehadiran per mata pelajaran (siswa x pertemuan). */
    public function rekapMapel()
    {
        if ($r = $this->wajibTp()) {
            return $r;
        }
        $id    = (int) $this->request->getGet('penugasan_id');
        $pilih = null;
        foreach ($this->opsiPenugasan() as $o) {
            if ((int) $o['id'] === $id) {
                $pilih = $o;
            }
        }
        if (! $pilih) {
            return $this->tolak('Pilih mata pelajaran & kelas yang Anda ampu.');
        }
        $dari   = $this->tgl('dari', $this->tp['tanggal_mulai'] ?: date('Y-m-01'));
        $sampai = $this->tgl('sampai', date('Y-m-d'));
        $data   = model(PresensiMapelModel::class)->rekap($id, $dari, $sampai);
        $guru   = model(GuruModel::class)->find($pilih['guru_id']);

        return view('laporan/rekap_mapel', [
            'judul'     => 'Rekap Kehadiran Mata Pelajaran',
            'subjudul'  => $this->tpLabel(),
            'orientasi' => 'landscape',
            'p'         => $pilih,
            'periode'   => $this->periode($dari, $sampai),
            'jurnal'    => $data['jurnal'],
            'matriks'   => $data['matriks'],
            'siswa'     => model(AnggotaKelasModel::class)->siswaKelas((int) $pilih['kelas_id'], $this->tpId(), false),
            'ttd'       => ['kiri' => $this->kepala(), 'kanan' => ['jabatan' => 'Guru Mata Pelajaran', 'nama' => $guru ? nama_guru($guru) : '', 'nip' => $guru['nip'] ?? null]],
        ]);
    }

    // ================================================================ WALI KELAS (dan peran terkait)
    /** Absensi kelas bulanan: baris = siswa, kolom = tanggal 1..akhir bulan. */
    public function absensiKelas()
    {
        if ($r = $this->wajibTp()) {
            return $r;
        }
        $kelasId = (int) $this->request->getGet('kelas_id');
        $kelas   = $this->kelas($kelasId);
        if (! $kelas || ! Akses::laporanKelas($kelasId, 'absensi')) {
            return $this->tolak();
        }
        $bulan = max(1, min(12, (int) ($this->request->getGet('bulan') ?: date('n'))));
        $tahun = (int) ($this->request->getGet('tahun') ?: date('Y'));
        $jml   = (int) date('t', mktime(0, 0, 0, $bulan, 1, $tahun));
        $libur  = [];
        $agenda = [];
        $efektif = 0;
        for ($d = 1; $d <= $jml; $d++) {
            $st        = Kalender::status(sprintf('%04d-%02d-%02d', $tahun, $bulan, $d), $kelasId);
            $libur[$d] = ! $st['absensi'];
            $efektif  += $st['absensi'] ? 1 : 0;
            foreach ($st['agenda'] as $a) {
                $agenda[$a['id']] = $a;
            }
        }

        return view('laporan/absensi_kelas', [
            'judul'     => 'Daftar Hadir Siswa',
            'subjudul'  => 'Bulan ' . bulan_list()[$bulan] . ' ' . $tahun . ' · ' . $this->tpLabel(),
            'orientasi' => 'landscape',
            'kelas'     => $kelas,
            'jml'       => $jml,
            'libur'     => $libur,
            'agenda'    => array_values($agenda),
            'efektif'   => $efektif,
            'siswa'     => model(AnggotaKelasModel::class)->siswaKelas($kelasId, $this->tpId(), false),
            'matriks'   => model(PresensiHarianModel::class)->matriksBulan($kelasId, $tahun, $bulan),
            'ttd'       => ['kiri' => $this->kepala(), 'kanan' => $this->waliTtd($kelasId)],
        ]);
    }

    /** Jurnal kelas: seluruh KBM di satu kelas (semua mapel). */
    public function jurnalKelas()
    {
        if ($r = $this->wajibTp()) {
            return $r;
        }
        $kelasId = (int) $this->request->getGet('kelas_id');
        $kelas   = $this->kelas($kelasId);
        if (! $kelas || ! Akses::laporanKelas($kelasId, 'jurnal')) {
            return $this->tolak();
        }
        $dari   = $this->tgl('dari', date('Y-m-01'));
        $sampai = $this->tgl('sampai', date('Y-m-d'));
        $rows   = model(JurnalModel::class)->base()
            ->where('jurnal_pembelajaran.kelas_id', $kelasId)
            ->where('jurnal_pembelajaran.tanggal >=', $dari)->where('jurnal_pembelajaran.tanggal <=', $sampai)
            ->orderBy('jurnal_pembelajaran.tanggal')->orderBy('jurnal_pembelajaran.jam_ke')->findAll();

        return view('laporan/jurnal_kelas', [
            'judul'     => 'Jurnal Kelas',
            'subjudul'  => $this->tpLabel(),
            'orientasi' => 'landscape',
            'kelas'     => $kelas,
            'periode'   => $this->periode($dari, $sampai),
            'rows'      => $rows,
            'absen'     => $this->tidakHadir(array_column($rows, 'id')),
            'ttd'       => ['kiri' => $this->kepala(), 'kanan' => $this->waliTtd($kelasId)],
        ]);
    }

    /** Catatan perilaku seluruh siswa satu kelas (dikelompokkan per siswa). */
    public function perilakuKelas()
    {
        if ($r = $this->wajibTp()) {
            return $r;
        }
        $kelasId = (int) $this->request->getGet('kelas_id');
        $kelas   = $this->kelas($kelasId);
        if (! $kelas || ! Akses::laporanKelas($kelasId, 'perilaku')) {
            return $this->tolak();
        }
        $dari   = $this->tgl('dari', $this->tp['tanggal_mulai'] ?: date('Y-m-01'));
        $sampai = $this->tgl('sampai', date('Y-m-d'));
        $rows   = model(CatatanPerilakuModel::class)->base()
            ->where(['catatan_perilaku.tahun_pelajaran_id' => $this->tpId(), 'catatan_perilaku.kelas_id' => $kelasId])
            ->where('catatan_perilaku.tanggal >=', $dari)->where('catatan_perilaku.tanggal <=', $sampai)
            ->orderBy('siswa.nama_lengkap')->orderBy('catatan_perilaku.tanggal')->findAll();
        $per = [];
        foreach ($rows as $r) {
            $per[$r['siswa_id']]['nama']      = $r['nama_siswa'];
            $per[$r['siswa_id']]['nis']       = $r['nis'];
            $per[$r['siswa_id']]['catatan'][] = $r;
        }

        return view('laporan/perilaku_kelas', [
            'judul'     => 'Rekap Catatan Perilaku Siswa',
            'subjudul'  => $this->tpLabel(),
            'orientasi' => 'portrait',
            'kelas'     => $kelas,
            'periode'   => $this->periode($dari, $sampai),
            'per'       => $per,
            'batas'     => (int) setting('batas_poin_bk', 50),
            'ttd'       => ['kiri' => $this->kepala(), 'kanan' => Akses::waliKelas($kelasId) || ! Akses::punya('kesiswaan') ? $this->waliTtd($kelasId) : $this->userTtd('Wakil Kepala Bidang Kesiswaan')],
        ]);
    }

    /** Kartu catatan perilaku satu siswa. */
    public function perilakuSiswa()
    {
        if ($r = $this->wajibTp()) {
            return $r;
        }
        $siswa = model(SiswaModel::class)->find((int) $this->request->getGet('siswa_id'));
        $kelas = $siswa ? model(AnggotaKelasModel::class)->kelasSiswa((int) $siswa['id'], $this->tpId()) : null;
        if (! $siswa || Akses::profilSiswa($kelas ? (int) $kelas['id'] : null) !== 'penuh') {
            return $this->tolak();
        }
        $cp = model(CatatanPerilakuModel::class);

        return view('laporan/perilaku_siswa', [
            'judul'     => 'Kartu Catatan Perilaku Siswa',
            'subjudul'  => $this->tpLabel(),
            'orientasi' => 'portrait',
            'siswa'     => $siswa,
            'kelas'     => $kelas,
            'rows'      => $cp->riwayatSiswa((int) $siswa['id'], $this->tpId()),
            'poin'      => $cp->poinSiswa((int) $siswa['id'], $this->tpId()),
            'hadir'     => model(PresensiHarianModel::class)->totalSiswa((int) $siswa['id'], $this->tpId()),
            'ttd'       => ['kiri' => $this->kepala(), 'kanan' => $kelas ? $this->waliTtd((int) $kelas['id']) : $this->userTtd('')],
        ]);
    }

    public function pembiasaan()
    {
        if ($r = $this->wajibTp()) {
            return $r;
        }
        $kelasId = (int) $this->request->getGet('kelas_id');
        $kelas   = $this->kelas($kelasId);
        if (! $kelas || ! Akses::laporanKelas($kelasId, 'pembiasaan')) {
            return $this->tolak();
        }
        $dari   = $this->tgl('dari', date('Y-m-01'));
        $sampai = $this->tgl('sampai', date('Y-m-d'));
        $rekap  = model(PembiasaanSiswaModel::class)->rekap($kelasId, $dari, $sampai);

        return view('laporan/pembiasaan', [
            'judul'      => 'Rekap Pembiasaan Siswa',
            'subjudul'   => $this->tpLabel(),
            'orientasi'  => 'landscape',
            'kelas'      => $kelas,
            'periode'    => $this->periode($dari, $sampai) . ' (' . $rekap['jumlah_hari'] . ' hari tercatat)',
            'pembiasaan' => model(PembiasaanModel::class)->aktif(),
            'siswa'      => model(AnggotaKelasModel::class)->siswaKelas($kelasId, $this->tpId(), false),
            'data'       => $rekap['data'],
            'ttd'        => ['kiri' => $this->kepala(), 'kanan' => $this->waliTtd($kelasId)],
        ]);
    }

    public function daftarSiswa()
    {
        if ($r = $this->wajibTp()) {
            return $r;
        }
        $kelasId = (int) $this->request->getGet('kelas_id');
        $kelas   = $this->kelas($kelasId);
        if (! $kelas || ! Akses::laporanKelas($kelasId, 'siswa')) {
            return $this->tolak();
        }
        return view('laporan/daftar_siswa', [
            'judul'     => 'Daftar Siswa',
            'subjudul'  => 'Kelas ' . $kelas['nama_kelas'] . ' · ' . $this->tpLabel(),
            'orientasi' => 'portrait',
            'siswa'     => model(AnggotaKelasModel::class)->siswaKelas($kelasId, $this->tpId()),
            'ttd'       => ['kiri' => $this->kepala(), 'kanan' => $this->waliTtd($kelasId)],
        ]);
    }

    // ================================================================ KESISWAAN / BK / KEPSEK
    public function rekapPoin()
    {
        if ($r = $this->wajibTp()) {
            return $r;
        }
        if (! Akses::rekapPoin()) {
            return $this->tolak();
        }
        $kelasId  = (int) $this->request->getGet('kelas_id');
        $kelasIds = Akses::perilakuLihatSemua() ? null : wali_kelas_ids();
        if ($kelasId && ($kelasIds === null || in_array($kelasId, $kelasIds, true))) {
            $kelasIds = [$kelasId];
        }
        $kelas = $kelasId ? $this->kelas($kelasId) : null;

        return view('laporan/rekap_poin', [
            'judul'     => 'Rekap Poin Perilaku Siswa',
            'subjudul'  => ($kelas ? 'Kelas ' . $kelas['nama_kelas'] . ' · ' : '') . $this->tpLabel(),
            'orientasi' => 'portrait',
            'rows'      => model(CatatanPerilakuModel::class)->akumulasiPoin($this->tpId(), $kelasIds),
            'batas'     => (int) setting('batas_poin_bk', 50),
            'ttd'       => ['kiri' => $this->kepala(), 'kanan' => Akses::punya('kesiswaan') ? $this->userTtd('Wakil Kepala Bidang Kesiswaan')
                : (Akses::punya('bk') ? $this->userTtd('Guru BK') : ($kelasId ? $this->waliTtd($kelasId) : $this->userTtd('')))],
        ]);
    }

    /** Rekap kehadiran seluruh kelas dalam satu bulan. */
    public function rekapKehadiran()
    {
        if ($r = $this->wajibTp()) {
            return $r;
        }
        if (! Akses::laporanRekapKehadiran()) {
            return $this->tolak();
        }
        $bulan  = max(1, min(12, (int) ($this->request->getGet('bulan') ?: date('n'))));
        $tahun  = (int) ($this->request->getGet('tahun') ?: date('Y'));
        $dari   = sprintf('%04d-%02d-01', $tahun, $bulan);
        $sampai = date('Y-m-t', strtotime($dari));

        $hit = [];
        foreach (model(PresensiHarianModel::class)->select('kelas_id, status, COUNT(*) AS n')
            ->where('tahun_pelajaran_id', $this->tpId())->where('tanggal >=', $dari)->where('tanggal <=', $sampai)
            ->groupBy(['kelas_id', 'status'])->findAll() as $r) {
            $hit[$r['kelas_id']][$r['status']] = (int) $r['n'];
        }
        $rows = [];
        foreach (model(KelasModel::class)->detailList($this->tpId()) as $k) {
            if (! $k['is_active']) {
                continue;
            }
            $h      = $hit[$k['id']] ?? [];
            $total  = array_sum($h);
            $rows[] = $k + ['h' => $h, 'total' => $total, 'persen' => $total ? round((($h['H'] ?? 0) + ($h['T'] ?? 0)) / $total * 100, 1) : null];
        }

        return view('laporan/rekap_kehadiran', [
            'judul'     => 'Rekapitulasi Kehadiran Siswa',
            'subjudul'  => 'Bulan ' . bulan_list()[$bulan] . ' ' . $tahun . ' · ' . $this->tpLabel(),
            'orientasi' => 'portrait',
            'rows'      => $rows,
            'ttd'       => ['kiri' => $this->kepala(), 'kanan' => $this->userTtd(Akses::punya('kesiswaan') ? 'Wakil Kepala Bidang Kesiswaan' : '')],
        ]);
    }

    /** Layanan BK. Isi layanan rahasia hanya tampil untuk konselornya / admin. */
    public function layananBk()
    {
        if ($r = $this->wajibTp()) {
            return $r;
        }
        if (! Akses::laporanBk()) {
            return $this->tolak();
        }
        $dari   = $this->tgl('dari', date('Y-m-01'));
        $sampai = $this->tgl('sampai', date('Y-m-d'));
        $model  = model(BkLayananModel::class);
        $rows   = $model->base()->where('bk_layanan.tahun_pelajaran_id', $this->tpId())
            ->where('bk_layanan.tanggal >=', $dari)->where('bk_layanan.tanggal <=', $sampai)
            ->orderBy('bk_layanan.tanggal')->findAll();
        $rows = $model->lampirkanPeserta($rows);
        foreach ($rows as &$l) {
            $l['tersembunyi'] = ! Akses::bkBuka($l);
        }

        return view('laporan/layanan_bk', [
            'judul'     => 'Laporan Layanan Bimbingan dan Konseling',
            'subjudul'  => $this->tpLabel(),
            'orientasi' => 'landscape',
            'periode'   => $this->periode($dari, $sampai),
            'rows'      => $rows,
            'statistik' => array_count_values(array_column($rows, 'jenis_layanan')),
            'perKomponen' => array_count_values(array_map(static fn ($r) => $r['komponen'] ?: (\App\Models\BkLayananModel::KATALOG[$r['jenis_layanan']][0] ?? 'Lainnya'), $rows)),
            'perBidang'   => array_count_values(array_column($rows, 'bidang')),
            'ttd'       => ['kiri' => $this->kepala(), 'kanan' => $this->userTtd('Guru Bimbingan dan Konseling')],
        ]);
    }

    // ================================================================ KURIKULUM
    /** Keterisian jurnal per guru: sesi terjadwal vs jurnal terisi. */
    public function keterisianJurnal()
    {
        if ($r = $this->wajibTp()) {
            return $r;
        }
        if (! Akses::laporanKeterisianJurnal()) {
            return $this->tolak();
        }
        $dari   = $this->tgl('dari', date('Y-m-01'));
        $sampai = min($this->tgl('sampai', date('Y-m-d')), date('Y-m-d'));

        $jadwal  = model(JadwalModel::class);
        $terisi = [];
        foreach (model(JurnalModel::class)->select('jadwal_pelajaran_id, tanggal')->where('tahun_pelajaran_id', $this->tpId())
            ->where('tanggal >=', $dari)->where('tanggal <=', $sampai)->findAll() as $j) {
            $terisi[$j['jadwal_pelajaran_id'] . '|' . $j['tanggal']] = true;
        }

        $guru = [];
        for ($d = $dari; $d <= $sampai; $d = date('Y-m-d', strtotime($d . ' +1 day'))) {
            if (! Kalender::status($d)['sekolah']) {
                continue;
            }
            foreach ($jadwal->sesiTanggal($this->tpId(), $d) as $s) {
                $g = (int) $s['guru_id'];
                $guru[$g]['nama'] ??= nama_guru($s);
                $guru[$g]['sesi'] = ($guru[$g]['sesi'] ?? 0) + 1;
                $guru[$g]['jp']   = ($guru[$g]['jp'] ?? 0) + $s['jumlah_jp'];
                $guru[$g]['isi']  = ($guru[$g]['isi'] ?? 0) + (isset($terisi[$s['id'] . '|' . $d]) ? 1 : 0);
            }
        }
        uasort($guru, static fn ($a, $b) => strcmp($a['nama'], $b['nama']));

        return view('laporan/keterisian_jurnal', [
            'judul'     => 'Rekap Keterisian Jurnal Mengajar',
            'subjudul'  => $this->tpLabel(),
            'orientasi' => 'portrait',
            'periode'   => $this->periode($dari, $sampai),
            'guru'      => $guru,
            'ttd'       => ['kiri' => $this->kepala(), 'kanan' => $this->userTtd(Akses::punya('kurikulum') ? 'Wakil Kepala Bidang Kurikulum' : '')],
        ]);
    }

    // ================================================================ PIKET
    /** Laporan harian guru piket: kehadiran semua kelas + jurnal yang belum terisi. */
    public function harianPiket()
    {
        if ($r = $this->wajibTp()) {
            return $r;
        }
        if (! Akses::laporanPiket()) {
            return $this->tolak();
        }
        $tanggal = min($this->tgl('tanggal', date('Y-m-d')), date('Y-m-d'));
        \App\Libraries\IzinKeluar::perbarui($tanggal);
        $ph      = model(PresensiHarianModel::class);
        $ringkas = $ph->ringkasTanggal($this->tpId(), $tanggal);
        $kelas   = model(KelasModel::class)->detailList($this->tpId());
        $tidak   = $ph->select('presensi_harian.*, siswa.nama_lengkap, kelas.nama_kelas')
            ->join('siswa', 'siswa.id = presensi_harian.siswa_id')->join('kelas', 'kelas.id = presensi_harian.kelas_id')
            ->where('presensi_harian.tanggal', $tanggal)->whereIn('presensi_harian.status', ['T', 'S', 'I', 'A'])
            ->orderBy('kelas.nama_kelas')->orderBy('siswa.nama_lengkap')->findAll();

        $status = Kalender::status($tanggal);
        $sesi   = $status['sekolah'] ? model(JadwalModel::class)->sesiTanggal($this->tpId(), $tanggal) : [];
        $peta = model(JurnalModel::class)->petaTanggal(array_column($sesi, 'id'), $tanggal);
        $belum = array_values(array_filter($sesi, static fn ($s) => ! isset($peta[$s['id']])));
        usort($belum, static fn ($a, $b) => [$a['nama_kelas'], $a['jam_mulai']] <=> [$b['nama_kelas'], $b['jam_mulai']]);

        return view('laporan/harian_piket', [
            'judul'     => 'Laporan Harian Guru Piket',
            'subjudul'  => tgl_indo($tanggal, true) . ($status['agenda'] || ! $status['sekolah'] ? ' · ' . $status['label'] : ''),
            'orientasi' => 'portrait',
            'kelas'     => array_values(array_filter($kelas, static fn ($k) => $k['is_active'])),
            'ringkas'   => $ringkas,
            'tidak'     => $tidak,
            'sesi'      => count($sesi),
            'belum'     => $belum,
            'pulang'    => model(\App\Models\IzinSiswaModel::class)->pulangAwal($tanggal, $this->tpId()),
            'dispen'    => model(\App\Models\IzinSiswaModel::class)->select('izin_siswa.*, siswa.nama_lengkap, kelas.nama_kelas')
                ->join('siswa', 'siswa.id = izin_siswa.siswa_id')
                ->join('anggota_kelas', 'anggota_kelas.siswa_id = siswa.id AND anggota_kelas.tahun_pelajaran_id = ' . $this->tpId())
                ->join('kelas', 'kelas.id = anggota_kelas.kelas_id')
                ->where('izin_siswa.jenis', 'D')->where('izin_siswa.jam_keluar', null)
                ->where('izin_siswa.tanggal_mulai <=', $tanggal)->where('izin_siswa.tanggal_selesai >=', $tanggal)
                ->orderBy('kelas.nama_kelas')->findAll(),
            'ttd'       => ['kiri' => $this->kepala(), 'kanan' => $this->userTtd('Guru Piket')],
        ]);
    }

    // ================================================================ KALENDER (semua pengguna)
    /** Rincian pekan & hari efektif semester + JP efektif per mata pelajaran (untuk prota/promes). */
    public function pekanEfektif()
    {
        if ($r = $this->wajibTp()) {
            return $r;
        }
        if (empty($this->tp['tanggal_mulai']) || empty($this->tp['tanggal_selesai'])) {
            return $this->tolak('Periode tahun pelajaran aktif (tanggal mulai & selesai) belum diisi oleh kurikulum.');
        }
        $data = Kalender::pekanEfektif($this->tp['tanggal_mulai'], $this->tp['tanggal_selesai']);

        // guru yang dihitung JP efektifnya
        // kurikulum/kepsek memilih guru (kosong = tanpa rincian JP); guru lain selalu dirinya sendiri
        $guruId = Akses::jurnalSemua() ? (int) $this->request->getGet('guru_id') : (int) $this->guruId();
        $guru = $guruId ? model(GuruModel::class)->find($guruId) : null;

        $mapel = [];
        if ($guru) {
            $slot = [];
            foreach (model(JadwalModel::class)->select('penugasan_guru_id, hari, COUNT(*) AS n')
                ->where('tahun_pelajaran_id', $this->tpId())->groupBy(['penugasan_guru_id', 'hari'])->findAll() as $j) {
                $slot[$j['penugasan_guru_id']][(int) $j['hari']] = (int) $j['n'];
            }
            foreach (model(PenugasanGuruModel::class)->daftar($this->tpId(), ['guru_id' => $guruId]) as $p) {
                $jp = 0;
                $rinci = [];
                foreach ($slot[$p['id']] ?? [] as $h => $n) {
                    $jp     += $n * ($data['per_hari'][$h] ?? 0);
                    $rinci[] = nama_hari($h) . ' ' . $n . ' JP × ' . ($data['per_hari'][$h] ?? 0);
                }
                $mapel[] = $p + ['jp_efektif' => $jp, 'rinci' => implode('; ', $rinci), 'jp_prota' => $p['jp_per_minggu'] * $data['total']['pekan_efektif']];
            }
        }

        return view('laporan/pekan_efektif', [
            'judul'     => 'Rincian Pekan dan Hari Efektif',
            'subjudul'  => $this->tpLabel() . ' (' . tgl_indo($this->tp['tanggal_mulai']) . ' – ' . tgl_indo($this->tp['tanggal_selesai']) . ')',
            'orientasi' => 'portrait',
            'data'      => $data,
            'guru'      => $guru,
            'mapel'     => $mapel,
            'ttd'       => ['kiri' => $this->kepala(), 'kanan' => $guru
                ? ['jabatan' => 'Guru Mata Pelajaran', 'nama' => nama_guru($guru), 'nip' => $guru['nip'] ?: null]
                : $this->userTtd(Akses::punya('kurikulum') ? 'Wakil Kepala Bidang Kurikulum' : '')],
        ]);
    }

    // ================================================================ KEHADIRAN GURU
    public function kehadiranGuru()
    {
        if ($r = $this->wajibTp()) {
            return $r;
        }
        if (! Akses::kehadiranGuruLihat()) {
            return $this->tolak();
        }
        $bulan = max(1, min(12, (int) ($this->request->getGet('bulan') ?: date('n'))));
        $tahun = (int) ($this->request->getGet('tahun') ?: date('Y'));
        $jml   = (int) date('t', mktime(0, 0, 0, $bulan, 1, $tahun));
        $libur = [];
        for ($d = 1; $d <= $jml; $d++) {
            $libur[$d] = ! Kalender::status(sprintf('%04d-%02d-%02d', $tahun, $bulan, $d))['sekolah'];
        }
        return view('laporan/kehadiran_guru', [
            'judul'     => 'Daftar Hadir Guru',
            'subjudul'  => 'Bulan ' . bulan_list()[$bulan] . ' ' . $tahun . ' · ' . $this->tpLabel(),
            'orientasi' => 'landscape',
            'jml'       => $jml,
            'libur'     => $libur,
            'efektif'   => count(array_filter($libur, static fn ($x) => ! $x)),
            'guru'      => model(GuruModel::class)->listAktif(),
            'matriks'   => model(\App\Models\PresensiGuruModel::class)->matriksBulan($tahun, $bulan),
            'ttd'       => ['kiri' => $this->kepala(), 'kanan' => $this->userTtd(Akses::punya('kurikulum') ? 'Wakil Kepala Bidang Kurikulum' : 'Guru Piket')],
        ]);
    }

    // ================================================================ REKAP SEMESTER (e-Rapor)
    /** Rekap ketidakhadiran satu semester per siswa (S/I/A) untuk diisikan ke e-Rapor. */
    public function rekapSemester()
    {
        if ($r = $this->wajibTp()) {
            return $r;
        }
        $kelasId = (int) $this->request->getGet('kelas_id');
        $kelas   = $this->kelas($kelasId);
        if (! $kelas || ! Akses::laporanKelas($kelasId, 'absensi')) {
            return $this->tolak();
        }
        $dari   = $this->tp['tanggal_mulai'] ?: date('Y-01-01');
        $sampai = min($this->tp['tanggal_selesai'] ?: date('Y-m-d'), date('Y-m-d'));
        $rows   = db_connect()->table('presensi_harian')->select('siswa_id, status, COUNT(*) AS n')
            ->where(['tahun_pelajaran_id' => $this->tpId(), 'kelas_id' => $kelasId])
            ->where('tanggal >=', $dari)->where('tanggal <=', $sampai)->groupBy(['siswa_id', 'status'])->get()->getResultArray();
        $rekap = [];
        foreach ($rows as $r) {
            $rekap[$r['siswa_id']][$r['status']] = (int) $r['n'];
        }
        $efektif = 0;
        foreach (Kalender::tanggal($dari, $sampai) as $d) {
            $efektif += Kalender::absensi($d, $kelasId) ? 1 : 0;
        }
        return view('laporan/rekap_semester', [
            'judul'     => 'Rekap Ketidakhadiran Siswa (untuk e-Rapor)',
            'subjudul'  => $this->tpLabel() . ' · ' . tgl_indo($dari) . ' – ' . tgl_indo($sampai),
            'orientasi' => 'portrait',
            'kelas'     => $kelas,
            'efektif'   => $efektif,
            'siswa'     => model(AnggotaKelasModel::class)->siswaKelas($kelasId, $this->tpId(), false),
            'rekap'     => $rekap,
            'ttd'       => ['kiri' => $this->kepala(), 'kanan' => $this->waliTtd($kelasId)],
        ]);
    }

    // ================================================================ KETERCAPAIAN ATP
    public function ketercapaianAtp()
    {
        if ($r = $this->wajibTp()) {
            return $r;
        }
        $id    = (int) $this->request->getGet('penugasan_id');
        $pilih = null;
        foreach ($this->opsiPenugasan() as $o) {
            if ((int) $o['id'] === $id) {
                $pilih = $o;
            }
        }
        if (! $pilih) {
            return $this->tolak('Pilih mata pelajaran & kelas yang Anda ampu.');
        }
        $kelas = $this->kelas((int) $pilih['kelas_id']);
        $rows  = model(\App\Models\AtpModel::class)->ketercapaian((int) $pilih['mapel_id'], (string) $kelas['tingkat'], $id, $this->tp['semester']);
        $guru  = model(GuruModel::class)->find($pilih['guru_id']);
        return view('laporan/ketercapaian_atp', [
            'judul'     => 'Ketercapaian Tujuan Pembelajaran',
            'subjudul'  => $this->tpLabel(),
            'orientasi' => 'portrait',
            'pilih'     => $pilih,
            'kelas'     => $kelas,
            'guru'      => $guru,
            'rows'      => $rows,
            'ttd'       => ['kiri' => $this->kepala(), 'kanan' => ['jabatan' => 'Guru Mata Pelajaran', 'nama' => nama_guru($guru), 'nip' => $guru['nip'] ?: null]],
        ]);
    }

    // ================================================================ MUTASI
    public function mutasi()
    {
        if ($r = $this->wajibTp()) {
            return $r;
        }
        if (! Akses::mutasiLihat()) {
            return $this->tolak();
        }
        $dari   = $this->tgl('dari', $this->tp['tanggal_mulai'] ?: date('Y-01-01'));
        $sampai = $this->tgl('sampai', date('Y-m-d'));
        return view('laporan/mutasi', [
            'judul'     => 'Laporan Mutasi Siswa',
            'subjudul'  => $this->tpLabel(),
            'orientasi' => 'landscape',
            'periode'   => $this->periode($dari, $sampai),
            'rows'      => array_reverse(model(\App\Models\MutasiSiswaModel::class)->daftar(null, ['dari' => $dari, 'sampai' => $sampai])),
            'ttd'       => ['kiri' => $this->kepala(), 'kanan' => $this->userTtd(Akses::punya('kesiswaan') ? 'Wakil Kepala Bidang Kesiswaan' : 'Petugas')],
        ]);
    }

    /** Rekap kelengkapan perangkat pembelajaran (semua guru) atau lembar pengesahan satu guru. */
    public function perangkat()
    {
        if ($r = $this->wajibTp()) {
            return $r;
        }
        $guruId = (int) $this->request->getGet('guru_id');
        if (! Akses::perangkatLihatSemua()) {
            if (! Akses::guruId()) {
                return $this->tolak();
            }
            $guruId = Akses::guruId();
        }
        $m      = model(\App\Models\PerangkatModel::class);
        $guru   = $guruId ? model(\App\Models\GuruModel::class)->find($guruId) : null;
        $kurik  = Akses::punya('kurikulum') ? $this->userTtd('Wakil Kepala Bidang Kurikulum') : ['jabatan' => 'Wakil Kepala Bidang Kurikulum', 'nama' => '', 'nip' => null];
        return view('laporan/perangkat', [
            'judul'     => $guru ? 'Lembar Pengesahan Perangkat Pembelajaran' : 'Rekap Kelengkapan Perangkat Pembelajaran',
            'subjudul'  => $this->tpLabel(),
            'orientasi' => $guru ? 'portrait' : 'landscape',
            'guru'      => $guru,
            'target'    => $m->target($this->tpId(), $guruId ?: null),
            'jenis'     => $m->jenisAktif(),
            'peta'      => $m->peta($this->tpId(), $guruId ?: null),
            'ttd'       => $guru
                ? ['kiri' => ['atas' => 'Mengesahkan,'] + $this->kepala(), 'kanan' => ['jabatan' => 'Guru Mata Pelajaran', 'nama' => nama_guru($guru), 'nip' => $guru['nip'] ?: null]]
                : ['kiri' => $this->kepala(), 'kanan' => $kurik],
        ]);
    }
}
