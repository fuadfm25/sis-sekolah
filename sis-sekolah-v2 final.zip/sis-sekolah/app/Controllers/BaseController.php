<?php

namespace App\Controllers;

use CodeIgniter\Controller;
use CodeIgniter\HTTP\RedirectResponse;
use CodeIgniter\HTTP\RequestInterface;
use CodeIgniter\HTTP\ResponseInterface;
use App\Libraries\Akses;
use Psr\Log\LoggerInterface;

abstract class BaseController extends Controller
{
    protected $helpers = ['url', 'form', 'text', 'sis'];

    protected ?array $tp = null;

    public function initController(RequestInterface $request, ResponseInterface $response, LoggerInterface $logger)
    {
        parent::initController($request, $response, $logger);
        $this->tp = tp_aktif();
    }

    /** ID tahun pelajaran aktif. */
    protected function tpId(): ?int
    {
        return $this->tp ? (int) $this->tp['id'] : null;
    }

    /** Redirect bila belum ada tahun pelajaran aktif. Pemakaian: if ($r = $this->wajibTp()) return $r; */
    protected function wajibTp(): ?RedirectResponse
    {
        if ($this->tp) {
            return null;
        }
        $msg = 'Belum ada Tahun Pelajaran aktif. ';
        $msg .= Akses::punya('kurikulum') ? 'Silakan atur di menu Pengaturan Akademik > Tahun Pelajaran.' : 'Hubungi wakil kurikulum / administrator.';
        return redirect()->to(Akses::punya('kurikulum') ? '/akademik/tahun-pelajaran' : '/dashboard')->with('error', $msg);
    }

    protected function userId(): int
    {
        return (int) session()->get('user_id');
    }

    protected function guruId(): ?int
    {
        $id = session()->get('guru_id');
        return $id ? (int) $id : null;
    }

    protected function hasRole(string ...$roles): bool
    {
        return has_role(...$roles);
    }

    /** Semua kelas aktif bila $semua, selain itu hanya kelas perwalian user. */
    protected function daftarKelas(bool $semua): array
    {
        $kelasModel = model(\App\Models\KelasModel::class);
        if ($semua) {
            return $kelasModel->listAktif();
        }
        $ids = wali_kelas_ids();
        return $ids ? $kelasModel->whereIn('id', $ids)->orderBy('nama_kelas')->findAll() : [];
    }

    /**
     * Validasi dengan label kolom otomatis (nama_lengkap → "Nama lengkap") agar pesan
     * berbahasa Indonesia tetap enak dibaca walaupun label tidak ditulis di aturan.
     */
    protected function validate($rules, array $messages = []): bool
    {
        return parent::validate(is_array($rules) ? $this->beriLabel($rules) : $rules, $messages);
    }

    protected function validateData(array $data, $rules, array $messages = [], ?string $dbGroup = null): bool
    {
        return parent::validateData($data, is_array($rules) ? $this->beriLabel($rules) : $rules, $messages, $dbGroup);
    }

    private function beriLabel(array $rules): array
    {
        $kamus = ['nis' => 'NIS', 'nisn' => 'NISN', 'nip' => 'NIP', 'nuptk' => 'NUPTK', 'rfid' => 'Kode RFID', 'npsn' => 'NPSN/NSM',
            'kelas_ids' => 'Kelas', 'siswa_id' => 'Siswa', 'guru_id' => 'Guru', 'mapel_id' => 'Mata pelajaran', 'kelas_id' => 'Kelas'];
        foreach ($rules as $field => $r) {
            if (is_string($r) || (is_array($r) && ! isset($r['label']) && ! isset($r['rules']))) {
                $rules[$field] = ['label' => $kamus[$field] ?? ucfirst(str_replace('_', ' ', $field)), 'rules' => $r];
            } elseif (is_array($r) && ! isset($r['label'])) {
                $rules[$field]['label'] = $kamus[$field] ?? ucfirst(str_replace('_', ' ', $field));
            }
        }
        return $rules;
    }

    /**
     * Cek apakah data masih dipakai tabel lain sebelum dihapus.
     * $cek = ['Jurnal' => ['jurnal_pembelajaran', ['kelas_id' => 5]], ...]
     * Mengembalikan pesan penolakan, atau null bila aman dihapus.
     */
    protected function masihDipakai(array $cek, string $saran = ''): ?string
    {
        $db    = db_connect();
        $pakai = [];
        foreach ($cek as $label => [$tabel, $where]) {
            $n = $db->table($tabel)->where($where)->countAllResults();
            if ($n) {
                $pakai[] = $n . ' ' . $label;
            }
        }
        return $pakai ? 'Tidak dapat dihapus karena masih dipakai: ' . implode(', ', $pakai) . '.' . ($saran ? ' ' . $saran : '') : null;
    }

    protected function back(string $type, string $msg): RedirectResponse
    {
        return redirect()->back()->withInput()->with($type, $msg);
    }
}
