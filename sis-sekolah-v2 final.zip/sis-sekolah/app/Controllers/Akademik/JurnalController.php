<?php

namespace App\Controllers\Akademik;

use App\Controllers\BaseController;
use App\Libraries\Akses;
use App\Libraries\Kalender;
use App\Models\AnggotaKelasModel;
use App\Models\GuruModel;
use App\Models\JadwalModel;
use App\Models\JurnalModel;
use App\Models\KelasModel;
use App\Models\PenugasanGuruModel;
use App\Models\PresensiHarianModel;
use App\Models\PresensiMapelModel;

/**
 * Jurnal pembelajaran + absensi per mata pelajaran.
 * Satu jurnal = satu sesi mengajar (slot jadwal berurutan dengan mapel yang sama digabung).
 */
class JurnalController extends BaseController
{
    private JurnalModel $jurnal;
    private JadwalModel $jadwal;

    public function __construct()
    {
        $this->jurnal = new JurnalModel();
        $this->jadwal = new JadwalModel();
    }

    private function tanggalGet(): string
    {
        $t = (string) $this->request->getGet('tanggal');
        return preg_match('/^\d{4}-\d{2}-\d{2}$/', $t) ? $t : date('Y-m-d');
    }


    /** Daftar sesi mengajar guru login pada tanggal tertentu. */
    private function tingkatKelas(int $kelasId): string
    {
        return (string) (model(KelasModel::class)->find($kelasId)['tingkat'] ?? '');
    }

    /** Daftar TP (ATP) untuk mapel & tingkat sesi pada semester aktif. */
    private function atpSesi(array $sesi): array
    {
        return model(\App\Models\AtpModel::class)->daftar((int) $sesi['mapel_id'], $this->tingkatKelas((int) $sesi['kelas_id']), $this->tp['semester'] ?? null);
    }

    /** Validasi tanggal untuk sesi jadwal: masa berlaku, hari jadwal (termasuk masuk pengganti), dan KBM kelas. */
    private function cekTanggalSesi(array $sesi, string $tanggal): ?string
    {
        $kelas = (int) $sesi['kelas_id'];
        if (! empty($sesi['_tidak_berlaku'])) {
            return 'Jadwal ini tidak berlaku pada ' . tgl_indo($tanggal, true) . ' (jadwal sudah diganti).';
        }
        if (Kalender::hariJadwal($tanggal, $kelas) !== (int) $sesi['hari']) {
            return tgl_indo($tanggal, true) . ' memakai jadwal hari ' . nama_hari(Kalender::hariJadwal($tanggal, $kelas)) . ', bukan ' . nama_hari($sesi['hari']) . '.';
        }
        if (! Kalender::kbm($tanggal, $kelas)) {
            return tgl_indo($tanggal, true) . ' tidak ada KBM untuk kelas ' . $sesi['nama_kelas'] . ' (' . Kalender::status($tanggal, $kelas)['label'] . ').';
        }
        return null;
    }

    public function index()
    {
        if ($r = $this->wajibTp()) {
            return $r;
        }
        if (! $this->guruId()) {
            return redirect()->to(Akses::jurnalMonitoring() ? '/jurnal/monitoring' : '/dashboard')
                ->with('info', 'Akun Anda belum ditautkan ke data guru, sehingga tidak memiliki jadwal mengajar.');
        }
        $tanggal = $this->tanggalGet();
        $status  = Kalender::status($tanggal);
        $sesi    = $status['sekolah'] ? $this->jadwal->sesiTanggal($this->tpId(), $tanggal, ['guru_id' => $this->guruId()]) : [];
        $peta    = $this->jurnal->petaTanggal(array_column($sesi, 'id'), $tanggal);
        foreach ($sesi as &$s) {
            $s['jurnal'] = $peta[$s['id']] ?? null;
        }

        // sesi minggu ini yang belum diisi (pengingat)
        $belum = [];
        $senin = date('Y-m-d', strtotime('monday this week', strtotime(date('Y-m-d'))));
        for ($d = $senin; $d < date('Y-m-d'); $d = date('Y-m-d', strtotime($d . ' +1 day'))) {
            if (! Kalender::status($d)['sekolah']) {
                continue;
            }
            $ss = $this->jadwal->sesiTanggal($this->tpId(), $d, ['guru_id' => $this->guruId()]);
            $pp = $this->jurnal->petaTanggal(array_column($ss, 'id'), $d);
            foreach ($ss as $x) {
                if (! isset($pp[$x['id']])) {
                    $x['tanggal'] = $d;
                    $belum[]      = $x;
                }
            }
        }

        return view('akademik/jurnal/index', [
            'title'    => 'Jurnal & Absensi Mapel',
            'subtitle' => 'Pilih sesi mengajar untuk mengisi jurnal sekaligus absensi siswa.',
            'tanggal'  => $tanggal,
            'status'   => $status,
            'sesi'     => $sesi,
            'belum'    => $belum,
        ]);
    }

    public function form($jadwalId)
    {
        if ($r = $this->wajibTp()) {
            return $r;
        }
        $tanggal = $this->tanggalGet();
        $sesi    = $this->jadwal->sesiDariJadwal((int) $jadwalId, $tanggal);
        if (! $sesi) {
            return redirect()->to('/jurnal')->with('error', 'Jadwal tidak ditemukan.');
        }
        if (! Akses::jurnalIsi($sesi, $tanggal)) {
            return redirect()->to('/jurnal')->with('error', 'Anda bukan pengampu sesi ini' . (in_array('piket', Akses::roles(), true) ? ' dan tanggal tersebut bukan hari piket Anda.' : '.'));
        }
        if ($tanggal > date('Y-m-d')) {
            return redirect()->to('/jurnal')->with('error', 'Jurnal tidak dapat diisi untuk tanggal yang akan datang.');
        }
        $jurnal = $this->jurnal->where(['jadwal_pelajaran_id' => $sesi['id'], 'tanggal' => $tanggal])->first();
        if (! $jurnal && ($e = $this->cekTanggalSesi($sesi, $tanggal))) {
            return redirect()->to('/jurnal?tanggal=' . $tanggal)->with('error', $e);
        }

        $siswa    = model(AnggotaKelasModel::class)->siswaKelas((int) $sesi['kelas_id'], $this->tpId());
        $presensi = $jurnal ? model(PresensiMapelModel::class)->petaJurnal((int) $jurnal['id']) : [];
        $pagi     = model(PresensiHarianModel::class)->statusSiswa(array_column($siswa, 'id'), $tanggal);
        \App\Libraries\IzinKeluar::perbarui($tanggal);
        $saran    = \App\Libraries\SinkronAbsensi::saran(array_column($siswa, 'id'), $tanggal, $sesi['jam_mulai'] ?? null);

        // jurnal pertemuan sebelumnya sebagai referensi
        $sebelum = $this->jurnal->where('penugasan_guru_id', $sesi['penugasan_guru_id'])->where('tanggal <', $tanggal)->orderBy('tanggal', 'DESC')->first();

        return view('akademik/jurnal/form', [
            'title'     => $jurnal ? 'Edit Jurnal' : 'Isi Jurnal',
            'subtitle'  => $sesi['nama_mapel'] . ' · ' . $sesi['nama_kelas'] . ' · ' . tgl_indo($tanggal, true) . ' · Jam ke-' . $sesi['jam_ke_label'],
            'sesi'      => $sesi,
            'tanggal'   => $tanggal,
            'jurnal'    => $jurnal,
            'siswa'     => $siswa,
            'presensi'  => $presensi,
            'pagi'      => $pagi,
            'saran'     => $saran,
            'sebelum'   => $sebelum,
            'pertemuan' => $jurnal['pertemuan_ke'] ?? $this->jurnal->pertemuanBerikut((int) $sesi['penugasan_guru_id'], $tanggal),
            'atp'       => $atp = $this->atpSesi($sesi),
            'atpPilih'  => $jurnal ? array_map('intval', array_column(db_connect()->table('jurnal_atp')->where('jurnal_id', $jurnal['id'])->get()->getResultArray(), 'atp_id')) : [],
            'atpSudah'  => $atp ? array_column(model(\App\Models\AtpModel::class)->ketercapaian((int) $sesi['mapel_id'], (string) $this->tingkatKelas((int) $sesi['kelas_id']), (int) $sesi['penugasan_guru_id']), 'pertemuan', 'id') : [],
        ]);
    }

    public function simpan($jadwalId)
    {
        if ($r = $this->wajibTp()) {
            return $r;
        }
        $tanggal = (string) $this->request->getPost('tanggal');
        $sesi    = $this->jadwal->sesiDariJadwal((int) $jadwalId, $tanggal);
        if (! $sesi || ! Akses::jurnalIsi($sesi, $tanggal)) {
            return redirect()->to('/jurnal')->with('error', 'Akses ditolak.');
        }
        $rules = [
            'tanggal'    => 'required|valid_date[Y-m-d]',
            'materi'     => 'required|max_length[255]',
            'status_kbm' => 'required|in_list[Terlaksana,Penilaian,Tugas Mandiri,Diganti Guru Lain,Tidak Terlaksana]',
        ];
        if (! $this->validate($rules, ['materi' => ['required' => 'Materi / topik pembelajaran wajib diisi.']])) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }
        if ($tanggal > date('Y-m-d')) {
            return $this->back('error', 'Jurnal tidak dapat diisi untuk tanggal yang akan datang.');
        }
        $sudahAda = $this->jurnal->where(['jadwal_pelajaran_id' => $sesi['id'], 'tanggal' => $tanggal])->countAllResults() > 0;
        if (! $sudahAda && ($e = $this->cekTanggalSesi($sesi, $tanggal))) {
            return $this->back('error', $e);
        }

        $p    = fn ($k) => trim((string) $this->request->getPost($k)) ?: null;
        $data = [
            'tahun_pelajaran_id'  => $this->tpId(),
            'jadwal_pelajaran_id' => $sesi['id'],
            'penugasan_guru_id'   => $sesi['penugasan_guru_id'],
            'guru_id'             => $sesi['guru_id'],
            'kelas_id'            => $sesi['kelas_id'],
            'tanggal'             => $tanggal,
            'jam_ke'              => $sesi['jam_ke_label'],
            'jumlah_jp'           => $sesi['jumlah_jp'],
            'pertemuan_ke'        => (int) $this->request->getPost('pertemuan_ke') ?: null,
            'materi'              => $p('materi'),
            'tujuan_pembelajaran' => $p('tujuan_pembelajaran'),
            'kegiatan'            => $p('kegiatan'),
            'metode'              => $p('metode'),
            'penilaian'           => $p('penilaian'),
            'catatan'             => $p('catatan'),
            'status_kbm'          => $this->request->getPost('status_kbm'),
            'diisi_oleh'          => $this->userId(),
        ];

        $db = db_connect();
        $db->transStart();
        $ada = $this->jurnal->where(['jadwal_pelajaran_id' => $sesi['id'], 'tanggal' => $tanggal])->first();
        if ($ada) {
            $this->jurnal->update($ada['id'], $data);
            $jurnalId = (int) $ada['id'];
        } else {
            $jurnalId = (int) $this->jurnal->insert($data);
        }
        $presensi = (array) $this->request->getPost('presensi');
        if ($data['status_kbm'] !== 'Tidak Terlaksana' && $presensi) {
            model(PresensiMapelModel::class)->simpanBatch($jurnalId, $presensi, \App\Libraries\SinkronAbsensi::saran(array_keys($presensi), $tanggal, $sesi['jam_mulai'] ?? null));
        }
        // tujuan pembelajaran (ATP) yang dibahas
        $valid = array_map('intval', array_column($this->atpSesi($sesi), 'id'));
        $pilih = array_values(array_intersect(array_map('intval', (array) $this->request->getPost('atp_ids')), $valid));
        $db->table('jurnal_atp')->where('jurnal_id', $jurnalId)->delete();
        foreach ($pilih as $aid) {
            $db->table('jurnal_atp')->insert(['jurnal_id' => $jurnalId, 'atp_id' => $aid]);
        }
        if ($pilih && empty($data['tujuan_pembelajaran'])) {
            $teks = array_column(array_filter($this->atpSesi($sesi), static fn ($x) => in_array((int) $x['id'], $pilih, true)), 'tujuan');
            $this->jurnal->update($jurnalId, ['tujuan_pembelajaran' => implode("\n", $teks)]);
        }
        $db->transComplete();

        if (! $db->transStatus()) {
            return $this->back('error', 'Gagal menyimpan jurnal.');
        }
        $tujuan = Akses::jurnalPengampu($sesi) ? '/jurnal?tanggal=' . $tanggal : '/jurnal/monitoring?tanggal=' . $tanggal;
        return redirect()->to($tujuan)->with('success', 'Jurnal & absensi ' . $sesi['nama_mapel'] . ' ' . $sesi['nama_kelas'] . ' tersimpan.');
    }

    public function detail($id)
    {
        $j = $this->jurnal->detail((int) $id);
        if (! $j) {
            return redirect()->to('/jurnal')->with('error', 'Jurnal tidak ditemukan.');
        }
        if (! Akses::jurnalLihat($j)) {
            return redirect()->to('/jurnal')->with('error', 'Akses ditolak.');
        }
        $siswa    = model(AnggotaKelasModel::class)->siswaKelas((int) $j['kelas_id'], (int) $j['tahun_pelajaran_id'], false);
        $presensi = model(PresensiMapelModel::class)->petaJurnal((int) $id);

        return view('akademik/jurnal/detail', [
            'title'    => 'Detail Jurnal',
            'subtitle' => $j['nama_mapel'] . ' · ' . $j['nama_kelas'] . ' · ' . tgl_indo($j['tanggal'], true),
            'j'        => $j,
            'siswa'    => $siswa,
            'presensi' => $presensi,
            'bolehUbah' => Akses::jurnalPengampu($j) || Akses::jurnalPengganti($j['tanggal']),
            'bolehHapus' => Akses::jurnalHapus($j),
        ]);
    }

    public function hapus($id)
    {
        $j = $this->jurnal->detail((int) $id);
        if (! $j || ! Akses::jurnalHapus($j)) {
            return redirect()->back()->with('error', 'Akses ditolak.');
        }
        catat_log('hapus', 'jurnal_pembelajaran', (int) $id);
        $this->jurnal->delete($id);
        return redirect()->to('/jurnal/riwayat')->with('success', 'Jurnal dihapus.');
    }

    /** Riwayat jurnal (guru: milik sendiri; kurikulum/kepsek: semua). */
    public function riwayat()
    {
        if ($r = $this->wajibTp()) {
            return $r;
        }
        $semua = Akses::jurnalSemua();
        $f = [
            'dari'     => $this->request->getGet('dari') ?: date('Y-m-01'),
            'sampai'   => $this->request->getGet('sampai') ?: date('Y-m-d'),
            'kelas_id' => $this->request->getGet('kelas_id'),
            'guru_id'  => $semua ? $this->request->getGet('guru_id') : $this->guruId(),
        ];
        if (! $semua && ! $this->guruId()) {
            return redirect()->to('/dashboard')->with('error', 'Akun belum tertaut ke data guru.');
        }
        $rows = $this->jurnal->riwayat($this->tpId(), $f);

        return view('akademik/jurnal/riwayat', [
            'title'   => 'Riwayat Jurnal',
            'rows'    => $rows,
            'ringkas' => $this->jurnal->ringkasPresensi(array_column($rows, 'id')),
            'pager'   => $this->jurnal->pager,
            'f'       => $f,
            'semua'   => $semua,
            'kelas'   => model(KelasModel::class)->listAktif(),
            'guru'    => $semua ? model(GuruModel::class)->listAktif() : [],
        ]);
    }

    /** Monitoring keterisian jurnal seluruh kelas pada satu tanggal. */
    public function monitoring()
    {
        if ($r = $this->wajibTp()) {
            return $r;
        }
        if (! Akses::jurnalMonitoring()) {
            return redirect()->to('/dashboard')->with('error', 'Monitoring jurnal hanya untuk kurikulum, kepala sekolah, dan guru piket.');
        }
        $tanggal = $this->tanggalGet();
        $kelasId = (int) $this->request->getGet('kelas_id');
        $f       = $kelasId ? ['kelas_id' => $kelasId] : [];
        $status  = Kalender::status($tanggal, $kelasId ?: null);
        $sesi    = $status['sekolah'] ? $this->jadwal->sesiTanggal($this->tpId(), $tanggal, $f) : [];
        $peta    = $this->jurnal->petaTanggal(array_column($sesi, 'id'), $tanggal);
        foreach ($sesi as &$s) {
            $s['jurnal'] = $peta[$s['id']] ?? null;
        }
        usort($sesi, static fn ($a, $b) => [$a['nama_kelas'], $a['jam_mulai']] <=> [$b['nama_kelas'], $b['jam_mulai']]);

        return view('akademik/jurnal/monitoring', [
            'title'   => 'Monitoring Jurnal',
            'tanggal' => $tanggal,
            'status'  => $status,
            'kelasId' => $kelasId,
            'kelas'   => model(KelasModel::class)->listAktif(),
            'sesi'    => $sesi,
            'terisi'  => count($peta),
            'ringkas' => $this->jurnal->ringkasPresensi(array_column($peta, 'id')),
            'izinGuru'  => model(\App\Models\IzinGuruModel::class)->berlaku($tanggal),
            'hadirGuru' => model(\App\Models\PresensiGuruModel::class)->petaTanggal($tanggal),
        ]);
    }

    /** Rekap absensi per mapel-kelas (matriks siswa x pertemuan). */
    public function rekapPresensi()
    {
        if ($r = $this->wajibTp()) {
            return $r;
        }
        $pm = model(PenugasanGuruModel::class);
        if (Akses::jurnalSemua()) {
            $opsi = $pm->daftar($this->tpId());
        } else {
            $opsi = $this->guruId() ? $pm->daftar($this->tpId(), ['guru_id' => $this->guruId()]) : [];
            foreach (wali_kelas_ids() as $kid) {
                foreach ($pm->daftar($this->tpId(), ['kelas_id' => $kid]) as $p) {
                    $opsi[] = $p;
                }
            }
            $opsi = array_values(array_column($opsi, null, 'id'));
        }

        $penugasanId = (int) $this->request->getGet('penugasan_id');
        $dari        = $this->request->getGet('dari') ?: ($this->tp['tanggal_mulai'] ?: date('Y-m-01'));
        $sampai      = $this->request->getGet('sampai') ?: date('Y-m-d');
        $pilih       = null;
        foreach ($opsi as $o) {
            if ((int) $o['id'] === $penugasanId) {
                $pilih = $o;
            }
        }

        $data = ['jurnal' => [], 'matriks' => []];
        $siswa = [];
        if ($pilih) {
            $data  = model(PresensiMapelModel::class)->rekap($penugasanId, $dari, $sampai);
            $siswa = model(AnggotaKelasModel::class)->siswaKelas((int) $pilih['kelas_id'], $this->tpId(), false);
        }

        return view('akademik/jurnal/rekap', [
            'title'       => 'Rekap Absensi Mata Pelajaran',
            'subtitle'    => $pilih ? $pilih['nama_mapel'] . ' · ' . $pilih['nama_kelas'] . ' · ' . nama_guru($pilih) : '',
            'opsi'        => $opsi,
            'penugasanId' => $penugasanId,
            'pilih'       => $pilih,
            'dari'        => $dari,
            'sampai'      => $sampai,
            'jurnal'      => $data['jurnal'],
            'matriks'     => $data['matriks'],
            'siswa'       => $siswa,
        ]);
    }
}
