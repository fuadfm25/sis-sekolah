<?php

namespace App\Controllers\Akademik;

use App\Controllers\BaseController;
use App\Libraries\Akses;
use App\Libraries\Berkas;
use App\Models\PerangkatModel;

/**
 * Perangkat pembelajaran: guru mengunggah → Waka Kurikulum memeriksa (setujui / perlu revisi) → kepala sekolah mengesahkan.
 */
class PerangkatController extends BaseController
{
    private PerangkatModel $model;

    public function __construct()
    {
        $this->model = new PerangkatModel();
    }

    private function tenggat(): ?string
    {
        $t = (string) setting('perangkat_tenggat', '');
        return preg_match('/^\d{4}-\d{2}-\d{2}$/', $t) ? $t : null;
    }

    // ------------------------------------------------------------------ GURU
    public function index()
    {
        if ($r = $this->wajibTp()) {
            return $r;
        }
        if (! Akses::perangkatGuru()) {
            return Akses::perangkatLihatSemua() ? redirect()->to('/perangkat/pemeriksaan')
                : redirect()->to('/dashboard')->with('error', 'Menu perangkat pembelajaran untuk akun guru.');
        }
        $g = Akses::guruId();
        return view('akademik/perangkat/index', [
            'title'    => 'Perangkat Pembelajaran Saya',
            'subtitle' => 'Unggah perangkat untuk tiap mapel & tingkat yang Anda ampu; Waka Kurikulum memeriksa, kepala sekolah mengesahkan.',
            'target'   => $this->model->target($this->tpId(), $g),
            'jenis'    => $this->model->jenisAktif(),
            'peta'     => $this->model->peta($this->tpId(), $g),
            'guruId'   => $g,
            'tenggat'  => $this->tenggat(),
            'hitung'   => $this->model->hitungStatus($this->tpId(), $g),
        ]);
    }

    public function unggah()
    {
        if (($r = $this->wajibTp()) || ! Akses::perangkatGuru()) {
            return $r ?: $this->back('error', 'Akses ditolak.');
        }
        $g       = Akses::guruId();
        $mapelId = (int) $this->request->getPost('mapel_id');
        $tingkat = (string) $this->request->getPost('tingkat');
        $jenisId = (int) $this->request->getPost('jenis_perangkat_id');
        $cocok   = array_filter($this->model->target($this->tpId(), $g), static fn ($t) => (int) $t['mapel_id'] === $mapelId && (string) $t['tingkat'] === $tingkat);
        $jenis   = array_column($this->model->jenisAktif(), null, 'id')[$jenisId] ?? null;
        if (! $cocok || ! $jenis) {
            return $this->back('error', 'Mapel/tingkat bukan penugasan Anda atau jenis perangkat tidak dikenal.');
        }
        $tautan  = trim((string) $this->request->getPost('tautan')) ?: null;
        $catatan = trim((string) $this->request->getPost('catatan_guru')) ?: null;
        if ($tautan && ! preg_match('~^https?://[^\s]+$~i', $tautan)) {
            return $this->back('error', 'Tautan harus diawali http:// atau https://');
        }
        $file = $this->request->getFile('file');
        [$nama, $err] = Berkas::simpan($file, 'perangkat', PerangkatModel::EKSTENSI, PerangkatModel::MAKS_KB);
        if ($err) {
            return $this->back('error', $err);
        }
        $ada = $this->model->where(['tahun_pelajaran_id' => $this->tpId(), 'guru_id' => $g, 'mapel_id' => $mapelId, 'tingkat' => $tingkat, 'jenis_perangkat_id' => $jenisId])->first();
        if (! $nama && ! $tautan && ! ($ada && ($ada['file'] || $ada['tautan'] || $ada['sumber']))) {
            return $this->back('error', 'Unggah berkas atau isi tautan (Google Drive, dsb.).');
        }
        if ($ada && in_array($ada['status'], PerangkatModel::SELESAI, true)) {
            Berkas::hapus('perangkat', $nama);
            return $this->back('error', 'Perangkat ini sudah ' . strtolower($ada['status']) . '. Minta Waka Kurikulum membukanya kembali bila perlu diganti.');
        }
        $now  = date('Y-m-d H:i:s');
        $data = [
            'file' => $nama ?? ($ada['file'] ?? null), 'nama_file' => $nama ? mb_substr($file->getClientName(), 0, 150) : ($ada['nama_file'] ?? null),
            'tautan' => $tautan ?? ($nama ? null : ($ada['tautan'] ?? null)), 'catatan_guru' => $catatan, 'status' => 'Diajukan', 'diajukan_at' => $now,
            'sumber' => $nama || $tautan ? null : ($ada['sumber'] ?? null),
        ];
        if ($ada) {
            $ulang = $ada['status'] === 'Perlu Revisi';
            $data['versi'] = (int) $ada['versi'] + ($ulang ? 1 : 0);
            $this->model->update($ada['id'], $data);
            $id   = (int) $ada['id'];
            $aksi = $ulang ? 'Diajukan ulang' : 'Diganti';
        } else {
            $id   = (int) $this->model->insert($data + ['tahun_pelajaran_id' => $this->tpId(), 'guru_id' => $g, 'mapel_id' => $mapelId, 'tingkat' => $tingkat, 'jenis_perangkat_id' => $jenisId, 'versi' => 1]);
            $aksi = 'Diajukan';
        }
        $this->model->catat($id, $aksi, $data['versi'] ?? 1, $catatan, $data['file'], $this->userId());
        catat_log('tambah', 'perangkat_pembelajaran', $id, $jenis['nama'] . ' – ' . $aksi);
        return redirect()->to('/perangkat')->with('success', $jenis['nama'] . ' ' . strtolower($aksi) . ' ke Waka Kurikulum.');
    }

    public function tarik($id)
    {
        $p = $this->model->find((int) $id);
        if (! $p || (int) $p['guru_id'] !== Akses::guruId() || $p['status'] !== 'Diajukan' || (int) $p['versi'] > 1) {
            return $this->back('error', 'Hanya pengajuan pertama yang belum diperiksa yang bisa ditarik.');
        }
        Berkas::hapus('perangkat', $p['file']);
        $this->model->delete($p['id']);
        return redirect()->to('/perangkat')->with('success', 'Pengajuan ditarik.');
    }

    // ------------------------------------------------------------------ BERSAMA
    private function boleh(array $p): bool
    {
        return Akses::perangkatLihatSemua() || (int) $p['guru_id'] === Akses::guruId();
    }

    public function detail($id)
    {
        $p = $this->model->detail((int) $id);
        if (! $p || ! $this->boleh($p)) {
            return redirect()->to('/perangkat')->with('error', 'Perangkat tidak ditemukan.');
        }
        return view('akademik/perangkat/detail', [
            'title'    => $p['nama_jenis'],
            'subtitle' => $p['nama_guru'] . ' · ' . $p['nama_mapel'] . ' · tingkat ' . $p['tingkat'] . ' · ' . $p['tahun_pelajaran'] . ' ' . $p['semester'],
            'p'        => $p,
            'riwayat'  => $this->model->riwayat((int) $id),
            'tenggat'  => $this->tenggat(),
        ]);
    }

    public function unduh($id, $riwayatId = null)
    {
        $p = $this->model->find((int) $id);
        if (! $p || ! $this->boleh($p)) {
            return $this->back('error', 'Akses ditolak.');
        }
        if (! $riwayatId && ($u = PerangkatModel::urlSumber($p))) {
            return redirect()->to($u);
        }
        $file = $p['file'];
        $nama = $p['nama_file'];
        if ($riwayatId) {
            $r    = db_connect()->table('perangkat_riwayat')->where(['id' => (int) $riwayatId, 'perangkat_id' => $p['id']])->get()->getRowArray();
            $file = $r['file'] ?? null;
            $nama = null;
        }
        $path = Berkas::path('perangkat', $file);
        if (! $path) {
            return $this->back('error', 'Berkas tidak tersedia.');
        }
        $ext  = strtolower(pathinfo($path, PATHINFO_EXTENSION));
        $resp = $this->response->download($path, null)->setFileName($nama ?: ('perangkat_' . $p['id'] . '_v' . $p['versi'] . '.' . $ext));
        return in_array($ext, ['pdf', 'jpg', 'jpeg', 'png'], true) && ! $this->request->getGet('unduh') ? $resp->inline() : $resp;
    }

    // ------------------------------------------------------------------ KURIKULUM & KEPSEK
    public function pemeriksaan()
    {
        if ($r = $this->wajibTp()) {
            return $r;
        }
        if (! Akses::perangkatLihatSemua()) {
            return redirect()->to('/perangkat')->with('error', 'Halaman pemeriksaan untuk Waka Kurikulum dan kepala sekolah.');
        }
        $f = [];
        foreach (['status', 'guru_id', 'jenis_perangkat_id'] as $k) {
            $f[$k] = $this->request->getGet($k);
        }
        if ($f['status'] === null) {
            $f['status'] = Akses::perangkatPeriksa() ? 'Diajukan' : 'Disetujui';
        }
        return view('akademik/perangkat/pemeriksaan', [
            'title'    => 'Pemeriksaan Perangkat Pembelajaran',
            'subtitle' => 'Periksa perangkat yang diajukan guru, pantau kelengkapan, dan sahkan.',
            'rows'     => $this->model->daftar($this->tpId(), $f),
            'rekap'    => $this->model->rekap($this->tpId()),
            'jenis'    => $this->model->jenisAktif(),
            'guru'     => model(\App\Models\GuruModel::class)->where('is_active', 1)->orderBy('nama_lengkap')->findAll(),
            'hitung'   => $this->model->hitungStatus($this->tpId()),
            'f'        => $f,
            'tenggat'  => $this->tenggat(),
        ]);
    }

    public function periksa($id)
    {
        if (! Akses::perangkatPeriksa()) {
            return $this->back('error', 'Hanya Waka Kurikulum yang memeriksa perangkat.');
        }
        $p       = $this->model->find((int) $id);
        $aksi    = (string) $this->request->getPost('aksi');
        $catatan = trim((string) $this->request->getPost('catatan')) ?: null;
        if (! $p || ! in_array($aksi, ['setujui', 'revisi', 'buka'], true)) {
            return $this->back('error', 'Data tidak valid.');
        }
        if ($aksi !== 'setujui' && ! $catatan) {
            return $this->back('error', 'Tuliskan catatan perbaikan untuk guru.');
        }
        if ($aksi === 'buka' && ! in_array($p['status'], PerangkatModel::SELESAI, true)) {
            return $this->back('error', 'Hanya perangkat yang sudah disetujui/disahkan yang bisa dibuka kembali.');
        }
        if ($aksi !== 'buka' && $p['status'] !== 'Diajukan') {
            return $this->back('warning', 'Perangkat ini berstatus ' . $p['status'] . ', tidak sedang menunggu pemeriksaan.');
        }
        $status = $aksi === 'setujui' ? 'Disetujui' : 'Perlu Revisi';
        $this->model->update($p['id'], ['status' => $status, 'catatan_pemeriksa' => $catatan, 'diperiksa_oleh' => $this->userId(), 'diperiksa_at' => date('Y-m-d H:i:s'),
            'disahkan_oleh' => null, 'disahkan_at' => null]);
        $this->model->catat((int) $p['id'], $aksi === 'buka' ? 'Dibuka kembali' : $status, (int) $p['versi'], $catatan, null, $this->userId());
        $lanjut = $this->request->getPost('lanjut') ? $this->berikutnya((int) $p['id']) : null;
        return redirect()->to($lanjut ? '/perangkat/detail/' . $lanjut : '/perangkat/pemeriksaan')->with('success', 'Perangkat ' . strtolower($status) . '.'
            . ($lanjut ? ' Berikut pengajuan selanjutnya.' : ''));
    }

    private function berikutnya(int $kecuali): ?int
    {
        $n = $this->model->where(['tahun_pelajaran_id' => $this->tpId(), 'status' => 'Diajukan'])->where('id !=', $kecuali)->orderBy('diajukan_at')->first();
        return $n ? (int) $n['id'] : null;
    }

    public function sahkan()
    {
        if (! Akses::perangkatSahkan()) {
            return $this->back('error', 'Hanya kepala sekolah yang mengesahkan perangkat.');
        }
        $ids = array_map('intval', (array) $this->request->getPost('ids'));
        if (! $ids) {
            return $this->back('warning', 'Pilih perangkat yang akan disahkan.');
        }
        $rows = $this->model->whereIn('id', $ids)->where('status', 'Disetujui')->findAll();
        foreach ($rows as $p) {
            $this->model->update($p['id'], ['status' => 'Disahkan', 'disahkan_oleh' => $this->userId(), 'disahkan_at' => date('Y-m-d H:i:s')]);
            $this->model->catat((int) $p['id'], 'Disahkan', (int) $p['versi'], null, null, $this->userId());
        }
        return $this->back('success', count($rows) . ' perangkat disahkan.' . (count($rows) < count($ids) ? ' Yang belum disetujui kurikulum dilewati.' : ''));
    }

    public function tenggatSimpan()
    {
        if (! Akses::perangkatPeriksa()) {
            return $this->back('error', 'Akses ditolak.');
        }
        $t = (string) $this->request->getPost('tenggat');
        if ($t !== '' && ! preg_match('/^\d{4}-\d{2}-\d{2}$/', $t)) {
            return $this->back('error', 'Tanggal tidak valid.');
        }
        model(\App\Models\PengaturanModel::class)->simpan('perangkat_tenggat', $t);
        return $this->back('success', $t ? 'Batas pengumpulan: ' . tgl_indo($t) . '.' : 'Batas pengumpulan dihapus.');
    }

    // ------------------------------------------------------------------ JENIS PERANGKAT (kurikulum)
    public function jenis()
    {
        if (! Akses::perangkatPeriksa()) {
            return redirect()->to('/perangkat')->with('error', 'Akses ditolak.');
        }
        return view('akademik/perangkat/jenis', [
            'title'    => 'Jenis Perangkat Pembelajaran',
            'subtitle' => 'Daftar dokumen yang dikumpulkan guru. Sesuaikan dengan kebijakan sekolah dan regulasi terbaru.',
            'rows'     => db_connect()->table('jenis_perangkat')->orderBy('urutan')->orderBy('id')->get()->getResultArray(),
        ]);
    }

    public function jenisSimpan($id = null)
    {
        if (! Akses::perangkatPeriksa()) {
            return $this->back('error', 'Akses ditolak.');
        }
        $data = [
            'nama'       => trim((string) $this->request->getPost('nama')),
            'periode'    => $this->request->getPost('periode') === 'Tahunan' ? 'Tahunan' : 'Semester',
            'wajib'      => $this->request->getPost('wajib') ? 1 : 0,
            'keterangan' => trim((string) $this->request->getPost('keterangan')) ?: null,
            'urutan'     => (int) $this->request->getPost('urutan'),
            'is_active'  => $this->request->getPost('is_active') === '0' ? 0 : 1,
            'updated_at' => date('Y-m-d H:i:s'),
        ];
        if ($data['nama'] === '' || mb_strlen($data['nama']) > 120) {
            return $this->back('error', 'Nama jenis perangkat wajib diisi (maks. 120 karakter).');
        }
        $t = db_connect()->table('jenis_perangkat');
        if ($id) {
            $t->where('id', (int) $id)->update($data);
        } else {
            $t->insert($data + ['created_at' => date('Y-m-d H:i:s')]);
        }
        return redirect()->to('/perangkat/jenis')->with('success', 'Jenis perangkat disimpan.');
    }
}
