<?php

namespace App\Controllers\Akademik;

use App\Controllers\BaseController;
use App\Libraries\Akses;
use App\Models\GuruModel;
use App\Models\KalenderModel;
use App\Models\KelasModel;
use App\Models\KokurikulerModel;

/**
 * Kegiatan kokurikuler (Permendikdasmen 13/2025, pengganti P5): dimensi profil lulusan, kelas sasaran,
 * dan agenda kalender yang dibuat otomatis agar jurnal/absensi menyesuaikan.
 */
class KokurikulerController extends BaseController
{
    private KokurikulerModel $model;

    public function __construct()
    {
        $this->model = new KokurikulerModel();
    }

    public function index()
    {
        if ($r = $this->wajibTp()) {
            return $r;
        }
        $kelas = model(KelasModel::class)->listAktif();
        return view('akademik/kokurikuler/index', [
            'title'     => 'Kegiatan Kokurikuler',
            'subtitle'  => 'Perencanaan kokurikuler dengan 8 dimensi profil lulusan. Agenda otomatis masuk kalender akademik untuk kelas sasaran.',
            'rows'      => $this->model->where('tahun_pelajaran_id', $this->tpId())->orderBy('tanggal_mulai')->findAll(),
            'kelas'     => $kelas,
            'namaKelas' => array_column($kelas, 'nama_kelas', 'id'),
            'guru'      => model(GuruModel::class)->listAktif(),
            'namaGuru'  => array_map('nama_guru', array_column(model(GuruModel::class)->listAktif(), null, 'id')),
            'kelola'    => Akses::kokurikulerKelola(),
        ]);
    }

    private function simpan(?int $id)
    {
        $row = $id ? $this->model->find($id) : null;
        // koordinator boleh mengisi refleksi kegiatannya
        if ($row && ! Akses::kokurikulerKelola() && (int) $row['koordinator_id'] === (int) $this->guruId()) {
            $this->model->update($id, ['refleksi' => trim((string) $this->request->getPost('refleksi')) ?: null]);
            return redirect()->to('/kokurikuler')->with('success', 'Refleksi disimpan.');
        }
        if (! Akses::kokurikulerKelola()) {
            return $this->back('error', 'Hanya kurikulum yang dapat mengatur kokurikuler.');
        }
        $p    = fn ($k) => trim((string) $this->request->getPost($k)) ?: null;
        $dim  = array_values(array_intersect((array) $this->request->getPost('dimensi'), array_keys(KokurikulerModel::DIMENSI)));
        $data = [
            'tahun_pelajaran_id' => $this->tpId(), 'judul' => (string) $p('judul'), 'tema' => $p('tema'), 'bentuk' => $p('bentuk'),
            'dimensi' => implode(',', $dim) ?: null,
            'kelas_ids' => implode(',', array_filter(array_map('intval', (array) $this->request->getPost('kelas_ids')))) ?: null,
            'tanggal_mulai' => (string) $p('tanggal_mulai'), 'tanggal_selesai' => (string) ($p('tanggal_selesai') ?: $p('tanggal_mulai')),
            'alokasi_jp' => (int) $this->request->getPost('alokasi_jp') ?: null, 'deskripsi' => $p('deskripsi'),
            'koordinator_id' => (int) $this->request->getPost('koordinator_id') ?: null, 'refleksi' => $p('refleksi'),
        ];
        if (! $this->validateData($data, ['judul' => 'required|max_length[200]', 'tanggal_mulai' => 'required|valid_date[Y-m-d]', 'tanggal_selesai' => 'required|valid_date[Y-m-d]'])) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }
        if ($data['tanggal_selesai'] < $data['tanggal_mulai']) {
            return $this->back('error', 'Tanggal selesai tidak boleh sebelum tanggal mulai.');
        }
        if (! $dim) {
            return $this->back('error', 'Pilih minimal satu dimensi profil lulusan.');
        }
        // agenda kalender
        $agenda = [
            'tahun_pelajaran_id' => $this->tpId(), 'tanggal_mulai' => $data['tanggal_mulai'], 'tanggal_selesai' => $data['tanggal_selesai'],
            'jenis' => 'Kokurikuler', 'nama' => mb_substr($data['judul'], 0, 150), 'keterangan' => $data['tema'],
            'ada_kbm' => $this->request->getPost('ada_kbm') ? 1 : 0, 'ada_absensi' => 1, 'kelas_ids' => $data['kelas_ids'],
        ];
        $kal = model(KalenderModel::class);
        if ($row && $row['kalender_id'] && $kal->find($row['kalender_id'])) {
            $kal->update($row['kalender_id'], $agenda);
            $data['kalender_id'] = $row['kalender_id'];
        } else {
            $data['kalender_id'] = (int) $kal->insert($agenda);
        }
        $id ? $this->model->update($id, $data) : $this->model->insert($data);
        return redirect()->to('/kokurikuler')->with('success', 'Kegiatan kokurikuler disimpan dan masuk kalender akademik.');
    }

    public function store()
    {
        return $this->simpan(null);
    }

    public function update($id)
    {
        return $this->simpan((int) $id);
    }

    public function delete($id)
    {
        if (! Akses::kokurikulerKelola()) {
            return $this->back('error', 'Akses ditolak.');
        }
        $row = $this->model->find($id);
        if ($row && $row['kalender_id']) {
            model(KalenderModel::class)->delete($row['kalender_id']);
        }
        $this->model->delete($id);
        catat_log('hapus', 'kokurikuler', (int) $id);
        return redirect()->to('/kokurikuler')->with('success', 'Kegiatan kokurikuler dan agendanya dihapus.');
    }
}
