<?php

namespace App\Controllers\Akademik;

use App\Controllers\BaseController;
use App\Models\GuruModel;
use App\Models\JadwalModel;
use App\Models\JamPelajaranModel;
use App\Models\KelasModel;
use App\Models\PenugasanGuruModel;

class JadwalController extends BaseController
{
    private JadwalModel $model;

    public function __construct()
    {
        $this->model = new JadwalModel();
    }

    /** Tanggal acuan versi jadwal: GET/POST "berlaku", dibatasi ke periode TP aktif. */
    private function tanggalBerlaku(): string
    {
        $t = (string) ($this->request->getPost('berlaku_mulai') ?: $this->request->getGet('berlaku'));
        if (! preg_match('/^\d{4}-\d{2}-\d{2}$/', $t)) {
            $t = date('Y-m-d');
        }
        if (! empty($this->tp['tanggal_mulai']) && $t < $this->tp['tanggal_mulai']) {
            $t = $this->tp['tanggal_mulai'];
        }
        if (! empty($this->tp['tanggal_selesai']) && $t > $this->tp['tanggal_selesai']) {
            $t = $this->tp['tanggal_selesai'];
        }
        return $t;
    }

    /** NULL bila perubahan berlaku sejak awal TP (tidak perlu versi). */
    private function nilaiMulai(string $tgl): ?string
    {
        return (empty($this->tp['tanggal_mulai']) || $tgl <= $this->tp['tanggal_mulai']) ? null : $tgl;
    }

    /** Data slot jam per hari untuk tampilan grid: [hari => [jam_ke => slot]] + istirahat. */
    public static function dataJam(array $hariList): array
    {
        $m      = model(JamPelajaranModel::class);
        $perHari = [];
        $khusus  = [];
        foreach (array_keys($hariList) as $h) {
            foreach ($m->kbmHari($h) as $j) {
                $perHari[$h][(int) $j['jam_ke']] = $j;
            }
            $khusus[$h] = (bool) $m->khusus($h);
        }
        return ['perHari' => $perHari, 'khusus' => $khusus, 'maxJam' => $m->maxJamKe($hariList), 'bawaan' => $m->bawaan()];
    }

    /** Akhiri (versi) atau hapus satu baris jadwal mulai tanggal $tgl. */
    private function akhiri(array $row, string $tgl): string
    {
        $adaJurnal = db_connect()->table('jurnal_pembelajaran')->where('jadwal_pelajaran_id', $row['id'])->where('tanggal <', $tgl)->countAllResults() > 0;
        if (! $adaJurnal || ($row['berlaku_mulai'] && $row['berlaku_mulai'] >= $tgl)) {
            $this->model->delete($row['id']);
            return 'hapus';
        }
        $this->model->update($row['id'], ['berlaku_sampai' => date('Y-m-d', strtotime($tgl . ' -1 day'))]);
        return 'akhiri';
    }

    /** Setting jadwal per kelas (grid hari x jam). */
    public function index()
    {
        if ($r = $this->wajibTp()) {
            return $r;
        }
        $kelasList = model(KelasModel::class)->listAktif();
        $kelasId   = (int) ($this->request->getGet('kelas_id') ?: ($kelasList[0]['id'] ?? 0));
        $berlaku   = $this->tanggalBerlaku();
        $versi     = $kelasId ? db_connect()->table('jadwal_pelajaran')->select('berlaku_mulai, berlaku_sampai')->distinct()
            ->where(['tahun_pelajaran_id' => $this->tpId(), 'kelas_id' => $kelasId])
            ->groupStart()->where('berlaku_mulai IS NOT NULL')->orWhere('berlaku_sampai IS NOT NULL')->groupEnd()->get()->getResultArray() : [];
        $tglVersi = [];
        foreach ($versi as $v) {
            if ($v['berlaku_mulai']) {
                $tglVersi[] = $v['berlaku_mulai'];
            }
            if ($v['berlaku_sampai']) {
                $tglVersi[] = date('Y-m-d', strtotime($v['berlaku_sampai'] . ' +1 day'));
            }
        }
        $tglVersi = array_values(array_unique($tglVersi));
        sort($tglVersi);

        return view('akademik/jadwal/index', self::dataJam(hari_list()) + [
            'title'     => 'Setting Jadwal Pelajaran',
            'subtitle'  => 'Klik slot kosong untuk mengisi. Perubahan di tengah semester disimpan sebagai versi baru sehingga jurnal lama tidak berubah.',
            'kelasList' => $kelasList,
            'kelasId'   => $kelasId,
            'berlaku'   => $berlaku,
            'tglVersi'  => $tglVersi,
            'grid'      => $kelasId ? $this->model->grid($this->tpId(), ['kelas_id' => $kelasId, 'tanggal' => $berlaku]) : [],
            'penugasan' => $kelasId ? model(PenugasanGuruModel::class)->daftar($this->tpId(), ['kelas_id' => $kelasId]) : [],
        ]);
    }

    public function store()
    {
        if ($r = $this->wajibTp()) {
            return $r;
        }
        $tp        = $this->tpId();
        $kelasId   = (int) $this->request->getPost('kelas_id');
        $hari      = (int) $this->request->getPost('hari');
        $jamId     = (int) $this->request->getPost('jam_pelajaran_id');
        $jumlah    = max(1, min(4, (int) $this->request->getPost('jumlah_slot')));
        $berlaku   = $this->tanggalBerlaku();
        $penugasan = model(PenugasanGuruModel::class)->find((int) $this->request->getPost('penugasan_guru_id'));

        if (! $penugasan || (int) $penugasan['kelas_id'] !== $kelasId || (int) $penugasan['tahun_pelajaran_id'] !== $tp) {
            return redirect()->back()->with('error', 'Penugasan tidak valid untuk kelas ini.');
        }

        // slot berurutan mulai dari jam terpilih (menurut slot hari itu)
        $kbm   = model(JamPelajaranModel::class)->kbmHari($hari);
        $mulai = array_search($jamId, array_map('intval', array_column($kbm, 'id')), true);
        if ($mulai === false) {
            return redirect()->back()->with('error', 'Slot jam tidak valid untuk hari tersebut.');
        }
        $slots = array_slice($kbm, $mulai, $jumlah);

        $ok = 0;
        $gagal = [];
        foreach ($slots as $s) {
            if ($this->model->bentrokKelas($tp, $kelasId, $hari, (int) $s['id'], $berlaku)) {
                $gagal[] = "jam ke-{$s['jam_ke']}: kelas sudah terisi";
                continue;
            }
            if ($b = $this->model->bentrokGuru($tp, (int) $penugasan['guru_id'], $hari, (int) $s['id'], $berlaku)) {
                $gagal[] = "jam ke-{$s['jam_ke']}: guru sedang mengajar di {$b['nama_kelas']}";
                continue;
            }
            $this->model->insert(['tahun_pelajaran_id' => $tp, 'penugasan_guru_id' => $penugasan['id'], 'kelas_id' => $kelasId, 'hari' => $hari,
                'jam_pelajaran_id' => $s['id'], 'berlaku_mulai' => $this->nilaiMulai($berlaku)]);
            $ok++;
        }

        $redir = redirect()->to('/akademik/jadwal?kelas_id=' . $kelasId . '&berlaku=' . $berlaku);
        if ($gagal) {
            return $redir->with($ok ? 'warning' : 'error', "$ok slot tersimpan. Bentrok → " . implode('; ', $gagal));
        }
        return $redir->with('success', "$ok slot jadwal tersimpan" . ($this->nilaiMulai($berlaku) ? ', berlaku mulai ' . tgl_indo($berlaku) : '') . '.');
    }

    public function update($id)
    {
        $row = $this->model->find($id);
        if (! $row) {
            return redirect()->back()->with('error', 'Jadwal tidak ditemukan.');
        }
        $berlaku   = $this->tanggalBerlaku();
        $penugasan = model(PenugasanGuruModel::class)->find((int) $this->request->getPost('penugasan_guru_id'));
        if (! $penugasan || (int) $penugasan['kelas_id'] !== (int) $row['kelas_id']) {
            return redirect()->back()->with('error', 'Penugasan tidak valid.');
        }
        if ((int) $penugasan['id'] === (int) $row['penugasan_guru_id']) {
            return redirect()->to('/akademik/jadwal?kelas_id=' . $row['kelas_id'] . '&berlaku=' . $berlaku)->with('info', 'Tidak ada perubahan.');
        }
        if ($b = $this->model->bentrokGuru((int) $row['tahun_pelajaran_id'], (int) $penugasan['guru_id'], (int) $row['hari'], (int) $row['jam_pelajaran_id'], $berlaku, (int) $id)) {
            return redirect()->back()->with('error', "Bentrok: guru sedang mengajar di {$b['nama_kelas']} pada slot tersebut.");
        }
        $cara = $this->akhiri($row, $berlaku);
        $this->model->insert(['tahun_pelajaran_id' => $row['tahun_pelajaran_id'], 'penugasan_guru_id' => $penugasan['id'], 'kelas_id' => $row['kelas_id'],
            'hari' => $row['hari'], 'jam_pelajaran_id' => $row['jam_pelajaran_id'],
            'berlaku_mulai' => $cara === 'akhiri' ? $berlaku : $row['berlaku_mulai'], 'berlaku_sampai' => $row['berlaku_sampai']]);
        catat_log('ubah', 'jadwal_pelajaran', (int) $id, $cara === 'akhiri' ? 'versi baru mulai ' . $berlaku : null);
        return redirect()->to('/akademik/jadwal?kelas_id=' . $row['kelas_id'] . '&berlaku=' . $berlaku)
            ->with('success', 'Jadwal diperbarui' . ($cara === 'akhiri' ? ' mulai ' . tgl_indo($berlaku) . ' (jurnal sebelumnya tetap memakai jadwal lama)' : '') . '.');
    }

    public function delete($id)
    {
        $row = $this->model->find($id);
        if (! $row) {
            return redirect()->back()->with('error', 'Jadwal tidak ditemukan.');
        }
        $berlaku = $this->tanggalBerlaku();
        $cara    = $this->akhiri($row, $berlaku);
        catat_log('hapus', 'jadwal_pelajaran', (int) $id, $cara === 'akhiri' ? 'diakhiri sebelum ' . $berlaku : null);
        return redirect()->to('/akademik/jadwal?kelas_id=' . $row['kelas_id'] . '&berlaku=' . $berlaku)
            ->with('success', $cara === 'akhiri' ? 'Slot jadwal tidak berlaku lagi mulai ' . tgl_indo($berlaku) . ' (riwayat jurnal tetap).' : 'Slot jadwal dihapus.');
    }

    public function kosongkan()
    {
        $kelasId = (int) $this->request->getPost('kelas_id');
        $berlaku = $this->tanggalBerlaku();
        $n       = ['hapus' => 0, 'akhiri' => 0];
        foreach ($this->model->daftar($this->tpId(), ['kelas_id' => $kelasId, 'tanggal' => $berlaku]) as $r) {
            $n[$this->akhiri($this->model->find($r['id']), $berlaku)]++;
        }
        // jadwal versi mendatang (mulai setelah tanggal acuan) ikut dihapus
        $this->model->where(['tahun_pelajaran_id' => $this->tpId(), 'kelas_id' => $kelasId])->where('berlaku_mulai >', $berlaku)->delete();
        catat_log('hapus', 'jadwal_pelajaran', $kelasId, 'kosongkan kelas mulai ' . $berlaku);
        return redirect()->to('/akademik/jadwal?kelas_id=' . $kelasId . '&berlaku=' . $berlaku)
            ->with('success', "Jadwal kelas dikosongkan mulai " . tgl_indo($berlaku) . " ({$n['hapus']} dihapus, {$n['akhiri']} diakhiri karena sudah ada jurnal).");
    }

    /** Lihat jadwal (semua pengguna): per kelas atau per guru. */
    public function lihat()
    {
        if ($r = $this->wajibTp()) {
            return $r;
        }
        $mode = $this->request->getGet('mode');
        $id   = (int) $this->request->getGet('id');
        if (! $mode) {
            if ($this->guruId()) {
                [$mode, $id] = ['guru', $this->guruId()];
            } else {
                $mode = 'kelas';
            }
        }
        $kelasList = model(KelasModel::class)->listAktif();
        $guruList  = model(GuruModel::class)->listAktif();
        if (! $id) {
            $id = $mode === 'guru' ? (int) ($guruList[0]['id'] ?? 0) : (int) (wali_kelas_ids()[0] ?? ($kelasList[0]['id'] ?? 0));
        }
        $filter = $mode === 'guru' ? ['guru_id' => $id] : ['kelas_id' => $id];

        $judul = '';
        foreach ($mode === 'guru' ? $guruList : $kelasList as $x) {
            if ((int) $x['id'] === $id) {
                $judul = $mode === 'guru' ? nama_guru($x) : $x['nama_kelas'];
            }
        }

        return view('akademik/jadwal/lihat', [
            'title'     => 'Jadwal Pelajaran',
            'subtitle'  => $judul ? ($mode === 'guru' ? 'Guru: ' : 'Kelas: ') . $judul : '',
            'mode'      => $mode,
            'id'        => $id,
            'kelasList' => $kelasList,
            'guruList'  => $guruList,
            'grid'      => $id ? $this->model->grid($this->tpId(), $filter + ['tanggal' => $this->tanggalBerlaku()]) : [],
            'berlaku'   => $this->tanggalBerlaku(),
        ] + self::dataJam(hari_list()));
    }
}
