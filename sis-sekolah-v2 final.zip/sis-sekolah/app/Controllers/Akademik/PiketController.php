<?php

namespace App\Controllers\Akademik;

use App\Controllers\BaseController;
use App\Models\GuruModel;
use App\Models\GuruPiketModel;
use App\Models\UserModel;

class PiketController extends BaseController
{
    public function index()
    {
        if ($r = $this->wajibTp()) {
            return $r;
        }
        return view('akademik/piket/index', [
            'title'    => 'Jadwal Guru Piket',
            'subtitle' => 'Guru piket otomatis mendapat role "piket" (akses absensi pagi & monitoring jurnal).',
            'perHari'  => model(GuruPiketModel::class)->perHari($this->tpId()),
            'guru'     => model(GuruModel::class)->listAktif(),
        ]);
    }

    public function store()
    {
        if ($r = $this->wajibTp()) {
            return $r;
        }
        $model = model(GuruPiketModel::class);
        $hari  = (int) $this->request->getPost('hari');
        foreach ((array) $this->request->getPost('guru_ids') as $gid) {
            $gid = (int) $gid;
            if (! $model->where(['tahun_pelajaran_id' => $this->tpId(), 'guru_id' => $gid, 'hari' => $hari])->first()) {
                $model->insert(['tahun_pelajaran_id' => $this->tpId(), 'guru_id' => $gid, 'hari' => $hari]);
            }
            $guru = model(GuruModel::class)->find($gid);
            if ($guru && $guru['user_id']) {
                model(UserModel::class)->addRole((int) $guru['user_id'], 'piket');
            }
        }
        return redirect()->to('/akademik/piket')->with('success', 'Guru piket disimpan.');
    }

    public function delete($id)
    {
        $model = model(GuruPiketModel::class);
        $row   = $model->find($id);
        catat_log('hapus', 'guru_piket', (int) $id);
        $model->delete($id);
        // cabut role piket bila guru tidak lagi punya jadwal piket di TP ini
        if ($row && ! $model->where(['tahun_pelajaran_id' => $row['tahun_pelajaran_id'], 'guru_id' => $row['guru_id']])->countAllResults()) {
            $guru = model(GuruModel::class)->find($row['guru_id']);
            if ($guru && $guru['user_id']) {
                $roleId = db_connect()->table('roles')->where('nama_role', 'piket')->get()->getRow('id');
                db_connect()->table('user_roles')->where(['user_id' => $guru['user_id'], 'role_id' => $roleId])->delete();
            }
        }
        return redirect()->to('/akademik/piket')->with('success', 'Guru piket dihapus.');
    }
}
