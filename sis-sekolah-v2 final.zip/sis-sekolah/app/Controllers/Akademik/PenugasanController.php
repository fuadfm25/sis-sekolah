<?php

namespace App\Controllers\Akademik;

use App\Controllers\BaseController;
use App\Models\GuruModel;
use App\Models\KelasModel;
use App\Models\MapelModel;
use App\Models\PenugasanGuruModel;

class PenugasanController extends BaseController
{
    private PenugasanGuruModel $model;

    public function __construct()
    {
        $this->model = new PenugasanGuruModel();
    }

    public function index()
    {
        if ($r = $this->wajibTp()) {
            return $r;
        }
        $f = ['kelas_id' => $this->request->getGet('kelas_id'), 'guru_id' => $this->request->getGet('guru_id')];
        return view('akademik/penugasan/index', [
            'title'    => 'Penugasan Guru Mengajar',
            'subtitle' => 'Guru – mata pelajaran – kelas pada TP aktif. Penugasan menjadi dasar penyusunan jadwal.',
            'rows'     => $this->model->daftar($this->tpId(), $f),
            'kelas'    => model(KelasModel::class)->listAktif(),
            'guru'     => model(GuruModel::class)->listAktif(),
            'mapel'    => model(MapelModel::class)->listAktif(),
            'f'        => $f,
        ]);
    }

    public function store()
    {
        if ($r = $this->wajibTp()) {
            return $r;
        }
        if (! $this->validate(['guru_id' => 'required|is_natural_no_zero', 'mapel_id' => 'required|is_natural_no_zero', 'kelas_ids' => 'required'])) {
            return redirect()->back()->withInput()->with('error', 'Guru, mapel, dan minimal satu kelas wajib dipilih.');
        }
        $guru = (int) $this->request->getPost('guru_id');
        $mapel = (int) $this->request->getPost('mapel_id');
        $jp = max(1, (int) $this->request->getPost('jp_per_minggu'));
        $baru = $ganda = 0;
        foreach ((array) $this->request->getPost('kelas_ids') as $kelasId) {
            $ada = $this->model->where(['tahun_pelajaran_id' => $this->tpId(), 'mapel_id' => $mapel, 'kelas_id' => (int) $kelasId])->first();
            if ($ada) {
                $ganda++;
                continue;
            }
            $this->model->insert(['tahun_pelajaran_id' => $this->tpId(), 'guru_id' => $guru, 'mapel_id' => $mapel, 'kelas_id' => (int) $kelasId, 'jp_per_minggu' => $jp]);
            $baru++;
        }
        $msg = "$baru penugasan ditambahkan.";
        if ($ganda) {
            $msg .= " $ganda dilewati karena mapel tersebut sudah memiliki guru di kelas itu (edit untuk mengganti guru).";
        }
        return redirect()->back()->with($ganda ? 'warning' : 'success', $msg);
    }

    public function update($id)
    {
        $row = $this->model->find($id);
        if (! $row) {
            return redirect()->back()->with('error', 'Data tidak ditemukan.');
        }
        $guruBaru = (int) $this->request->getPost('guru_id');
        // cek bentrok jadwal bila guru diganti
        if ($guruBaru && $guruBaru !== (int) $row['guru_id']) {
            $jadwal = model(\App\Models\JadwalModel::class);
            foreach ($jadwal->where('penugasan_guru_id', $id)->findAll() as $j) {
                if ($b = $jadwal->bentrokGuru((int) $row['tahun_pelajaran_id'], $guruBaru, (int) $j['hari'], (int) $j['jam_pelajaran_id'])) {
                    return redirect()->back()->with('error', 'Guru pengganti bentrok jadwal: ' . nama_hari($b['hari']) . ' jam ke-' . $b['jam_ke'] . ' di ' . $b['nama_kelas'] . '.');
                }
            }
        }
        $this->model->update($id, ['guru_id' => $guruBaru ?: $row['guru_id'], 'jp_per_minggu' => max(1, (int) $this->request->getPost('jp_per_minggu'))]);
        return redirect()->back()->with('success', 'Penugasan diperbarui.');
    }

    public function delete($id)
    {
        if ($pesan = $this->masihDipakai(['jurnal' => ['jurnal_pembelajaran', ['penugasan_guru_id' => (int) $id]]], 'Untuk mengganti guru, gunakan tombol edit.')) {
            return redirect()->back()->with('error', $pesan);
        }
        $this->model->delete($id);
        catat_log('hapus', 'penugasan_guru', (int) $id);
        return redirect()->back()->with('success', 'Penugasan dan slot jadwalnya dihapus.');
    }
}
