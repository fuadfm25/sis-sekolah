<?php

namespace App\Controllers\Akademik;

use App\Controllers\BaseController;
use App\Libraries\Akses;
use App\Libraries\Kalender;
use App\Models\GuruModel;
use App\Models\IzinGuruModel;
use App\Models\PresensiGuruModel;

/** Kehadiran harian guru: diisi guru piket/kurikulum, atau otomatis lewat kiosk (kartu RFID guru) dan izin yang disetujui. */
class KehadiranGuruController extends BaseController
{
    private PresensiGuruModel $model;

    public function __construct()
    {
        $this->model = new PresensiGuruModel();
    }

    private function tanggal(): string
    {
        $t = (string) ($this->request->getGet('tanggal') ?: $this->request->getPost('tanggal') ?: date('Y-m-d'));
        return preg_match('/^\d{4}-\d{2}-\d{2}$/', $t) && $t <= date('Y-m-d') ? $t : date('Y-m-d');
    }

    public function index()
    {
        if ($r = $this->wajibTp()) {
            return $r;
        }
        $tanggal = $this->tanggal();
        if (! Akses::kehadiranGuruLihat() && ! Akses::kehadiranGuruInput($tanggal)) {
            return redirect()->to('/dashboard')->with('error', 'Akses ditolak.');
        }
        return view('akademik/kehadiran_guru/index', [
            'title'     => 'Kehadiran Guru',
            'subtitle'  => tgl_indo($tanggal, true),
            'tanggal'   => $tanggal,
            'status'    => Kalender::status($tanggal),
            'guru'      => model(GuruModel::class)->listAktif(),
            'data'      => $this->model->petaTanggal($tanggal),
            'izin'      => model(IzinGuruModel::class)->berlaku($tanggal),
            'bisaInput' => Akses::kehadiranGuruInput($tanggal) && Kalender::status($tanggal)['sekolah'],
        ]);
    }

    public function simpan()
    {
        if ($r = $this->wajibTp()) {
            return $r;
        }
        $tanggal = $this->tanggal();
        if (! Akses::kehadiranGuruInput($tanggal) || ! Kalender::status($tanggal)['sekolah']) {
            return $this->back('error', 'Anda tidak berhak mengisi kehadiran guru pada tanggal ini, atau bukan hari sekolah.');
        }
        $lama = $this->model->petaTanggal($tanggal);
        $n    = 0;
        foreach ((array) $this->request->getPost('hadir') as $gid => $h) {
            $st = (string) ($h['status'] ?? '');
            if (! isset(PresensiGuruModel::STATUS[$st])) {
                continue;
            }
            $old = $lama[$gid] ?? null;
            $this->model->simpanUnik(['tanggal' => $tanggal, 'guru_id' => (int) $gid], [
                'tahun_pelajaran_id' => $this->tpId(), 'status' => $st,
                'jam_datang' => in_array($st, ['H', 'T'], true) ? (($h['jam_datang'] ?? '') ?: ($old['jam_datang'] ?? null)) : null,
                'keterangan' => trim((string) ($h['keterangan'] ?? '')) ?: null,
                'izin_guru_id' => $old['izin_guru_id'] ?? null, 'sumber' => $old['sumber'] ?? 'Manual', 'dicatat_oleh' => $this->userId(),
            ]);
            $n++;
        }
        return redirect()->to('/guru-hadir?tanggal=' . $tanggal)->with('success', "Kehadiran {$n} guru tersimpan.");
    }
}
