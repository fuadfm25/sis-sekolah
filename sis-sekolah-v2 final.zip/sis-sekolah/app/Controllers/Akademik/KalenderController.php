<?php

namespace App\Controllers\Akademik;

use App\Controllers\BaseController;
use App\Libraries\Akses;
use App\Libraries\Kalender;
use App\Models\KalenderModel;

/**
 * Kalender akademik: libur nasional/semester/fakultatif, ujian, kegiatan sekolah.
 * Kelola: kurikulum (dan admin). Lihat: semua pengguna.
 */
class KalenderController extends BaseController
{
    private KalenderModel $model;

    public function __construct()
    {
        $this->model = new KalenderModel();
    }

    /** Data bersama tampilan bulan. */
    private function dataBulan(): array
    {
        $ym = (string) $this->request->getGet('bulan');
        if (! preg_match('/^\d{4}-\d{2}$/', $ym)) {
            $ym = date('Y-m');
        }
        $awal  = $ym . '-01';
        $akhir = date('Y-m-t', strtotime($awal));
        $hari  = [];
        foreach (Kalender::tanggal($awal, $akhir) as $d) {
            $hari[$d] = Kalender::status($d);
        }
        $ringkas = Kalender::pekanEfektif($awal, $akhir)['total'];

        return [
            'ym'        => $ym,
            'awal'      => $awal,
            'hari'      => $hari,
            'ringkas'   => $ringkas,
            'sebelum'   => date('Y-m', strtotime($awal . ' -1 month')),
            'sesudah'   => date('Y-m', strtotime($awal . ' +1 month')),
            'agendaBln' => $this->model->rentang($awal, $akhir),
            'kelasList' => $kelas = model(\App\Models\KelasModel::class)->listAktif(),
            'namaKelas' => array_column($kelas, 'nama_kelas', 'id'),
        ];
    }

    /** Pengaturan kalender (kurikulum). */
    public function index()
    {
        if ($r = $this->wajibTp()) {
            return $r;
        }
        return view('akademik/kalender/index', $this->dataBulan() + [
            'title'    => 'Setting Kalender Akademik',
            'subtitle' => 'Libur, ujian, dan kegiatan sekolah otomatis berlaku pada jurnal, absensi, kiosk, monitoring, dan laporan.',
            'kelola'   => true,
            'semua'    => $this->model->where('tahun_pelajaran_id', $this->tpId())->orderBy('tanggal_mulai')->findAll(),
        ]);
    }

    /** Lihat kalender (semua pengguna). */
    public function lihat()
    {
        if ($r = $this->wajibTp()) {
            return $r;
        }
        return view('akademik/kalender/index', $this->dataBulan() + [
            'title'    => 'Kalender Akademik',
            'subtitle' => 'TP ' . $this->tp['tahun_pelajaran'] . ' ' . $this->tp['semester'] . (empty($this->tp['tanggal_mulai']) ? '' : ' (' . tgl_indo($this->tp['tanggal_mulai']) . ' – ' . tgl_indo($this->tp['tanggal_selesai']) . ')'),
            'kelola'   => false,
            'semua'    => $this->model->where('tahun_pelajaran_id', $this->tpId())->orderBy('tanggal_mulai')->findAll(),
        ]);
    }

    private function input(): array
    {
        $jenis = (string) $this->request->getPost('jenis');
        return [
            'tahun_pelajaran_id' => $this->tpId(),
            'tanggal_mulai'      => (string) $this->request->getPost('tanggal_mulai'),
            'tanggal_selesai'    => (string) ($this->request->getPost('tanggal_selesai') ?: $this->request->getPost('tanggal_mulai')),
            'jenis'              => $jenis,
            'nama'               => trim((string) $this->request->getPost('nama')),
            'keterangan'         => trim((string) $this->request->getPost('keterangan')) ?: null,
            'ada_kbm'            => $this->request->getPost('ada_kbm') ? 1 : 0,
            'ada_absensi'        => $this->request->getPost('ada_absensi') ? 1 : 0,
            'kelas_ids'          => implode(',', array_filter(array_map('intval', (array) $this->request->getPost('kelas_ids')))) ?: null,
            'hari_jadwal'        => $jenis === 'Masuk Pengganti' ? ((int) $this->request->getPost('hari_jadwal') ?: null) : null,
        ];
    }

    private function simpan(?int $id)
    {
        if ($r = $this->wajibTp()) {
            return $r;
        }
        $data  = $this->input();
        $rules = [
            'tanggal_mulai'   => 'required|valid_date[Y-m-d]',
            'tanggal_selesai' => 'required|valid_date[Y-m-d]',
            'jenis'           => 'required|in_list[' . implode(',', KalenderModel::JENIS) . ']',
            'nama'            => 'required|max_length[150]',
        ];
        if (! $this->validateData($data, $rules)) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }
        if ($data['tanggal_selesai'] < $data['tanggal_mulai']) {
            return $this->back('error', 'Tanggal selesai tidak boleh sebelum tanggal mulai.');
        }
        if ($data['jenis'] === 'Masuk Pengganti') {
            if (! $data['hari_jadwal']) {
                return $this->back('error', 'Pilih jadwal hari apa yang dipakai pada hari masuk pengganti.');
            }
            $data['ada_kbm'] = $data['ada_absensi'] = 1;
        }
        if ((int) $data['ada_absensi'] === 0 && (int) $data['ada_kbm'] === 1) {
            return $this->back('error', 'Tidak logis: ada KBM tetapi tanpa absensi. Centang absensi bila KBM tetap berjalan.');
        }
        $id ? $this->model->update($id, $data) : $this->model->insert($data);

        // informasikan data yang sudah terlanjur tercatat pada rentang tsb (tidak dihapus)
        $db  = db_connect();
        $pesan = 'Agenda kalender disimpan.';
        if (! $data['ada_kbm']) {
            $n = $db->table('jurnal_pembelajaran')->where('tanggal >=', $data['tanggal_mulai'])->where('tanggal <=', $data['tanggal_selesai'])->countAllResults();
            if ($n) {
                $pesan .= " Catatan: sudah ada {$n} jurnal pada rentang ini (tetap tersimpan).";
            }
        }
        if (! $data['ada_absensi']) {
            $n = $db->table('presensi_harian')->where('tanggal >=', $data['tanggal_mulai'])->where('tanggal <=', $data['tanggal_selesai'])->countAllResults();
            if ($n) {
                $pesan .= " Sudah ada {$n} data absensi harian pada rentang ini (tetap tersimpan).";
            }
        }
        return redirect()->to('/akademik/kalender?bulan=' . substr($data['tanggal_mulai'], 0, 7))->with(str_contains($pesan, 'Catatan') || str_contains($pesan, 'Sudah ada') ? 'warning' : 'success', $pesan);
    }

    public function store()
    {
        return $this->simpan(null);
    }

    public function update($id)
    {
        return $this->simpan((int) $id);
    }

    public function delete($id)
    {
        $row = $this->model->find($id);
        catat_log('hapus', 'kalender_akademik', (int) $id);
        $this->model->delete($id);
        return redirect()->to('/akademik/kalender?bulan=' . substr($row['tanggal_mulai'] ?? date('Y-m'), 0, 7))->with('success', 'Agenda dihapus.');
    }
}
