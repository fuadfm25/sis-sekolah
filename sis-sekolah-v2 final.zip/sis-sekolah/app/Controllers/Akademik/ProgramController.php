<?php

namespace App\Controllers\Akademik;

use App\Controllers\BaseController;
use App\Libraries\Akses;
use App\Libraries\Perencanaan;
use App\Models\PerangkatModel;

/**
 * Program Semester (Promes) & Program Tahunan (Prota) yang disusun dari kalender akademik:
 * guru mengisi butir TP/materi beserta JP, lalu menyebarkannya ke pekan efektif (otomatis atau manual).
 */
class ProgramController extends BaseController
{
    private function db()
    {
        return db_connect();
    }

    /** Konteks guru–mapel–tingkat dari query string; kurikulum/kepsek boleh melihat milik guru lain. */
    private function pilihan(bool $boleLain = false): ?array
    {
        $guruId = Akses::guruId();
        if ($boleLain && Akses::perangkatLihatSemua() && $this->request->getGet('guru_id')) {
            $guruId = (int) $this->request->getGet('guru_id');
        }
        $tpId = $this->tpId();
        if ($boleLain && Akses::perangkatLihatSemua() && $this->request->getGet('tp')) {
            $tpId = (int) $this->request->getGet('tp');
        }
        $mapelId = (int) ($this->request->getGet('mapel_id') ?? $this->request->getPost('mapel_id'));
        $tingkat = (string) ($this->request->getGet('tingkat') ?? $this->request->getPost('tingkat'));
        if (! $guruId || ! $mapelId || $tingkat === '') {
            return null;
        }
        $ktx = Perencanaan::konteks($tpId, $guruId, $mapelId, $tingkat);
        if (! $ktx) {
            return null;
        }
        $mapel = $this->db()->table('mata_pelajaran')->where('id', $mapelId)->get()->getRowArray();
        $tp    = $this->db()->table('tahun_pelajaran')->where('id', $tpId)->get()->getRowArray();
        return $ktx + ['tp_id' => $tpId, 'tp' => $tp, 'guru_id' => $guruId, 'mapel_id' => $mapelId, 'tingkat' => $tingkat, 'mapel' => $mapel,
            'guru' => model(\App\Models\GuruModel::class)->find($guruId)];
    }

    private function items(array $p): array
    {
        return $this->db()->table('promes_item')->where(['tahun_pelajaran_id' => $p['tp_id'], 'guru_id' => $p['guru_id'], 'mapel_id' => $p['mapel_id'], 'tingkat' => $p['tingkat']])
            ->orderBy('urutan')->orderBy('id')->get()->getResultArray();
    }

    private function alokasi(array $items): array
    {
        if (! $items) {
            return [];
        }
        $out = [];
        foreach ($this->db()->table('promes_alokasi')->whereIn('item_id', array_column($items, 'id'))->get()->getResultArray() as $a) {
            $out[$a['item_id']][$a['pekan']] = (int) $a['jp'];
        }
        return $out;
    }

    private function balik(array $p, string $tipe, string $pesan)
    {
        return redirect()->to('/program?mapel_id=' . $p['mapel_id'] . '&tingkat=' . urlencode($p['tingkat']))->with($tipe, $pesan);
    }

    public function index()
    {
        if ($r = $this->wajibTp()) {
            return $r;
        }
        if (! Akses::guruId()) {
            return redirect()->to('/dashboard')->with('error', 'Program semester disusun oleh akun guru.');
        }
        $target = model(PerangkatModel::class)->target($this->tpId(), Akses::guruId());
        $p      = $this->pilihan();
        if (! $p && count($target) >= 1 && ! $this->request->getGet('mapel_id')) {
            foreach (['success', 'error', 'warning', 'info'] as $fk) { session()->keepFlashdata($fk); }
            return redirect()->to('/program?mapel_id=' . $target[0]['mapel_id'] . '&tingkat=' . urlencode($target[0]['tingkat']));
        }
        $data = ['title' => 'Program Semester & Tahunan', 'subtitle' => 'Disusun dari kalender akademik: isi butir materi/TP dan JP, sebarkan ke pekan efektif, lalu cetak Promes & Prota.',
            'target' => $target, 'p' => $p];
        if ($p) {
            $items = $this->items($p);
            $data += [
                'pekan'    => Perencanaan::pekan($p['tp'], $p),
                'items'    => $items,
                'alokasi'  => $this->alokasi($items),
                'atpBaru'  => $this->atpBelum($p, $items),
                'perlu'    => empty($p['tp']['tanggal_mulai']) || empty($p['tp']['tanggal_selesai']),
            ];
        }
        return view('akademik/program/index', $data);
    }

    private function atpBelum(array $p, array $items): array
    {
        $sudah = array_filter(array_map('intval', array_column($items, 'atp_id')));
        $b = $this->db()->table('atp')->where(['mapel_id' => $p['mapel_id'], 'tingkat' => $p['tingkat']])
            ->groupStart()->where('semester', null)->orWhere('semester', '')->orWhere('semester', $p['tp']['semester'])->groupEnd()
            ->orderBy('urutan')->orderBy('id');
        if ($sudah) {
            $b->whereNotIn('id', $sudah);
        }
        return $b->get()->getResultArray();
    }

    public function ambilAtp()
    {
        $p = $this->pilihan();
        if (! $p) {
            return redirect()->to('/program')->with('error', 'Pilih mapel & tingkat yang Anda ampu.');
        }
        $items = $this->items($p);
        $n     = count($items);
        foreach ($this->atpBelum($p, $items) as $a) {
            $this->db()->table('promes_item')->insert([
                'tahun_pelajaran_id' => $p['tp_id'], 'guru_id' => $p['guru_id'], 'mapel_id' => $p['mapel_id'], 'tingkat' => $p['tingkat'],
                'atp_id' => $a['id'], 'jenis' => 'Materi', 'materi' => mb_substr(($a['kode'] ? $a['kode'] . ' ' : '') . ($a['elemen'] ?: strtok($a['tujuan'], "\n")), 0, 255),
                'tujuan' => $a['tujuan'], 'jp' => (int) ($a['alokasi_jp'] ?: $p['jp_minggu'] * 2), 'urutan' => ++$n, 'created_at' => date('Y-m-d H:i:s'),
            ]);
        }
        return $this->balik($p, 'success', 'Butir dari ATP ditambahkan. Periksa JP lalu klik "Sebar otomatis".');
    }

    public function itemSimpan($id = null)
    {
        $p = $this->pilihan();
        if (! $p) {
            return redirect()->to('/program')->with('error', 'Pilih mapel & tingkat yang Anda ampu.');
        }
        $data = [
            'materi' => mb_substr(trim((string) $this->request->getPost('materi')), 0, 255),
            'tujuan' => trim((string) $this->request->getPost('tujuan')) ?: null,
            'jp'     => max(0, min(200, (int) $this->request->getPost('jp'))),
            'jenis'  => in_array($this->request->getPost('jenis'), ['Materi', 'Asesmen', 'Cadangan'], true) ? $this->request->getPost('jenis') : 'Materi',
            'updated_at' => date('Y-m-d H:i:s'),
        ];
        if ($data['materi'] === '') {
            return $this->balik($p, 'error', 'Materi / lingkup materi wajib diisi.');
        }
        $t = $this->db()->table('promes_item');
        if ($id) {
            $t->where(['id' => (int) $id, 'guru_id' => $p['guru_id'], 'tahun_pelajaran_id' => $p['tp_id']])->update($data);
        } else {
            $t->insert($data + ['tahun_pelajaran_id' => $p['tp_id'], 'guru_id' => $p['guru_id'], 'mapel_id' => $p['mapel_id'], 'tingkat' => $p['tingkat'],
                'urutan' => count($this->items($p)) + 1, 'created_at' => date('Y-m-d H:i:s')]);
        }
        return $this->balik($p, 'success', 'Butir disimpan.');
    }

    public function itemHapus($id)
    {
        $p = $this->pilihan();
        if ($p) {
            $this->db()->table('promes_item')->where(['id' => (int) $id, 'guru_id' => $p['guru_id'], 'tahun_pelajaran_id' => $p['tp_id']])->delete();
        }
        return $p ? $this->balik($p, 'success', 'Butir dihapus.') : redirect()->to('/program');
    }

    public function itemGeser($id, $arah)
    {
        $p = $this->pilihan();
        if (! $p) {
            return redirect()->to('/program');
        }
        $items = $this->items($p);
        $ids   = array_map('intval', array_column($items, 'id'));
        $i     = array_search((int) $id, $ids, true);
        $j     = $arah === 'naik' ? $i - 1 : $i + 1;
        if ($i !== false && isset($ids[$j])) {
            [$ids[$i], $ids[$j]] = [$ids[$j], $ids[$i]];
            foreach ($ids as $u => $iid) {
                $this->db()->table('promes_item')->where('id', $iid)->update(['urutan' => $u + 1]);
            }
        }
        return $this->balik($p, 'success', 'Urutan diperbarui. Klik "Sebar otomatis" bila ingin menyebar ulang.');
    }

    public function sebar()
    {
        $p = $this->pilihan();
        if (! $p) {
            return redirect()->to('/program');
        }
        $items = $this->items($p);
        $pekan = Perencanaan::pekan($p['tp'], $p);
        $hasil = Perencanaan::sebar($items, $pekan);
        $db    = $this->db();
        $db->transStart();
        if ($items) {
            $db->table('promes_alokasi')->whereIn('item_id', array_column($items, 'id'))->delete();
        }
        foreach ($hasil as $iid => $per) {
            foreach ($per as $senin => $jp) {
                $db->table('promes_alokasi')->insert(['item_id' => $iid, 'pekan' => $senin, 'jp' => $jp]);
            }
        }
        $db->transComplete();
        $butuh = array_sum(array_map('intval', array_column($items, 'jp')));
        $ada   = array_sum(array_column(array_filter($pekan, static fn ($w) => $w['efektif']), 'jp'));
        $pesan = "JP disebar ke pekan efektif ({$butuh} JP direncanakan, {$ada} JP tersedia).";
        if ($butuh > $ada) {
            $pesan .= ' ' . ($butuh - $ada) . ' JP tidak tertampung — kurangi JP butir atau gabungkan materi.';
        }
        return $this->balik($p, $butuh > $ada ? 'warning' : 'success', $pesan);
    }

    public function alokasiSimpan()
    {
        $p = $this->pilihan();
        if (! $p) {
            return redirect()->to('/program');
        }
        $valid = array_map('intval', array_column($this->items($p), 'id'));
        $pekan = Perencanaan::pekan($p['tp'], $p);
        $db    = $this->db();
        $db->transStart();
        foreach ((array) $this->request->getPost('alok') as $iid => $per) {
            if (! in_array((int) $iid, $valid, true)) {
                continue;
            }
            $db->table('promes_alokasi')->where('item_id', (int) $iid)->delete();
            $total = 0;
            foreach ((array) $per as $senin => $jp) {
                $jp = max(0, min(60, (int) $jp));
                if ($jp > 0 && isset($pekan[$senin])) {
                    $db->table('promes_alokasi')->insert(['item_id' => (int) $iid, 'pekan' => $senin, 'jp' => $jp]);
                    $total += $jp;
                }
            }
            $db->table('promes_item')->where('id', (int) $iid)->update(['jp' => $total, 'updated_at' => date('Y-m-d H:i:s')]);
        }
        $db->transComplete();
        return $this->balik($p, 'success', 'Sebaran JP disimpan; JP tiap butir mengikuti jumlah isian.');
    }

    public function ajukan($jenis)
    {
        $p = $this->pilihan();
        if (! $p || ! in_array($jenis, ['promes', 'prota'], true)) {
            return redirect()->to('/program');
        }
        if (! $this->items($p)) {
            return $this->balik($p, 'error', 'Program masih kosong.');
        }
        [$ok, $pesan] = model(PerangkatModel::class)->ajukanInternal($p['tp_id'], $p['guru_id'], $p['mapel_id'], $p['tingkat'],
            $jenis === 'promes' ? 'Program Semester' : 'Program Tahunan', $jenis, $this->userId());
        return $this->balik($p, $ok ? 'success' : 'error', $pesan);
    }

    // ------------------------------------------------------------------ CETAK
    private function ttd(array $p): array
    {
        $madrasah = in_array(setting('jenjang'), ['MI', 'MTs', 'MA', 'MAK'], true) || setting('jenis_nomor') === 'NSM';
        return [
            'kiri'  => ['atas' => 'Mengetahui,', 'jabatan' => $madrasah ? 'Kepala Madrasah' : 'Kepala Sekolah', 'nama' => setting('kepala_sekolah', ''), 'nip' => setting('nip_kepala_sekolah', '') ?: null],
            'kanan' => ['jabatan' => 'Guru Mata Pelajaran', 'nama' => nama_guru($p['guru']), 'nip' => $p['guru']['nip'] ?: null],
        ];
    }

    public function cetak($jenis)
    {
        $p = $this->pilihan(true);
        if (! $p || ! in_array($jenis, ['promes', 'prota'], true)) {
            return redirect()->to('/program')->with('error', 'Program tidak ditemukan.');
        }
        $info = ['Mata Pelajaran' => $p['mapel']['nama_mapel'], 'Fase / Kelas' => trim(($p['fase'] ? 'Fase ' . $p['fase'] . ' / ' : '') . 'Kelas ' . $p['tingkat'] . ' (' . implode(', ', $p['kelas']) . ')'),
            'Tahun Pelajaran' => $p['tp']['tahun_pelajaran'], 'Guru' => nama_guru($p['guru'])];
        if ($jenis === 'promes') {
            $items = $this->items($p);
            $tpAktif = (int) $p['tp_id'] === (int) $this->tpId();
            return view('akademik/program/cetak_promes', [
                'judul' => 'Program Semester', 'subjudul' => 'Semester ' . $p['tp']['semester'] . ' Tahun Pelajaran ' . $p['tp']['tahun_pelajaran'],
                'orientasi' => 'landscape', 'info' => $info + ['Semester' => $p['tp']['semester']], 'items' => $items, 'alokasi' => $this->alokasi($items),
                'pekan' => $tpAktif ? Perencanaan::pekan($p['tp'], $p) : $this->pekanDariAlokasi($this->alokasi($items)), 'ttd' => $this->ttd($p), 'word' => true,
            ]);
        }
        // prota: gabungan semester ganjil & genap pada tahun pelajaran yang sama
        $sem = [];
        foreach ($this->db()->table('tahun_pelajaran')->where('tahun_pelajaran', $p['tp']['tahun_pelajaran'])->orderBy('semester')->get()->getResultArray() as $tp) {
            $sem[$tp['semester']] = $this->db()->table('promes_item')->where(['tahun_pelajaran_id' => $tp['id'], 'guru_id' => $p['guru_id'], 'mapel_id' => $p['mapel_id'], 'tingkat' => $p['tingkat']])
                ->orderBy('urutan')->orderBy('id')->get()->getResultArray();
        }
        return view('akademik/program/cetak_prota', [
            'judul' => 'Program Tahunan', 'subjudul' => 'Tahun Pelajaran ' . $p['tp']['tahun_pelajaran'], 'orientasi' => 'portrait',
            'info' => $info, 'semester' => $sem, 'jpMinggu' => $p['jp_minggu'], 'ttd' => $this->ttd($p), 'word' => true,
        ]);
    }

    /** Untuk semester yang sudah tidak aktif: pekan diambil dari alokasi yang tersimpan. */
    private function pekanDariAlokasi(array $alok): array
    {
        $out = [];
        foreach ($alok as $per) {
            foreach ($per as $senin => $jp) {
                $out[$senin] = ['senin' => $senin, 'bulan' => substr($senin, 0, 7), 'efektif' => true, 'jp' => 0, 'ket' => '', 'minggu_ke' => 0];
            }
        }
        ksort($out);
        $pb = [];
        foreach ($out as &$w) {
            $w['minggu_ke'] = $pb[$w['bulan']] = ($pb[$w['bulan']] ?? 0) + 1;
        }
        return $out;
    }
}
