<?php

namespace App\Controllers\Akademik;

use App\Controllers\BaseController;
use App\Models\TahunPelajaranModel;

class TahunPelajaranController extends BaseController
{
    private TahunPelajaranModel $model;

    public function __construct()
    {
        $this->model = new TahunPelajaranModel();
    }

    public function index()
    {
        return view('akademik/tahun_pelajaran/index', [
            'title'    => 'Tahun Pelajaran',
            'subtitle' => 'Satu tahun pelajaran/semester aktif. Tanggal mulai & selesai menjadi batas kalender akademik, jurnal, dan absensi.',
            'rows'     => $this->model->orderBy('tahun_pelajaran', 'DESC')->orderBy('semester', 'DESC')->findAll(),
        ]);
    }

    private function input(): array
    {
        return [
            'tahun_pelajaran' => trim((string) $this->request->getPost('tahun_pelajaran')),
            'semester'        => $this->request->getPost('semester'),
            'tanggal_mulai'   => $this->request->getPost('tanggal_mulai') ?: null,
            'tanggal_selesai' => $this->request->getPost('tanggal_selesai') ?: null,
        ];
    }

    private function rules(?int $id = null): array
    {
        return [
            'tahun_pelajaran' => 'required|regex_match[/^\d{4}\/\d{4}$/]',
            'semester'        => 'required|in_list[Ganjil,Genap]',
            'tanggal_mulai'   => 'required|valid_date[Y-m-d]',
            'tanggal_selesai' => 'required|valid_date[Y-m-d]',
        ];
    }

    public function store()
    {
        if (! $this->validate($this->rules(), ['tahun_pelajaran' => ['regex_match' => 'Format tahun pelajaran: 2026/2027']])) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }
        $data = $this->input();
        if ($data['tanggal_selesai'] <= $data['tanggal_mulai']) {
            return $this->back('error', 'Tanggal selesai harus setelah tanggal mulai.');
        }
        if ($this->model->where(['tahun_pelajaran' => $data['tahun_pelajaran'], 'semester' => $data['semester']])->first()) {
            return $this->back('error', 'Tahun pelajaran & semester tersebut sudah ada.');
        }
        $data['is_active'] = 0;
        $id = $this->model->insert($data);
        if ($this->request->getPost('is_active') || ! $this->model->getAktif()) {
            $this->model->setAktif((int) $id);
        }
        return redirect()->to('/akademik/tahun-pelajaran')->with('success', 'Tahun pelajaran ditambahkan.');
    }

    public function update($id)
    {
        if (! $this->validate($this->rules((int) $id))) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }
        $data = $this->input();
        if ($data['tanggal_selesai'] <= $data['tanggal_mulai']) {
            return $this->back('error', 'Tanggal selesai harus setelah tanggal mulai.');
        }
        $this->model->update($id, $data);
        return redirect()->to('/akademik/tahun-pelajaran')->with('success', 'Tahun pelajaran diperbarui.');
    }

    public function aktifkan($id)
    {
        $this->model->setAktif((int) $id);
        return redirect()->to('/akademik/tahun-pelajaran')->with('success', 'Tahun pelajaran aktif diganti.');
    }

    public function delete($id)
    {
        $row = $this->model->find($id);
        if ($row && (int) $row['is_active']) {
            return redirect()->back()->with('error', 'Tahun pelajaran aktif tidak dapat dihapus.');
        }
        $w = ['tahun_pelajaran_id' => (int) $id];
        if ($pesan = $this->masihDipakai(['anggota rombel' => ['anggota_kelas', $w], 'penugasan' => ['penugasan_guru', $w], 'jurnal' => ['jurnal_pembelajaran', $w],
            'absensi harian' => ['presensi_harian', $w], 'catatan perilaku' => ['catatan_perilaku', $w], 'layanan BK' => ['bk_layanan', $w]],
            'Tahun pelajaran yang sudah berisi data harus disimpan sebagai arsip.')) {
            return redirect()->back()->with('error', $pesan);
        }
        $this->model->delete($id);
        catat_log('hapus', 'tahun_pelajaran', (int) $id, ($row['tahun_pelajaran'] ?? '') . ' ' . ($row['semester'] ?? ''));
        return redirect()->to('/akademik/tahun-pelajaran')->with('success', 'Tahun pelajaran dihapus.');
    }
}
