<?php

namespace App\Controllers\Akademik;

use App\Controllers\BaseController;
use App\Models\TahunPelajaranModel;

/**
 * Salin data pengaturan dari semester/TP lain ke TP aktif: penugasan, jadwal, wali kelas, guru piket, dan rombel.
 * Data yang sudah ada di TP tujuan tidak ditimpa (hanya menambah yang belum ada).
 */
class SalinSemesterController extends BaseController
{
    public function index()
    {
        if ($r = $this->wajibTp()) {
            return $r;
        }
        $db   = db_connect();
        $tpId = $this->tpId();
        $list = model(TahunPelajaranModel::class)->where('id !=', $tpId)->orderBy('tahun_pelajaran', 'DESC')->orderBy('semester', 'DESC')->findAll();
        $hit  = static fn (int $id) => [
            'penugasan' => $db->table('penugasan_guru')->where('tahun_pelajaran_id', $id)->countAllResults(),
            'jadwal'    => $db->table('jadwal_pelajaran')->where('tahun_pelajaran_id', $id)->where('berlaku_sampai', null)->countAllResults(),
            'wali'      => $db->table('wali_kelas')->where('tahun_pelajaran_id', $id)->countAllResults(),
            'piket'     => $db->table('guru_piket')->where('tahun_pelajaran_id', $id)->countAllResults(),
            'rombel'    => $db->table('anggota_kelas')->where('tahun_pelajaran_id', $id)->countAllResults(),
        ];
        foreach ($list as &$t) {
            $t['jumlah'] = $hit((int) $t['id']);
        }
        return view('akademik/salin_semester', [
            'title'    => 'Salin dari Semester Lain',
            'subtitle' => 'Mempercepat persiapan semester baru: penugasan guru, jadwal, wali kelas, guru piket, dan rombel.',
            'list'     => $list,
            'tujuan'   => $hit($tpId),
        ]);
    }

    public function proses()
    {
        if ($r = $this->wajibTp()) {
            return $r;
        }
        $dari  = (int) $this->request->getPost('dari');
        $ke    = $this->tpId();
        $item  = (array) $this->request->getPost('item');
        $src   = model(TahunPelajaranModel::class)->find($dari);
        if (! $src || $dari === $ke || ! $item) {
            return redirect()->back()->with('error', 'Pilih semester sumber dan minimal satu jenis data.');
        }
        if (in_array('jadwal', $item, true) && ! in_array('penugasan', $item, true)) {
            $item[] = 'penugasan';   // jadwal membutuhkan penugasan
        }
        $db  = db_connect();
        $now = date('Y-m-d H:i:s');
        $n   = [];
        $db->transStart();

        // --- penugasan (kunci: mapel, kelas — satu mapel di satu kelas hanya punya satu pengampu)
        $petaPenugasan = [];
        if (in_array('penugasan', $item, true)) {
            $n['penugasan'] = 0;
            $ada = [];
            foreach ($db->table('penugasan_guru')->where('tahun_pelajaran_id', $ke)->get()->getResultArray() as $p) {
                $ada[$p['mapel_id'] . '|' . $p['kelas_id']] = (int) $p['id'];
            }
            foreach ($db->table('penugasan_guru')->where('tahun_pelajaran_id', $dari)->get()->getResultArray() as $p) {
                $k = $p['mapel_id'] . '|' . $p['kelas_id'];
                if (! isset($ada[$k])) {
                    $db->table('penugasan_guru')->insert(['tahun_pelajaran_id' => $ke, 'guru_id' => $p['guru_id'], 'mapel_id' => $p['mapel_id'],
                        'kelas_id' => $p['kelas_id'], 'jp_per_minggu' => $p['jp_per_minggu'], 'created_at' => $now, 'updated_at' => $now]);
                    $ada[$k] = (int) $db->insertID();
                    $n['penugasan']++;
                }
                $petaPenugasan[(int) $p['id']] = $ada[$k];
            }
        }

        // --- jadwal (versi yang masih berlaku di akhir semester sumber)
        if (in_array('jadwal', $item, true)) {
            $n['jadwal'] = 0;
            $n['jadwal_lewat'] = 0;
            $terisi = [];
            foreach ($db->table('jadwal_pelajaran')->where('tahun_pelajaran_id', $ke)->where('berlaku_sampai', null)->get()->getResultArray() as $j) {
                $terisi[$j['kelas_id'] . '|' . $j['hari'] . '|' . $j['jam_pelajaran_id']] = true;
            }
            foreach ($db->table('jadwal_pelajaran')->where('tahun_pelajaran_id', $dari)->where('berlaku_sampai', null)->get()->getResultArray() as $j) {
                $k = $j['kelas_id'] . '|' . $j['hari'] . '|' . $j['jam_pelajaran_id'];
                if (isset($terisi[$k]) || ! isset($petaPenugasan[(int) $j['penugasan_guru_id']])) {
                    $n['jadwal_lewat']++;
                    continue;
                }
                $db->table('jadwal_pelajaran')->insert(['tahun_pelajaran_id' => $ke, 'penugasan_guru_id' => $petaPenugasan[(int) $j['penugasan_guru_id']],
                    'kelas_id' => $j['kelas_id'], 'hari' => $j['hari'], 'jam_pelajaran_id' => $j['jam_pelajaran_id'], 'created_at' => $now, 'updated_at' => $now]);
                $terisi[$k] = true;
                $n['jadwal']++;
            }
        }

        // --- wali kelas (kunci: kelas)
        if (in_array('wali', $item, true)) {
            $n['wali'] = 0;
            $ada = array_flip(array_column($db->table('wali_kelas')->where('tahun_pelajaran_id', $ke)->get()->getResultArray(), 'kelas_id'));
            foreach ($db->table('wali_kelas')->where('tahun_pelajaran_id', $dari)->get()->getResultArray() as $w) {
                if (! isset($ada[$w['kelas_id']])) {
                    $db->table('wali_kelas')->insert(['tahun_pelajaran_id' => $ke, 'kelas_id' => $w['kelas_id'], 'guru_id' => $w['guru_id'], 'created_at' => $now, 'updated_at' => $now]);
                    $n['wali']++;
                }
            }
        }

        // --- guru piket (kunci: guru, hari)
        if (in_array('piket', $item, true)) {
            $n['piket'] = 0;
            $ada = [];
            foreach ($db->table('guru_piket')->where('tahun_pelajaran_id', $ke)->get()->getResultArray() as $p) {
                $ada[$p['guru_id'] . '|' . $p['hari']] = true;
            }
            foreach ($db->table('guru_piket')->where('tahun_pelajaran_id', $dari)->get()->getResultArray() as $p) {
                if (! isset($ada[$p['guru_id'] . '|' . $p['hari']])) {
                    $db->table('guru_piket')->insert(['tahun_pelajaran_id' => $ke, 'guru_id' => $p['guru_id'], 'hari' => $p['hari'], 'created_at' => $now, 'updated_at' => $now]);
                    $n['piket']++;
                }
            }
        }

        // --- rombel (hanya siswa aktif; kunci: siswa)
        if (in_array('rombel', $item, true)) {
            $n['rombel'] = 0;
            $ada = array_flip(array_column($db->table('anggota_kelas')->where('tahun_pelajaran_id', $ke)->get()->getResultArray(), 'siswa_id'));
            $rows = $db->table('anggota_kelas')->select('anggota_kelas.*')->join('siswa', 'siswa.id = anggota_kelas.siswa_id')
                ->where('anggota_kelas.tahun_pelajaran_id', $dari)->where('siswa.status', 'Aktif')->get()->getResultArray();
            foreach ($rows as $a) {
                if (! isset($ada[$a['siswa_id']])) {
                    $db->table('anggota_kelas')->insert(['tahun_pelajaran_id' => $ke, 'kelas_id' => $a['kelas_id'], 'siswa_id' => $a['siswa_id'],
                        'no_absen' => $a['no_absen'], 'status' => $a['status'] ?? 'Aktif', 'created_at' => $now, 'updated_at' => $now]);
                    $n['rombel']++;
                }
            }
        }
        $db->transComplete();
        if (! $db->transStatus()) {
            return redirect()->back()->with('error', 'Penyalinan gagal; tidak ada data yang berubah.');
        }

        $label = ['penugasan' => 'penugasan', 'jadwal' => 'slot jadwal', 'wali' => 'wali kelas', 'piket' => 'guru piket', 'rombel' => 'anggota rombel'];
        $teks  = [];
        foreach ($label as $k => $l) {
            if (isset($n[$k])) {
                $teks[] = $n[$k] . ' ' . $l;
            }
        }
        catat_log('salin', 'tahun_pelajaran', $ke, 'dari TP #' . $dari . ': ' . implode(', ', $teks));
        return redirect()->to('/akademik/salin-semester')->with('success', 'Disalin dari ' . $src['tahun_pelajaran'] . ' ' . $src['semester'] . ': ' . implode(', ', $teks) . '.'
            . (! empty($n['jadwal_lewat']) ? " {$n['jadwal_lewat']} slot jadwal dilewati karena slot tujuan sudah terisi." : ''));
    }
}
