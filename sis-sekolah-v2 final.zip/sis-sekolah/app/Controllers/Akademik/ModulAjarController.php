<?php

namespace App\Controllers\Akademik;

use App\Controllers\BaseController;
use App\Libraries\Akses;
use App\Libraries\ModulAjar;
use App\Libraries\Perencanaan;
use App\Models\PerangkatModel;

/**
 * Penyusun modul ajar: dibuat dari butir program semester (topik, TP, JP otomatis), guru melengkapi
 * identifikasi, model/metode, alat & media, langkah per pertemuan, dan asesmen, lalu dicetak/diunduh Word.
 */
class ModulAjarController extends BaseController
{
    private function db()
    {
        return db_connect();
    }

    private function modul(int $id, bool $bolehLain = false): ?array
    {
        $m = $this->db()->table('modul_ajar')->where('id', $id)->get()->getRowArray();
        if (! $m || ! ((int) $m['guru_id'] === Akses::guruId() || ($bolehLain && Akses::perangkatLihatSemua()))) {
            return null;
        }
        $m['isi'] = array_replace(ModulAjar::kosong(), json_decode((string) $m['isi'], true) ?: []);
        return $m;
    }

    public function index()
    {
        if ($r = $this->wajibTp()) {
            return $r;
        }
        if (! Akses::guruId()) {
            return redirect()->to('/dashboard')->with('error', 'Modul ajar disusun oleh akun guru.');
        }
        $g       = Akses::guruId();
        $target  = model(PerangkatModel::class)->target($this->tpId(), $g);
        $mapelId = (int) $this->request->getGet('mapel_id');
        $tingkat = (string) $this->request->getGet('tingkat');
        if (! $mapelId && $target) {
            foreach (['success', 'error', 'warning', 'info'] as $fk) { session()->keepFlashdata($fk); }
            return redirect()->to('/modul-ajar?mapel_id=' . $target[0]['mapel_id'] . '&tingkat=' . urlencode($target[0]['tingkat']));
        }
        $w = ['tahun_pelajaran_id' => $this->tpId(), 'guru_id' => $g, 'mapel_id' => $mapelId, 'tingkat' => $tingkat];
        $modul = $this->db()->table('modul_ajar')->where($w)->orderBy('urutan')->orderBy('id')->get()->getResultArray();
        $items = $this->db()->table('promes_item')->where($w)->where('jenis', 'Materi')->orderBy('urutan')->orderBy('id')->get()->getResultArray();
        return view('akademik/modul/index', [
            'title'    => 'Modul Ajar',
            'subtitle' => 'Buat modul dari butir program semester; data identitas, tujuan, dan alokasi waktu terisi otomatis.',
            'target'   => $target, 'mapelId' => $mapelId, 'tingkat' => $tingkat,
            'modul'    => $modul, 'items' => $items,
            'sudah'    => array_map('intval', array_filter(array_column($modul, 'promes_item_id'))),
            'format'   => ModulAjar::formatBawaan(),
        ]);
    }

    public function buat()
    {
        if (($r = $this->wajibTp()) || ! Akses::guruId()) {
            return $r ?: redirect()->to('/dashboard');
        }
        $g       = Akses::guruId();
        $mapelId = (int) $this->request->getPost('mapel_id');
        $tingkat = (string) $this->request->getPost('tingkat');
        $ktx     = Perencanaan::konteks($this->tpId(), $g, $mapelId, $tingkat);
        if (! $ktx) {
            return $this->back('error', 'Mapel/tingkat bukan penugasan Anda.');
        }
        $item = null;
        if ($iid = (int) $this->request->getPost('item_id')) {
            $item = $this->db()->table('promes_item')->where(['id' => $iid, 'guru_id' => $g])->get()->getRowArray();
        }
        $format = isset(ModulAjar::FORMAT[$this->request->getPost('format')]) ? $this->request->getPost('format') : ModulAjar::formatBawaan();
        $jp     = (int) ($item['jp'] ?? $ktx['jp_minggu']);
        $jpPert = max($ktx['slot'] ? max($ktx['slot']) : 2, 1);
        $topik  = (string) ($item['materi'] ?? 'Topik baru');
        $isi    = ModulAjar::kosong();
        $isi['topik']  = $topik;
        $isi['tujuan'] = (string) ($item['tujuan'] ?? '');
        if (! empty($item['atp_id']) && ($atp = $this->db()->table('atp')->where('id', $item['atp_id'])->get()->getRowArray())) {
            $isi['cp'] = $atp['elemen'] ? 'Elemen: ' . $atp['elemen'] : '';
        }
        $isi['asesmen_awal']   = 'Asesmen diagnostik singkat (pertanyaan pemantik/kuis 3–5 soal) untuk mengetahui pengetahuan awal dan minat peserta didik tentang ' . $topik . '.';
        $isi['asesmen_proses'] = 'Observasi keaktifan dan kolaborasi (lembar observasi), penilaian LKPD/hasil diskusi dengan rubrik, umpan balik lisan.';
        $isi['asesmen_akhir']  = 'Tes tertulis/produk/presentasi sesuai kriteria ketercapaian tujuan pembelajaran (KKTP).';
        $pert = (int) max(1, ceil($jp / $jpPert));
        $isi['pertemuan'] = ModulAjar::pertemuanDariModel('', $topik, $format, $pert);
        $n  = $this->db()->table('modul_ajar')->where(['tahun_pelajaran_id' => $this->tpId(), 'guru_id' => $g, 'mapel_id' => $mapelId, 'tingkat' => $tingkat])->countAllResults();
        $this->db()->table('modul_ajar')->insert([
            'tahun_pelajaran_id' => $this->tpId(), 'guru_id' => $g, 'mapel_id' => $mapelId, 'tingkat' => $tingkat, 'promes_item_id' => $item['id'] ?? null,
            'judul' => mb_substr($topik, 0, 200), 'format' => $format, 'jp' => $jp, 'pertemuan' => min(255, $pert),
            'isi' => json_encode($isi, JSON_UNESCAPED_UNICODE), 'urutan' => $n + 1, 'created_at' => date('Y-m-d H:i:s'),
        ]);
        return redirect()->to('/modul-ajar/edit/' . $this->db()->insertID())->with('success', 'Kerangka modul dibuat. Lengkapi bagian-bagiannya; pilih model pembelajaran untuk mengisi langkah otomatis.');
    }

    public function edit($id)
    {
        $m = $this->modul((int) $id);
        if (! $m) {
            return redirect()->to('/modul-ajar')->with('error', 'Modul tidak ditemukan.');
        }
        $mapel = $this->db()->table('mata_pelajaran')->where('id', $m['mapel_id'])->get()->getRowArray();
        return view('akademik/modul/edit', [
            'title'    => 'Susun Modul Ajar',
            'subtitle' => ($mapel['nama_mapel'] ?? '') . ' · tingkat ' . $m['tingkat'] . ' · ' . ModulAjar::FORMAT[$m['format']],
            'm'        => $m,
            'mapel'    => $mapel,
            'fase'     => Perencanaan::fase($m['tingkat']),
        ]);
    }

    public function simpan($id)
    {
        $m = $this->modul((int) $id);
        if (! $m) {
            return redirect()->to('/modul-ajar')->with('error', 'Modul tidak ditemukan.');
        }
        $isi = ModulAjar::kosong();
        foreach ($isi as $k => $v) {
            if (is_array($v)) {
                continue;
            }
            $isi[$k] = trim((string) $this->request->getPost($k));
        }
        $isi['dpl']       = array_values(array_intersect(ModulAjar::DPL, (array) $this->request->getPost('dpl')));
        $isi['kbc_topik'] = array_values(array_intersect(ModulAjar::PANCA_CINTA, (array) $this->request->getPost('kbc_topik')));
        $isi['metode']    = array_values(array_filter(array_map('trim', explode(',', (string) $this->request->getPost('metode')))));
        $isi['pertemuan'] = [];
        foreach ((array) $this->request->getPost('pertemuan') as $p) {
            $row = [];
            foreach (['awal', 'memahami', 'mengaplikasi', 'merefleksi', 'penutup'] as $k) {
                $row[$k] = trim((string) ($p[$k] ?? ''));
            }
            if (implode('', $row) !== '') {
                $isi['pertemuan'][] = $row;
            }
        }
        $format = isset(ModulAjar::FORMAT[$this->request->getPost('format')]) ? $this->request->getPost('format') : $m['format'];
        $judul  = mb_substr(trim((string) $this->request->getPost('judul')) ?: $isi['topik'] ?: $m['judul'], 0, 200);
        $this->db()->table('modul_ajar')->where('id', $m['id'])->update([
            'judul' => $judul, 'format' => $format, 'jp' => max(0, min(300, (int) $this->request->getPost('jp'))),
            'pertemuan' => max(1, count($isi['pertemuan'])), 'isi' => json_encode($isi, JSON_UNESCAPED_UNICODE), 'updated_at' => date('Y-m-d H:i:s'),
        ]);
        if ($this->request->getPost('cetak')) {
            return redirect()->to('/modul-ajar/cetak/' . $m['id']);
        }
        return redirect()->to('/modul-ajar/edit/' . $m['id'])->with('success', 'Modul ajar disimpan.');
    }

    public function salin($id)
    {
        $m = $this->modul((int) $id);
        if (! $m) {
            return $this->back('error', 'Modul tidak ditemukan.');
        }
        $this->db()->table('modul_ajar')->insert([
            'tahun_pelajaran_id' => $this->tpId(), 'guru_id' => $m['guru_id'], 'mapel_id' => $m['mapel_id'], 'tingkat' => $m['tingkat'], 'promes_item_id' => null,
            'judul' => mb_substr('Salinan ' . $m['judul'], 0, 200), 'format' => $m['format'], 'jp' => $m['jp'], 'pertemuan' => $m['pertemuan'],
            'isi' => json_encode($m['isi'], JSON_UNESCAPED_UNICODE), 'urutan' => (int) $m['urutan'] + 1, 'created_at' => date('Y-m-d H:i:s'),
        ]);
        return redirect()->to('/modul-ajar/edit/' . $this->db()->insertID())->with('success', 'Modul disalin. Sesuaikan topik dan butir program.');
    }

    public function hapus($id)
    {
        $m = $this->modul((int) $id);
        if ($m) {
            $this->db()->table('modul_ajar')->where('id', $m['id'])->delete();
        }
        return redirect()->to('/modul-ajar?mapel_id=' . ($m['mapel_id'] ?? '') . '&tingkat=' . urlencode($m['tingkat'] ?? ''))->with('success', 'Modul dihapus.');
    }

    public function ajukan()
    {
        $g       = Akses::guruId();
        $mapelId = (int) $this->request->getPost('mapel_id');
        $tingkat = (string) $this->request->getPost('tingkat');
        if (! $g || ! $this->db()->table('modul_ajar')->where(['tahun_pelajaran_id' => $this->tpId(), 'guru_id' => $g, 'mapel_id' => $mapelId, 'tingkat' => $tingkat])->countAllResults()) {
            return $this->back('error', 'Belum ada modul ajar untuk diajukan.');
        }
        [$ok, $pesan] = model(PerangkatModel::class)->ajukanInternal($this->tpId(), $g, $mapelId, $tingkat, 'Modul Ajar', 'modul', $this->userId());
        return $this->back($ok ? 'success' : 'error', $pesan);
    }

    // ------------------------------------------------------------------ CETAK
    private function dataCetak(array $m): array
    {
        $guru  = model(\App\Models\GuruModel::class)->find($m['guru_id']);
        $tp    = $this->db()->table('tahun_pelajaran')->where('id', $m['tahun_pelajaran_id'])->get()->getRowArray();
        $mapel = $this->db()->table('mata_pelajaran')->where('id', $m['mapel_id'])->get()->getRowArray();
        return ['m' => $m, 'guru' => $guru, 'tp' => $tp, 'mapel' => $mapel, 'fase' => Perencanaan::fase($m['tingkat'])];
    }

    private function ttd(array $guru): array
    {
        $madrasah = in_array(setting('jenjang'), ['MI', 'MTs', 'MA', 'MAK'], true) || setting('jenis_nomor') === 'NSM';
        return ['kiri' => ['atas' => 'Mengetahui,', 'jabatan' => $madrasah ? 'Kepala Madrasah' : 'Kepala Sekolah', 'nama' => setting('kepala_sekolah', ''), 'nip' => setting('nip_kepala_sekolah', '') ?: null],
            'kanan' => ['jabatan' => 'Guru Mata Pelajaran', 'nama' => nama_guru($guru), 'nip' => $guru['nip'] ?: null]];
    }

    public function cetak($id)
    {
        $m = $this->modul((int) $id, true);
        if (! $m) {
            return redirect()->to('/modul-ajar')->with('error', 'Modul tidak ditemukan.');
        }
        $d = $this->dataCetak($m);
        return view('akademik/modul/cetak', [
            'judul' => 'Modul Ajar', 'subjudul' => ModulAjar::FORMAT[$m['format']], 'orientasi' => 'portrait', 'daftar' => [$d], 'ttdModul' => $this->ttd($d['guru']), 'word' => true,
        ]);
    }

    public function cetakSemua()
    {
        $g = Akses::guruId();
        if (Akses::perangkatLihatSemua() && $this->request->getGet('guru_id')) {
            $g = (int) $this->request->getGet('guru_id');
        }
        $tpId = Akses::perangkatLihatSemua() && $this->request->getGet('tp') ? (int) $this->request->getGet('tp') : $this->tpId();
        $rows = $this->db()->table('modul_ajar')->where(['tahun_pelajaran_id' => $tpId, 'guru_id' => $g, 'mapel_id' => (int) $this->request->getGet('mapel_id'),
            'tingkat' => (string) $this->request->getGet('tingkat')])->orderBy('urutan')->orderBy('id')->get()->getResultArray();
        if (! $g || ! $rows) {
            return redirect()->to('/modul-ajar')->with('error', 'Belum ada modul ajar.');
        }
        $daftar = [];
        foreach ($rows as $m) {
            $m['isi'] = array_replace(ModulAjar::kosong(), json_decode((string) $m['isi'], true) ?: []);
            $daftar[] = $this->dataCetak($m);
        }
        return view('akademik/modul/cetak', [
            'judul' => 'Modul Ajar', 'subjudul' => $daftar[0]['mapel']['nama_mapel'] . ' · Kelas ' . $rows[0]['tingkat'] . ' · ' . count($rows) . ' modul',
            'orientasi' => 'portrait', 'daftar' => $daftar, 'ttdModul' => $this->ttd($daftar[0]['guru']), 'word' => true,
        ]);
    }
}
