<?php

namespace App\Controllers\Akademik;

use App\Controllers\BaseController;
use App\Libraries\Akses;
use App\Libraries\Berkas;
use App\Models\AtpModel;
use App\Models\MapelModel;

/** Alur Tujuan Pembelajaran + modul ajar per mapel & tingkat. */
class AtpController extends BaseController
{
    private AtpModel $model;

    public function __construct()
    {
        $this->model = new AtpModel();
    }

    /** Pilihan mapel-tingkat: semua untuk kurikulum, selain itu yang diampu. */
    private function pilihan(): array
    {
        $db = db_connect();
        $b  = $db->table('penugasan_guru')->select('DISTINCT penugasan_guru.mapel_id, kelas.tingkat, mata_pelajaran.nama_mapel', false)
            ->join('kelas', 'kelas.id = penugasan_guru.kelas_id')->join('mata_pelajaran', 'mata_pelajaran.id = penugasan_guru.mapel_id')
            ->where('penugasan_guru.tahun_pelajaran_id', $this->tpId());
        if (! Akses::punya('kurikulum', 'kepsek')) {
            $b->where('penugasan_guru.guru_id', (int) $this->guruId());
        }
        return $b->orderBy('mata_pelajaran.nama_mapel')->orderBy('kelas.tingkat')->get()->getResultArray();
    }

    public function index()
    {
        if ($r = $this->wajibTp()) {
            return $r;
        }
        $pilihan = $this->pilihan();
        $mapelId = (int) $this->request->getGet('mapel_id');
        $tingkat = (string) $this->request->getGet('tingkat');
        if ((! $mapelId || $tingkat === '') && $pilihan) {
            [$mapelId, $tingkat] = [(int) $pilihan[0]['mapel_id'], $pilihan[0]['tingkat']];
        }
        $boleh = false;
        foreach ($pilihan as $p) {
            $boleh = $boleh || ((int) $p['mapel_id'] === $mapelId && $p['tingkat'] === $tingkat);
        }
        if (! $boleh && ! Akses::punya('kurikulum', 'kepsek')) {
            $mapelId = 0;
        }
        return view('akademik/atp/index', [
            'title'    => 'ATP & Modul Ajar',
            'subtitle' => 'Alur tujuan pembelajaran per mapel & tingkat. TP dipilih saat mengisi jurnal sehingga ketercapaian terpantau.',
            'pilihan'  => $pilihan,
            'mapelId'  => $mapelId,
            'tingkat'  => $tingkat,
            'mapel'    => $mapelId ? model(MapelModel::class)->find($mapelId) : null,
            'rows'     => $mapelId ? $this->model->daftar($mapelId, $tingkat) : [],
            'kelola'   => $mapelId && Akses::atpKelola($mapelId, $tingkat),
            'fase'     => AtpModel::faseDari($tingkat),
        ]);
    }

    private function simpan(?int $id)
    {
        $row     = $id ? $this->model->find($id) : null;
        $mapelId = $row ? (int) $row['mapel_id'] : (int) $this->request->getPost('mapel_id');
        $tingkat = $row ? $row['tingkat'] : (string) $this->request->getPost('tingkat');
        if (! Akses::atpKelola($mapelId, $tingkat)) {
            return $this->back('error', 'Anda tidak mengampu mapel ini di tingkat tersebut.');
        }
        $p    = fn ($k) => trim((string) $this->request->getPost($k)) ?: null;
        $data = [
            'mapel_id' => $mapelId, 'tingkat' => $tingkat, 'fase' => $p('fase') ?: AtpModel::faseDari($tingkat),
            'semester' => in_array($p('semester'), ['Ganjil', 'Genap'], true) ? $p('semester') : null,
            'elemen' => $p('elemen'), 'kode' => $p('kode'), 'tujuan' => (string) $p('tujuan'),
            'alokasi_jp' => (int) $this->request->getPost('alokasi_jp') ?: null, 'urutan' => (int) $this->request->getPost('urutan'),
        ];
        if (! $this->validateData($data, ['tujuan' => 'required|max_length[2000]', 'elemen' => 'permit_empty|max_length[150]', 'kode' => 'permit_empty|max_length[20]'])) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }
        [$file, $err] = Berkas::simpan($this->request->getFile('modul_ajar'), 'modul_ajar', ['pdf', 'doc', 'docx', 'ppt', 'pptx'], 10240);
        if ($err) {
            return $this->back('error', $err);
        }
        if ($file) {
            if ($row) {
                Berkas::hapus('modul_ajar', $row['modul_ajar']);
            }
            $data['modul_ajar'] = $file;
        }
        if (! $id) {
            $data['dibuat_oleh'] = $this->userId();
            if (! $data['urutan']) {
                $data['urutan'] = count($this->model->daftar($mapelId, $tingkat)) + 1;
            }
        }
        $id ? $this->model->update($id, $data) : $this->model->insert($data);
        return redirect()->to("/atp?mapel_id={$mapelId}&tingkat=" . urlencode($tingkat))->with('success', 'Tujuan pembelajaran disimpan.');
    }

    public function store()
    {
        return $this->simpan(null);
    }

    public function update($id)
    {
        return $this->simpan((int) $id);
    }

    public function delete($id)
    {
        $row = $this->model->find($id);
        if (! $row || ! Akses::atpKelola((int) $row['mapel_id'], $row['tingkat'])) {
            return $this->back('error', 'Akses ditolak.');
        }
        if ($pesan = $this->masihDipakai(['jurnal' => ['jurnal_atp', ['atp_id' => (int) $id]]], 'TP yang sudah tercatat di jurnal tidak dapat dihapus.')) {
            return $this->back('error', $pesan);
        }
        Berkas::hapus('modul_ajar', $row['modul_ajar']);
        $this->model->delete($id);
        catat_log('hapus', 'atp', (int) $id);
        return redirect()->to("/atp?mapel_id={$row['mapel_id']}&tingkat=" . urlencode($row['tingkat']))->with('success', 'TP dihapus.');
    }

    public function modul($id)
    {
        $row = $this->model->find($id);
        if (! $row || ! ($p = Berkas::path('modul_ajar', $row['modul_ajar']))) {
            return $this->back('error', 'Modul ajar tidak tersedia.');
        }
        return $this->response->download($p, null)->setFileName('Modul_' . preg_replace('/\W+/', '_', $row['kode'] ?: 'TP' . $row['id']) . '.' . pathinfo($p, PATHINFO_EXTENSION));
    }
}
