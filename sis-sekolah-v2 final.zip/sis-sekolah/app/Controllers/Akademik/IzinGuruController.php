<?php

namespace App\Controllers\Akademik;

use App\Controllers\BaseController;
use App\Libraries\Akses;
use App\Libraries\Berkas;
use App\Libraries\Kalender;
use App\Models\IzinGuruModel;
use App\Models\PresensiGuruModel;

/**
 * Pengajuan izin guru (sakit/izin/dinas luar/cuti) + tugas untuk kelas yang ditinggalkan.
 * Disetujui kurikulum/kepala sekolah → kehadiran guru terisi otomatis dan tugas tampil di monitoring piket.
 */
class IzinGuruController extends BaseController
{
    private IzinGuruModel $model;

    public function __construct()
    {
        $this->model = new IzinGuruModel();
    }

    public function index()
    {
        $putus = Akses::izinGuruPutus();
        if (! $putus && ! $this->guruId()) {
            return redirect()->to('/dashboard')->with('error', 'Akun Anda belum ditautkan ke data guru.');
        }
        return view('akademik/izin_guru/index', [
            'title'    => 'Izin Guru',
            'subtitle' => $putus ? 'Pengajuan izin guru menunggu persetujuan dan riwayatnya.' : 'Ajukan izin/sakit/dinas luar dan tinggalkan tugas untuk kelas.',
            'putus'    => $putus,
            'menunggu' => $putus ? $this->model->daftar(['status' => 'Diajukan']) : [],
            'rows'     => $putus ? $this->model->daftar() : $this->model->daftar(['guru_id' => $this->guruId()]),
        ]);
    }

    public function ajukan()
    {
        if (! $this->guruId()) {
            return $this->back('error', 'Akun Anda belum ditautkan ke data guru.');
        }
        $data = [
            'guru_id'         => $this->guruId(),
            'tanggal_mulai'   => (string) $this->request->getPost('tanggal_mulai'),
            'tanggal_selesai' => (string) ($this->request->getPost('tanggal_selesai') ?: $this->request->getPost('tanggal_mulai')),
            'jenis'           => (string) $this->request->getPost('jenis'),
            'keterangan'      => trim((string) $this->request->getPost('keterangan')) ?: null,
            'tugas_siswa'     => trim((string) $this->request->getPost('tugas_siswa')) ?: null,
            'status'          => 'Diajukan',
        ];
        if (! $this->validateData($data, ['tanggal_mulai' => 'required|valid_date[Y-m-d]', 'tanggal_selesai' => 'required|valid_date[Y-m-d]',
            'jenis' => 'required|in_list[S,I,DL,C]', 'keterangan' => 'required|max_length[1000]'])) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }
        if ($data['tanggal_selesai'] < $data['tanggal_mulai']) {
            return $this->back('error', 'Tanggal selesai tidak boleh sebelum tanggal mulai.');
        }
        [$lampiran, $err] = Berkas::simpan($this->request->getFile('lampiran'), 'izin_guru', ['pdf', 'jpg', 'jpeg', 'png']);
        if ($err) {
            return $this->back('error', $err);
        }
        $data['lampiran'] = $lampiran;
        $id               = $this->model->insert($data);
        catat_log('tambah', 'izin_guru', (int) $id);
        return redirect()->to('/izin-guru')->with('success', 'Izin diajukan dan menunggu persetujuan.');
    }

    public function putus($id)
    {
        if (! Akses::izinGuruPutus()) {
            return $this->back('error', 'Hanya kurikulum/kepala sekolah yang dapat memutus izin.');
        }
        $row = $this->model->find($id);
        $ok  = $this->request->getPost('putusan') === 'Disetujui';
        if (! $row || $row['status'] !== 'Diajukan') {
            return $this->back('error', 'Izin tidak ditemukan atau sudah diputus.');
        }
        $this->model->update($id, ['status' => $ok ? 'Disetujui' : 'Ditolak', 'diputus_oleh' => $this->userId(),
            'catatan_putusan' => trim((string) $this->request->getPost('catatan_putusan')) ?: null]);
        $n = 0;
        if ($ok) {
            $pg = model(PresensiGuruModel::class);
            foreach (Kalender::tanggal($row['tanggal_mulai'], $row['tanggal_selesai']) as $d) {
                if (! Kalender::status($d)['sekolah']) {
                    continue;
                }
                $pg->simpanUnik(['tanggal' => $d, 'guru_id' => (int) $row['guru_id']], [
                    'tahun_pelajaran_id' => $this->tpId(), 'status' => $row['jenis'], 'izin_guru_id' => (int) $id, 'sumber' => 'Izin',
                    'keterangan' => mb_substr((string) $row['keterangan'], 0, 150), 'dicatat_oleh' => $this->userId(),
                ]);
                $n++;
            }
        }
        catat_log($ok ? 'setujui' : 'tolak', 'izin_guru', (int) $id);
        return redirect()->to('/izin-guru')->with('success', $ok ? "Izin disetujui; {$n} hari kehadiran guru terisi otomatis." : 'Izin ditolak.');
    }

    public function batal($id)
    {
        $row = $this->model->find($id);
        if (! $row || ((int) $row['guru_id'] !== (int) $this->guruId() && ! Akses::izinGuruPutus())) {
            return $this->back('error', 'Akses ditolak.');
        }
        model(PresensiGuruModel::class)->where(['izin_guru_id' => (int) $id, 'sumber' => 'Izin'])->delete();
        Berkas::hapus('izin_guru', $row['lampiran']);
        $this->model->delete($id);
        catat_log('hapus', 'izin_guru', (int) $id);
        return redirect()->to('/izin-guru')->with('success', 'Izin dibatalkan.');
    }

    public function lampiran($id)
    {
        $row = $this->model->find($id);
        if (! $row || ! Akses::izinGuruLihat($row) || ! ($p = Berkas::path('izin_guru', $row['lampiran']))) {
            return $this->back('error', 'Lampiran tidak tersedia atau akses ditolak.');
        }
        return $this->response->download($p, null)->inline();
    }
}
