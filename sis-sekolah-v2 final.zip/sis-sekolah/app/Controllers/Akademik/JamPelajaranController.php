<?php

namespace App\Controllers\Akademik;

use App\Controllers\BaseController;
use App\Models\JadwalModel;
use App\Models\JamPelajaranModel;

/**
 * Jam pelajaran bawaan (semua hari) + jam khusus per hari (mis. Jumat lebih pendek, Senin ada upacara).
 */
class JamPelajaranController extends BaseController
{
    private JamPelajaranModel $model;

    public function __construct()
    {
        $this->model = new JamPelajaranModel();
    }

    private function hariGet(): int
    {
        $h = (int) $this->request->getGet('hari');
        return isset(hari_list()[$h]) ? $h : 0;
    }

    public function index()
    {
        $hari   = $this->hariGet();
        $khusus = [];
        foreach (array_keys(hari_list()) as $h) {
            $khusus[$h] = count($this->model->khusus($h));
        }
        return view('akademik/jam/index', [
            'title'    => 'Jam Pelajaran',
            'subtitle' => 'Atur jam bawaan untuk semua hari, lalu buat jam khusus untuk hari yang berbeda (mis. Jumat lebih pendek).',
            'hari'     => $hari,
            'khusus'   => $khusus,
            'rows'     => $hari ? $this->model->khusus($hari) : $this->model->bawaan(),
        ]);
    }

    public function store()
    {
        return $this->simpan();
    }

    public function update($id)
    {
        return $this->simpan((int) $id);
    }

    private function simpan(?int $id = null)
    {
        $rules = ['jam_mulai' => 'required', 'jam_selesai' => 'required', 'jam_ke' => 'permit_empty|is_natural'];
        if (! $this->validate($rules)) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }
        $hari  = $id ? ($this->model->find($id)['hari'] ?? null) : ((int) $this->request->getPost('hari') ?: null);
        $isKbm = $this->request->getPost('is_kbm') ? 1 : 0;
        $data  = [
            'hari'        => $hari,
            'jam_ke'      => $isKbm ? (int) $this->request->getPost('jam_ke') : 0,
            'jam_mulai'   => $this->request->getPost('jam_mulai'),
            'jam_selesai' => $this->request->getPost('jam_selesai'),
            'is_kbm'      => $isKbm,
            'keterangan'  => trim((string) $this->request->getPost('keterangan')) ?: null,
        ];
        if ($data['jam_selesai'] <= $data['jam_mulai']) {
            return $this->back('error', 'Jam selesai harus setelah jam mulai.');
        }
        if ($isKbm) {
            if ($data['jam_ke'] < 1) {
                return $this->back('error', 'Slot KBM wajib diberi nomor jam ke (1, 2, 3, ...).');
            }
            $dup = $this->model->where(['is_kbm' => 1, 'jam_ke' => $data['jam_ke']])->where('hari', $hari);
            if ($id) {
                $dup->where('id !=', $id);
            }
            if ($dup->countAllResults()) {
                return $this->back('error', "Jam ke-{$data['jam_ke']} sudah ada pada " . ($hari ? 'hari ' . nama_hari($hari) : 'jam bawaan') . '.');
            }
        }
        // tidak boleh tumpang tindih dengan slot lain pada set yang sama
        $tumpang = $this->model->where('hari', $hari)->where('jam_mulai <', $data['jam_selesai'])->where('jam_selesai >', $data['jam_mulai']);
        if ($id) {
            $tumpang->where('id !=', $id);
        }
        if ($t = $tumpang->first()) {
            return $this->back('error', 'Waktu bertabrakan dengan slot ' . jam($t['jam_mulai']) . '–' . jam($t['jam_selesai']) . '.');
        }
        $id ? $this->model->update($id, $data) : $this->model->insert($data);
        return redirect()->to('/akademik/jam-pelajaran' . ($hari ? '?hari=' . $hari : ''))->with('success', 'Jam pelajaran disimpan.');
    }

    public function delete($id)
    {
        $row = $this->model->find($id);
        if ($pesan = $this->masihDipakai(['slot jadwal' => ['jadwal_pelajaran', ['jam_pelajaran_id' => (int) $id]]], 'Pindahkan/hapus jadwal pada jam ini terlebih dahulu.')) {
            return redirect()->back()->with('error', $pesan);
        }
        $this->model->delete($id);
        catat_log('hapus', 'jam_pelajaran', (int) $id);
        return redirect()->to('/akademik/jam-pelajaran' . (! empty($row['hari']) ? '?hari=' . $row['hari'] : ''))->with('success', 'Slot jam dihapus.');
    }

    /** Buat jam khusus untuk satu hari dengan menyalin jam bawaan; jadwal hari itu dipindah ke slot baru (berdasarkan jam ke). */
    public function buatKhusus($hari)
    {
        $hari = (int) $hari;
        if (! isset(hari_list()[$hari]) || $this->model->khusus($hari)) {
            return redirect()->back()->with('error', 'Hari tidak valid atau sudah memiliki jam khusus.');
        }
        $bawaan = $this->model->bawaan();
        $db     = db_connect();
        $db->transStart();
        foreach ($bawaan as $b) {
            $this->model->insert(['hari' => $hari, 'jam_ke' => $b['jam_ke'], 'jam_mulai' => $b['jam_mulai'], 'jam_selesai' => $b['jam_selesai'], 'is_kbm' => $b['is_kbm'], 'keterangan' => $b['keterangan']]);
        }
        JamPelajaranModel::resetCache();
        $gagal = model(JadwalModel::class)->petakanUlangHari($hari, $bawaan, $this->model->khusus($hari));
        $db->transComplete();
        catat_log('tambah', 'jam_pelajaran', $hari, 'buat jam khusus hari ' . nama_hari($hari));
        return redirect()->to('/akademik/jam-pelajaran?hari=' . $hari)->with($gagal ? 'warning' : 'success',
            'Jam khusus hari ' . nama_hari($hari) . ' dibuat dari jam bawaan. Silakan ubah waktunya.' . ($gagal ? " {$gagal} slot jadwal tidak terpetakan." : ''));
    }

    /** Hapus jam khusus satu hari; jadwal dikembalikan ke jam bawaan (berdasarkan jam ke). */
    public function hapusKhusus($hari)
    {
        $hari   = (int) $hari;
        $khusus = $this->model->khusus($hari);
        if (! $khusus) {
            return redirect()->back()->with('error', 'Hari ini tidak memiliki jam khusus.');
        }
        $bawaanKe = array_column(array_filter($this->model->bawaan(), static fn ($j) => (int) $j['is_kbm'] === 1), 'jam_ke');
        $ids      = array_column($khusus, 'id');
        foreach ($khusus as $k) {
            if ((int) $k['is_kbm'] === 1 && ! in_array($k['jam_ke'], $bawaanKe) && db_connect()->table('jadwal_pelajaran')->where(['hari' => $hari, 'jam_pelajaran_id' => $k['id']])->countAllResults()) {
                return redirect()->back()->with('error', "Jam ke-{$k['jam_ke']} hari " . nama_hari($hari) . ' masih berisi jadwal tetapi tidak ada di jam bawaan. Hapus jadwal itu dulu.');
            }
        }
        $db = db_connect();
        $db->transStart();
        model(JadwalModel::class)->petakanUlangHari($hari, $khusus, $this->model->bawaan());
        $this->model->whereIn('id', $ids)->delete();
        $db->transComplete();
        catat_log('hapus', 'jam_pelajaran', $hari, 'hapus jam khusus hari ' . nama_hari($hari));
        return redirect()->to('/akademik/jam-pelajaran?hari=' . $hari)->with('success', 'Hari ' . nama_hari($hari) . ' kembali memakai jam bawaan.');
    }
}
