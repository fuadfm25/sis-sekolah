<?php

namespace App\Controllers;

use App\Filters\InstalledFilter;
use CodeIgniter\Controller;
use CodeIgniter\Database\MigrationRunner;
use CodeIgniter\Database\Seeder;
use Config\Database;

/**
 * Pemasang otomatis: cek kebutuhan → buat database → migrasi → data awal → akun admin → tulis .env → kunci.
 * Hanya dapat dibuka selama aplikasi belum terpasang (lihat InstalledFilter).
 */
class Install extends Controller
{
    protected $helpers = ['url', 'form'];

    private function kebutuhan(): array
    {
        $cek = [
            ['PHP ≥ 8.2', version_compare(PHP_VERSION, '8.2.0', '>='), 'PHP ' . PHP_VERSION],
        ];
        foreach (['intl', 'mbstring', 'mysqli', 'json', 'xml', 'zip', 'gd', 'curl'] as $ext) {
            $cek[] = ['Ekstensi ' . $ext, extension_loaded($ext), extension_loaded($ext) ? 'aktif' : 'aktifkan di php.ini' . ($ext === 'curl' || $ext === 'gd' ? ' (disarankan)' : '')];
        }
        foreach ([WRITEPATH, WRITEPATH . 'session', WRITEPATH . 'uploads', FCPATH . 'uploads/logo', ROOTPATH] as $dir) {
            $cek[] = ['Dapat ditulisi: ' . str_replace(ROOTPATH, '', $dir) ?: '/', is_writable($dir), is_writable($dir) ? 'OK' : ($dir === ROOTPATH ? 'tidak (isi .env akan ditampilkan untuk disalin manual)' : 'beri izin tulis')];
        }
        $cek[] = ['Folder vendor (composer)', is_file(ROOTPATH . 'vendor/autoload.php'), 'OK'];
        return $cek;
    }

    private function wajibOk(array $cek): bool
    {
        foreach ($cek as [$nama, $ok]) {
            $opsional = str_contains($nama, 'gd') || str_contains($nama, 'curl') || $nama === 'Dapat ditulisi: ';
            if (! $ok && ! $opsional) {
                return false;
            }
        }
        return true;
    }

    public function index()
    {
        $base = rtrim((string) ($this->request->getServer('HTTPS') === 'on' ? 'https' : 'http') . '://' . $this->request->getServer('HTTP_HOST')
            . rtrim(str_replace('\\', '/', dirname((string) $this->request->getServer('SCRIPT_NAME'))), '/'), '/') . '/';
        $cek = $this->kebutuhan();
        return view('install/index', ['cek' => $cek, 'siap' => $this->wajibOk($cek), 'baseUrl' => $base]);
    }

    public function proses()
    {
        $p = fn (string $k, string $d = '') => trim((string) ($this->request->getPost($k) ?? $d));
        $in = [
            'hostname' => $p('hostname', 'localhost'), 'port' => (int) ($p('port') ?: 3306), 'username' => $p('username', 'root'),
            'password' => (string) $this->request->getPost('password'), 'database' => $p('database'),
            'base_url' => rtrim($p('base_url'), '/') . '/', 'tanpa_index' => (bool) $this->request->getPost('tanpa_index'),
            'alamat_otomatis' => $this->request->getPost('alamat_otomatis') !== '0',
            'zona' => $p('zona', 'Asia/Jakarta'), 'mode' => $p('mode', 'production'),
            'nama_aplikasi' => $p('nama_aplikasi', 'SIS Sekolah'), 'nama_sekolah' => $p('nama_sekolah'), 'jenjang' => $p('jenjang'),
            'jenis_nomor' => $p('jenis_nomor', 'NPSN'), 'npsn' => $p('npsn'),
            'admin_user' => $p('admin_user', 'admin'), 'admin_nama' => $p('admin_nama', 'Administrator'),
            'admin_pass' => (string) $this->request->getPost('admin_pass'), 'admin_pass2' => (string) $this->request->getPost('admin_pass2'),
            'demo' => (bool) $this->request->getPost('demo'),
        ];
        $err = [];
        if (! preg_match('/^[A-Za-z0-9_]{1,64}$/', $in['database'])) {
            $err[] = 'Nama database hanya boleh huruf, angka, dan garis bawah.';
        }
        if (! $in['alamat_otomatis'] && ! filter_var($in['base_url'], FILTER_VALIDATE_URL)) {
            $err[] = 'Alamat aplikasi (base URL) tidak valid.';
        }
        if (! preg_match('/^[A-Za-z0-9._-]{3,50}$/', $in['admin_user'])) {
            $err[] = 'Username admin 3–50 karakter (huruf, angka, titik, garis bawah, tanda hubung).';
        }
        if (strlen($in['admin_pass']) < 8 || $in['admin_pass'] !== $in['admin_pass2']) {
            $err[] = 'Password admin minimal 8 karakter dan harus sama dengan ulangannya.';
        }
        if ($in['nama_sekolah'] === '') {
            $err[] = 'Nama sekolah wajib diisi.';
        }
        if (! in_array($in['zona'], ['Asia/Jakarta', 'Asia/Makassar', 'Asia/Jayapura'], true) || ! in_array($in['mode'], ['production', 'development'], true)) {
            $err[] = 'Pilihan zona waktu / mode tidak valid.';
        }
        if ($err) {
            return redirect()->back()->withInput()->with('errors', $err);
        }

        // 1) koneksi server & buat database
        mysqli_report(MYSQLI_REPORT_OFF);
        $link = @mysqli_connect($in['hostname'], $in['username'], $in['password'], '', $in['port']);
        if (! $link) {
            return redirect()->back()->withInput()->with('errors', ['Tidak dapat terhubung ke MySQL: ' . mysqli_connect_error()]);
        }
        if (! mysqli_query($link, 'CREATE DATABASE IF NOT EXISTS `' . $in['database'] . '` CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci')) {
            return redirect()->back()->withInput()->with('errors', ['Gagal membuat database: ' . mysqli_error($link)]);
        }
        $res = mysqli_query($link, "SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = '" . mysqli_real_escape_string($link, $in['database']) . "'");
        if ($res && (int) mysqli_fetch_row($res)[0] > 0) {
            return redirect()->back()->withInput()->with('errors', ['Database "' . $in['database'] . '" sudah berisi tabel. Gunakan nama database baru/kosong, atau kosongkan dulu lewat phpMyAdmin.']);
        }
        mysqli_close($link);

        $cfg = config(Database::class)->default;
        $cfg = array_merge($cfg, ['hostname' => $in['hostname'], 'port' => $in['port'], 'username' => $in['username'], 'password' => $in['password'], 'database' => $in['database'], 'DBDriver' => 'MySQLi', 'DBPrefix' => '']);

        return $this->pasang($cfg, $in);
    }

    /** Jalankan migrasi, seeder, akun admin, .env, kunci. Dipisah agar dapat diuji dengan driver lain. */
    public function pasang(array $cfg, array $in)
    {
        try {
            $db     = Database::connect($cfg, false);
            $runner = new MigrationRunner(config('Migrations'), $db);
            $runner->setNamespace('App')->latest();

            $seeder = new Seeder(config(Database::class), $db);
            $seeder->setSilent(true)->call($in['demo'] ? 'DemoSeeder' : 'DatabaseSeeder');

            // akun admin
            $db->table('users')->where('username', 'admin')->update([
                'username' => $in['admin_user'], 'nama_lengkap' => $in['admin_nama'],
                'password' => password_hash($in['admin_pass'], PASSWORD_DEFAULT), 'updated_at' => date('Y-m-d H:i:s'),
            ]);
            // identitas & token kiosk
            foreach (['nama_aplikasi' => $in['nama_aplikasi'], 'nama_sekolah' => $in['nama_sekolah'], 'jenjang' => $in['jenjang'],
                'jenis_nomor' => $in['jenis_nomor'], 'npsn' => $in['npsn'], 'kiosk_token' => bin2hex(random_bytes(12))] as $k => $v) {
                $db->table('pengaturan')->where('kunci', $k)->update(['nilai' => $v, 'updated_at' => date('Y-m-d H:i:s')]);
            }
        } catch (\Throwable $e) {
            return redirect()->to('/install')->withInput()->with('errors', ['Pemasangan gagal: ' . $e->getMessage()]);
        }

        $env = $this->isiEnv($cfg, $in);
        $tulisOk = @file_put_contents(ROOTPATH . '.env', $env) !== false;
        @file_put_contents(InstalledFilter::LOCK, 'Terpasang ' . date('Y-m-d H:i:s') . PHP_EOL);

        return view('install/selesai', ['tulisOk' => $tulisOk, 'env' => $env, 'in' => $in]);
    }

    private function isiEnv(array $cfg, array $in): string
    {
        $q = static fn (string $v) => "'" . str_replace("'", "\\'", $v) . "'";
        return "#--------------------------------------------------------------------\n"
            . "# Dibuat otomatis oleh pemasang SIS Sekolah pada " . date('Y-m-d H:i') . "\n"
            . "#--------------------------------------------------------------------\n\n"
            . "CI_ENVIRONMENT = {$in['mode']}\n\n"
            . ($in['alamat_otomatis']
                ? "# Alamat aplikasi dideteksi otomatis dari alamat yang dibuka di browser,\n"
                  . "# sehingga bisa diakses lewat localhost, IP server (mis. http://192.168.1.10/...), atau nama domain.\n"
                  . "# Isi hanya bila perlu memaksa satu alamat tertentu:\n"
                  . "# app.baseURL = " . $q($in['base_url']) . "\n"
                : "app.baseURL = " . $q($in['base_url']) . "\n")
            . ($in['tanpa_index'] ? "app.indexPage = ''\n" : '')
            . "app.appTimezone = {$in['zona']}\n\n"
            . "database.default.hostname = {$cfg['hostname']}\n"
            . "database.default.database = {$cfg['database']}\n"
            . "database.default.username = {$cfg['username']}\n"
            . "database.default.password = " . $q((string) $cfg['password']) . "\n"
            . "database.default.DBDriver = MySQLi\n"
            . "database.default.port = {$cfg['port']}\n";
    }
}
