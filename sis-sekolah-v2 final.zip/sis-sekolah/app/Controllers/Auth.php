<?php

namespace App\Controllers;

use App\Models\GuruModel;
use App\Models\UserModel;

class Auth extends BaseController
{
    public function index()
    {
        if (session('isLoggedIn')) {
            return redirect()->to('/dashboard');
        }
        return view('auth/login');
    }

    public function login()
    {
        if (! $this->validate(['username' => 'required', 'password' => 'required'])) {
            return $this->back('error', 'Username dan password wajib diisi.');
        }

        $username = trim((string) $this->request->getPost('username'));
        $password = (string) $this->request->getPost('password');

        // batasi 5 percobaan gagal per 5 menit per (IP + username)
        $throttler = service('throttler');
        $kunci     = 'login_' . md5($this->request->getIPAddress() . '|' . strtolower($username));
        $kunciAkun = 'login_kunci_' . md5(strtolower($username));   // bisa dibuka admin
        if (cache($kunciAkun)) {
            return $this->back('error', 'Terlalu banyak percobaan gagal. Coba lagi beberapa menit lagi.');
        }

        $users = new UserModel();
        $user  = $users->where('username', $username)->first();

        if (! $user || ! password_verify($password, $user['password'])) {
            if ($throttler->check($kunci, 5, MINUTE * 5) === false) {
                cache()->save($kunciAkun, 1, MINUTE * 5);
            }
            catat_log('gagal_login', 'users', $user['id'] ?? null, 'username: ' . $username);
            return $this->back('error', 'Username atau password salah.');
        }
        if (! (int) $user['is_active']) {
            return $this->back('error', 'Akun Anda dinonaktifkan. Hubungi administrator.');
        }

        $guru = model(GuruModel::class)->byUser((int) $user['id']);

        session()->regenerate(true);
        session()->set([
            'isLoggedIn'   => true,
            'user_id'      => (int) $user['id'],
            'username'     => $user['username'],
            'nama_lengkap' => $user['nama_lengkap'],
            'roles'        => $users->roleNames((int) $user['id']),
            'guru_id'      => $guru['id'] ?? null,
        ]);
        $users->update($user['id'], ['last_login' => date('Y-m-d H:i:s')]);
        catat_log('login', 'users', (int) $user['id']);

        // password direset admin: wajib diganti sebelum memakai aplikasi
        if ((int) ($user['wajib_ganti_password'] ?? 0) === 1) {
            session()->set('wajib_ganti', true);
            return redirect()->to('/profil')->with('warning', 'Password Anda baru direset oleh admin. Buat password baru terlebih dahulu.');
        }

        // password lemah/bawaan: wajib diganti (di mode produksi diblokir sampai diganti)
        if (in_array($password, ['admin123', '123456', '12345678', 'password'], true) || strcasecmp($password, $username) === 0) {
            session()->set('password_lemah', true);
            return redirect()->to('/profil')->with('warning', 'Password Anda masih bawaan/mudah ditebak. Silakan ganti sekarang demi keamanan data siswa.');
        }

        // password kuat dan bukan sementara → tandai sebagai password buatan sendiri
        if (empty($user['password_sendiri_at']) && (int) ($user['wajib_ganti_password'] ?? 0) === 0) {
            $users->update($user['id'], ['password_sendiri_at' => date('Y-m-d H:i:s')]);
        }
        return redirect()->to('/dashboard');
    }

    public function logout()
    {
        if (session('isLoggedIn')) {
            catat_log('logout', 'users', (int) session('user_id'));
        }
        session()->destroy();
        return redirect()->to('/login');
    }
}
