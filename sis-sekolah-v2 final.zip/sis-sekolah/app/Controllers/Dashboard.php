<?php

namespace App\Controllers;

use App\Libraries\Akses;
use App\Libraries\Kalender;
use App\Models\AnggotaKelasModel;
use App\Models\KalenderModel;
use App\Models\CatatanPerilakuModel;
use App\Models\GuruModel;
use App\Models\JadwalModel;
use App\Models\JurnalModel;
use App\Models\KelasModel;
use App\Models\PresensiHarianModel;
use App\Models\SiswaModel;

class Dashboard extends BaseController
{
    public function index()
    {
        $roles = session('roles') ?? [];
        if ($roles && ! array_diff($roles, ['satpam'])) {   // akun satpam langsung ke pos gerbang
            return redirect()->to('/gerbang');
        }
        $today = date('Y-m-d');
        $hari  = hari_dari_tanggal($today);
        $data  = ['title' => 'Dashboard', 'tp' => $this->tp, 'today' => $today];
        $data['statusHari']  = $this->tp ? Kalender::status($today) : null;
        $data['agendaNanti'] = $this->tp ? model(KalenderModel::class)->mendatang(5) : [];
        $kbm                 = $this->tp && $data['statusHari']['sekolah'];

        if (! $this->tp) {
            return view('dashboard/index', $data);
        }
        $tpId   = $this->tpId();
        $jadwal = model(JadwalModel::class);
        $jurnal = model(JurnalModel::class);

        // Jadwal mengajar hari ini (guru)
        if ($this->guruId()) {
            $sesi = $kbm ? $jadwal->sesiTanggal($tpId, $today, ['guru_id' => $this->guruId()]) : [];
            $peta = $jurnal->petaTanggal(array_column($sesi, 'id'), $today);
            foreach ($sesi as &$s) {
                $s['jurnal'] = $peta[$s['id']] ?? null;
            }
            $data['sesiSaya'] = $sesi;
        }

        // Kelas perwalian
        if ($ids = wali_kelas_ids()) {
            $ringkas = model(PresensiHarianModel::class)->ringkasTanggal($tpId, $today);
            $kelas   = model(KelasModel::class)->whereIn('id', $ids)->findAll();
            foreach ($kelas as &$k) {
                $k['jumlah_siswa'] = count(model(AnggotaKelasModel::class)->siswaKelas((int) $k['id'], $tpId));
                $k['presensi']     = $ringkas[$k['id']] ?? [];
            }
            $data['kelasWali'] = $kelas;
        }

        // Statistik umum
        if ($this->hasRole('kurikulum', 'kepsek', 'kesiswaan', 'tu', 'piket')) {
            $semuaSesi = $kbm ? $jadwal->sesiTanggal($tpId, $today) : [];
            $terisi    = $jurnal->petaTanggal(array_column($semuaSesi, 'id'), $today);
            $data['stat'] = [
                'siswa'         => model(SiswaModel::class)->where('status', 'Aktif')->countAllResults(),
                'guru'          => model(GuruModel::class)->where('is_active', 1)->countAllResults(),
                'kelas'         => model(KelasModel::class)->where('is_active', 1)->countAllResults(),
                'sesi_hari_ini' => count($semuaSesi),
                'jurnal_terisi' => count($terisi),
            ];
            $ringkas = model(PresensiHarianModel::class)->ringkasTanggal($tpId, $today);
            $tot     = ['H' => 0, 'T' => 0, 'S' => 0, 'I' => 0, 'A' => 0];
            foreach ($ringkas as $r) {
                foreach ($r as $st => $n) {
                    $tot[$st] += $n;
                }
            }
            $data['presensiHariIni'] = $tot;
            $data['kelasTerabsen']   = count($ringkas);
        }

        // Kesiswaan & BK
        if ($this->hasRole('kesiswaan', 'bk', 'kepsek')) {
            $cp                       = model(CatatanPerilakuModel::class);
            $data['perilakuTerbaru']  = $cp->base()->where('catatan_perilaku.tahun_pelajaran_id', $tpId)->orderBy('catatan_perilaku.id', 'DESC')->limit(6)->find();
            $data['rujukanBaru']      = $cp->where(['tahun_pelajaran_id' => $tpId, 'status' => 'Dirujuk BK'])->countAllResults();
            $batas                    = (int) setting('batas_poin_bk', 50);
            $data['batasPoin']        = $batas;
            $data['siswaMelewati']    = array_values(array_filter($cp->akumulasiPoin($tpId), static fn ($r) => (int) $r['poin_negatif'] >= $batas));
        }

        $pm = model(\App\Models\PerangkatModel::class);
        $data['perangkatInfo'] = array_filter([
            'revisi'   => Akses::guruId() ? (int) ($pm->hitungStatus($tpId, Akses::guruId())['Perlu Revisi'] ?? 0) : 0,
            'diajukan' => Akses::perangkatPeriksa() ? (int) ($pm->hitungStatus($tpId)['Diajukan'] ?? 0) : 0,
            'sahkan'   => Akses::perangkatSahkan() ? (int) ($pm->hitungStatus($tpId)['Disetujui'] ?? 0) : 0,
        ]);

        return view('dashboard/index', $data);
    }
}
