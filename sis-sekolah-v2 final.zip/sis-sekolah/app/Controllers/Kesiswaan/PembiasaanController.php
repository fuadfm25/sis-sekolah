<?php

namespace App\Controllers\Kesiswaan;

use App\Controllers\BaseController;
use App\Libraries\Akses;
use App\Libraries\Kalender;
use App\Models\AnggotaKelasModel;
use App\Models\PembiasaanModel;
use App\Models\PembiasaanSiswaModel;
use App\Models\PresensiHarianModel;

/**
 * Pembiasaan siswa (checklist harian per kelas) + master daftar pembiasaan.
 */
class PembiasaanController extends BaseController
{
    private PembiasaanModel $master;
    private PembiasaanSiswaModel $catatan;

    public function __construct()
    {
        $this->master  = new PembiasaanModel();
        $this->catatan = new PembiasaanSiswaModel();
    }

    private function pilihKelas(array $kelas): int
    {
        $id  = (int) $this->request->getGet('kelas_id');
        $ids = array_map('intval', array_column($kelas, 'id'));
        return in_array($id, $ids, true) ? $id : (int) (wali_kelas_ids()[0] ?? ($ids[0] ?? 0));
    }

    public function index()
    {
        if ($r = $this->wajibTp()) {
            return $r;
        }
        $kelas = $this->daftarKelas(Akses::pembiasaanLihatSemua());
        if (! $kelas) {
            return redirect()->to('/dashboard')->with('error', 'Anda tidak memiliki akses pembiasaan kelas mana pun.');
        }
        $kelasId = $this->pilihKelas($kelas);
        $tanggal = (string) ($this->request->getGet('tanggal') ?: date('Y-m-d'));
        if ($tanggal > date('Y-m-d')) {
            $tanggal = date('Y-m-d');
        }
        $siswa   = model(AnggotaKelasModel::class)->siswaKelas($kelasId, $this->tpId());
        $tingkat = (string) (model(\App\Models\KelasModel::class)->find($kelasId)['tingkat'] ?? '');

        return view('kesiswaan/pembiasaan/index', [
            'title'      => 'Pembiasaan Siswa',
            'subtitle'   => 'Centang kegiatan pembiasaan yang dilaksanakan siswa.',
            'kelas'      => $kelas,
            'kelasId'    => $kelasId,
            'tanggal'    => $tanggal,
            'pembiasaan' => $this->master->untukGuru(hari_dari_tanggal($tanggal), $tingkat),
            'menunggu'   => $this->catatan->menunggu($kelasId),
            'siswa'      => $siswa,
            'data'       => $this->catatan->petaKelasTanggal($kelasId, $tanggal),
            'pagi'       => model(PresensiHarianModel::class)->statusSiswa(array_column($siswa, 'id'), $tanggal),
            'bisaInput'  => Akses::pembiasaanInput($kelasId) && Kalender::absensi($tanggal, $kelasId ?: null),
            'status'     => Kalender::status($tanggal, $kelasId ?: null),
        ]);
    }

    public function simpan()
    {
        if ($r = $this->wajibTp()) {
            return $r;
        }
        $kelasId = (int) $this->request->getPost('kelas_id');
        $tanggal = (string) $this->request->getPost('tanggal');
        if (! Akses::pembiasaanInput($kelasId) || ! preg_match('/^\d{4}-\d{2}-\d{2}$/', $tanggal) || $tanggal > date('Y-m-d')) {
            return redirect()->back()->with('error', 'Data tidak valid atau akses ditolak.');
        }
        if (! Kalender::absensi($tanggal, $kelasId ?: null)) {
            return redirect()->back()->with('error', 'Siswa tidak masuk pada tanggal ini menurut kalender akademik (' . Kalender::status($tanggal, $kelasId ?: null)['label'] . ').');
        }
        $pbIds  = array_map('intval', (array) $this->request->getPost('pembiasaan_ids'));
        $siswa  = array_column(model(AnggotaKelasModel::class)->siswaKelas($kelasId, $this->tpId()), 'id');
        $cek    = (array) $this->request->getPost('cek');     // [siswa][pembiasaan] = 1
        $ket    = (array) $this->request->getPost('ket');     // [siswa] = keterangan
        $lama   = $this->catatan->petaKelasTanggal($kelasId, $tanggal);

        $db = db_connect();
        $db->transStart();
        foreach ($siswa as $sid) {
            foreach ($pbIds as $pid) {
                $data = [
                    'tahun_pelajaran_id' => $this->tpId(), 'kelas_id' => $kelasId, 'terlaksana' => isset($cek[$sid][$pid]) ? 1 : 0,
                    'keterangan' => trim($ket[$sid] ?? '') ?: null, 'dicatat_oleh' => $this->userId(), 'verifikasi' => 'Disetujui',
                ];
                if (($lama[$sid][$pid]['verifikasi'] ?? '') === 'Menunggu') {   // laporan siswa ikut diputuskan guru
                    $data += ['diverifikasi_oleh' => $this->userId(), 'diverifikasi_at' => date('Y-m-d H:i:s')];
                    unset($data['keterangan']);
                }
                $this->catatan->simpanUnik(['tanggal' => $tanggal, 'siswa_id' => (int) $sid, 'pembiasaan_id' => $pid], $data);
            }
        }
        $db->transComplete();

        return redirect()->to("/pembiasaan?kelas_id={$kelasId}&tanggal={$tanggal}")->with('success', 'Catatan pembiasaan tersimpan.');
    }

    /** Verifikasi laporan pembiasaan yang diisi siswa lewat portal. */
    public function verifikasi()
    {
        $kelasId = (int) $this->request->getPost('kelas_id');
        $aksi    = (string) $this->request->getPost('aksi');
        $ids     = array_map('intval', (array) $this->request->getPost('ids'));
        if (! Akses::pembiasaanInput($kelasId) || ! in_array($aksi, ['setujui', 'tolak'], true)) {
            return redirect()->back()->with('error', 'Akses ditolak.');
        }
        if (! $ids) {
            return redirect()->back()->with('warning', 'Centang laporan yang akan diverifikasi.');
        }
        $rows = $this->catatan->whereIn('id', $ids)->where(['kelas_id' => $kelasId, 'verifikasi' => 'Menunggu'])->findAll();
        foreach ($rows as $r) {
            $this->catatan->update($r['id'], [
                'verifikasi' => $aksi === 'setujui' ? 'Disetujui' : 'Ditolak',
                'terlaksana' => $aksi === 'setujui' ? (int) $r['lapor_siswa'] : 0,
                'diverifikasi_oleh' => $this->userId(), 'diverifikasi_at' => date('Y-m-d H:i:s'),
            ]);
        }
        return redirect()->back()->with('success', count($rows) . ' laporan siswa ' . ($aksi === 'setujui' ? 'disetujui.' : 'ditolak.'));
    }

    public function rekap()
    {
        if ($r = $this->wajibTp()) {
            return $r;
        }
        $kelas = $this->daftarKelas(Akses::pembiasaanLihatSemua());
        if (! $kelas) {
            return redirect()->to('/dashboard')->with('error', 'Anda tidak memiliki akses pembiasaan kelas mana pun.');
        }
        $kelasId = $this->pilihKelas($kelas);
        $dari    = $this->request->getGet('dari') ?: date('Y-m-01');
        $sampai  = $this->request->getGet('sampai') ?: date('Y-m-d');
        $nama    = '';
        foreach ($kelas as $k) {
            if ((int) $k['id'] === $kelasId) {
                $nama = $k['nama_kelas'];
            }
        }
        $rekap = $this->catatan->rekap($kelasId, $dari, $sampai);

        return view('kesiswaan/pembiasaan/rekap', [
            'title'      => 'Rekap Pembiasaan',
            'subtitle'   => $nama . ' · ' . tgl_indo($dari) . ' – ' . tgl_indo($sampai) . ' (' . $rekap['jumlah_hari'] . ' hari tercatat)',
            'kelas'      => $kelas,
            'kelasId'    => $kelasId,
            'dari'       => $dari,
            'sampai'     => $sampai,
            'pembiasaan' => $this->master->aktif(),
            'siswa'      => model(AnggotaKelasModel::class)->siswaKelas($kelasId, $this->tpId(), false),
            'data'       => $rekap['data'],
        ]);
    }

    // ---------------------------------------------------------------- master
    public function master()
    {
        $tingkat = array_values(array_unique(array_column(model(\App\Models\KelasModel::class)->where('is_active', 1)->orderBy('tingkat')->findAll(), 'tingkat')));
        return view('kesiswaan/pembiasaan/master', [
            'title'    => 'Pengaturan Pembiasaan',
            'subtitle' => 'Atur kegiatan pembiasaan: siapa yang mengisi (guru/siswa), tempat, verifikasi, catatan, hari, dan tingkat.',
            'rows'     => $this->master->orderBy('urutan')->orderBy('nama')->findAll(),
            'tingkat'  => $tingkat,
            'mundur'   => (int) setting('pembiasaan_mundur', 1),
            'ada7kaih' => (bool) $this->master->where('nama', 'Gemar belajar')->countAllResults(),
        ]);
    }

    public function pengaturan()
    {
        $n = max(0, min(7, (int) $this->request->getPost('pembiasaan_mundur')));
        model(\App\Models\PengaturanModel::class)->simpan('pembiasaan_mundur', (string) $n);
        return redirect()->to('/pembiasaan/master')->with('success', $n ? "Siswa boleh mengisi sampai {$n} hari ke belakang." : 'Siswa hanya boleh mengisi untuk hari ini.');
    }

    /** Tambahkan paket Gerakan 7 Kebiasaan Anak Indonesia Hebat (diisi siswa di rumah, diverifikasi wali kelas). */
    public function paket7kaih()
    {
        $n = 0;
        $u = (int) $this->master->selectMax('urutan')->first()['urutan'];
        foreach (PembiasaanModel::PAKET_7KAIH as [$nama, $desk, $petunjuk]) {
            if ($this->master->where('nama', $nama)->countAllResults()) {
                continue;
            }
            $this->master->insert(['nama' => $nama, 'kategori' => '7 Kebiasaan Anak Indonesia Hebat', 'deskripsi' => $desk, 'hari' => null,
                'pengisi' => 'Siswa', 'tempat' => 'Rumah', 'berlaku' => 'Sekolah', 'perlu_verifikasi' => 1, 'wajib_catatan' => 0, 'petunjuk_catatan' => $petunjuk,
                'urutan' => ++$u, 'is_active' => 1]);
            $n++;
        }
        return redirect()->to('/pembiasaan/master')->with('success', $n ? "{$n} kegiatan 7 Kebiasaan Anak Indonesia Hebat ditambahkan (diisi siswa di rumah pada hari masuk sekolah, diverifikasi wali kelas). Ubah ke \"Setiap hari\" bila ingin dipantau juga saat libur." : 'Paket 7 Kebiasaan sudah ada.');
    }

    public function store()
    {
        return $this->simpanMaster();
    }

    public function update($id)
    {
        return $this->simpanMaster((int) $id);
    }

    private function simpanMaster(?int $id = null)
    {
        if (! $this->validate(['nama' => 'required|max_length[100]'])) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }
        $hari = array_filter(array_map('intval', (array) $this->request->getPost('hari')));
        $data = [
            'nama'      => trim($this->request->getPost('nama')),
            'kategori'  => trim((string) $this->request->getPost('kategori')) ?: null,
            'deskripsi' => trim((string) $this->request->getPost('deskripsi')) ?: null,
            'hari'      => $hari && count($hari) < 7 ? implode(',', $hari) : null,
            'pengisi'   => array_key_exists((string) $this->request->getPost('pengisi'), PembiasaanModel::PENGISI) ? $this->request->getPost('pengisi') : 'Guru',
            'tempat'    => $this->request->getPost('tempat') === 'Rumah' ? 'Rumah' : 'Sekolah',
            'berlaku'   => $this->request->getPost('tempat') !== 'Rumah' ? 'Sekolah'
                : (array_key_exists((string) $this->request->getPost('berlaku'), PembiasaanModel::BERLAKU) ? $this->request->getPost('berlaku') : 'Semua'),
            'perlu_verifikasi' => $this->request->getPost('perlu_verifikasi') ? 1 : 0,
            'wajib_catatan'    => $this->request->getPost('wajib_catatan') ? 1 : 0,
            'petunjuk_catatan' => mb_substr(trim((string) $this->request->getPost('petunjuk_catatan')), 0, 100) ?: null,
            'tingkat'   => implode(',', array_filter(array_map('trim', (array) $this->request->getPost('tingkat')))) ?: null,
            'urutan'    => (int) $this->request->getPost('urutan'),
            'is_active' => $this->request->getPost('is_active') ? 1 : 0,
        ];
        $id ? $this->master->update($id, $data) : $this->master->insert($data);
        return redirect()->to('/pembiasaan/master')->with('success', 'Pembiasaan disimpan.');
    }

    public function delete($id)
    {
        if ($pesan = $this->masihDipakai(['catatan harian' => ['pembiasaan_siswa', ['pembiasaan_id' => (int) $id]]], 'Nonaktifkan saja agar rekap lama tetap utuh.')) {
            return redirect()->back()->with('error', $pesan);
        }
        $this->master->delete($id);
        catat_log('hapus', 'pembiasaan', (int) $id);
        return redirect()->to('/pembiasaan/master')->with('success', 'Pembiasaan dihapus beserta catatannya.');
    }
}
