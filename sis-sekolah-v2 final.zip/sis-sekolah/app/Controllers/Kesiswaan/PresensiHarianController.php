<?php

namespace App\Controllers\Kesiswaan;

use App\Controllers\BaseController;
use App\Models\AnggotaKelasModel;
use App\Libraries\Akses;
use App\Libraries\Kalender;
use App\Models\PresensiHarianModel;

/**
 * Absensi pagi / harian. Diisi wali kelas (kelasnya) atau guru piket / kesiswaan (semua kelas).
 */
class PresensiHarianController extends BaseController
{
    private PresensiHarianModel $model;

    public function __construct()
    {
        $this->model = new PresensiHarianModel();
    }

    private function pilihKelas(array $kelas): int
    {
        $id  = (int) ($this->request->getGet('kelas_id') ?? $this->request->getPost('kelas_id'));
        $ids = array_map('intval', array_column($kelas, 'id'));
        return in_array($id, $ids, true) ? $id : (int) (wali_kelas_ids()[0] ?? ($ids[0] ?? 0));
    }

    public function index()
    {
        if ($r = $this->wajibTp()) {
            return $r;
        }
        $tanggal = (string) ($this->request->getGet('tanggal') ?: date('Y-m-d'));
        if (! preg_match('/^\d{4}-\d{2}-\d{2}$/', $tanggal) || $tanggal > date('Y-m-d')) {
            $tanggal = date('Y-m-d');
        }
        $kelas = $this->daftarKelas(Akses::absensiLihatSemua() || Akses::absensiInputSemua($tanggal));
        if (! $kelas) {
            return redirect()->to('/dashboard')->with('error', 'Anda tidak memiliki akses absensi kelas mana pun.');
        }
        $kelasId = $this->pilihKelas($kelas);
        $siswa = model(AnggotaKelasModel::class)->siswaKelas($kelasId, $this->tpId());
        $data  = $this->model->petaKelasTanggal($kelasId, $tanggal);

        $ringkas = $this->model->ringkasTanggal($this->tpId(), $tanggal);
        return view('kesiswaan/absensi/index', [
            'title'    => 'Absensi Pagi',
            'subtitle' => 'Kehadiran harian siswa. Sakit/izin/alpa otomatis terbawa ke absensi mapel.',
            'kelas'    => $kelas,
            'kelasId'  => $kelasId,
            'tanggal'  => $tanggal,
            'status'   => Kalender::status($tanggal, $kelasId ?: null),
            'siswa'    => $siswa,
            'data'     => $data,
            'ringkas'  => $ringkas,
            'bisaInput' => Akses::absensiInput($kelasId, $tanggal) && Kalender::absensi($tanggal, $kelasId ?: null),
            'infoPiket' => in_array('piket', Akses::roles(), true) && ! Akses::admin()
                ? 'Hari piket Anda: ' . (implode(', ', array_map('nama_hari', Akses::hariPiket())) ?: 'belum dijadwalkan') . '.' : '',
        ]);
    }

    public function simpan()
    {
        if ($r = $this->wajibTp()) {
            return $r;
        }
        $kelasId = (int) $this->request->getPost('kelas_id');
        $tanggal = (string) $this->request->getPost('tanggal');
        if (! preg_match('/^\d{4}-\d{2}-\d{2}$/', $tanggal) || $tanggal > date('Y-m-d') || ! Akses::absensiInput($kelasId, $tanggal)) {
            return redirect()->back()->with('error', 'Data tidak valid atau akses ditolak.');
        }
        if (! Kalender::absensi($tanggal, $kelasId ?: null)) {
            return redirect()->back()->with('error', 'Tidak ada absensi pada tanggal ini menurut kalender akademik (' . Kalender::status($tanggal, $kelasId ?: null)['label'] . ').');
        }
        $jamMasuk = (string) setting('jam_masuk', '07:00');
        $lama     = $this->model->petaKelasTanggal($kelasId, $tanggal);
        $valid    = array_column(model(AnggotaKelasModel::class)->siswaKelas($kelasId, $this->tpId()), 'id');

        $db = db_connect();
        $db->transStart();
        foreach ((array) $this->request->getPost('absen') as $siswaId => $a) {
            if (! in_array((string) $siswaId, array_map('strval', $valid), true)) {
                continue;
            }
            $status = in_array($a['status'] ?? 'H', ['H', 'T', 'S', 'I', 'A'], true) ? $a['status'] : 'H';
            $jam    = ($a['jam_datang'] ?? '') ?: null;
            if ($status === 'H' && $jam && $jam > $jamMasuk) {
                $status = 'T';
            }
            $this->model->simpanUnik(['tanggal' => $tanggal, 'siswa_id' => (int) $siswaId], [
                'tahun_pelajaran_id' => $this->tpId(), 'kelas_id' => $kelasId,
                'status' => $status, 'jam_datang' => in_array($status, ['H', 'T'], true) ? $jam : null,
                'keterangan' => trim($a['keterangan'] ?? '') ?: null, 'dicatat_oleh' => $this->userId(),
                'sumber' => isset($lama[$siswaId]) ? ($lama[$siswaId]['sumber'] ?? 'Manual') : 'Manual',
            ]);
        }
        $db->transComplete();
        $sinkron = \App\Libraries\SinkronAbsensi::terapkan($valid, $tanggal);

        return redirect()->to("/absensi-pagi?kelas_id={$kelasId}&tanggal={$tanggal}")->with('success', 'Absensi pagi tersimpan.'
            . ($sinkron ? " {$sinkron} data absensi mapel yang terisi otomatis ikut diperbarui." : ''));
    }

    public function rekap()
    {
        if ($r = $this->wajibTp()) {
            return $r;
        }
        $kelas = $this->daftarKelas(Akses::absensiLihatSemua());
        if (! $kelas) {
            return redirect()->to('/dashboard')->with('error', 'Anda tidak memiliki akses kelas.');
        }
        $kelasId = $this->pilihKelas($kelas);
        $bulan   = (int) ($this->request->getGet('bulan') ?: date('n'));
        $tahun   = (int) ($this->request->getGet('tahun') ?: date('Y'));
        $nama    = '';
        foreach ($kelas as $k) {
            if ((int) $k['id'] === $kelasId) {
                $nama = $k['nama_kelas'];
            }
        }

        return view('kesiswaan/absensi/rekap', [
            'title'    => 'Rekap Absensi Pagi',
            'subtitle' => $nama . ' · ' . bulan_list()[$bulan] . ' ' . $tahun,
            'kelas'    => $kelas,
            'kelasId'  => $kelasId,
            'bulan'    => $bulan,
            'tahun'    => $tahun,
            'hari'     => (int) date('t', mktime(0, 0, 0, $bulan, 1, $tahun)),
            'siswa'    => model(AnggotaKelasModel::class)->siswaKelas($kelasId, $this->tpId(), false),
            'matriks'  => $this->model->matriksBulan($kelasId, $tahun, $bulan),
        ]);
    }
}
