<?php

namespace App\Controllers\Kesiswaan;

use App\Controllers\BaseController;
use App\Libraries\Akses;
use App\Libraries\PortalSiswa;
use App\Models\AnggotaKelasModel;
use App\Models\SiswaModel;

/** Akun portal siswa per kelas: status login, reset password ke bawaan, cetak kartu login. Untuk TU/admin, kesiswaan, dan wali kelas (kelasnya). */
class AkunSiswaController extends BaseController
{
    private function boleh(int $kelasId): bool
    {
        return Akses::masterData() || Akses::punya('kesiswaan') || Akses::waliKelas($kelasId);
    }

    private function kelasBoleh(): array
    {
        return $this->daftarKelas(Akses::masterData() || Akses::punya('kesiswaan'));
    }

    public function index()
    {
        if ($r = $this->wajibTp()) {
            return $r;
        }
        $kelas = $this->kelasBoleh();
        if (! $kelas) {
            return redirect()->to('/dashboard')->with('error', 'Akses ditolak.');
        }
        $ids     = array_map('intval', array_column($kelas, 'id'));
        $kelasId = (int) $this->request->getGet('kelas_id');
        $kelasId = in_array($kelasId, $ids, true) ? $kelasId : $ids[0];
        return view('kesiswaan/akun_siswa/index', [
            'title'    => 'Akun Portal Siswa',
            'subtitle' => 'Siswa masuk ke ' . site_url('portal') . ' dengan NISN/NIS. Password bawaan: tanggal lahir (ddmmyyyy).',
            'kelas'    => $kelas,
            'kelasId'  => $kelasId,
            'siswa'    => model(AnggotaKelasModel::class)->siswaKelas($kelasId, $this->tpId()),
            'aktif'    => PortalSiswa::aktif(),
        ]);
    }

    public function reset()
    {
        $kelasId = (int) $this->request->getPost('kelas_id');
        if (! $this->boleh($kelasId)) {
            return $this->back('error', 'Akses ditolak.');
        }
        $ids  = array_map('intval', (array) $this->request->getPost('ids'));
        $sah  = array_map('intval', array_column(model(AnggotaKelasModel::class)->siswaKelas($kelasId, $this->tpId()), 'id'));
        $ids  = array_values(array_intersect($ids, $sah));
        if (! $ids) {
            return $this->back('error', 'Pilih minimal satu siswa.');
        }
        model(SiswaModel::class)->builder()->whereIn('id', $ids)->update(['password' => null]);
        catat_log('reset_password_siswa', 'siswa', null, count($ids) . ' siswa kelas #' . $kelasId);
        return redirect()->to('/akun-siswa?kelas_id=' . $kelasId)->with('success', count($ids) . ' password siswa dikembalikan ke bawaan (tanggal lahir ddmmyyyy, atau NIS bila tanggal lahir kosong).');
    }

    /** Kartu login portal untuk satu kelas (password bawaan dicetak hanya untuk siswa yang belum menggantinya). */
    public function kartu()
    {
        $kelasId = (int) $this->request->getGet('kelas_id');
        if (! $this->tp || ! $this->boleh($kelasId)) {
            return redirect()->to('/akun-siswa')->with('error', 'Akses ditolak.');
        }
        $kelas = model(\App\Models\KelasModel::class)->find($kelasId);
        return view('kesiswaan/akun_siswa/kartu', [
            'judul'     => 'Kartu Login Portal Siswa',
            'subjudul'  => 'Kelas ' . ($kelas['nama_kelas'] ?? '') . ' · TP ' . $this->tp['tahun_pelajaran'],
            'orientasi' => 'portrait',
            'siswa'     => model(AnggotaKelasModel::class)->siswaKelas($kelasId, $this->tpId()),
            'alamat'    => site_url('portal'),
        ]);
    }
}
