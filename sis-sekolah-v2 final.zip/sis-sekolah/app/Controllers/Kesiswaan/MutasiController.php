<?php

namespace App\Controllers\Kesiswaan;

use App\Controllers\BaseController;
use App\Libraries\Akses;
use App\Models\AnggotaKelasModel;
use App\Models\KelasModel;
use App\Models\MutasiSiswaModel;
use App\Models\SiswaModel;

/**
 * Mutasi siswa: keluar (pindah sekolah/mengundurkan diri/dikeluarkan/meninggal), masuk (pindahan), pindah kelas.
 * Status siswa & rombel ikut diperbarui; riwayat absensi/jurnal tetap tersimpan. Mutasi terakhir siswa bisa dibatalkan.
 */
class MutasiController extends BaseController
{
    private MutasiSiswaModel $model;

    public function __construct()
    {
        $this->model = new MutasiSiswaModel();
    }

    public function index()
    {
        if ($r = $this->wajibTp()) {
            return $r;
        }
        if (! Akses::mutasiLihat()) {
            return redirect()->to('/dashboard')->with('error', 'Akses ditolak.');
        }
        $jenis = (string) $this->request->getGet('jenis');
        $rows  = $this->model->daftar($this->tpId(), ['jenis' => $jenis]);
        $hit   = ['masuk' => 0, 'keluar' => 0, 'pindah' => 0, 'lulus' => 0];
        foreach ($this->model->daftar($this->tpId()) as $m) {
            $k = $m['jenis'] === 'Masuk' ? 'masuk' : ($m['jenis'] === 'Pindah Kelas' ? 'pindah' : ($m['jenis'] === 'Lulus' ? 'lulus' : 'keluar'));
            $hit[$k]++;
        }
        // mutasi terakhir per siswa (yang boleh dibatalkan)
        $terakhir = [];
        foreach (db_connect()->table('mutasi_siswa')->select('siswa_id, MAX(id) AS id')->groupBy('siswa_id')->get()->getResultArray() as $t) {
            $terakhir[(int) $t['id']] = true;
        }
        return view('kesiswaan/mutasi/index', [
            'title'     => 'Mutasi Siswa',
            'subtitle'  => 'Siswa masuk, keluar, dan pindah kelas pada TP ' . $this->tp['tahun_pelajaran'] . ' ' . $this->tp['semester'] . '.',
            'rows'      => $rows,
            'jenis'     => $jenis,
            'hit'       => $hit,
            'terakhir'  => $terakhir,
            'kelola'    => Akses::mutasiKelola(),
            'kelas'     => model(KelasModel::class)->listAktif(),
            'siswa'     => model(SiswaModel::class)->dropdownAktif($this->tpId()),
        ]);
    }

    private function cekKelola()
    {
        if ($r = $this->wajibTp()) {
            return $r;
        }
        return Akses::mutasiKelola() ? null : $this->back('error', 'Hanya TU/admin dan kesiswaan yang dapat mencatat mutasi.');
    }

    private function tanggalValid(string $t): bool
    {
        return (bool) preg_match('/^\d{4}-\d{2}-\d{2}$/', $t) && strtotime($t) !== false;
    }

    /** Siswa keluar: pindah sekolah, mengundurkan diri, dikeluarkan, meninggal. */
    public function keluar()
    {
        if ($r = $this->cekKelola()) {
            return $r;
        }
        $sid   = (int) $this->request->getPost('siswa_id');
        $jenis = (string) $this->request->getPost('jenis');
        $tgl   = (string) $this->request->getPost('tanggal');
        $siswa = model(SiswaModel::class)->find($sid);
        if (! $siswa || $siswa['status'] !== 'Aktif' || ! in_array($jenis, MutasiSiswaModel::KELUAR, true) || ! $this->tanggalValid($tgl)) {
            return $this->back('error', 'Lengkapi siswa (yang masih aktif), jenis mutasi, dan tanggal.');
        }
        $ak    = model(AnggotaKelasModel::class);
        $rombel = $ak->where(['tahun_pelajaran_id' => $this->tpId(), 'siswa_id' => $sid])->first();
        [, $stSiswa, $stRombel] = MutasiSiswaModel::JENIS[$jenis];
        $db = db_connect();
        $db->transStart();
        $id = $this->model->insert([
            'tahun_pelajaran_id' => $this->tpId(), 'siswa_id' => $sid, 'jenis' => $jenis, 'tanggal' => $tgl,
            'kelas_asal_id' => $rombel['kelas_id'] ?? null, 'sekolah' => trim((string) $this->request->getPost('sekolah')) ?: null,
            'alasan' => trim((string) $this->request->getPost('alasan')) ?: null, 'no_surat' => trim((string) $this->request->getPost('no_surat')) ?: null,
            'status_sebelum' => $siswa['status'], 'dicatat_oleh' => $this->userId(),
        ]);
        model(SiswaModel::class)->update($sid, ['status' => $stSiswa]);
        if ($rombel) {
            $ak->update($rombel['id'], ['status' => $stRombel]);
        }
        $db->transComplete();
        catat_log('mutasi', 'siswa', $sid, $jenis . ' ' . $tgl);
        return redirect()->to('/mutasi')->with('success', "{$siswa['nama_lengkap']} dicatat " . strtolower(MutasiSiswaModel::JENIS[$jenis][0]) . '. Siswa tidak lagi muncul di absensi & jurnal; riwayatnya tetap tersimpan.');
    }

    /** Siswa masuk (pindahan): data baru atau siswa lama yang kembali (dicocokkan NISN/NIS). */
    public function masuk()
    {
        if ($r = $this->cekKelola()) {
            return $r;
        }
        $p    = fn ($k) => trim((string) $this->request->getPost($k)) ?: null;
        $data = [
            'nis' => $p('nis'), 'nisn' => $p('nisn'), 'nama_lengkap' => $p('nama_lengkap'), 'jenis_kelamin' => $p('jenis_kelamin'),
            'tempat_lahir' => $p('tempat_lahir'), 'tanggal_lahir' => $p('tanggal_lahir'), 'nama_wali' => $p('nama_wali'), 'no_hp_wali' => $p('no_hp_wali'), 'alamat' => $p('alamat'),
        ];
        $kelasId = (int) $this->request->getPost('kelas_id');
        $tgl     = (string) $this->request->getPost('tanggal');
        if (! $this->validateData($data + ['kelas_id' => $kelasId, 'tanggal' => $tgl], [
            'nis' => 'required|max_length[30]', 'nama_lengkap' => 'required|max_length[150]', 'jenis_kelamin' => 'required|in_list[L,P]',
            'nisn' => 'permit_empty|max_length[20]', 'tanggal_lahir' => 'permit_empty|valid_date[Y-m-d]', 'kelas_id' => 'required|is_natural_no_zero', 'tanggal' => 'required|valid_date[Y-m-d]',
        ])) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }
        $sm  = model(SiswaModel::class);
        $ada = ($data['nisn'] ? $sm->where('nisn', $data['nisn'])->first() : null) ?: $sm->where('nis', $data['nis'])->first();
        if ($ada && $ada['status'] === 'Aktif') {
            return $this->back('error', "NIS/NISN sudah dipakai siswa aktif ({$ada['nama_lengkap']}). Gunakan Pindah Kelas bila hanya pindah rombel.");
        }
        $db = db_connect();
        $db->transStart();
        $statusLama = $ada['status'] ?? null;
        if ($ada) {
            unset($data['nis']);
            $sm->update($ada['id'], array_filter($data, static fn ($v) => $v !== null) + ['status' => 'Aktif']);
            $sid = (int) $ada['id'];
        } else {
            $sid = (int) $sm->insert($data + ['status' => 'Aktif']);
        }
        $ak  = model(AnggotaKelasModel::class);
        $row = $ak->where(['tahun_pelajaran_id' => $this->tpId(), 'siswa_id' => $sid])->first();
        $row ? $ak->update($row['id'], ['kelas_id' => $kelasId, 'status' => 'Aktif', 'no_absen' => null])
             : $ak->insert(['tahun_pelajaran_id' => $this->tpId(), 'kelas_id' => $kelasId, 'siswa_id' => $sid, 'status' => 'Aktif']);
        $this->model->insert([
            'tahun_pelajaran_id' => $this->tpId(), 'siswa_id' => $sid, 'jenis' => 'Masuk', 'tanggal' => $tgl, 'kelas_tujuan_id' => $kelasId,
            'sekolah' => $p('sekolah'), 'alasan' => $p('alasan'), 'no_surat' => $p('no_surat'), 'status_sebelum' => $statusLama, 'dicatat_oleh' => $this->userId(),
        ]);
        $ak->urutkanAbsen($kelasId, $this->tpId());
        $db->transComplete();
        catat_log('mutasi', 'siswa', $sid, 'Masuk ' . $tgl);
        return redirect()->to('/mutasi')->with('success', ($ada ? 'Siswa lama diaktifkan kembali' : 'Siswa pindahan ditambahkan') . ' dan dimasukkan ke rombel.');
    }

    /** Pindah kelas di tengah tahun pelajaran (riwayat absensi kelas lama tetap). */
    public function pindahKelas()
    {
        if ($r = $this->cekKelola()) {
            return $r;
        }
        $sid     = (int) $this->request->getPost('siswa_id');
        $kelasId = (int) $this->request->getPost('kelas_id');
        $tgl     = (string) $this->request->getPost('tanggal');
        $ak      = model(AnggotaKelasModel::class);
        $row     = $ak->where(['tahun_pelajaran_id' => $this->tpId(), 'siswa_id' => $sid])->first();
        if (! $row || ! $kelasId || ! $this->tanggalValid($tgl)) {
            return $this->back('error', 'Pilih siswa yang sudah punya rombel, kelas tujuan, dan tanggal.');
        }
        if ((int) $row['kelas_id'] === $kelasId) {
            return $this->back('error', 'Kelas tujuan sama dengan kelas sekarang.');
        }
        $db = db_connect();
        $db->transStart();
        $this->model->insert([
            'tahun_pelajaran_id' => $this->tpId(), 'siswa_id' => $sid, 'jenis' => 'Pindah Kelas', 'tanggal' => $tgl,
            'kelas_asal_id' => $row['kelas_id'], 'kelas_tujuan_id' => $kelasId, 'alasan' => trim((string) $this->request->getPost('alasan')) ?: null,
            'status_sebelum' => 'Aktif', 'dicatat_oleh' => $this->userId(),
        ]);
        $ak->update($row['id'], ['kelas_id' => $kelasId, 'no_absen' => null]);
        $ak->urutkanAbsen($kelasId, $this->tpId());
        $ak->urutkanAbsen((int) $row['kelas_id'], $this->tpId());
        $db->transComplete();
        catat_log('mutasi', 'siswa', $sid, 'Pindah kelas ' . $tgl);
        return redirect()->to('/mutasi')->with('success', 'Siswa dipindahkan kelas. Absensi sebelum tanggal pindah tetap tercatat di kelas lama.');
    }

    /** Batalkan mutasi terakhir seorang siswa (salah input). */
    public function batal($id)
    {
        if ($r = $this->cekKelola()) {
            return $r;
        }
        $m = $this->model->find($id);
        if (! $m) {
            return $this->back('error', 'Data mutasi tidak ditemukan.');
        }
        $akhir = db_connect()->table('mutasi_siswa')->selectMax('id')->where('siswa_id', $m['siswa_id'])->get()->getRow('id');
        if ((int) $akhir !== (int) $id) {
            return $this->back('error', 'Hanya mutasi terakhir siswa yang dapat dibatalkan.');
        }
        $ak  = model(AnggotaKelasModel::class);
        $row = $ak->where(['tahun_pelajaran_id' => $m['tahun_pelajaran_id'], 'siswa_id' => $m['siswa_id']])->first();
        $db  = db_connect();
        $db->transStart();
        if (in_array($m['jenis'], MutasiSiswaModel::KELUAR, true) || $m['jenis'] === 'Lulus') {
            model(SiswaModel::class)->update($m['siswa_id'], ['status' => $m['status_sebelum'] ?: 'Aktif']);
            if ($row) {
                $ak->update($row['id'], ['status' => 'Aktif']);
            }
        } elseif ($m['jenis'] === 'Pindah Kelas' && $row && $m['kelas_asal_id']) {
            $ak->update($row['id'], ['kelas_id' => $m['kelas_asal_id'], 'no_absen' => null]);
            $ak->urutkanAbsen((int) $m['kelas_asal_id'], (int) $m['tahun_pelajaran_id']);
        } elseif ($m['jenis'] === 'Masuk') {
            if ($row) {
                $ak->delete($row['id']);
            }
            model(SiswaModel::class)->update($m['siswa_id'], ['status' => $m['status_sebelum'] ?: 'Pindah']);
        }
        $this->model->delete($id);
        $db->transComplete();
        catat_log('batal_mutasi', 'siswa', (int) $m['siswa_id'], $m['jenis']);
        return redirect()->to('/mutasi')->with('success', 'Mutasi dibatalkan dan status siswa dikembalikan.');
    }
}
