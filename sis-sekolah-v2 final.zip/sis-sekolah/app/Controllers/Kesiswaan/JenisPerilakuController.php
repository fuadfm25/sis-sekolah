<?php

namespace App\Controllers\Kesiswaan;

use App\Controllers\BaseController;
use App\Models\JenisPerilakuModel;

class JenisPerilakuController extends BaseController
{
    private JenisPerilakuModel $model;

    public function __construct()
    {
        $this->model = new JenisPerilakuModel();
    }

    public function index()
    {
        return view('kesiswaan/perilaku/jenis', [
            'title'    => 'Jenis Perilaku & Poin',
            'subtitle' => 'Referensi tata tertib: perilaku positif (prestasi) dan pelanggaran beserta poinnya.',
            'rows'     => $this->model->orderBy('kategori', 'DESC')->orderBy('tingkat')->orderBy('poin')->findAll(),
        ]);
    }

    public function store()
    {
        return $this->simpan();
    }

    public function update($id)
    {
        return $this->simpan((int) $id);
    }

    private function simpan(?int $id = null)
    {
        if (! $this->validate(['nama' => 'required|max_length[150]', 'kategori' => 'required|in_list[Positif,Negatif]', 'poin' => 'required|is_natural'])) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }
        $data = [
            'kategori'  => $this->request->getPost('kategori'),
            'nama'      => trim($this->request->getPost('nama')),
            'tingkat'   => $this->request->getPost('kategori') === 'Negatif' ? ($this->request->getPost('tingkat') ?: null) : null,
            'poin'      => (int) $this->request->getPost('poin'),
            'is_active' => $this->request->getPost('is_active') ? 1 : 0,
        ];
        $id ? $this->model->update($id, $data) : $this->model->insert($data);
        return redirect()->to('/perilaku/jenis')->with('success', 'Jenis perilaku disimpan.');
    }

    public function delete($id)
    {
        catat_log('hapus', 'jenis_perilaku', (int) $id);
        $this->model->delete($id);
        return redirect()->to('/perilaku/jenis')->with('success', 'Jenis perilaku dihapus (catatan lama tetap tersimpan).');
    }
}
