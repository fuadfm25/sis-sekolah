<?php

namespace App\Controllers\Kesiswaan;

use App\Controllers\BaseController;
use App\Libraries\Akses;
use App\Models\AnggotaKelasModel;
use App\Models\CatatanPerilakuModel;
use App\Models\JenisPerilakuModel;
use App\Models\KelasModel;
use App\Models\SiswaModel;

/**
 * Catatan perilaku siswa (positif / negatif + poin).
 * Aturan akses ada di App\Libraries\Akses (perilaku*).
 * Semua pengguna boleh mencatat; melihat/menindaklanjuti/mengelola dibatasi.
 */
class PerilakuController extends BaseController
{
    private CatatanPerilakuModel $model;

    public function __construct()
    {
        $this->model = new CatatanPerilakuModel();
    }

    public function index()
    {
        if ($r = $this->wajibTp()) {
            return $r;
        }
        $f = [];
        foreach (['kelas_id', 'kategori', 'status', 'dari', 'sampai', 'q', 'siswa_id'] as $k) {
            $f[$k] = $this->request->getGet($k);
        }
        $q = $f;
        if (! Akses::perilakuLihatSemua()) {
            $q['scope_user']  = $this->userId();
            $q['scope_kelas'] = wali_kelas_ids();
        }
        $rows = $this->model->daftar($this->tpId(), $q);

        return view('kesiswaan/perilaku/index', [
            'title'    => 'Catatan Perilaku Siswa',
            'subtitle' => Akses::perilakuLihatSemua() ? 'Seluruh catatan pada TP aktif.' : 'Catatan yang Anda buat' . (is_wali_kelas() ? ' dan seluruh catatan siswa kelas perwalian Anda.' : '.'),
            'rows'     => $rows,
            'pager'    => $this->model->pager,
            'f'        => $f,
            'kelas'    => Akses::perilakuLihatSemua() ? model(KelasModel::class)->listAktif() : $this->daftarKelas(false),
        ]);
    }

    public function create()
    {
        if ($r = $this->wajibTp()) {
            return $r;
        }
        return $this->form(null, (int) $this->request->getGet('siswa_id'));
    }

    public function edit($id)
    {
        $c = $this->model->find($id);
        if (! $c || ! Akses::perilakuKelola($c)) {
            return redirect()->to('/perilaku')->with('error', 'Catatan tidak ditemukan atau Anda tidak berhak mengubahnya.');
        }
        return $this->form($c, (int) $c['siswa_id']);
    }

    private function form(?array $c, int $siswaId)
    {
        return view('kesiswaan/perilaku/form', [
            'title'   => $c ? 'Edit Catatan Perilaku' : 'Catat Perilaku Siswa',
            'c'       => $c,
            'siswaId' => $siswaId,
            'siswa'   => model(SiswaModel::class)->dropdownAktif($this->tpId()),
            'jenis'   => model(JenisPerilakuModel::class)->aktif(),
        ]);
    }

    private function input(): array
    {
        $jenisId = (int) $this->request->getPost('jenis_perilaku_id');
        $jenis   = $jenisId ? model(JenisPerilakuModel::class)->find($jenisId) : null;
        $data    = [
            'siswa_id'          => (int) $this->request->getPost('siswa_id'),
            'tanggal'           => $this->request->getPost('tanggal'),
            'jenis_perilaku_id' => $jenis['id'] ?? null,
            'kategori'          => $jenis['kategori'] ?? $this->request->getPost('kategori'),
            'poin'              => max(0, (int) $this->request->getPost('poin')),
            'deskripsi'         => trim((string) $this->request->getPost('deskripsi')),
            'lokasi'            => trim((string) $this->request->getPost('lokasi')) ?: null,
            'tindak_lanjut'     => trim((string) $this->request->getPost('tindak_lanjut')) ?: null,
        ];
        $kelas             = model(AnggotaKelasModel::class)->kelasSiswa($data['siswa_id'], (int) $this->tpId());
        $data['kelas_id']  = $kelas['id'] ?? null;
        return $data;
    }

    private function rules(): array
    {
        return [
            'siswa_id'  => 'required|is_natural_no_zero',
            'tanggal'   => 'required|valid_date[Y-m-d]',
            'kategori'  => 'required|in_list[Positif,Negatif]',
            'deskripsi' => 'required',
        ];
    }

    public function store()
    {
        if ($r = $this->wajibTp()) {
            return $r;
        }
        if (! $this->validate($this->rules(), ['deskripsi' => ['required' => 'Uraian kejadian wajib diisi.']])) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }
        $data = $this->input() + [
            'tahun_pelajaran_id' => $this->tpId(),
            'dicatat_oleh'       => $this->userId(),
            'status'             => $this->request->getPost('rujuk_bk') ? 'Dirujuk BK' : ($this->request->getPost('tindak_lanjut') ? 'Ditindaklanjuti' : 'Tercatat'),
        ];
        $this->model->insert($data);

        $msg = 'Catatan perilaku tersimpan.';
        if ($data['kategori'] === 'Negatif') {
            $poin  = $this->model->poinSiswa($data['siswa_id'], $this->tpId());
            $batas = (int) setting('batas_poin_bk', 50);
            if ($poin['negatif'] >= $batas) {
                $msg .= " Perhatian: akumulasi poin pelanggaran siswa ini {$poin['negatif']} (batas {$batas}).";
                return redirect()->to($this->request->getPost('kembali') ?: '/perilaku')->with('warning', $msg);
            }
        }
        return redirect()->to($this->request->getPost('kembali') ?: '/perilaku')->with('success', $msg);
    }

    public function update($id)
    {
        $c = $this->model->find($id);
        if (! $c || ! Akses::perilakuKelola($c)) {
            return redirect()->to('/perilaku')->with('error', 'Akses ditolak.');
        }
        if (! $this->validate($this->rules())) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }
        $data = $this->input();
        if ($this->request->getPost('rujuk_bk') && in_array($c['status'], ['Tercatat', 'Ditindaklanjuti'], true)) {
            $data['status'] = 'Dirujuk BK';
        }
        $this->model->update($id, $data);
        return redirect()->to('/perilaku')->with('success', 'Catatan diperbarui.');
    }

    /** Ubah status + tindak lanjut (kesiswaan, bk, wali kelas siswa, pencatat). */
    public function status($id)
    {
        $c = $this->model->find($id);
        if (! $c || ! Akses::perilakuTindakLanjut($c)) {
            return redirect()->back()->with('error', 'Akses ditolak.');
        }
        $status = (string) $this->request->getPost('status');
        if (! in_array($status, CatatanPerilakuModel::STATUS, true)) {
            return redirect()->back()->with('error', 'Status tidak valid.');
        }
        $tl = trim((string) $this->request->getPost('tindak_lanjut'));
        $this->model->update($id, ['status' => $status, 'tindak_lanjut' => $tl !== '' ? $tl : $c['tindak_lanjut']]);
        return redirect()->back()->with('success', 'Status catatan diperbarui.');
    }

    public function delete($id)
    {
        $c = $this->model->find($id);
        if (! $c || ! Akses::perilakuKelola($c)) {
            return redirect()->back()->with('error', 'Akses ditolak.');
        }
        catat_log('hapus', 'catatan_perilaku', (int) $id);
        $this->model->delete($id);
        return redirect()->back()->with('success', 'Catatan dihapus.');
    }

    /** Rekap akumulasi poin per siswa. */
    public function rekap()
    {
        if ($r = $this->wajibTp()) {
            return $r;
        }
        if (! Akses::rekapPoin()) {
            return redirect()->to('/perilaku')->with('error', 'Rekap poin hanya untuk kesiswaan, BK, kepala sekolah, dan wali kelas.');
        }
        $kelasIds = Akses::perilakuLihatSemua() ? null : wali_kelas_ids();
        $kelasId  = (int) $this->request->getGet('kelas_id');
        if ($kelasId && ($kelasIds === null || in_array($kelasId, $kelasIds, true))) {
            $kelasIds = [$kelasId];
        }
        return view('kesiswaan/perilaku/rekap', [
            'title'    => 'Rekap Poin Perilaku',
            'subtitle' => 'Akumulasi poin positif & pelanggaran per siswa pada TP aktif.',
            'rows'     => $this->model->akumulasiPoin($this->tpId(), $kelasIds),
            'kelas'    => Akses::perilakuLihatSemua() ? model(KelasModel::class)->listAktif() : $this->daftarKelas(false),
            'kelasId'  => $kelasId,
            'batas'    => (int) setting('batas_poin_bk', 50),
        ]);
    }
}
