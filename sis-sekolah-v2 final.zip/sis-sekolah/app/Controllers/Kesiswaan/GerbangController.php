<?php

namespace App\Controllers\Kesiswaan;

use App\Controllers\BaseController;
use App\Libraries\Akses;
use App\Libraries\IzinKeluar;
use App\Models\AnggotaKelasModel;
use App\Models\IzinSiswaModel;
use App\Models\SiswaModel;

/**
 * Pos gerbang (satpam): cek izin keluar siswa (scan kartu / NIS / nama), catat keluar, catat kembali.
 * Terlambat kembali ≤ toleransi menit = "Terlambat kembali"; lebih dari itu atau tidak kembali = "Membolos".
 */
class GerbangController extends BaseController
{
    private IzinSiswaModel $izin;

    public function __construct()
    {
        $this->izin = new IzinSiswaModel();
    }

    public function index()
    {
        if ($r = $this->wajibTp()) {
            return $r;
        }
        if (! Akses::gerbang()) {
            return redirect()->to('/dashboard')->with('error', 'Halaman gerbang hanya untuk satpam, guru piket hari ini, dan kesiswaan.');
        }
        IzinKeluar::perbarui();
        $hari  = date('Y-m-d');
        $rows  = $this->izin->pulangAwal($hari, $this->tpId());
        $q     = trim((string) $this->request->getGet('q'));
        $hasil = null;
        $calon = [];
        if ($q !== '') {
            $siswa = model(SiswaModel::class)->cariKartu($q)
                ?? model(SiswaModel::class)->where('status', 'Aktif')->groupStart()->where('nis', $q)->orWhere('nisn', $q)->groupEnd()->first();
            if (! $siswa) {
                $calon = model(SiswaModel::class)->select('siswa.id, siswa.nama_lengkap, siswa.nis, kelas.nama_kelas')
                    ->join('anggota_kelas', 'anggota_kelas.siswa_id = siswa.id AND anggota_kelas.tahun_pelajaran_id = ' . $this->tpId())
                    ->join('kelas', 'kelas.id = anggota_kelas.kelas_id')
                    ->where('siswa.status', 'Aktif')->like('siswa.nama_lengkap', $q)->orderBy('siswa.nama_lengkap')->findAll(10);
                if (count($calon) === 1) {
                    $siswa = model(SiswaModel::class)->find($calon[0]['id']);
                    $calon = [];
                }
            }
            if ($siswa) {
                $kelas = model(AnggotaKelasModel::class)->kelasSiswa((int) $siswa['id'], $this->tpId());
                $izin  = $this->izin->where('siswa_id', $siswa['id'])->where('tanggal_mulai <=', $hari)->where('tanggal_selesai >=', $hari)->orderBy('id', 'DESC')->findAll();
                $hasil = ['siswa' => $siswa, 'kelas' => $kelas, 'keluar' => array_values(array_filter($izin, static fn ($z) => ! empty($z['jam_keluar']))),
                    'sehari' => array_values(array_filter($izin, static fn ($z) => empty($z['jam_keluar'])))];
            }
        }

        return view('kesiswaan/gerbang/index', [
            'title'     => 'Pos Gerbang',
            'subtitle'  => 'Cek izin keluar siswa, catat keluar & kembali. ' . tgl_indo($hari, true),
            'q'         => $q,
            'hasil'     => $hasil,
            'calon'     => $calon,
            'rows'      => $rows,
            'toleransi' => IzinKeluar::toleransi(),
            'koreksi'   => Akses::punya('kesiswaan') || Akses::piketPada($hari),
        ]);
    }

    private function izinHariIni(int $id): ?array
    {
        $z = $this->izin->find($id);
        return $z && $z['tanggal_mulai'] === date('Y-m-d') && ! empty($z['jam_keluar']) ? $z : null;
    }

    public function keluar($id)
    {
        if (! Akses::gerbang()) {
            return $this->back('error', 'Akses ditolak.');
        }
        $z = $this->izinHariIni((int) $id);
        if (! $z) {
            return $this->back('error', 'Izin keluar tidak ditemukan atau bukan untuk hari ini.');
        }
        if (! empty($z['keluar_at'])) {
            return $this->back('warning', 'Siswa sudah tercatat keluar pukul ' . substr($z['keluar_at'], 11, 5) . '.');
        }
        if (IzinKeluar::sementara($z) && date('H:i') >= substr($z['batas_kembali'], 0, 5)) {
            return $this->back('error', 'Batas kembali izin ini (' . substr($z['batas_kembali'], 0, 5) . ') sudah lewat. Minta guru piket menerbitkan izin baru.');
        }
        $this->izin->update($z['id'], ['keluar_at' => date('Y-m-d H:i:s'), 'keluar_oleh' => $this->userId()]);
        IzinKeluar::simpanStatus($this->izin->find($z['id']), $this->userId(), true);
        catat_log('ubah', 'izin_siswa', (int) $z['id'], 'keluar gerbang');
        $nama = model(SiswaModel::class)->find($z['siswa_id'])['nama_lengkap'] ?? '';
        return redirect()->to('/gerbang')->with('success', $nama . ' tercatat keluar pukul ' . date('H:i') . '.'
            . (IzinKeluar::sementara($z) ? ' Wajib kembali paling lambat ' . substr($z['batas_kembali'], 0, 5) . '.' : ''));
    }

    public function kembali($id)
    {
        if (! Akses::gerbang()) {
            return $this->back('error', 'Akses ditolak.');
        }
        $z = $this->izinHariIni((int) $id);
        if (! $z || ! IzinKeluar::sementara($z)) {
            return $this->back('error', 'Izin keluar sementara tidak ditemukan atau bukan untuk hari ini.');
        }
        $koreksi = Akses::punya('kesiswaan') || Akses::piketPada(date('Y-m-d'));
        $jam     = trim((string) $this->request->getPost('jam'));
        if ($jam !== '' && ! $koreksi) {
            return $this->back('error', 'Hanya guru piket/kesiswaan yang boleh mengisi jam kembali secara manual.');
        }
        if (! empty($z['kembali_at']) && ! ($koreksi && $jam !== '')) {
            return $this->back('warning', 'Siswa sudah tercatat kembali pukul ' . substr($z['kembali_at'], 11, 5) . '.');
        }
        if ($jam !== '' && ! preg_match('/^([01]\d|2[0-3]):[0-5]\d$/', $jam)) {
            return $this->back('error', 'Format jam kembali harus JJ:MM.');
        }
        $data = ['kembali_at' => date('Y-m-d') . ' ' . ($jam !== '' ? $jam . ':00' : date('H:i:s')), 'kembali_oleh' => $this->userId()];
        if (empty($z['keluar_at'])) {   // satpam lupa mencatat keluar: anggap keluar sesuai jam izin
            $data['keluar_at'] = date('Y-m-d') . ' ' . substr($z['jam_keluar'], 0, 5) . ':00';
            $data['keluar_oleh'] = $this->userId();
        }
        if ($data['kembali_at'] < ($data['keluar_at'] ?? $z['keluar_at'])) {
            return $this->back('error', 'Jam kembali tidak boleh sebelum jam keluar.');
        }
        $this->izin->update($z['id'], $data);
        $z = $this->izin->find($z['id']);
        IzinKeluar::simpanStatus($z, $this->userId(), true);
        $s = IzinKeluar::status($z);
        catat_log('ubah', 'izin_siswa', (int) $z['id'], 'kembali ' . substr($data['kembali_at'], 11, 5) . ' – ' . $s['status']);
        $nama  = model(SiswaModel::class)->find($z['siswa_id'])['nama_lengkap'] ?? '';
        $jenis = ['Kembali' => 'success', 'Terlambat kembali' => 'warning', 'Membolos' => 'error'][$s['status']] ?? 'success';
        return redirect()->to('/gerbang')->with($jenis, $nama . ' kembali pukul ' . substr($data['kembali_at'], 11, 5) . ': ' . strtoupper($s['status'])
            . ($s['menit'] ? ' (' . $s['menit'] . ' menit setelah batas ' . substr($z['batas_kembali'], 0, 5) . ')' : '') . '.');
    }
}
