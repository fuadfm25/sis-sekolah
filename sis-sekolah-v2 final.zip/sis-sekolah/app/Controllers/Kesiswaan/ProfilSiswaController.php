<?php

namespace App\Controllers\Kesiswaan;

use App\Controllers\BaseController;
use App\Libraries\Akses;
use App\Models\AnggotaKelasModel;
use App\Models\BkLayananModel;
use App\Models\CatatanPerilakuModel;
use App\Models\PembiasaanSiswaModel;
use App\Models\PresensiHarianModel;
use App\Models\SiswaModel;
use App\Models\WaliKelasModel;

/**
 * Profil 360° siswa: identitas, kehadiran, pembiasaan, perilaku, layanan BK.
 */
class ProfilSiswaController extends BaseController
{
    public function index($id)
    {
        $siswa = model(SiswaModel::class)->find($id);
        if (! $siswa) {
            return redirect()->back()->with('error', 'Siswa tidak ditemukan.');
        }
        $tpId  = $this->tpId();
        $kelas = $tpId ? model(AnggotaKelasModel::class)->kelasSiswa((int) $id, $tpId) : null;

        $level = Akses::profilSiswa($kelas ? (int) $kelas['id'] : null);
        if ($level === null) {
            return redirect()->to('/dashboard')->with('error', 'Anda tidak berwenang membuka profil siswa ini.');
        }
        $aksesPenuh = $level === 'penuh';
        $isBk       = Akses::modulBk();

        $perilaku = $tpId ? model(CatatanPerilakuModel::class)->riwayatSiswa((int) $id, $tpId) : [];
        if (! $aksesPenuh) {
            $perilaku = array_values(array_filter($perilaku, fn ($p) => (int) $p['dicatat_oleh'] === $this->userId()));
        }

        $bk = [];
        if ($isBk) {
            foreach (model(BkLayananModel::class)->riwayatSiswa((int) $id) as $l) {
                $l['tersembunyi'] = ! Akses::bkBuka($l);
                $bk[] = $l;
            }
        }

        return view('kesiswaan/profil/index', [
            'title'      => 'Profil Siswa',
            'subtitle'   => $siswa['nama_lengkap'] . ($kelas ? ' · ' . $kelas['nama_kelas'] : ''),
            'siswa'      => $siswa,
            'kelas'      => $kelas,
            'wali'       => $kelas ? model(WaliKelasModel::class)->waliDari((int) $kelas['id'], $tpId) : null,
            'aksesPenuh' => $aksesPenuh,
            'isBk'       => $isBk,
            'presensi'   => $tpId ? model(PresensiHarianModel::class)->totalSiswa((int) $id, $tpId) : [],
            'pembiasaan' => ($tpId && $aksesPenuh) ? model(PembiasaanSiswaModel::class)->ringkasSiswa((int) $id, $tpId) : [],
            'poin'       => $tpId ? model(CatatanPerilakuModel::class)->poinSiswa((int) $id, $tpId) : ['positif' => 0, 'negatif' => 0],
            'perilaku'   => $perilaku,
            'bk'         => $bk,
        ]);
    }
}
