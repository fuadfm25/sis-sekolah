<?php

namespace App\Controllers\Kesiswaan;

use App\Controllers\BaseController;
use App\Libraries\Akses;
use App\Libraries\Berkas;
use App\Libraries\Kalender;
use App\Models\AnggotaKelasModel;
use App\Models\IzinSiswaModel;
use App\Models\PresensiHarianModel;

/**
 * Izin / sakit / dispensasi siswa beserta lampiran surat. Menyimpan izin otomatis mengisi absensi harian
 * pada hari-hari sekolah dalam rentang izin (tidak menimpa siswa yang sudah tercatat hadir).
 */
class IzinSiswaController extends BaseController
{
    private IzinSiswaModel $model;

    public function __construct()
    {
        $this->model = new IzinSiswaModel();
    }

    private function kelasBoleh(): array
    {
        return $this->daftarKelas(Akses::absensiLihatSemua() || Akses::punya('kesiswaan') || Akses::piketPada(date('Y-m-d')));
    }

    public function index()
    {
        if ($r = $this->wajibTp()) {
            return $r;
        }
        \App\Libraries\IzinKeluar::perbarui();
        $kelas = $this->kelasBoleh();
        if (! $kelas) {
            return redirect()->to('/dashboard')->with('error', 'Anda tidak memiliki akses ke izin siswa.');
        }
        $ids     = array_map('intval', array_column($kelas, 'id'));
        $kelasId = (int) $this->request->getGet('kelas_id');
        $dari    = (string) ($this->request->getGet('dari') ?: date('Y-m-d', strtotime('-30 days')));
        $sampai  = (string) ($this->request->getGet('sampai') ?: date('Y-m-d', strtotime('+30 days')));
        $siswa   = [];
        foreach ($kelas as $k) {
            if (Akses::izinSiswaInput((int) $k['id'])) {
                foreach (model(AnggotaKelasModel::class)->siswaKelas((int) $k['id'], $this->tpId()) as $s) {
                    $siswa[] = $s + ['nama_kelas' => $k['nama_kelas']];
                }
            }
        }
        return view('kesiswaan/izin/index', [
            'title'    => 'Izin & Sakit Siswa',
            'subtitle' => 'Catat surat izin/sakit/dispensasi; absensi harian terisi otomatis pada rentang tanggalnya.',
            'kelas'    => $kelas,
            'kelasId'  => $kelasId,
            'dari'     => $dari,
            'sampai'   => $sampai,
            'rows'     => $this->model->daftar($this->tpId(), ['kelas_ids' => $kelasId && in_array($kelasId, $ids, true) ? [$kelasId] : $ids, 'dari' => $dari, 'sampai' => $sampai]),
            'siswa'    => $siswa,
        ]);
    }

    public function simpan()
    {
        if ($r = $this->wajibTp()) {
            return $r;
        }
        $siswaId = (int) $this->request->getPost('siswa_id');
        $kelas   = model(AnggotaKelasModel::class)->kelasSiswa($siswaId, $this->tpId());
        if (! $kelas || ! Akses::izinSiswaInput((int) $kelas['id'])) {
            return $this->back('error', 'Siswa tidak ditemukan atau Anda tidak berhak mencatat izin untuk kelas tersebut.');
        }
        $data = [
            'siswa_id'        => $siswaId,
            'tanggal_mulai'   => (string) $this->request->getPost('tanggal_mulai'),
            'tanggal_selesai' => (string) ($this->request->getPost('tanggal_selesai') ?: $this->request->getPost('tanggal_mulai')),
            'jenis'           => (string) $this->request->getPost('jenis'),
            'keterangan'      => trim((string) $this->request->getPost('keterangan')) ?: null,
            'jam_keluar'      => trim((string) $this->request->getPost('jam_keluar')) ?: null,
            'penjemput'       => trim((string) $this->request->getPost('penjemput')) ?: null,
            'batas_kembali'   => trim((string) $this->request->getPost('batas_kembali')) ?: null,
            'dicatat_oleh'    => $this->userId(),
        ];
        $mode = (string) $this->request->getPost('mode');
        if ($mode === 'hari' || ($mode === '' && ! $data['jam_keluar'])) {
            $data['jam_keluar'] = $data['batas_kembali'] = $data['penjemput'] = null;
        } elseif ($mode === 'pulang') {
            $data['batas_kembali'] = null;
        }
        if ($data['jam_keluar']) {   // izin keluar/pulang awal hanya untuk satu hari
            $data['tanggal_selesai'] = $data['tanggal_mulai'];
            if (! $data['jam_keluar'] || ($mode === 'sementara' && ! $data['batas_kembali'])) {
                return $this->back('error', 'Isi jam keluar dan batas kembali.');
            }
        } elseif (in_array($mode, ['pulang', 'sementara'], true)) {
            return $this->back('error', 'Jam keluar wajib diisi.');
        }
        if (! $this->validateData($data, [
            'tanggal_mulai'   => 'required|valid_date[Y-m-d]',
            'tanggal_selesai' => 'required|valid_date[Y-m-d]',
            'jenis'           => 'required|in_list[S,I,D]',
            'keterangan'      => 'permit_empty|max_length[255]',
            'jam_keluar'      => 'permit_empty|regex_match[/^([01]\d|2[0-3]):[0-5]\d(:\d\d)?$/]',
            'penjemput'       => 'permit_empty|max_length[100]',
            'batas_kembali'   => 'permit_empty|regex_match[/^([01]\d|2[0-3]):[0-5]\d(:\d\d)?$/]',
        ], ['jam_keluar' => ['regex_match' => 'Format jam keluar harus JJ:MM, mis. 10:15.']])) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }
        if ($data['tanggal_selesai'] < $data['tanggal_mulai']) {
            return $this->back('error', 'Tanggal selesai tidak boleh sebelum tanggal mulai.');
        }
        if ($data['batas_kembali'] && substr($data['batas_kembali'], 0, 5) <= substr($data['jam_keluar'], 0, 5)) {
            return $this->back('error', 'Batas kembali harus sesudah jam keluar.');
        }
        if ((strtotime($data['tanggal_selesai']) - strtotime($data['tanggal_mulai'])) / 86400 > 31) {
            return $this->back('error', 'Rentang izin maksimal 31 hari. Untuk izin panjang, buat beberapa catatan.');
        }
        [$lampiran, $err] = Berkas::simpan($this->request->getFile('lampiran'), 'izin_siswa', ['pdf', 'jpg', 'jpeg', 'png']);
        if ($err) {
            return $this->back('error', $err);
        }
        $data['lampiran'] = $lampiran;
        $id               = (int) $this->model->insert($data);
        $n                = $data['jam_keluar'] ? $this->terapkanPulang($id, $data, (int) $kelas['id']) : $this->terapkan($id, $data, (int) $kelas['id']);
        if ($data['jam_keluar']) {
            \App\Libraries\IzinKeluar::simpanStatus($this->model->find($id), $this->userId());
        }
        $m                = $this->sinkronMapel($data);
        catat_log('tambah', 'izin_siswa', $id, IzinSiswaModel::JENIS[$data['jenis']] . ' ' . $data['tanggal_mulai'] . '..' . $data['tanggal_selesai'] . ($data['jam_keluar'] ? ' pulang ' . $data['jam_keluar'] : ''));
        $satpam = \App\Libraries\IzinKeluar::verifikasiSatpam() ? ' Izin berlaku setelah satpam mencatat siswa keluar gerbang.' : '';
        $pesan = $data['batas_kembali']
            ? 'Izin keluar ' . substr($data['jam_keluar'], 0, 5) . '–' . substr($data['batas_kembali'], 0, 5) . ' diterbitkan.' . $satpam
                . ' Terlambat kembali lebih dari ' . \App\Libraries\IzinKeluar::toleransi() . ' menit dicatat membolos.'
            : ($data['jam_keluar'] ? 'Izin pulang pukul ' . substr($data['jam_keluar'], 0, 5) . ' tersimpan. Absensi mapel jam berikutnya otomatis ' . IzinSiswaModel::JENIS[$data['jenis']] . '.' . $satpam
            : "Izin tersimpan; {$n['isi']} hari absensi terisi otomatis." . ($n['hadir'] ? " {$n['hadir']} hari dilewati karena siswa sudah tercatat hadir." : ''));
        return redirect()->to('/izin-siswa?kelas_id=' . $kelas['id'])->with('success', $pesan . ($m ? " {$m} absensi mapel yang sudah diisi ikut diperbarui." : ''));
    }

    /** Isi absensi harian pada hari sekolah dalam rentang izin. */
    private function terapkan(int $izinId, array $izin, int $kelasId): array
    {
        $ph     = model(PresensiHarianModel::class);
        $status = IzinSiswaModel::statusAbsen($izin['jenis']);
        $ket    = IzinSiswaModel::JENIS[$izin['jenis']] . ($izin['keterangan'] ? ': ' . $izin['keterangan'] : '') . ' (surat izin)';
        $n      = ['isi' => 0, 'hadir' => 0];
        foreach (Kalender::tanggal($izin['tanggal_mulai'], $izin['tanggal_selesai']) as $d) {
            if (! Kalender::absensi($d, $kelasId)) {
                continue;
            }
            $ada = $ph->where(['siswa_id' => $izin['siswa_id'], 'tanggal' => $d])->first();
            if ($ada && in_array($ada['status'], ['H', 'T'], true) && empty($ada['izin_siswa_id'])) {
                if ($izin['jenis'] === 'D') {   // dispensasi tetap hadir; cukup beri keterangan
                    $ph->update($ada['id'], ['keterangan' => mb_substr(trim(($ada['keterangan'] ? $ada['keterangan'] . '; ' : '') . $ket), 0, 150)]);
                    $n['isi']++;
                    continue;
                }
                $n['hadir']++;
                continue;
            }
            $ph->simpanUnik(['tanggal' => $d, 'siswa_id' => (int) $izin['siswa_id']], [
                'tahun_pelajaran_id' => $this->tpId(), 'kelas_id' => $kelasId, 'status' => $status, 'jam_datang' => null,
                'keterangan' => mb_substr($ket, 0, 255), 'sumber' => 'Izin', 'izin_siswa_id' => $izinId, 'dicatat_oleh' => $this->userId(),
            ]);
            $n['isi']++;
        }
        return $n;
    }

    /** Izin keluar/pulang awal: siswa tetap hadir di absensi pagi, diberi keterangan jam pulang. */
    private function terapkanPulang(int $izinId, array $izin, int $kelasId): array
    {
        $ph  = model(PresensiHarianModel::class);
        $tag = empty($izin['batas_kembali']) ? self::tagPulang($izin) : null;
        $ada = $ph->where(['siswa_id' => $izin['siswa_id'], 'tanggal' => $izin['tanggal_mulai']])->first();
        if ($ada && $tag === null) {
            // keluar sementara: keterangan "[keluar ...]" diatur IzinKeluar
        } elseif ($ada) {
            $ph->update($ada['id'], ['keterangan' => mb_substr(trim(($ada['keterangan'] ? $ada['keterangan'] . '; ' : '') . $tag), 0, 150)]);
        } else {
            $ph->simpanUnik(['tanggal' => $izin['tanggal_mulai'], 'siswa_id' => (int) $izin['siswa_id']], [
                'tahun_pelajaran_id' => $this->tpId(), 'kelas_id' => $kelasId, 'status' => 'H', 'keterangan' => $tag,
                'sumber' => 'Izin', 'izin_siswa_id' => $izinId, 'dicatat_oleh' => $this->userId(),
            ]);
        }
        return ['isi' => 1, 'hadir' => 0];
    }

    private static function tagPulang(array $izin): string
    {
        return 'pulang ' . substr((string) $izin['jam_keluar'], 0, 5) . ' (' . strtolower(IzinSiswaModel::JENIS[$izin['jenis']]) . ')';
    }

    /** Perbarui absensi mapel yang sudah diisi pada rentang izin. */
    private function sinkronMapel(array $izin): int
    {
        $n = 0;
        foreach (Kalender::tanggal($izin['tanggal_mulai'], min($izin['tanggal_selesai'], date('Y-m-d'))) as $d) {
            $n += \App\Libraries\SinkronAbsensi::terapkan([(int) $izin['siswa_id']], $d);
        }
        return $n;
    }

    public function hapus($id)
    {
        $row   = $this->model->find($id);
        $kelas = $row ? model(AnggotaKelasModel::class)->kelasSiswa((int) $row['siswa_id'], $this->tpId()) : null;
        if (! $row || ! $kelas || ! Akses::izinSiswaInput((int) $kelas['id'])) {
            return $this->back('error', 'Akses ditolak.');
        }
        // absensi yang berasal dari izin ini dihapus (kembali kosong) kecuali sudah diubah manual
        model(PresensiHarianModel::class)->where(['izin_siswa_id' => (int) $id, 'sumber' => 'Izin'])->delete();
        db_connect()->table('presensi_harian')->where('izin_siswa_id', (int) $id)->update(['izin_siswa_id' => null]);
        if (! empty($row['catatan_perilaku_id'])) {   // catatan perilaku otomatis (belum ditindaklanjuti) ikut dihapus
            db_connect()->table('catatan_perilaku')->where(['id' => $row['catatan_perilaku_id'], 'status' => 'Tercatat'])->delete();
        }
        if (! empty($row['batas_kembali'])) {
            \App\Libraries\IzinKeluar::keteranganPagi(['siswa_id' => $row['siswa_id'], 'tanggal_mulai' => $row['tanggal_mulai']]);
        } elseif (! empty($row['jam_keluar']) || $row['jenis'] === 'D') {   // buang keterangan yang ditambahkan izin ini
            $tag = ! empty($row['jam_keluar']) ? self::tagPulang($row)
                : IzinSiswaModel::JENIS['D'] . ($row['keterangan'] ? ': ' . $row['keterangan'] : '') . ' (surat izin)';
            foreach (model(PresensiHarianModel::class)->where(['siswa_id' => $row['siswa_id'], 'tanggal >=' => $row['tanggal_mulai'], 'tanggal <=' => $row['tanggal_selesai']])->findAll() as $p) {
                $ket = trim(str_replace(['; ' . $tag, $tag], '', (string) $p['keterangan'])) ?: null;
                model(PresensiHarianModel::class)->update($p['id'], ['keterangan' => $ket]);
            }
        }
        Berkas::hapus('izin_siswa', $row['lampiran']);
        $this->model->delete($id);
        $this->sinkronMapel($row);
        catat_log('hapus', 'izin_siswa', (int) $id);
        return redirect()->to('/izin-siswa?kelas_id=' . $kelas['id'])->with('success', 'Izin dihapus beserta absensi otomatisnya.');
    }

    public function lampiran($id)
    {
        $row   = $this->model->find($id);
        $kelas = $row ? model(AnggotaKelasModel::class)->kelasSiswa((int) $row['siswa_id'], $this->tpId()) : null;
        if (! $row || ! $kelas || ! (Akses::izinSiswaLihat((int) $kelas['id']) || Akses::izinSiswaInput((int) $kelas['id']))) {
            return $this->back('error', 'Akses ditolak.');
        }
        $p = Berkas::path('izin_siswa', $row['lampiran']);
        if (! $p) {
            return $this->back('error', 'Lampiran tidak ditemukan.');
        }
        return $this->response->download($p, null)->setFileName('surat_izin_' . $row['siswa_id'] . '_' . $row['tanggal_mulai'] . '.' . pathinfo($p, PATHINFO_EXTENSION))->inline();
    }
}
