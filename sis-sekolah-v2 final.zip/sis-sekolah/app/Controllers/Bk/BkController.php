<?php

namespace App\Controllers\Bk;

use App\Controllers\BaseController;
use App\Libraries\Akses;
use App\Models\BkLayananModel;
use App\Models\CatatanPerilakuModel;
use App\Models\KelasModel;
use App\Models\SiswaModel;

/**
 * Modul Guru Bimbingan & Konseling.
 * Layanan bertanda rahasia hanya dapat dibuka oleh konselor pembuatnya (dan admin).
 */
class BkController extends BaseController
{
    private BkLayananModel $model;

    public function __construct()
    {
        $this->model = new BkLayananModel();
    }


    public function index()
    {
        if ($r = $this->wajibTp()) {
            return $r;
        }
        $cp    = model(CatatanPerilakuModel::class);
        $batas = (int) setting('batas_poin_bk', 50);

        $agenda = $this->model->base()->where(['bk_layanan.tahun_pelajaran_id' => $this->tpId()])
            ->whereIn('bk_layanan.status', ['Dijadwalkan', 'Berlangsung'])->orderBy('bk_layanan.tanggal')->limit(10)->find();

        return view('bk/index', [
            'title'     => 'Dashboard BK',
            'subtitle'  => 'Rujukan, siswa prioritas, dan agenda layanan.',
            'rujukan'   => $cp->base()->where(['catatan_perilaku.tahun_pelajaran_id' => $this->tpId(), 'catatan_perilaku.status' => 'Dirujuk BK'])->orderBy('catatan_perilaku.tanggal')->find(),
            'prioritas' => array_values(array_filter($cp->akumulasiPoin($this->tpId()), static fn ($r) => (int) $r['poin_negatif'] >= $batas)),
            'batas'     => $batas,
            'statistik' => $this->model->statistik($this->tpId()),
            'agenda'    => $this->model->lampirkanPeserta($agenda),
        ]);
    }

    public function layanan()
    {
        if ($r = $this->wajibTp()) {
            return $r;
        }
        $f = [];
        foreach (['jenis_layanan', 'komponen', 'bidang', 'status', 'dari', 'sampai', 'q', 'siswa_id'] as $k) {
            $f[$k] = $this->request->getGet($k);
        }
        $rows = $this->model->daftar($this->tpId(), $f);
        foreach ($rows as &$r) {
            $r['tersembunyi'] = ! Akses::bkBuka($r);
            $r['bisaKelola']  = Akses::bkKelola($r);
        }
        return view('bk/layanan', [
            'title' => 'Layanan BK',
            'rows'  => $rows,
            'pager' => $this->model->pager,
            'f'     => $f,
        ]);
    }

    public function create()
    {
        if ($r = $this->wajibTp()) {
            return $r;
        }
        $layanan = ['tanggal' => date('Y-m-d'), 'status' => 'Dijadwalkan', 'is_rahasia' => 1, 'peserta' => []];
        $rujukan = null;
        if ($rid = (int) $this->request->getGet('rujukan_id')) {
            $rujukan = model(CatatanPerilakuModel::class)->detail($rid);
            if ($rujukan) {
                $layanan += [
                    'jenis_layanan' => 'Konseling Individual', 'bidang' => 'Pribadi',
                    'topik'         => 'Tindak lanjut: ' . ($rujukan['nama_jenis'] ?? 'catatan perilaku'),
                    'permasalahan'  => $rujukan['deskripsi'],
                ];
                $layanan['catatan_perilaku_id'] = $rid;
                $layanan['peserta']             = [['id' => $rujukan['siswa_id']]];
            }
        }
        if ($sid = (int) $this->request->getGet('siswa_id')) {
            $layanan['peserta'] = [['id' => $sid]];
        }
        return $this->form($layanan, $rujukan);
    }

    public function edit($id)
    {
        $l = $this->model->detail((int) $id);
        if (! $l || ! Akses::bkKelola($l)) {
            return redirect()->to('/bk/layanan')->with('error', 'Layanan hanya dapat diubah oleh konselor yang mencatatnya.');
        }
        $rujukan = $l['catatan_perilaku_id'] ? model(CatatanPerilakuModel::class)->detail((int) $l['catatan_perilaku_id']) : null;
        return $this->form($l, $rujukan);
    }

    private function form(array $l, ?array $rujukan)
    {
        return view('bk/form', [
            'title'   => isset($l['id']) ? 'Edit Layanan BK' : 'Catat Layanan BK',
            'l'       => $l,
            'rujukan' => $rujukan,
            'siswa'   => model(SiswaModel::class)->dropdownAktif($this->tpId()),
            'kelas'   => model(KelasModel::class)->listAktif(),
        ]);
    }

    private function input(): array
    {
        $p     = fn ($k) => trim((string) $this->request->getPost($k)) ?: null;
        $jenis = (string) $this->request->getPost('jenis_layanan');
        $kat   = BkLayananModel::KATALOG[$jenis] ?? [null, null];
        return [
            'tanggal'               => $this->request->getPost('tanggal'),
            'jenis_layanan'         => $jenis,
            'komponen'              => in_array($p('komponen'), BkLayananModel::KOMPONEN, true) ? $p('komponen') : $kat[0],
            'format'                => in_array($p('format'), BkLayananModel::FORMAT, true) ? $p('format') : $kat[1],
            'media'                 => in_array($p('media'), BkLayananModel::MEDIA, true) ? $p('media') : 'Tatap muka',
            'pihak_terkait'         => $p('pihak_terkait'),
            'bidang'                => $this->request->getPost('bidang'),
            'kelas_id'              => (int) $this->request->getPost('kelas_id') ?: null,
            'topik'                 => $p('topik'),
            'permasalahan'          => $p('permasalahan'),
            'penanganan'            => $p('penanganan'),
            'hasil'                 => $p('hasil'),
            'rencana_tindak_lanjut' => $p('rencana_tindak_lanjut'),
            'status'                => $this->request->getPost('status'),
            'is_rahasia'            => $this->request->getPost('is_rahasia') ? 1 : 0,
        ];
    }

    private function rules(): array
    {
        return [
            'tanggal'       => 'required|valid_date[Y-m-d]',
            'jenis_layanan' => 'required|in_list[' . implode(',', BkLayananModel::JENIS) . ']',
            'bidang'        => 'required|in_list[' . implode(',', BkLayananModel::BIDANG) . ']',
            'status'        => 'required|in_list[' . implode(',', BkLayananModel::STATUS) . ']',
            'topik'         => 'required|max_length[200]',
        ];
    }

    public function store()
    {
        if ($r = $this->wajibTp()) {
            return $r;
        }
        if (! $this->validate($this->rules())) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }
        $peserta = (array) $this->request->getPost('peserta');
        $data    = $this->input();
        if (! $peserta && ! $data['kelas_id'] && ! in_array($data['jenis_layanan'], BkLayananModel::TANPA_PESERTA, true)) {
            return $this->back('error', 'Pilih minimal satu siswa peserta atau satu kelas (untuk layanan klasikal).');
        }
        $data += [
            'tahun_pelajaran_id'  => $this->tpId(),
            'konselor_id'         => $this->userId(),
            'catatan_perilaku_id' => (int) $this->request->getPost('catatan_perilaku_id') ?: null,
        ];

        $db = db_connect();
        $db->transStart();
        $id = (int) $this->model->insert($data);
        $this->model->simpanPeserta($id, $peserta);
        if ($data['catatan_perilaku_id']) {
            model(CatatanPerilakuModel::class)->update($data['catatan_perilaku_id'], ['status' => $data['status'] === 'Selesai' ? 'Selesai' : 'Ditangani BK']);
        }
        $db->transComplete();

        return redirect()->to('/bk/layanan/' . $id)->with('success', 'Layanan BK tersimpan.');
    }

    public function update($id)
    {
        $l = $this->model->find($id);
        if (! $l || ! Akses::bkKelola($l)) {
            return redirect()->to('/bk/layanan')->with('error', 'Layanan hanya dapat diubah oleh konselor yang mencatatnya.');
        }
        if (! $this->validate($this->rules())) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }
        $data = $this->input();
        $db   = db_connect();
        $db->transStart();
        $this->model->update($id, $data);
        $this->model->simpanPeserta((int) $id, (array) $this->request->getPost('peserta'));
        if ($l['catatan_perilaku_id'] && $data['status'] === 'Selesai') {
            model(CatatanPerilakuModel::class)->update($l['catatan_perilaku_id'], ['status' => 'Selesai']);
        }
        $db->transComplete();
        return redirect()->to('/bk/layanan/' . $id)->with('success', 'Layanan BK diperbarui.');
    }

    public function show($id)
    {
        $l = $this->model->detail((int) $id);
        if (! $l) {
            return redirect()->to('/bk/layanan')->with('error', 'Layanan tidak ditemukan.');
        }
        if (! Akses::bkBuka($l)) {
            return redirect()->to('/bk/layanan')->with('error', 'Catatan layanan ini bersifat rahasia dan hanya dapat dibuka oleh konselornya (' . $l['konselor'] . ').');
        }
        return view('bk/show', [
            'title'   => 'Detail Layanan BK',
            'subtitle' => $l['jenis_layanan'] . ' · ' . tgl_indo($l['tanggal'], true),
            'l'       => $l,
            'rujukan' => $l['catatan_perilaku_id'] ? model(CatatanPerilakuModel::class)->detail((int) $l['catatan_perilaku_id']) : null,
            'bisaKelola' => Akses::bkKelola($l),
        ]);
    }

    public function delete($id)
    {
        $l = $this->model->find($id);
        if (! $l || ! Akses::bkKelola($l)) {
            return redirect()->back()->with('error', 'Hanya konselor pembuat yang dapat menghapus.');
        }
        catat_log('hapus', 'bk_layanan', (int) $id);
        $this->model->delete($id);
        return redirect()->to('/bk/layanan')->with('success', 'Layanan dihapus.');
    }

    public function rujukan()
    {
        if ($r = $this->wajibTp()) {
            return $r;
        }
        $status = $this->request->getGet('status') ?: 'Dirujuk BK';
        $cp     = model(CatatanPerilakuModel::class);
        return view('bk/rujukan', [
            'title'    => 'Rujukan Masuk',
            'subtitle' => 'Catatan perilaku yang dirujuk guru / wali kelas ke BK.',
            'rows'     => $cp->daftar($this->tpId(), ['status' => $status], 50),
            'pager'    => $cp->pager,
            'status'   => $status,
        ]);
    }

    public function tangani($catatanId)
    {
        return redirect()->to('/bk/layanan/tambah?rujukan_id=' . (int) $catatanId);
    }
}
