<?php

namespace App\Filters;

use App\Libraries\Akses;
use CodeIgniter\Filters\FilterInterface;
use CodeIgniter\HTTP\RequestInterface;
use CodeIgniter\HTTP\ResponseInterface;

/**
 * Pemakaian di Routes: ['filter' => 'role:kurikulum,kepsek']  (admin selalu lolos).
 */
class RoleFilter implements FilterInterface
{
    public function before(RequestInterface $request, $arguments = null)
    {
        if (! AuthFilter::segarkan()) {
            return redirect()->to('/login')->with('error', 'Silakan login kembali.');
        }
        if (! empty($arguments) && ! Akses::punya(...$arguments)) {
            return redirect()->to('/dashboard')->with('error', 'Anda tidak memiliki akses ke halaman tersebut.');
        }
    }

    public function after(RequestInterface $request, ResponseInterface $response, $arguments = null)
    {
    }
}
