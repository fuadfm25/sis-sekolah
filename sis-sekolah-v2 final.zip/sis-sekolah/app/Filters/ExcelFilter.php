<?php

namespace App\Filters;

use CodeIgniter\Filters\FilterInterface;
use CodeIgniter\HTTP\RequestInterface;
use CodeIgniter\HTTP\ResponseInterface;
use PhpOffice\PhpSpreadsheet\Reader\Html;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

/**
 * Ekspor laporan cetak ke Excel: tambahkan ?format=xlsx pada URL laporan.
 * Isi <div class="kertas"> (kop, judul, tabel) diubah menjadi lembar kerja tanpa mengubah tiap laporan.
 */
class ExcelFilter implements FilterInterface
{
    public function before(RequestInterface $request, $arguments = null)
    {
    }

    public function after(RequestInterface $request, ResponseInterface $response, $arguments = null)
    {
        if ($request->getGet('format') === 'doc' && $response->getStatusCode() === 200) {
            return $this->word($response);
        }
        if ($request->getGet('format') !== 'xlsx' || $response->getStatusCode() !== 200) {
            return null;
        }
        $html = (string) $response->getBody();
        $a    = strpos($html, '<div class="kertas">');
        if ($a === false) {
            return null;
        }
        $isi = substr($html, $a);
        $isi = preg_replace('#<!--noxls-->.*?<!--/noxls-->#s', '', $isi);   // bagian khusus layar/cetak
        $isi = preg_replace('#<!-- DEBUG-VIEW.*?-->#s', '', $isi);
        $isi = preg_replace('#<(img|script|style)[^>]*>(.*?</\1>)?#is', '', $isi);
        $isi = preg_replace('#<div class="ttd">.*$#s', '', $isi);   // tanda tangan tidak perlu di Excel
        $isi = strip_tags($isi, '<table><thead><tbody><tr><th><td><b><strong><br><h2><div><p><span>');
        $isi = str_replace('•', 'H', $isi);
        $doc = '<html><head><meta charset="utf-8"></head><body>' . $isi . '</body></html>';

        $tmp = tempnam(sys_get_temp_dir(), 'lap') . '.html';
        file_put_contents($tmp, $doc);
        try {
            $sheet = (new Html())->load($tmp);
        } finally {
            @unlink($tmp);
        }
        $ws = $sheet->getActiveSheet();
        $ws->setTitle('Laporan');
        foreach ($ws->getColumnIterator() as $col) {
            $ws->getColumnDimension($col->getColumnIndex())->setAutoSize(true);
        }
        ob_start();
        (new Xlsx($sheet))->save('php://output');
        $bin  = ob_get_clean();
        $nama = trim(preg_replace('/[^A-Za-z0-9]+/', '_', $request->getUri()->getSegment(2) ?: 'laporan'), '_') . '_' . date('Ymd_His') . '.xlsx';

        return $response->setBody($bin)
            ->setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
            ->setHeader('Content-Disposition', 'attachment; filename="' . $nama . '"');
    }

    /** Dokumen cetak → .doc (HTML yang dibuka Microsoft Word / LibreOffice), agar guru bisa menyunting. */
    private function word(ResponseInterface $response): ResponseInterface
    {
        $html = (string) $response->getBody();
        if (! str_contains($html, '<div class="kertas">')) {
            return $response;
        }
        $html  = preg_replace('#<!--toolbar-->.*?<!--/toolbar-->#s', '', $html);
        $html  = preg_replace('#<!--noxls-->.*?<!--/noxls-->#s', '', $html);
        $html  = preg_replace('#<script.*?</script>#is', '', $html);
        $html  = preg_replace('#<!-- DEBUG-VIEW.*?-->#s', '', $html);
        $html  = str_replace('<html lang="id">', '<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:w="urn:schemas-microsoft-com:office:word" lang="id">', $html);
        $html  = str_replace('background: #e9ecef;', '', $html);
        preg_match('#<title>(.*?)</title>#s', $html, $m);
        $nama  = trim(preg_replace('/[^\w\- ]+/u', '', html_entity_decode($m[1] ?? 'dokumen'))) ?: 'dokumen';
        return $response->setBody("\xEF\xBB\xBF" . $html)
            ->setHeader('Content-Type', 'application/msword; charset=utf-8')
            ->setHeader('Content-Disposition', 'attachment; filename="' . substr(str_replace(' ', '_', $nama), 0, 90) . '.doc"');
    }
}
