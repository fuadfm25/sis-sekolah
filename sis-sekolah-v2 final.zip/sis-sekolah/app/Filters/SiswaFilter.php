<?php

namespace App\Filters;

use App\Libraries\PortalSiswa;
use CodeIgniter\Filters\FilterInterface;
use CodeIgniter\HTTP\RequestInterface;
use CodeIgniter\HTTP\ResponseInterface;

/** Wajib login sebagai siswa (portal). Sesi terpisah dari akun guru/staf. */
class SiswaFilter implements FilterInterface
{
    public function before(RequestInterface $request, $arguments = null)
    {
        helper('sis');
        if (! PortalSiswa::aktif()) {
            session()->remove(['siswa_id', 'siswa_wajib_ganti']);
            return redirect()->to('/portal/login')->with('error', 'Portal siswa sedang dinonaktifkan sekolah.');
        }
        if (! PortalSiswa::saya()) {
            session()->remove(['siswa_id', 'siswa_wajib_ganti']);
            return redirect()->to('/portal/login')->with('error', 'Silakan masuk terlebih dahulu.');
        }
        $path = trim($request->getUri()->getPath(), '/');
        if (session('siswa_wajib_ganti') && ! preg_match('#portal/(akun|keluar)#', $path)) {
            return redirect()->to('/portal/akun')->with('warning', 'Buat password baru terlebih dahulu.');
        }
    }

    public function after(RequestInterface $request, ResponseInterface $response, $arguments = null)
    {
    }
}
