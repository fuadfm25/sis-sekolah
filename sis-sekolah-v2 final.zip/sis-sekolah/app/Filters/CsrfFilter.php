<?php

namespace App\Filters;

use CodeIgniter\Filters\FilterInterface;
use CodeIgniter\HTTP\IncomingRequest;
use CodeIgniter\HTTP\RequestInterface;
use CodeIgniter\HTTP\ResponseInterface;
use CodeIgniter\Security\Exceptions\SecurityException;

/**
 * CSRF dengan penanganan ramah: bila token kedaluwarsa, pengguna dikembalikan ke formulir
 * BESERTA isiannya (withInput), bukan halaman error. Permintaan AJAX mendapat JSON 403.
 */
class CsrfFilter implements FilterInterface
{
    public function before(RequestInterface $request, $arguments = null)
    {
        if (! $request instanceof IncomingRequest) {
            return null;
        }
        try {
            service('security')->verify($request);
        } catch (SecurityException $e) {
            if ($request->isAJAX()) {
                return service('response')->setStatusCode(403)->setJSON(['ok' => false, 'pesan' => lang('Security.disallowedAction')]);
            }
            return redirect()->back()->withInput()->with('error', lang('Security.disallowedAction'));
        }
        return null;
    }

    public function after(RequestInterface $request, ResponseInterface $response, $arguments = null)
    {
    }
}
