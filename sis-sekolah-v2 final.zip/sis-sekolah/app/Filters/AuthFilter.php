<?php

namespace App\Filters;

use App\Models\GuruModel;
use App\Models\UserModel;
use CodeIgniter\Filters\FilterInterface;
use CodeIgniter\HTTP\RequestInterface;
use CodeIgniter\HTTP\ResponseInterface;

/**
 * Wajib login. Role & status akun dibaca ulang dari database setiap request,
 * sehingga perubahan role / penonaktifan akun langsung berlaku tanpa login ulang.
 */
class AuthFilter implements FilterInterface
{
    private static bool $sudahSegar = false;

    /** Segarkan data sesi dari database. false = sesi tidak sah (belum login / akun nonaktif). */
    public static function segarkan(): bool
    {
        $session = session();
        if (! $session->get('isLoggedIn')) {
            return false;
        }
        if (self::$sudahSegar) {
            return true;
        }
        $users = model(UserModel::class);
        $user  = $users->select('id, is_active, nama_lengkap')->find((int) $session->get('user_id'));
        if (! $user || ! (int) $user['is_active']) {
            $session->destroy();
            return false;
        }
        $guru = model(GuruModel::class)->select('id, is_active')->where('user_id', $user['id'])->first();
        $session->set([
            'roles'        => $users->roleNames((int) $user['id']),
            'guru_id'      => ($guru && (int) $guru['is_active']) ? (int) $guru['id'] : null,
            'nama_lengkap' => $user['nama_lengkap'],
        ]);
        return self::$sudahSegar = true;
    }

    public function before(RequestInterface $request, $arguments = null)
    {
        if (! self::segarkan()) {
            return redirect()->to('/login')->with('error', 'Silakan login kembali.');
        }
        // password direset admin: wajib diganti dulu (semua mode)
        if (session('wajib_ganti')) {
            $path = trim($request->getUri()->getPath(), '/');
            if (! preg_match('#(^|/)(profil|logout|ping)(/|$)#', $path)) {
                return redirect()->to('/profil')->with('warning', 'Buat password baru terlebih dahulu.');
            }
        }
        // mode produksi: akun dengan password bawaan hanya boleh membuka halaman profil sampai password diganti
        if (ENVIRONMENT === 'production' && session('password_lemah')) {
            $path = trim($request->getUri()->getPath(), '/');
            if (! preg_match('#(^|/)(profil|logout|ping)(/|$)#', $path)) {
                return redirect()->to('/profil')->with('warning', 'Ganti password bawaan terlebih dahulu.');
            }
        }
    }

    public function after(RequestInterface $request, ResponseInterface $response, $arguments = null)
    {
    }
}
