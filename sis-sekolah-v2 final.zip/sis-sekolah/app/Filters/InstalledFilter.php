<?php

namespace App\Filters;

use CodeIgniter\Filters\FilterInterface;
use CodeIgniter\HTTP\RequestInterface;
use CodeIgniter\HTTP\ResponseInterface;

/**
 * Arahkan ke /install bila aplikasi belum terpasang; kunci /install bila sudah.
 * Instalasi lama (sebelum ada installer) dikenali dari adanya tabel users berisi data.
 */
class InstalledFilter implements FilterInterface
{
    public const LOCK = WRITEPATH . 'installed.lock';

    public static function terpasang(): bool
    {
        if (is_file(self::LOCK)) {
            return true;
        }
        try {
            $db = db_connect();
            if ($db->tableExists('users') && $db->table('users')->countAllResults() > 0) {
                @file_put_contents(self::LOCK, 'Terpasang (terdeteksi otomatis) ' . date('Y-m-d H:i:s') . PHP_EOL);
                return true;
            }
        } catch (\Throwable $e) {
            // belum ada koneksi database yang valid
        }
        return false;
    }

    public function before(RequestInterface $request, $arguments = null)
    {
        $path    = trim($request->getUri()->getPath(), '/');
        $path    = preg_replace('#^index\.php/?#', '', $path);
        $install = str_starts_with($path, 'install');

        if ($install && self::terpasang()) {
            return redirect()->to('/login')->with('error', 'Aplikasi sudah terpasang. Hapus writable/installed.lock untuk memasang ulang.');
        }
        if (! $install && ! self::terpasang()) {
            return redirect()->to('/install');
        }
    }

    public function after(RequestInterface $request, ResponseInterface $response, $arguments = null)
    {
    }
}
