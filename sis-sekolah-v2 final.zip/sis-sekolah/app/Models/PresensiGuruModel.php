<?php

namespace App\Models;

use CodeIgniter\Model;

class PresensiGuruModel extends Model
{
    use SimpanUnikTrait;

    protected $table         = 'presensi_guru';
    protected $returnType    = 'array';
    protected $allowedFields = ['tahun_pelajaran_id', 'guru_id', 'tanggal', 'status', 'jam_datang', 'jam_pulang', 'keterangan', 'izin_guru_id', 'sumber', 'dicatat_oleh'];
    protected $useTimestamps = true;

    public const STATUS = ['H' => 'Hadir', 'T' => 'Terlambat', 'S' => 'Sakit', 'I' => 'Izin', 'DL' => 'Dinas Luar', 'C' => 'Cuti', 'A' => 'Tanpa keterangan'];
    public const WARNA  = ['H' => 'success', 'T' => 'warning', 'S' => 'info', 'I' => 'primary', 'DL' => 'secondary', 'C' => 'dark', 'A' => 'danger'];

    public function petaTanggal(string $tanggal): array
    {
        return array_column($this->where('tanggal', $tanggal)->findAll(), null, 'guru_id');
    }

    /** [guru_id][hari(int)] => status untuk satu bulan. */
    public function matriksBulan(int $tahun, int $bulan): array
    {
        $dari = sprintf('%04d-%02d-01', $tahun, $bulan);
        $out  = [];
        foreach ($this->where('tanggal >=', $dari)->where('tanggal <=', date('Y-m-t', strtotime($dari)))->findAll() as $r) {
            $out[$r['guru_id']][(int) substr($r['tanggal'], 8)] = $r['status'];
        }
        return $out;
    }
}
