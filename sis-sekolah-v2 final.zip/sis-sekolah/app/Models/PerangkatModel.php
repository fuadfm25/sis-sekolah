<?php

namespace App\Models;

use CodeIgniter\Model;

class PerangkatModel extends Model
{
    protected $table         = 'perangkat_pembelajaran';
    protected $returnType    = 'array';
    protected $useTimestamps = true;
    protected $allowedFields = ['tahun_pelajaran_id', 'guru_id', 'mapel_id', 'tingkat', 'jenis_perangkat_id', 'file', 'nama_file', 'tautan', 'sumber', 'catatan_guru',
        'status', 'versi', 'diajukan_at', 'catatan_pemeriksa', 'diperiksa_oleh', 'diperiksa_at', 'disahkan_oleh', 'disahkan_at'];

    public const STATUS = ['Diajukan' => 'info', 'Perlu Revisi' => 'warning', 'Disetujui' => 'primary', 'Disahkan' => 'success'];
    public const SELESAI = ['Disetujui', 'Disahkan'];
    public const EKSTENSI = ['pdf', 'doc', 'docx', 'xls', 'xlsx', 'ppt', 'pptx', 'odt', 'ods', 'odp', 'jpg', 'jpeg', 'png', 'zip'];
    public const MAKS_KB = 10240;

    public function jenisAktif(): array
    {
        return $this->db->table('jenis_perangkat')->where('is_active', 1)->orderBy('urutan')->orderBy('id')->get()->getResultArray();
    }

    /** Pasangan mapel–tingkat yang diampu guru pada TP (dari penugasan). */
    public function target(int $tpId, ?int $guruId = null): array
    {
        $b = $this->db->table('penugasan_guru pg')
            ->select('pg.guru_id, guru.nama_lengkap AS nama_guru, guru.nip, pg.mapel_id, mapel.nama_mapel, kelas.tingkat, GROUP_CONCAT(kelas.nama_kelas) AS kelas_list')
            ->join('kelas', 'kelas.id = pg.kelas_id')->join('mata_pelajaran mapel', 'mapel.id = pg.mapel_id')->join('guru', 'guru.id = pg.guru_id')
            ->where('pg.tahun_pelajaran_id', $tpId)->groupBy('pg.guru_id, guru.nama_lengkap, guru.nip, pg.mapel_id, mapel.nama_mapel, kelas.tingkat')
            ->orderBy('guru.nama_lengkap')->orderBy('mapel.nama_mapel')->orderBy('kelas.tingkat');
        if ($guruId) {
            $b->where('pg.guru_id', $guruId);
        }
        return $b->get()->getResultArray();
    }

    /** TP lain dengan tahun pelajaran yang sama (untuk perangkat tahunan yang dikumpulkan di semester lain). */
    public function tpSetahun(int $tpId): array
    {
        $tp = $this->db->table('tahun_pelajaran')->where('id', $tpId)->get()->getRowArray();
        return $tp ? array_map('intval', array_column($this->db->table('tahun_pelajaran')->select('id')->where('tahun_pelajaran', $tp['tahun_pelajaran'])->get()->getResultArray(), 'id')) : [$tpId];
    }

    /**
     * Peta perangkat: kunci "guru|mapel|tingkat|jenis" → baris. Perangkat periode Tahunan dari semester lain
     * pada tahun pelajaran yang sama ikut terhitung (ditandai _semester_lain).
     */
    public function peta(int $tpId, ?int $guruId = null): array
    {
        $jenis   = array_column($this->jenisAktif(), 'periode', 'id');
        $tahunan = array_keys(array_filter($jenis, static fn ($p) => $p === 'Tahunan'));
        $b = $this->select('perangkat_pembelajaran.*, jenis_perangkat.nama AS nama_jenis, jenis_perangkat.periode')
            ->join('jenis_perangkat', 'jenis_perangkat.id = perangkat_pembelajaran.jenis_perangkat_id');
        $b->groupStart()->where('perangkat_pembelajaran.tahun_pelajaran_id', $tpId);
        if ($tahunan) {
            $b->orGroupStart()->whereIn('perangkat_pembelajaran.tahun_pelajaran_id', $this->tpSetahun($tpId))->whereIn('perangkat_pembelajaran.jenis_perangkat_id', $tahunan)->groupEnd();
        }
        $b->groupEnd();
        if ($guruId) {
            $b->where('perangkat_pembelajaran.guru_id', $guruId);
        }
        $out = [];
        foreach ($b->orderBy('perangkat_pembelajaran.tahun_pelajaran_id')->findAll() as $r) {
            $k = $r['guru_id'] . '|' . $r['mapel_id'] . '|' . $r['tingkat'] . '|' . $r['jenis_perangkat_id'];
            if ((int) $r['tahun_pelajaran_id'] !== $tpId) {
                if (isset($out[$k])) {
                    continue;
                }
                $r['_semester_lain'] = true;
            }
            $out[$k] = $r;   // baris TP aktif menimpa baris semester lain
        }
        return $out;
    }

    /** Rekap kelengkapan per guru (hanya jenis wajib). */
    public function rekap(int $tpId): array
    {
        $jenis = array_filter($this->jenisAktif(), static fn ($j) => (int) $j['wajib'] === 1);
        $peta  = $this->peta($tpId);
        $out   = [];
        foreach ($this->target($tpId) as $t) {
            $g = &$out[$t['guru_id']];
            $g ??= ['guru_id' => $t['guru_id'], 'nama_guru' => $t['nama_guru'], 'nip' => $t['nip'], 'target' => 0, 'terkumpul' => 0, 'disetujui' => 0, 'disahkan' => 0, 'revisi' => 0, 'menunggu' => 0];
            foreach ($jenis as $j) {
                $g['target']++;
                $p = $peta[$t['guru_id'] . '|' . $t['mapel_id'] . '|' . $t['tingkat'] . '|' . $j['id']] ?? null;
                if (! $p) {
                    continue;
                }
                $g['terkumpul']++;
                $g['disetujui'] += in_array($p['status'], self::SELESAI, true) ? 1 : 0;
                $g['disahkan']  += $p['status'] === 'Disahkan' ? 1 : 0;
                $g['revisi']    += $p['status'] === 'Perlu Revisi' ? 1 : 0;
                $g['menunggu']  += $p['status'] === 'Diajukan' ? 1 : 0;
            }
            unset($g);
        }
        return array_values($out);
    }

    public function daftar(int $tpId, array $f = []): array
    {
        $b = $this->select('perangkat_pembelajaran.*, jenis_perangkat.nama AS nama_jenis, guru.nama_lengkap AS nama_guru, mapel.nama_mapel, u.nama_lengkap AS pemeriksa')
            ->join('jenis_perangkat', 'jenis_perangkat.id = perangkat_pembelajaran.jenis_perangkat_id')
            ->join('guru', 'guru.id = perangkat_pembelajaran.guru_id')->join('mata_pelajaran mapel', 'mapel.id = perangkat_pembelajaran.mapel_id')
            ->join('users u', 'u.id = perangkat_pembelajaran.diperiksa_oleh', 'left')
            ->where('perangkat_pembelajaran.tahun_pelajaran_id', $tpId);
        foreach (['status', 'guru_id', 'jenis_perangkat_id', 'mapel_id'] as $k) {
            if (! empty($f[$k])) {
                $b->where('perangkat_pembelajaran.' . $k, $f[$k]);
            }
        }
        return $b->orderBy('perangkat_pembelajaran.diajukan_at', 'ASC')->findAll(500);
    }

    public function detail(int $id): ?array
    {
        return $this->select('perangkat_pembelajaran.*, jenis_perangkat.nama AS nama_jenis, jenis_perangkat.periode, guru.nama_lengkap AS nama_guru, guru.user_id AS guru_user_id, mapel.nama_mapel,
                u.nama_lengkap AS pemeriksa, k.nama_lengkap AS pengesah, tahun_pelajaran.tahun_pelajaran, tahun_pelajaran.semester')
            ->join('jenis_perangkat', 'jenis_perangkat.id = perangkat_pembelajaran.jenis_perangkat_id')
            ->join('guru', 'guru.id = perangkat_pembelajaran.guru_id')->join('mata_pelajaran mapel', 'mapel.id = perangkat_pembelajaran.mapel_id')
            ->join('tahun_pelajaran', 'tahun_pelajaran.id = perangkat_pembelajaran.tahun_pelajaran_id')
            ->join('users u', 'u.id = perangkat_pembelajaran.diperiksa_oleh', 'left')->join('users k', 'k.id = perangkat_pembelajaran.disahkan_oleh', 'left')
            ->where('perangkat_pembelajaran.id', $id)->first();
    }

    public function riwayat(int $id): array
    {
        return $this->db->table('perangkat_riwayat r')->select('r.*, users.nama_lengkap')->join('users', 'users.id = r.user_id', 'left')
            ->where('r.perangkat_id', $id)->orderBy('r.id', 'DESC')->get()->getResultArray();
    }

    public function catat(int $id, string $aksi, int $versi, ?string $catatan, ?string $file, int $userId): void
    {
        $this->db->table('perangkat_riwayat')->insert(['perangkat_id' => $id, 'aksi' => $aksi, 'versi' => $versi, 'catatan' => $catatan,
            'file' => $file, 'user_id' => $userId ?: null, 'created_at' => date('Y-m-d H:i:s')]);
    }

    public function hitungStatus(int $tpId, ?int $guruId = null): array
    {
        $b = $this->select('status, COUNT(*) AS n')->where('tahun_pelajaran_id', $tpId);
        if ($guruId) {
            $b->where('guru_id', $guruId);
        }
        return array_column($b->groupBy('status')->findAll(), 'n', 'status');
    }

    /** URL dokumen yang dibuat di aplikasi (prota/promes/modul) untuk perangkat ber-sumber internal. */
    public static function urlSumber(array $p): ?string
    {
        $q = '?guru_id=' . $p['guru_id'] . '&mapel_id=' . $p['mapel_id'] . '&tingkat=' . urlencode($p['tingkat']) . '&tp=' . $p['tahun_pelajaran_id'];
        return match ($p['sumber'] ?? null) {
            'promes' => site_url('program/cetak/promes') . $q,
            'prota'  => site_url('program/cetak/prota') . $q,
            'modul'  => site_url('modul-ajar/cetak-semua') . $q,
            default  => null,
        };
    }

    /**
     * Ajukan dokumen buatan aplikasi sebagai perangkat (tanpa unggah berkas).
     * @return array{0: bool, 1: string}
     */
    public function ajukanInternal(int $tpId, int $guruId, int $mapelId, string $tingkat, string $polaJenis, string $sumber, int $userId): array
    {
        $jenis = $this->db->table('jenis_perangkat')->where('is_active', 1)->like('nama', $polaJenis, 'after')->get()->getRowArray();
        if (! $jenis) {
            return [false, 'Jenis perangkat "' . $polaJenis . '…" tidak aktif. Minta Waka Kurikulum mengaktifkannya di Jenis Perangkat.'];
        }
        $ada = $this->where(['tahun_pelajaran_id' => $tpId, 'guru_id' => $guruId, 'mapel_id' => $mapelId, 'tingkat' => $tingkat, 'jenis_perangkat_id' => $jenis['id']])->first();
        if ($ada && in_array($ada['status'], self::SELESAI, true)) {
            return [false, $jenis['nama'] . ' sudah ' . strtolower($ada['status']) . '. Minta Waka Kurikulum membukanya kembali bila ada perubahan.'];
        }
        $now  = date('Y-m-d H:i:s');
        $data = ['sumber' => $sumber, 'file' => null, 'nama_file' => null, 'tautan' => null, 'status' => 'Diajukan', 'diajukan_at' => $now, 'catatan_guru' => 'Disusun di aplikasi.'];
        if ($ada) {
            $ulang = $ada['status'] === 'Perlu Revisi';
            $data['versi'] = (int) $ada['versi'] + ($ulang ? 1 : 0);
            $this->update($ada['id'], $data);
            $this->catat((int) $ada['id'], $ulang ? 'Diajukan ulang' : 'Diperbarui', $data['versi'], 'Disusun di aplikasi.', null, $userId);
        } else {
            $id = (int) $this->insert($data + ['tahun_pelajaran_id' => $tpId, 'guru_id' => $guruId, 'mapel_id' => $mapelId, 'tingkat' => $tingkat, 'jenis_perangkat_id' => $jenis['id'], 'versi' => 1]);
            $this->catat($id, 'Diajukan', 1, 'Disusun di aplikasi.', null, $userId);
        }
        return [true, $jenis['nama'] . ' diajukan ke Waka Kurikulum.'];
    }
}
