<?php

namespace App\Models;

use CodeIgniter\Model;

class PresensiMapelModel extends Model
{
    use SimpanUnikTrait;

    protected $table         = 'presensi_mapel';
    protected $returnType    = 'array';
    protected $allowedFields = ['jurnal_id', 'siswa_id', 'status', 'keterangan', 'sumber'];
    protected $useTimestamps = true;

    public function petaJurnal(int $jurnalId): array
    {
        return array_column($this->where('jurnal_id', $jurnalId)->findAll(), null, 'siswa_id');
    }

    /**
     * @param array<int, array{status: string, alasan: ?string}> $saran status otomatis dari absensi pagi/izin (SinkronAbsensi::saran).
     *        Siswa yang statusnya sama dengan saran ditandai 'Otomatis' (ikut berubah bila absensi pagi/izin berubah);
     *        yang diubah guru ditandai 'Guru' dan tidak akan ditimpa.
     */
    public function simpanBatch(int $jurnalId, array $presensi, array $saran = []): void
    {
        foreach ($presensi as $siswaId => $p) {
            $status = in_array($p['status'] ?? 'H', ['H', 'S', 'I', 'A', 'D'], true) ? $p['status'] : 'H';
            $ket    = trim($p['keterangan'] ?? '') ?: null;
            $s      = $saran[(int) $siswaId] ?? null;
            $oto    = $s && $s['status'] === $status && ($ket === null || $ket === $s['alasan']);
            $this->simpanUnik(['jurnal_id' => $jurnalId, 'siswa_id' => (int) $siswaId], [
                'status'     => $status,
                'keterangan' => $oto ? $s['alasan'] : $ket,
                'sumber'     => $oto ? 'Otomatis' : 'Guru',
            ]);
        }
    }

    /**
     * Rekap presensi mapel untuk satu penugasan (mapel-kelas) pada rentang tanggal.
     * @return array{jurnal: list<array>, matriks: array<int, array<int,string>>}
     */
    public function rekap(int $penugasanId, string $dari, string $sampai): array
    {
        $jurnal = $this->db->table('jurnal_pembelajaran')
            ->select('id, tanggal, pertemuan_ke, jam_ke')
            ->where('penugasan_guru_id', $penugasanId)
            ->where('tanggal >=', $dari)->where('tanggal <=', $sampai)
            ->orderBy('tanggal')->get()->getResultArray();

        $matriks = [];
        if ($jurnal) {
            foreach ($this->whereIn('jurnal_id', array_column($jurnal, 'id'))->findAll() as $p) {
                $matriks[$p['siswa_id']][$p['jurnal_id']] = $p['status'];
            }
        }
        return ['jurnal' => $jurnal, 'matriks' => $matriks];
    }
}
