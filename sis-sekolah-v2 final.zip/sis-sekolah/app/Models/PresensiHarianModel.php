<?php

namespace App\Models;

use CodeIgniter\Model;

class PresensiHarianModel extends Model
{
    use SimpanUnikTrait;

    protected $table         = 'presensi_harian';
    protected $returnType    = 'array';
    protected $allowedFields = ['tahun_pelajaran_id', 'kelas_id', 'siswa_id', 'tanggal', 'status', 'jam_datang', 'jam_pulang', 'keterangan', 'sumber', 'dicatat_oleh', 'izin_siswa_id'];
    protected $useTimestamps = true;

    public function petaKelasTanggal(int $kelasId, string $tanggal): array
    {
        return array_column($this->where(['kelas_id' => $kelasId, 'tanggal' => $tanggal])->findAll(), null, 'siswa_id');
    }

    /** Status absensi pagi untuk sekumpulan siswa pada satu tanggal: [siswa_id => status]. */
    public function statusSiswa(array $siswaIds, string $tanggal): array
    {
        if (! $siswaIds) {
            return [];
        }
        return array_column($this->select('siswa_id, status')->whereIn('siswa_id', $siswaIds)->where('tanggal', $tanggal)->findAll(), 'status', 'siswa_id');
    }

    /** Matriks bulanan [siswa_id][tgl(int)] => status. */
    public function matriksBulan(int $kelasId, int $tahun, int $bulan): array
    {
        $dari   = sprintf('%04d-%02d-01', $tahun, $bulan);
        $sampai = date('Y-m-t', strtotime($dari));
        $out    = [];
        foreach ($this->where('kelas_id', $kelasId)->where('tanggal >=', $dari)->where('tanggal <=', $sampai)->findAll() as $r) {
            $out[$r['siswa_id']][(int) substr($r['tanggal'], 8, 2)] = $r['status'];
        }
        return $out;
    }

    /** Ringkasan satu tanggal per kelas: [kelas_id => [H=>n, S=>n, ...]] */
    public function ringkasTanggal(int $tpId, string $tanggal): array
    {
        $out = [];
        foreach ($this->select('kelas_id, status, COUNT(*) AS n')->where(['tahun_pelajaran_id' => $tpId, 'tanggal' => $tanggal])->groupBy(['kelas_id', 'status'])->findAll() as $r) {
            $out[$r['kelas_id']][$r['status']] = (int) $r['n'];
        }
        return $out;
    }

    /** Total per status untuk satu siswa pada TP. */
    public function totalSiswa(int $siswaId, int $tpId): array
    {
        return array_column(
            $this->select('status, COUNT(*) AS n')->where(['siswa_id' => $siswaId, 'tahun_pelajaran_id' => $tpId])->groupBy('status')->findAll(),
            'n', 'status'
        );
    }
}
