<?php

namespace App\Models;

use CodeIgniter\Model;

/** Alur Tujuan Pembelajaran (Kurikulum Merdeka) per mapel & tingkat. */
class AtpModel extends Model
{
    protected $table         = 'atp';
    protected $returnType    = 'array';
    protected $allowedFields = ['mapel_id', 'tingkat', 'fase', 'semester', 'elemen', 'kode', 'tujuan', 'alokasi_jp', 'urutan', 'modul_ajar', 'dibuat_oleh'];
    protected $useTimestamps = true;

    /** Fase menurut tingkat (Permendikbudristek/BSKAP): A 1–2, B 3–4, C 5–6, D 7–9, E 10, F 11–12. */
    public static function faseDari(string $tingkat): ?string
    {
        $r = ['I' => 1, 'II' => 2, 'III' => 3, 'IV' => 4, 'V' => 5, 'VI' => 6, 'VII' => 7, 'VIII' => 8, 'IX' => 9, 'X' => 10, 'XI' => 11, 'XII' => 12];
        $n = ctype_digit($tingkat) ? (int) $tingkat : ($r[strtoupper($tingkat)] ?? 0);
        return match (true) {
            $n >= 1 && $n <= 2  => 'A', $n <= 4 && $n >= 3 => 'B', $n <= 6 && $n >= 5 => 'C',
            $n >= 7 && $n <= 9  => 'D', $n === 10 => 'E', $n >= 11 && $n <= 12 => 'F', default => null,
        };
    }

    public function daftar(int $mapelId, string $tingkat, ?string $semester = null): array
    {
        $b = $this->where(['mapel_id' => $mapelId, 'tingkat' => $tingkat]);
        if ($semester) {
            $b->groupStart()->where('semester', $semester)->orWhere('semester', null)->groupEnd();
        }
        return $b->orderBy('urutan')->orderBy('id')->findAll();
    }

    /** Ketercapaian TP untuk satu penugasan: berapa kali dibahas di jurnal, kapan, dan JP terpakai. */
    public function ketercapaian(int $mapelId, string $tingkat, int $penugasanId, ?string $semester = null): array
    {
        $atp = $this->daftar($mapelId, $tingkat, $semester);
        if (! $atp) {
            return [];
        }
        $rows = $this->db->table('jurnal_atp')->select('jurnal_atp.atp_id, COUNT(*) AS n, MIN(j.tanggal) AS awal, MAX(j.tanggal) AS akhir, SUM(j.jumlah_jp) AS jp')
            ->join('jurnal_pembelajaran j', 'j.id = jurnal_atp.jurnal_id')
            ->where('j.penugasan_guru_id', $penugasanId)->whereIn('jurnal_atp.atp_id', array_column($atp, 'id'))
            ->groupBy('jurnal_atp.atp_id')->get()->getResultArray();
        $peta = array_column($rows, null, 'atp_id');
        foreach ($atp as &$a) {
            $a += ['pertemuan' => (int) ($peta[$a['id']]['n'] ?? 0), 'awal' => $peta[$a['id']]['awal'] ?? null, 'akhir' => $peta[$a['id']]['akhir'] ?? null, 'jp' => (int) ($peta[$a['id']]['jp'] ?? 0)];
        }
        return $atp;
    }
}
