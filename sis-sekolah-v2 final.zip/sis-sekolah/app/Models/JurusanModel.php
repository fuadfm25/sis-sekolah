<?php

namespace App\Models;

use CodeIgniter\Model;

class JurusanModel extends Model
{
    protected $table         = 'jurusan';
    protected $returnType    = 'array';
    protected $allowedFields = ['kode_jurusan', 'nama_jurusan'];
    protected $useTimestamps = true;
}
