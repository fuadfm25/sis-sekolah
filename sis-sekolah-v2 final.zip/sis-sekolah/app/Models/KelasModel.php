<?php

namespace App\Models;

use CodeIgniter\Model;

class KelasModel extends Model
{
    protected $table         = 'kelas';
    protected $returnType    = 'array';
    protected $allowedFields = ['tingkat', 'nama_kelas', 'jurusan_id', 'is_active'];
    protected $useTimestamps = true;

    public function listAktif(): array
    {
        return $this->where('is_active', 1)->orderBy('tingkat')->orderBy('nama_kelas')->findAll();
    }

    /** Kelas + jurusan + wali kelas + jumlah siswa untuk TP tertentu. */
    public function detailList(?int $tpId): array
    {
        $b = $this->select('kelas.*, jurusan.nama_jurusan, guru.nama_lengkap AS wali_nama, guru.nama_lengkap AS wali_nama_lengkap, guru.gelar_depan AS wali_gelar_depan, guru.gelar_belakang AS wali_gelar_belakang, wali_kelas.guru_id AS wali_guru_id')
            ->join('jurusan', 'jurusan.id = kelas.jurusan_id', 'left')
            ->join('wali_kelas', 'wali_kelas.kelas_id = kelas.id AND wali_kelas.tahun_pelajaran_id = ' . (int) $tpId, 'left')
            ->join('guru', 'guru.id = wali_kelas.guru_id', 'left')
            ->orderBy('kelas.tingkat')->orderBy('kelas.nama_kelas');
        $rows = $b->findAll();

        $jumlah = [];
        if ($tpId) {
            foreach ($this->db->table('anggota_kelas')->select('kelas_id, COUNT(*) AS n')->where('tahun_pelajaran_id', $tpId)->groupBy('kelas_id')->get()->getResultArray() as $r) {
                $jumlah[$r['kelas_id']] = (int) $r['n'];
            }
        }
        foreach ($rows as &$r) {
            $r['jumlah_siswa'] = $jumlah[$r['id']] ?? 0;
        }
        return $rows;
    }
}
