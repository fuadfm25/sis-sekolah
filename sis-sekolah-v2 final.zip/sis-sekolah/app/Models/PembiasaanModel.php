<?php

namespace App\Models;

use CodeIgniter\Model;

class PembiasaanModel extends Model
{
    protected $table         = 'pembiasaan';
    protected $returnType    = 'array';
    protected $allowedFields = ['nama', 'kategori', 'deskripsi', 'hari', 'pengisi', 'tempat', 'berlaku', 'perlu_verifikasi', 'wajib_catatan', 'petunjuk_catatan', 'tingkat', 'urutan', 'is_active'];

    public const PENGISI = ['Guru' => 'Dicatat guru', 'Siswa' => 'Diisi siswa', 'Keduanya' => 'Guru & siswa'];
    public const TEMPAT  = ['Sekolah' => 'Di sekolah', 'Rumah' => 'Di rumah'];
    /** Hari masuk sekolah = hari yang ada absensinya menurut kalender akademik (termasuk hari ujian). */
    public const BERLAKU = ['Semua' => 'Setiap hari', 'Sekolah' => 'Hari masuk sekolah', 'Libur' => 'Hari libur saja'];
    protected $useTimestamps = true;

    /** Pembiasaan aktif; bila $hari diisi, hanya yang berlaku pada hari tersebut. */
    public function aktif(?int $hari = null): array
    {
        $rows = $this->where('is_active', 1)->orderBy('urutan')->orderBy('nama')->findAll();
        if ($hari === null) {
            return $rows;
        }
        return array_values(array_filter($rows, static fn ($r) => empty($r['hari']) || in_array((string) $hari, explode(',', $r['hari']), true)));
    }

    /** Berlaku untuk tingkat kelas tertentu? (kolom tingkat kosong = semua) */
    public static function untukTingkat(array $p, ?string $tingkat): bool
    {
        return empty($p['tingkat']) || $tingkat === null || in_array((string) $tingkat, explode(',', $p['tingkat']), true);
    }

    /** Pembiasaan yang diisi guru di halaman kelas (pengisi Guru/Keduanya). */
    public function untukGuru(int $hari, ?string $tingkat = null): array
    {
        return array_values(array_filter($this->aktif($hari), static fn ($p) => ($p['pengisi'] ?? 'Guru') !== 'Siswa' && self::untukTingkat($p, $tingkat)));
    }

    /** Pembiasaan yang diisi siswa lewat portal pada tanggal tsb. */
    public function untukSiswa(string $tanggal, ?string $tingkat, bool $hariSekolah): array
    {
        $hari = (int) date('N', strtotime($tanggal));
        return array_values(array_filter($this->where('is_active', 1)->orderBy('urutan')->orderBy('nama')->findAll(), static function ($p) use ($hari, $tingkat, $hariSekolah) {
            if (! in_array($p['pengisi'] ?? 'Guru', ['Siswa', 'Keduanya'], true) || ! self::untukTingkat($p, $tingkat)) {
                return false;
            }
            $berlaku = ($p['tempat'] ?? 'Sekolah') === 'Sekolah' ? 'Sekolah' : ($p['berlaku'] ?? 'Semua');
            if (($berlaku === 'Sekolah' && ! $hariSekolah) || ($berlaku === 'Libur' && $hariSekolah)) {
                return false;
            }
            return empty($p['hari']) || in_array((string) $hari, explode(',', $p['hari']), true);
        }));
    }

    /** Paket Gerakan 7 Kebiasaan Anak Indonesia Hebat (Kemendikdasmen). */
    public const PAKET_7KAIH = [
        ['Bangun pagi', 'Bangun pagi tepat waktu dan bersiap memulai hari.', 'Jam bangun'],
        ['Beribadah', 'Melaksanakan ibadah sesuai agama dan kepercayaan masing-masing.', 'Ibadah yang dilakukan'],
        ['Berolahraga', 'Melakukan olahraga atau aktivitas fisik.', 'Jenis & lama olahraga'],
        ['Makan sehat dan bergizi', 'Sarapan dan makan makanan sehat dan bergizi.', 'Menu makan'],
        ['Gemar belajar', 'Membaca atau belajar di luar jam pelajaran.', 'Buku/materi yang dipelajari'],
        ['Bermasyarakat', 'Membantu keluarga, tetangga, atau ikut kegiatan di lingkungan.', 'Kegiatan yang dilakukan'],
        ['Tidur cepat', 'Semalam tidur lebih awal agar cukup istirahat (diisi pagi harinya, jadi tidur Minggu malam tercatat di hari Senin).', 'Jam tidur semalam'],
    ];
}
