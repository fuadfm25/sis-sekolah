<?php

namespace App\Models;

use CodeIgniter\Model;

class WaliKelasModel extends Model
{
    protected $table         = 'wali_kelas';
    protected $returnType    = 'array';
    protected $allowedFields = ['tahun_pelajaran_id', 'kelas_id', 'guru_id'];
    protected $useTimestamps = true;

    public function kelasIdsByGuru(int $guruId, int $tpId): array
    {
        return array_map('intval', array_column(
            $this->select('kelas_id')->where(['guru_id' => $guruId, 'tahun_pelajaran_id' => $tpId])->findAll(),
            'kelas_id'
        ));
    }

    public function waliDari(int $kelasId, int $tpId): ?array
    {
        return $this->select('guru.*')
            ->join('guru', 'guru.id = wali_kelas.guru_id')
            ->where(['wali_kelas.kelas_id' => $kelasId, 'wali_kelas.tahun_pelajaran_id' => $tpId])
            ->first();
    }

    public function tetapkan(int $tpId, int $kelasId, ?int $guruId): void
    {
        $row = $this->where(['tahun_pelajaran_id' => $tpId, 'kelas_id' => $kelasId])->first();
        if (! $guruId) {
            if ($row) {
                $this->delete($row['id']);
            }
            return;
        }
        $row ? $this->update($row['id'], ['guru_id' => $guruId])
             : $this->insert(['tahun_pelajaran_id' => $tpId, 'kelas_id' => $kelasId, 'guru_id' => $guruId]);
    }
}
