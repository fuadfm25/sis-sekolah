<?php

namespace App\Models;

use CodeIgniter\Model;

class BkLayananModel extends Model
{
    protected $table         = 'bk_layanan';
    protected $returnType    = 'array';
    protected $allowedFields = [
        'komponen', 'format', 'media', 'pihak_terkait',
        'tahun_pelajaran_id', 'tanggal', 'jenis_layanan', 'bidang', 'kelas_id', 'catatan_perilaku_id', 'topik',
        'permasalahan', 'penanganan', 'hasil', 'rencana_tindak_lanjut', 'status', 'is_rahasia', 'konselor_id',
    ];
    protected $useTimestamps = true;

    /** Komponen layanan BK (Permendikbud 111/2014 Pasal 6 ayat 1). */
    public const KOMPONEN = ['Layanan Dasar', 'Peminatan & Perencanaan Individual', 'Responsif', 'Dukungan Sistem'];

    /** Format menurut jumlah individu yang dilayani (Pasal 7 ayat 2). */
    public const FORMAT = ['Individual', 'Kelompok', 'Klasikal', 'Kelas Besar', 'Lainnya'];

    /** Cara komunikasi layanan. */
    public const MEDIA = ['Tatap muka', 'Daring', 'Telepon/pesan', 'Tertulis/media'];

    /**
     * Katalog jenis layanan & kegiatan pendukung BK yang lazim di sekolah:
     * jenis => [komponen bawaan, format bawaan, sasaran (siswa|kelas|pihak), keterangan singkat]
     */
    public const KATALOG = [
        // Layanan dasar – untuk semua siswa, preventif & pengembangan
        'Bimbingan Klasikal'       => ['Layanan Dasar', 'Klasikal', 'kelas', 'Bimbingan terjadwal di kelas (materi pribadi, sosial, belajar, karier).'],
        'Bimbingan Kelompok'       => ['Layanan Dasar', 'Kelompok', 'siswa', 'Pembahasan topik bersama 2–10 siswa memakai dinamika kelompok.'],
        'Bimbingan Kelas Besar'    => ['Layanan Dasar', 'Kelas Besar', 'kelas', 'Bimbingan lintas kelas / satu angkatan sekaligus (seminar, talkshow).'],
        'Layanan Orientasi'        => ['Layanan Dasar', 'Kelas Besar', 'kelas', 'Pengenalan lingkungan sekolah bagi siswa baru/pindahan.'],
        'Layanan Informasi'        => ['Layanan Dasar', 'Klasikal', 'kelas', 'Pemberian informasi (cara belajar, kesehatan mental, perundungan, studi lanjut).'],
        'Penguasaan Konten'        => ['Layanan Dasar', 'Kelompok', 'siswa', 'Latihan keterampilan tertentu (manajemen waktu, teknik belajar, asertif).'],
        'Media Informasi BK'       => ['Layanan Dasar', 'Lainnya', 'kelas', 'Papan bimbingan, leaflet, poster, unggahan daring.'],
        // Peminatan & perencanaan individual
        'Layanan Peminatan'        => ['Peminatan & Perencanaan Individual', 'Kelompok', 'siswa', 'Pemilihan mata pelajaran pilihan/jurusan sesuai minat & potensi.'],
        'Perencanaan Individual'   => ['Peminatan & Perencanaan Individual', 'Individual', 'siswa', 'Menyusun rencana belajar/karier/studi lanjut pribadi siswa.'],
        'Penempatan & Penyaluran'  => ['Peminatan & Perencanaan Individual', 'Individual', 'siswa', 'Penempatan di kelompok belajar, ekstrakurikuler, magang, atau studi lanjut.'],
        // Responsif – membantu siswa yang mengalami masalah
        'Konseling Individual'     => ['Responsif', 'Individual', 'siswa', 'Konseling tatap muka satu siswa untuk masalah pribadi/sosial/belajar/karier.'],
        'Konseling Kelompok'       => ['Responsif', 'Kelompok', 'siswa', 'Pengentasan masalah pribadi anggota kelompok (bersifat rahasia).'],
        'Konsultasi'               => ['Responsif', 'Individual', 'pihak', 'Konsultasi dengan guru/wali kelas/orang tua tentang penanganan siswa.'],
        'Mediasi'                  => ['Responsif', 'Kelompok', 'siswa', 'Menengahi konflik/perselisihan antarsiswa atau siswa dengan pihak lain.'],
        'Advokasi'                 => ['Responsif', 'Individual', 'siswa', 'Pendampingan pemenuhan hak siswa (perundungan, diskriminasi, kekerasan).'],
        'Kolaborasi'               => ['Responsif', 'Lainnya', 'pihak', 'Kerja sama dengan guru, orang tua, atau pihak luar (puskesmas, psikolog).'],
        'Konferensi Kasus'         => ['Responsif', 'Lainnya', 'pihak', 'Pertemuan pihak terkait membahas penanganan kasus siswa (tertutup).'],
        'Pemanggilan Orang Tua'    => ['Responsif', 'Individual', 'pihak', 'Pertemuan dengan orang tua/wali di sekolah.'],
        'Kunjungan Rumah'          => ['Responsif', 'Individual', 'pihak', 'Mengunjungi rumah siswa untuk data & kerja sama orang tua.'],
        'Alih Tangan Kasus'        => ['Responsif', 'Individual', 'pihak', 'Merujuk kasus ke ahli lain (psikolog, dokter, lembaga) yang lebih berwenang.'],
        // Dukungan sistem / kegiatan pendukung
        'Aplikasi Instrumentasi'   => ['Dukungan Sistem', 'Klasikal', 'kelas', 'Asesmen kebutuhan: AKPD, DCM, angket minat, sosiometri, tes.'],
        'Himpunan Data'            => ['Dukungan Sistem', 'Lainnya', 'kelas', 'Pengumpulan & pemutakhiran data pribadi siswa (buku pribadi).'],
        'Tampilan Kepustakaan'     => ['Dukungan Sistem', 'Lainnya', 'siswa', 'Penyediaan bahan bacaan/referensi pengembangan diri.'],
        'Pengembangan Profesi'     => ['Dukungan Sistem', 'Lainnya', 'pihak', 'Pelatihan, MGBK, seminar, atau penelitian guru BK.'],
    ];

    /** Daftar nama jenis (untuk validasi & filter). */
    public const JENIS = [
        'Bimbingan Klasikal', 'Bimbingan Kelompok', 'Bimbingan Kelas Besar', 'Layanan Orientasi', 'Layanan Informasi', 'Penguasaan Konten', 'Media Informasi BK',
        'Layanan Peminatan', 'Perencanaan Individual', 'Penempatan & Penyaluran',
        'Konseling Individual', 'Konseling Kelompok', 'Konsultasi', 'Mediasi', 'Advokasi', 'Kolaborasi', 'Konferensi Kasus', 'Pemanggilan Orang Tua', 'Kunjungan Rumah', 'Alih Tangan Kasus',
        'Aplikasi Instrumentasi', 'Himpunan Data', 'Tampilan Kepustakaan', 'Pengembangan Profesi',
    ];

    /** Jenis yang tidak membutuhkan siswa/kelas tertentu. */
    public const TANPA_PESERTA = ['Pengembangan Profesi', 'Media Informasi BK', 'Tampilan Kepustakaan'];

    public const BIDANG = ['Pribadi', 'Sosial', 'Belajar', 'Karier'];
    public const STATUS = ['Dijadwalkan', 'Berlangsung', 'Selesai'];

    public function base()
    {
        return $this->select('bk_layanan.*, kelas.nama_kelas, users.nama_lengkap AS konselor')
            ->join('kelas', 'kelas.id = bk_layanan.kelas_id', 'left')
            ->join('users', 'users.id = bk_layanan.konselor_id', 'left');
    }

    public function daftar(int $tpId, array $f = [], int $perPage = 25): array
    {
        $b = $this->base()->where('bk_layanan.tahun_pelajaran_id', $tpId);
        foreach (['jenis_layanan', 'bidang', 'status', 'komponen'] as $k) {
            if (! empty($f[$k])) {
                $b->where('bk_layanan.' . $k, $f[$k]);
            }
        }
        if (! empty($f['siswa_id'])) {
            $b->whereIn('bk_layanan.id', static fn ($q) => $q->select('layanan_id')->from('bk_peserta')->where('siswa_id', (int) $f['siswa_id']));
        }
        if (! empty($f['dari'])) {
            $b->where('bk_layanan.tanggal >=', $f['dari']);
        }
        if (! empty($f['sampai'])) {
            $b->where('bk_layanan.tanggal <=', $f['sampai']);
        }
        if (! empty($f['q'])) {
            $b->like('bk_layanan.topik', $f['q']);
        }
        $rows = $b->orderBy('bk_layanan.tanggal', 'DESC')->orderBy('bk_layanan.id', 'DESC')->paginate($perPage);
        return $this->lampirkanPeserta($rows);
    }

    public function lampirkanPeserta(array $rows): array
    {
        if (! $rows) {
            return $rows;
        }
        $peserta = [];
        foreach ($this->db->table('bk_peserta p')->select('p.layanan_id, s.id, s.nama_lengkap, s.nis')
            ->join('siswa s', 's.id = p.siswa_id')->whereIn('p.layanan_id', array_column($rows, 'id'))
            ->orderBy('s.nama_lengkap')->get()->getResultArray() as $p) {
            $peserta[$p['layanan_id']][] = $p;
        }
        foreach ($rows as &$r) {
            $r['peserta'] = $peserta[$r['id']] ?? [];
        }
        return $rows;
    }

    public function detail(int $id): ?array
    {
        $row = $this->base()->where('bk_layanan.id', $id)->first();
        return $row ? $this->lampirkanPeserta([$row])[0] : null;
    }

    public function simpanPeserta(int $layananId, array $siswaIds): void
    {
        $this->db->table('bk_peserta')->where('layanan_id', $layananId)->delete();
        $rows = [];
        foreach (array_unique(array_filter(array_map('intval', $siswaIds))) as $sid) {
            $rows[] = ['layanan_id' => $layananId, 'siswa_id' => $sid];
        }
        if ($rows) {
            $this->db->table('bk_peserta')->insertBatch($rows);
        }
    }

    public function riwayatSiswa(int $siswaId): array
    {
        $rows = $this->base()
            ->join('bk_peserta', 'bk_peserta.layanan_id = bk_layanan.id')
            ->where('bk_peserta.siswa_id', $siswaId)
            ->orderBy('bk_layanan.tanggal', 'DESC')->findAll();
        return $rows;
    }

    public function statistik(int $tpId): array
    {
        return array_column(
            $this->select('jenis_layanan, COUNT(*) AS n')->where('tahun_pelajaran_id', $tpId)->groupBy('jenis_layanan')->findAll(),
            'n', 'jenis_layanan'
        );
    }
}
