<?php

namespace App\Models;

use App\Libraries\Kalender;
use CodeIgniter\Model;

/**
 * Jadwal pelajaran ber-versi: setiap baris berlaku dari berlaku_mulai s.d. berlaku_sampai (NULL = tanpa batas),
 * sehingga perubahan jadwal di tengah semester tidak mengubah riwayat jurnal.
 */
class JadwalModel extends Model
{
    protected $table         = 'jadwal_pelajaran';
    protected $returnType    = 'array';
    protected $allowedFields = ['tahun_pelajaran_id', 'penugasan_guru_id', 'kelas_id', 'hari', 'jam_pelajaran_id', 'berlaku_mulai', 'berlaku_sampai'];
    protected $useTimestamps = true;

    private function base(int $tpId)
    {
        return $this->select('jadwal_pelajaran.*, jam_pelajaran.jam_ke, jam_pelajaran.jam_mulai, jam_pelajaran.jam_selesai,
                penugasan_guru.guru_id, penugasan_guru.mapel_id, mata_pelajaran.nama_mapel, mata_pelajaran.kode_mapel,
                kelas.nama_kelas, guru.nama_lengkap, guru.gelar_depan, guru.gelar_belakang')
            ->join('jam_pelajaran', 'jam_pelajaran.id = jadwal_pelajaran.jam_pelajaran_id')
            ->join('penugasan_guru', 'penugasan_guru.id = jadwal_pelajaran.penugasan_guru_id')
            ->join('mata_pelajaran', 'mata_pelajaran.id = penugasan_guru.mapel_id')
            ->join('guru', 'guru.id = penugasan_guru.guru_id')
            ->join('kelas', 'kelas.id = jadwal_pelajaran.kelas_id')
            ->where('jadwal_pelajaran.tahun_pelajaran_id', $tpId);
    }

    /** Batasi ke baris yang berlaku pada tanggal tsb. */
    private function berlakuPada($b, string $tanggal)
    {
        return $b->groupStart()->where('jadwal_pelajaran.berlaku_mulai', null)->orWhere('jadwal_pelajaran.berlaku_mulai <=', $tanggal)->groupEnd()
            ->groupStart()->where('jadwal_pelajaran.berlaku_sampai', null)->orWhere('jadwal_pelajaran.berlaku_sampai >=', $tanggal)->groupEnd();
    }

    /** Batasi ke baris yang masih berlaku pada/atau setelah tanggal tsb (untuk cek bentrok). */
    private function berlakuSejak($b, string $tanggal)
    {
        return $b->groupStart()->where('jadwal_pelajaran.berlaku_sampai', null)->orWhere('jadwal_pelajaran.berlaku_sampai >=', $tanggal)->groupEnd();
    }

    public function detail(int $id): ?array
    {
        $row = $this->find($id);
        return $row ? $this->base((int) $row['tahun_pelajaran_id'])->where('jadwal_pelajaran.id', $id)->first() : null;
    }

    /** f: kelas_id, guru_id, hari, tanggal (berlaku pada tanggal; bawaan: hari ini) */
    public function daftar(int $tpId, array $f = []): array
    {
        $b = $this->base($tpId);
        foreach (['kelas_id' => 'jadwal_pelajaran.kelas_id', 'guru_id' => 'penugasan_guru.guru_id', 'hari' => 'jadwal_pelajaran.hari'] as $k => $col) {
            if (! empty($f[$k])) {
                $b->where($col, (int) $f[$k]);
            }
        }
        $this->berlakuPada($b, $f['tanggal'] ?? date('Y-m-d'));
        return $b->orderBy('jadwal_pelajaran.hari')->orderBy('jam_pelajaran.jam_mulai')->orderBy('kelas.nama_kelas')->findAll();
    }

    /** Matriks jadwal [hari][jam_ke] => row. */
    public function grid(int $tpId, array $f): array
    {
        $out = [];
        foreach ($this->daftar($tpId, $f) as $r) {
            $out[$r['hari']][$r['jam_ke']] = $r;
        }
        return $out;
    }

    public function bentrokKelas(int $tpId, int $kelasId, int $hari, int $jamId, string $sejak, ?int $exceptId = null): ?array
    {
        $b = $this->base($tpId)->where(['jadwal_pelajaran.kelas_id' => $kelasId, 'jadwal_pelajaran.hari' => $hari, 'jadwal_pelajaran.jam_pelajaran_id' => $jamId]);
        $this->berlakuSejak($b, $sejak);
        if ($exceptId) {
            $b->where('jadwal_pelajaran.id !=', $exceptId);
        }
        return $b->first();
    }

    public function bentrokGuru(int $tpId, int $guruId, int $hari, int $jamId, string $sejak, ?int $exceptId = null): ?array
    {
        $jam = model(JamPelajaranModel::class)->find($jamId);
        $b   = $this->base($tpId)->where(['penugasan_guru.guru_id' => $guruId, 'jadwal_pelajaran.hari' => $hari]);
        // slot khusus vs bawaan bisa berbeda id; bandingkan rentang waktunya
        $b->where('jam_pelajaran.jam_mulai <', $jam['jam_selesai'])->where('jam_pelajaran.jam_selesai >', $jam['jam_mulai']);
        $this->berlakuSejak($b, $sejak);
        if ($exceptId) {
            $b->where('jadwal_pelajaran.id !=', $exceptId);
        }
        return $b->first();
    }

    /**
     * Sesi mengajar pada satu HARI JADWAL: slot berurutan dengan penugasan sama digabung (jam 1–2 = 1 sesi = 1 jurnal).
     */
    public function sesiHari(int $tpId, int $hari, array $f = [], ?string $tanggal = null): array
    {
        $rows = $this->daftar($tpId, $f + ['hari' => $hari, 'tanggal' => $tanggal ?? date('Y-m-d')]);

        $pos = [];
        foreach (model(JamPelajaranModel::class)->kbmHari($hari) as $i => $j) {
            $pos[$j['id']] = $i;
        }
        usort($rows, static fn ($a, $b) => [$a['kelas_id'], $a['jam_mulai']] <=> [$b['kelas_id'], $b['jam_mulai']]);

        $sesi = [];
        $last = null;
        foreach ($rows as $r) {
            $p = $pos[$r['jam_pelajaran_id']] ?? -99;
            if ($last !== null && (int) $sesi[$last]['penugasan_guru_id'] === (int) $r['penugasan_guru_id']
                && (int) $sesi[$last]['kelas_id'] === (int) $r['kelas_id'] && $sesi[$last]['_pos'] + 1 === $p) {
                $sesi[$last]['jam_selesai']  = $r['jam_selesai'];
                $sesi[$last]['jam_ke_akhir'] = $r['jam_ke'];
                $sesi[$last]['jumlah_jp']++;
                $sesi[$last]['jadwal_ids'][] = (int) $r['id'];
                $sesi[$last]['_pos']         = $p;
                continue;
            }
            $r += ['jam_ke_akhir' => $r['jam_ke'], 'jumlah_jp' => 1, 'jadwal_ids' => [(int) $r['id']], '_pos' => $p];
            $sesi[] = $r;
            $last   = array_key_last($sesi);
        }
        foreach ($sesi as &$s) {
            $s['jam_ke_label'] = $s['jam_ke'] == $s['jam_ke_akhir'] ? (string) $s['jam_ke'] : $s['jam_ke'] . '-' . $s['jam_ke_akhir'];
            unset($s['_pos']);
        }
        usort($sesi, static fn ($a, $b) => [$a['jam_mulai'], $a['nama_kelas']] <=> [$b['jam_mulai'], $b['nama_kelas']]);
        return $sesi;
    }

    /**
     * Sesi yang BENAR-BENAR berlangsung pada tanggal tsb menurut kalender akademik:
     * memperhitungkan libur/ujian per kelas dan hari masuk pengganti (pakai jadwal hari lain).
     */
    public function sesiTanggal(int $tpId, string $tanggal, array $f = []): array
    {
        $hariSet = array_unique(array_merge([(int) date('N', strtotime($tanggal))], Kalender::hariPengganti($tanggal)));
        $out     = [];
        foreach ($hariSet as $h) {
            if ($h < 1 || $h > 7) {
                continue;
            }
            foreach ($this->sesiHari($tpId, $h, $f, $tanggal) as $s) {
                $k = (int) $s['kelas_id'];
                if (Kalender::hariJadwal($tanggal, $k) === (int) $s['hari'] && Kalender::kbm($tanggal, $k)) {
                    $out[] = $s;
                }
            }
        }
        usort($out, static fn ($a, $b) => [$a['jam_mulai'], $a['nama_kelas']] <=> [$b['jam_mulai'], $b['nama_kelas']]);
        return $out;
    }

    /** Sesi yang memuat jadwal tertentu (pada tanggal tertentu). */
    public function sesiDariJadwal(int $jadwalId, ?string $tanggal = null): ?array
    {
        $j = $this->find($jadwalId);
        if (! $j) {
            return null;
        }
        $tgl = $tanggal ?? date('Y-m-d');
        foreach ($this->sesiHari((int) $j['tahun_pelajaran_id'], (int) $j['hari'], ['kelas_id' => $j['kelas_id']], $tgl) as $s) {
            if (in_array($jadwalId, $s['jadwal_ids'], true)) {
                return $s;
            }
        }
        // jadwal sudah tidak berlaku pada tanggal tsb: kembalikan sesi tunggal dari baris itu
        $row = $this->base((int) $j['tahun_pelajaran_id'])->where('jadwal_pelajaran.id', $jadwalId)->first();
        return $row ? $row + ['jam_ke_akhir' => $row['jam_ke'], 'jumlah_jp' => 1, 'jadwal_ids' => [$jadwalId], 'jam_ke_label' => (string) $row['jam_ke'], '_tidak_berlaku' => true] : null;
    }

    /**
     * Pindahkan jadwal suatu hari dari satu set slot ke set slot lain berdasarkan nomor jam_ke
     * (dipakai saat membuat/menghapus jam khusus hari). Mengembalikan jumlah baris yang tidak terpetakan.
     */
    public function petakanUlangHari(int $hari, array $dariSlot, array $keSlot): int
    {
        $ke = [];
        foreach ($keSlot as $s) {
            if ((int) $s['is_kbm'] === 1) {
                $ke[(int) $s['jam_ke']] = (int) $s['id'];
            }
        }
        $gagal = 0;
        foreach ($dariSlot as $s) {
            if ((int) $s['is_kbm'] !== 1) {
                continue;
            }
            $baris = $this->where(['hari' => $hari, 'jam_pelajaran_id' => $s['id']])->findAll();
            if (! $baris) {
                continue;
            }
            if (! isset($ke[(int) $s['jam_ke']])) {
                $gagal += count($baris);
                continue;
            }
            $this->builder()->where(['hari' => $hari, 'jam_pelajaran_id' => $s['id']])->update(['jam_pelajaran_id' => $ke[(int) $s['jam_ke']]]);
        }
        return $gagal;
    }
}
