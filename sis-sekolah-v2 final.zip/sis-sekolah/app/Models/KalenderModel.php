<?php

namespace App\Models;

use CodeIgniter\Model;

class KalenderModel extends Model
{
    protected $table         = 'kalender_akademik';
    protected $returnType    = 'array';
    protected $allowedFields = ['tahun_pelajaran_id', 'tanggal_mulai', 'tanggal_selesai', 'jenis', 'nama', 'keterangan', 'ada_kbm', 'ada_absensi', 'kelas_ids', 'hari_jadwal'];
    protected $useTimestamps = true;

    public const JENIS = ['Libur Nasional', 'Cuti Bersama', 'Libur Semester', 'Libur Fakultatif', 'Ujian', 'Kegiatan Sekolah', 'Masuk Pengganti', 'Kokurikuler'];

    /** Bawaan per jenis: [ada_kbm, ada_absensi, warna bootstrap] */
    public const BAWAAN = [
        'Libur Nasional'   => [0, 0, 'danger'],
        'Cuti Bersama'     => [0, 0, 'danger'],
        'Libur Semester'   => [0, 0, 'secondary'],
        'Libur Fakultatif' => [0, 0, 'warning'],
        'Ujian'            => [0, 1, 'primary'],
        'Kegiatan Sekolah' => [0, 1, 'info'],
        'Masuk Pengganti'  => [1, 1, 'success'],
        'Kokurikuler'      => [0, 1, 'info'],
    ];

    /** Daftar id kelas sasaran; [] = seluruh sekolah. */
    public static function kelasDari(?string $csv): array
    {
        return array_values(array_filter(array_map('intval', explode(',', (string) $csv))));
    }

    /** Agenda yang beririsan dengan rentang tanggal. */
    public function rentang(string $dari, string $sampai): array
    {
        return $this->where('tanggal_mulai <=', $sampai)->where('tanggal_selesai >=', $dari)
            ->orderBy('tanggal_mulai')->findAll();
    }

    public function mendatang(int $limit = 5): array
    {
        return $this->where('tanggal_selesai >=', date('Y-m-d'))->orderBy('tanggal_mulai')->limit($limit)->find();
    }
}
