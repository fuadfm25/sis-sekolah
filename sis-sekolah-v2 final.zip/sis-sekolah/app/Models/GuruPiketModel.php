<?php

namespace App\Models;

use CodeIgniter\Model;

class GuruPiketModel extends Model
{
    protected $table         = 'guru_piket';
    protected $returnType    = 'array';
    protected $allowedFields = ['tahun_pelajaran_id', 'guru_id', 'hari'];
    protected $useTimestamps = true;

    public function perHari(int $tpId): array
    {
        $rows = $this->select('guru_piket.*, guru.nama_lengkap, guru.gelar_depan, guru.gelar_belakang')
            ->join('guru', 'guru.id = guru_piket.guru_id')
            ->where('tahun_pelajaran_id', $tpId)->orderBy('hari')->orderBy('guru.nama_lengkap')->findAll();
        $out = [];
        foreach ($rows as $r) {
            $out[$r['hari']][] = $r;
        }
        return $out;
    }
}
