<?php

namespace App\Models;

use CodeIgniter\Model;

class GuruModel extends Model
{
    protected $table         = 'guru';
    protected $returnType    = 'array';
    protected $allowedFields = ['user_id', 'nip', 'nuptk', 'nama_lengkap', 'gelar_depan', 'gelar_belakang', 'jenis_kelamin', 'no_hp', 'email', 'status_kepegawaian', 'is_active', 'rfid'];
    protected $useTimestamps = true;

    public function listAktif(): array
    {
        return $this->where('is_active', 1)->orderBy('nama_lengkap')->findAll();
    }

    public function withUser(): array
    {
        return $this->select('guru.*, users.username')
            ->join('users', 'users.id = guru.user_id', 'left')
            ->orderBy('guru.nama_lengkap')->findAll();
    }

    public function byUser(int $userId): ?array
    {
        return $this->where('user_id', $userId)->first();
    }
}
