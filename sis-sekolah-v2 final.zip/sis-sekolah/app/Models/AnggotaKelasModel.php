<?php

namespace App\Models;

use CodeIgniter\Model;

class AnggotaKelasModel extends Model
{
    protected $table         = 'anggota_kelas';
    protected $returnType    = 'array';
    protected $allowedFields = ['tahun_pelajaran_id', 'kelas_id', 'siswa_id', 'no_absen', 'status'];
    protected $useTimestamps = true;

    /** Siswa dalam satu kelas pada TP tertentu, urut no absen lalu nama. */
    public function siswaKelas(int $kelasId, int $tpId, bool $hanyaAktif = true): array
    {
        $b = $this->select('anggota_kelas.id AS anggota_id, anggota_kelas.no_absen, anggota_kelas.status AS status_anggota, siswa.*')
            ->join('siswa', 'siswa.id = anggota_kelas.siswa_id')
            ->where(['anggota_kelas.kelas_id' => $kelasId, 'anggota_kelas.tahun_pelajaran_id' => $tpId]);
        if ($hanyaAktif) {
            $b->where('siswa.status', 'Aktif');
        }
        return $b->orderBy('anggota_kelas.no_absen IS NULL', '', false)->orderBy('anggota_kelas.no_absen')->orderBy('siswa.nama_lengkap')->findAll();
    }

    public function kelasSiswa(int $siswaId, int $tpId): ?array
    {
        return $this->select('kelas.*')
            ->join('kelas', 'kelas.id = anggota_kelas.kelas_id')
            ->where(['anggota_kelas.siswa_id' => $siswaId, 'anggota_kelas.tahun_pelajaran_id' => $tpId])
            ->first();
    }

    /** Siswa berstatus Aktif yang belum masuk kelas manapun pada TP. */
    public function siswaBelumBerkelas(int $tpId): array
    {
        return $this->db->table('siswa')
            ->select('siswa.*')
            ->join('anggota_kelas', 'anggota_kelas.siswa_id = siswa.id AND anggota_kelas.tahun_pelajaran_id = ' . $tpId, 'left')
            ->where('anggota_kelas.id', null)
            ->where('siswa.status', 'Aktif')
            ->orderBy('siswa.nama_lengkap')
            ->get()->getResultArray();
    }

    /** Urutkan ulang nomor absen berdasarkan nama. */
    public function urutkanAbsen(int $kelasId, int $tpId): void
    {
        $rows = $this->select('anggota_kelas.id')
            ->join('siswa', 'siswa.id = anggota_kelas.siswa_id')
            ->where(['kelas_id' => $kelasId, 'tahun_pelajaran_id' => $tpId])
            ->orderBy('siswa.nama_lengkap')->findAll();
        foreach ($rows as $i => $r) {
            $this->update($r['id'], ['no_absen' => $i + 1]);
        }
    }
}
