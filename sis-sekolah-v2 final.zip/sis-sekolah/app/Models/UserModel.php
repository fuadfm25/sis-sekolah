<?php

namespace App\Models;

use CodeIgniter\Model;

class UserModel extends Model
{
    protected $table         = 'users';
    protected $returnType    = 'array';
    protected $allowedFields = ['username', 'password', 'nama_lengkap', 'email', 'is_active', 'wajib_ganti_password', 'password_sendiri_at', 'last_login'];
    protected $useTimestamps = true;

    public function roleNames(int $userId): array
    {
        return array_column(
            $this->db->table('user_roles ur')->select('r.nama_role')
                ->join('roles r', 'r.id = ur.role_id')->where('ur.user_id', $userId)
                ->get()->getResultArray(),
            'nama_role'
        );
    }

    public function roleIds(int $userId): array
    {
        return array_map('intval', array_column(
            $this->db->table('user_roles')->select('role_id')->where('user_id', $userId)->get()->getResultArray(),
            'role_id'
        ));
    }

    public function syncRoles(int $userId, array $roleIds): void
    {
        $this->db->table('user_roles')->where('user_id', $userId)->delete();
        $rows = [];
        foreach (array_unique(array_filter($roleIds)) as $rid) {
            $rows[] = ['user_id' => $userId, 'role_id' => (int) $rid];
        }
        if ($rows) {
            $this->db->table('user_roles')->insertBatch($rows);
        }
    }

    /** Tambahkan satu role berdasarkan nama tanpa menghapus role lain. */
    public function addRole(int $userId, string $roleName): void
    {
        $roleId = $this->db->table('roles')->where('nama_role', $roleName)->get()->getRow('id');
        if ($roleId && ! $this->db->table('user_roles')->where(['user_id' => $userId, 'role_id' => $roleId])->countAllResults()) {
            $this->db->table('user_roles')->insert(['user_id' => $userId, 'role_id' => $roleId]);
        }
    }

    /** Password sementara yang mudah dibaca (tanpa 0/O, 1/l/I). */
    public static function passwordSementara(int $panjang = 8): string
    {
        $abjad = 'abcdefghjkmnpqrstuvwxyz23456789';
        $out   = '';
        for ($i = 0; $i < $panjang; $i++) {
            $out .= $abjad[random_int(0, strlen($abjad) - 1)];
        }
        return $out;
    }

    /** Jumlah admin aktif selain $kecuali (mencegah sekolah kehilangan semua akun admin). */
    public function jumlahAdminAktif(?int $kecuali = null): int
    {
        $b = $this->db->table('users u')->join('user_roles ur', 'ur.user_id = u.id')->join('roles r', 'r.id = ur.role_id')
            ->where(['r.nama_role' => 'admin', 'u.is_active' => 1]);
        if ($kecuali) {
            $b->where('u.id !=', $kecuali);
        }
        return $b->countAllResults();
    }

    /** Username unik dari teks dasar: "Budi Santoso, S.Pd." → budi.santoso (budi.santoso2 bila sudah dipakai). */
    public function usernameUnik(string $dasar): string
    {
        $u = strtolower(trim(preg_replace('/[^a-z0-9]+/i', '.', preg_replace('/,.*$/', '', $dasar)), '.'));
        $p = explode('.', $u);
        $u = implode('.', array_slice(array_filter($p, static fn ($x) => strlen($x) > 1 || ctype_digit($x)), 0, 2)) ?: 'guru';
        $u = substr($u, 0, 40);
        $c = $u;
        for ($i = 2; $this->where('username', $c)->countAllResults() > 0; $i++) {
            $c = $u . $i;
        }
        return $c;
    }

    /** Semua user + daftar role + guru tertaut. f: role, q (cari nama/username), status (aktif/nonaktif/wajib) */
    public function withRoles(?string $role = null, array $f = []): array
    {
        $b = $this->select('users.*, guru.id AS guru_id, guru.nip, guru.nuptk')
            ->join('guru', 'guru.user_id = users.id', 'left');
        if (! empty($f['q'])) {
            $b->groupStart()->like('users.nama_lengkap', $f['q'])->orLike('users.username', $f['q'])->groupEnd();
        }
        if (($f['status'] ?? '') === 'aktif') {
            $b->where('users.is_active', 1);
        } elseif (($f['status'] ?? '') === 'nonaktif') {
            $b->where('users.is_active', 0);
        } elseif (($f['status'] ?? '') === 'wajib') {
            $b->where('users.wajib_ganti_password', 1);
        }
        $users = $b->orderBy('users.nama_lengkap')->findAll();

        $map = [];
        foreach ($this->db->table('user_roles ur')->select('ur.user_id, r.nama_role')->join('roles r', 'r.id = ur.role_id')->get()->getResultArray() as $r) {
            $map[$r['user_id']][] = $r['nama_role'];
        }
        $out = [];
        foreach ($users as $u) {
            $u['roles'] = $map[$u['id']] ?? [];
            if ($role && ! in_array($role, $u['roles'], true)) {
                continue;
            }
            $out[] = $u;
        }
        return $out;
    }
}
