<?php

namespace App\Models;

use CodeIgniter\Model;

class JurnalModel extends Model
{
    protected $table         = 'jurnal_pembelajaran';
    protected $returnType    = 'array';
    protected $allowedFields = [
        'guru_id',
        'tahun_pelajaran_id', 'jadwal_pelajaran_id', 'penugasan_guru_id', 'kelas_id', 'tanggal', 'jam_ke', 'jumlah_jp',
        'pertemuan_ke', 'materi', 'tujuan_pembelajaran', 'kegiatan', 'metode', 'penilaian', 'catatan', 'status_kbm', 'diisi_oleh',
    ];
    protected $useTimestamps = true;

    public function base()
    {
        return $this->select('jurnal_pembelajaran.*, kelas.nama_kelas, mata_pelajaran.nama_mapel, mata_pelajaran.kode_mapel,
                COALESCE(jurnal_pembelajaran.guru_id, penugasan_guru.guru_id) AS guru_id, guru.nama_lengkap, guru.gelar_depan, guru.gelar_belakang, users.nama_lengkap AS pengisi')
            ->join('penugasan_guru', 'penugasan_guru.id = jurnal_pembelajaran.penugasan_guru_id')
            ->join('mata_pelajaran', 'mata_pelajaran.id = penugasan_guru.mapel_id')
            ->join('guru', 'guru.id = COALESCE(jurnal_pembelajaran.guru_id, penugasan_guru.guru_id)', '', false)
            ->join('kelas', 'kelas.id = jurnal_pembelajaran.kelas_id')
            ->join('users', 'users.id = jurnal_pembelajaran.diisi_oleh', 'left');
    }

    public function detail(int $id): ?array
    {
        return $this->base()->where('jurnal_pembelajaran.id', $id)->first();
    }

    /** Peta jurnal per jadwal untuk satu tanggal: [jadwal_id => jurnal]. */
    public function petaTanggal(array $jadwalIds, string $tanggal): array
    {
        if (! $jadwalIds) {
            return [];
        }
        $rows = $this->whereIn('jadwal_pelajaran_id', $jadwalIds)->where('tanggal', $tanggal)->findAll();
        return array_column($rows, null, 'jadwal_pelajaran_id');
    }

    public function riwayat(int $tpId, array $f = [], int $perPage = 20): array
    {
        $b = $this->base()->where('jurnal_pembelajaran.tahun_pelajaran_id', $tpId);
        if (! empty($f['guru_id'])) {
            $b->where('COALESCE(jurnal_pembelajaran.guru_id, penugasan_guru.guru_id)', (int) $f['guru_id']);
        }
        if (! empty($f['kelas_id'])) {
            $b->where('jurnal_pembelajaran.kelas_id', (int) $f['kelas_id']);
        }
        if (! empty($f['penugasan_guru_id'])) {
            $b->where('jurnal_pembelajaran.penugasan_guru_id', (int) $f['penugasan_guru_id']);
        }
        if (! empty($f['dari'])) {
            $b->where('jurnal_pembelajaran.tanggal >=', $f['dari']);
        }
        if (! empty($f['sampai'])) {
            $b->where('jurnal_pembelajaran.tanggal <=', $f['sampai']);
        }
        return $b->orderBy('jurnal_pembelajaran.tanggal', 'DESC')->orderBy('jurnal_pembelajaran.jam_ke', 'ASC')->paginate($perPage);
    }

    public function pertemuanBerikut(int $penugasanId, ?string $sebelumTanggal = null): int
    {
        $b = $this->where('penugasan_guru_id', $penugasanId);
        if ($sebelumTanggal) {
            $b->where('tanggal <', $sebelumTanggal);
        }
        return $b->countAllResults() + 1;
    }

    /** Ringkasan presensi (jumlah per status) untuk daftar jurnal. */
    public function ringkasPresensi(array $jurnalIds): array
    {
        if (! $jurnalIds) {
            return [];
        }
        $out = [];
        foreach ($this->db->table('presensi_mapel')->select('jurnal_id, status, COUNT(*) AS n')->whereIn('jurnal_id', $jurnalIds)->groupBy(['jurnal_id', 'status'])->get()->getResultArray() as $r) {
            $out[$r['jurnal_id']][$r['status']] = (int) $r['n'];
        }
        return $out;
    }
}
