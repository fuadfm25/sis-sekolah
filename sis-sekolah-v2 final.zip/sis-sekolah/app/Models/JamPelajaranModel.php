<?php

namespace App\Models;

use CodeIgniter\Model;

/**
 * Slot jam pelajaran. hari = NULL → slot bawaan (semua hari); hari = 1..6 → slot khusus hari itu.
 * Bila suatu hari punya slot khusus, hari itu HANYA memakai slot khususnya.
 */
class JamPelajaranModel extends Model
{
    protected $table         = 'jam_pelajaran';
    protected $returnType    = 'array';
    protected $allowedFields = ['hari', 'jam_ke', 'jam_mulai', 'jam_selesai', 'is_kbm', 'keterangan'];
    protected $useTimestamps = true;

    private static array $cache = [];

    public function semua(): array
    {
        return $this->orderBy('hari')->orderBy('jam_mulai')->findAll();
    }

    public function bawaan(): array
    {
        return $this->where('hari', null)->orderBy('jam_mulai')->findAll();
    }

    public function khusus(int $hari): array
    {
        return $this->where('hari', $hari)->orderBy('jam_mulai')->findAll();
    }

    /** Slot yang berlaku pada hari tertentu (khusus bila ada, selain itu bawaan). */
    public function untukHari(int $hari): array
    {
        if (! isset(self::$cache[$hari])) {
            $k                  = $this->khusus($hari);
            self::$cache[$hari] = $k ?: $this->bawaan();
        }
        return self::$cache[$hari];
    }

    public function kbmHari(int $hari): array
    {
        return array_values(array_filter($this->untukHari($hari), static fn ($j) => (int) $j['is_kbm'] === 1));
    }

    /** Kompatibilitas: slot KBM bawaan. */
    public function kbm(): array
    {
        return array_values(array_filter($this->bawaan(), static fn ($j) => (int) $j['is_kbm'] === 1));
    }

    public static function resetCache(): void
    {
        self::$cache = [];
    }

    /** Nomor jam ke terbesar di seluruh hari (untuk baris tabel jadwal). */
    public function maxJamKe(array $hariList): int
    {
        $max = 0;
        foreach (array_keys($hariList) as $h) {
            foreach ($this->kbmHari($h) as $j) {
                $max = max($max, (int) $j['jam_ke']);
            }
        }
        return $max;
    }
}
