<?php

namespace App\Models;

use CodeIgniter\Model;

class TahunPelajaranModel extends Model
{
    protected $table         = 'tahun_pelajaran';
    protected $returnType    = 'array';
    protected $allowedFields = ['tahun_pelajaran', 'semester', 'tanggal_mulai', 'tanggal_selesai', 'is_active'];
    protected $useTimestamps = true;

    public function getAktif(): ?array
    {
        return $this->where('is_active', 1)->first();
    }

    public function setAktif(int $id): void
    {
        $this->db->transStart();
        $this->builder()->set('is_active', 0)->update();
        $this->update($id, ['is_active' => 1]);
        $this->db->transComplete();
    }

    public function label(array $tp): string
    {
        return $tp['tahun_pelajaran'] . ' - ' . $tp['semester'];
    }
}
