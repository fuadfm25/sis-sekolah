<?php

namespace App\Models;

use CodeIgniter\Model;

class PenugasanGuruModel extends Model
{
    protected $table         = 'penugasan_guru';
    protected $returnType    = 'array';
    protected $allowedFields = ['tahun_pelajaran_id', 'guru_id', 'mapel_id', 'kelas_id', 'jp_per_minggu'];
    protected $useTimestamps = true;

    private function base()
    {
        return $this->select('penugasan_guru.*, mata_pelajaran.nama_mapel, mata_pelajaran.kode_mapel, kelas.nama_kelas,
                guru.nama_lengkap, guru.gelar_depan, guru.gelar_belakang, guru.user_id AS guru_user_id')
            ->join('mata_pelajaran', 'mata_pelajaran.id = penugasan_guru.mapel_id')
            ->join('kelas', 'kelas.id = penugasan_guru.kelas_id')
            ->join('guru', 'guru.id = penugasan_guru.guru_id');
    }

    public function detail(int $id): ?array
    {
        return $this->base()->where('penugasan_guru.id', $id)->first();
    }

    public function daftar(int $tpId, array $f = []): array
    {
        $b = $this->base()->where('penugasan_guru.tahun_pelajaran_id', $tpId);
        if (! empty($f['kelas_id'])) {
            $b->where('penugasan_guru.kelas_id', (int) $f['kelas_id']);
        }
        if (! empty($f['guru_id'])) {
            $b->where('penugasan_guru.guru_id', (int) $f['guru_id']);
        }
        if (! empty($f['mapel_id'])) {
            $b->where('penugasan_guru.mapel_id', (int) $f['mapel_id']);
        }
        $rows = $b->orderBy('kelas.nama_kelas')->orderBy('mata_pelajaran.nama_mapel')->findAll();

        // jumlah slot jadwal terpasang
        $terpasang = [];
        foreach ($this->db->table('jadwal_pelajaran')->select('penugasan_guru_id, COUNT(*) AS n')->where('tahun_pelajaran_id', $tpId)->groupBy('penugasan_guru_id')->get()->getResultArray() as $r) {
            $terpasang[$r['penugasan_guru_id']] = (int) $r['n'];
        }
        foreach ($rows as &$r) {
            $r['jp_terjadwal'] = $terpasang[$r['id']] ?? 0;
        }
        return $rows;
    }
}
