<?php

namespace App\Models;

/**
 * Simpan baris berdasarkan kunci unik secara atomik (INSERT ... ON DUPLICATE KEY UPDATE / ON CONFLICT).
 * Aman bila dua pengguna (mis. kiosk & wali kelas) menyimpan data yang sama pada saat bersamaan.
 */
trait SimpanUnikTrait
{
    /**
     * @param array $kunci kolom unik => nilai  (harus sesuai indeks UNIQUE tabel)
     * @param array $data  kolom lain yang disimpan/diperbarui
     */
    public function simpanUnik(array $kunci, array $data): void
    {
        $now = date('Y-m-d H:i:s');
        $row = $kunci + $data + ['created_at' => $now, 'updated_at' => $now];
        $this->db->table($this->table)
            ->onConstraint(array_keys($kunci))
            ->updateFields(array_merge(array_keys($data), ['updated_at']))
            ->upsert($row);
    }
}
