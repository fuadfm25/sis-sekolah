<?php

namespace App\Models;

use CodeIgniter\Model;

class JenisPerilakuModel extends Model
{
    protected $table         = 'jenis_perilaku';
    protected $returnType    = 'array';
    protected $allowedFields = ['kategori', 'nama', 'tingkat', 'poin', 'is_active'];
    protected $useTimestamps = true;

    public function aktif(): array
    {
        return $this->where('is_active', 1)->orderBy('kategori', 'DESC')->orderBy('poin')->orderBy('nama')->findAll();
    }
}
