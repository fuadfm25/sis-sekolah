<?php

namespace App\Models;

use CodeIgniter\Model;

/** Kegiatan kokurikuler (pengganti P5) dengan 8 dimensi profil lulusan. */
class KokurikulerModel extends Model
{
    protected $table         = 'kokurikuler';
    protected $returnType    = 'array';
    protected $allowedFields = ['tahun_pelajaran_id', 'judul', 'tema', 'bentuk', 'dimensi', 'kelas_ids', 'tanggal_mulai', 'tanggal_selesai', 'alokasi_jp', 'deskripsi', 'koordinator_id', 'kalender_id', 'refleksi'];
    protected $useTimestamps = true;

    /** 8 dimensi profil lulusan. */
    public const DIMENSI = [
        'keimanan'   => 'Keimanan dan ketakwaan terhadap Tuhan YME',
        'kewargaan'  => 'Kewargaan',
        'penalaran'  => 'Penalaran kritis',
        'kreativitas' => 'Kreativitas',
        'kolaborasi' => 'Kolaborasi',
        'kemandirian' => 'Kemandirian',
        'kesehatan'  => 'Kesehatan',
        'komunikasi' => 'Komunikasi',
    ];

    public const BENTUK = ['Pembelajaran kolaboratif lintas disiplin ilmu', 'Gerakan 7 Kebiasaan Anak Indonesia Hebat', 'Cara lainnya'];
}
