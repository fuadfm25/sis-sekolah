<?php

namespace App\Models;

use CodeIgniter\Model;

class IzinSiswaModel extends Model
{
    protected $table         = 'izin_siswa';
    protected $returnType    = 'array';
    protected $allowedFields = ['siswa_id', 'tanggal_mulai', 'tanggal_selesai', 'jenis', 'jam_keluar', 'penjemput', 'batas_kembali', 'keluar_at', 'keluar_oleh', 'kembali_at', 'kembali_oleh', 'status_keluar', 'catatan_perilaku_id', 'keterangan', 'lampiran', 'dicatat_oleh'];
    protected $useTimestamps = true;

    public const JENIS = ['S' => 'Sakit', 'I' => 'Izin', 'D' => 'Dispensasi (tugas sekolah)'];

    /** Status absensi harian yang dihasilkan: dispensasi dihitung hadir. */
    public static function statusAbsen(string $jenis): string
    {
        return $jenis === 'D' ? 'H' : $jenis;
    }

    /** Siswa yang izin keluar/pulang awal pada tanggal tertentu (untuk laporan piket & halaman gerbang). */
    public function pulangAwal(string $tanggal, int $tpId): array
    {
        return $this->select('izin_siswa.*, siswa.nama_lengkap, siswa.nis, kelas.nama_kelas, users.nama_lengkap AS pencatat, uk.nama_lengkap AS petugas_keluar, um.nama_lengkap AS petugas_kembali')
            ->join('users uk', 'uk.id = izin_siswa.keluar_oleh', 'left')->join('users um', 'um.id = izin_siswa.kembali_oleh', 'left')
            ->join('siswa', 'siswa.id = izin_siswa.siswa_id')
            ->join('anggota_kelas', 'anggota_kelas.siswa_id = siswa.id AND anggota_kelas.tahun_pelajaran_id = ' . $tpId)
            ->join('kelas', 'kelas.id = anggota_kelas.kelas_id')
            ->join('users', 'users.id = izin_siswa.dicatat_oleh', 'left')
            ->where('izin_siswa.tanggal_mulai', $tanggal)->where('izin_siswa.jam_keluar IS NOT NULL')
            ->orderBy('izin_siswa.jam_keluar')->findAll();
    }

    public function daftar(int $tpId, array $f = []): array
    {
        $b = $this->select('izin_siswa.*, siswa.nama_lengkap, siswa.nis, kelas.nama_kelas, kelas.id AS kelas_id, users.nama_lengkap AS pencatat')
            ->join('siswa', 'siswa.id = izin_siswa.siswa_id')
            ->join('anggota_kelas', 'anggota_kelas.siswa_id = siswa.id AND anggota_kelas.tahun_pelajaran_id = ' . $tpId)
            ->join('kelas', 'kelas.id = anggota_kelas.kelas_id')
            ->join('users', 'users.id = izin_siswa.dicatat_oleh', 'left');
        if (! empty($f['kelas_ids'])) {
            $b->whereIn('kelas.id', $f['kelas_ids']);
        }
        if (! empty($f['dari'])) {
            $b->where('izin_siswa.tanggal_selesai >=', $f['dari']);
        }
        if (! empty($f['sampai'])) {
            $b->where('izin_siswa.tanggal_mulai <=', $f['sampai']);
        }
        return $b->orderBy('izin_siswa.tanggal_mulai', 'DESC')->orderBy('kelas.nama_kelas')->findAll(200);
    }
}
