<?php

namespace App\Models;

use CodeIgniter\Model;

class IzinGuruModel extends Model
{
    protected $table         = 'izin_guru';
    protected $returnType    = 'array';
    protected $allowedFields = ['guru_id', 'tanggal_mulai', 'tanggal_selesai', 'jenis', 'keterangan', 'tugas_siswa', 'lampiran', 'status', 'diputus_oleh', 'catatan_putusan'];
    protected $useTimestamps = true;

    public const JENIS = ['S' => 'Sakit', 'I' => 'Izin', 'DL' => 'Dinas Luar', 'C' => 'Cuti'];

    public function daftar(array $f = []): array
    {
        $b = $this->select('izin_guru.*, guru.nama_lengkap, guru.gelar_depan, guru.gelar_belakang, users.nama_lengkap AS pemutus')
            ->join('guru', 'guru.id = izin_guru.guru_id')
            ->join('users', 'users.id = izin_guru.diputus_oleh', 'left');
        if (! empty($f['guru_id'])) {
            $b->where('izin_guru.guru_id', (int) $f['guru_id']);
        }
        if (! empty($f['status'])) {
            $b->where('izin_guru.status', $f['status']);
        }
        if (! empty($f['tanggal'])) {
            $b->where('izin_guru.tanggal_mulai <=', $f['tanggal'])->where('izin_guru.tanggal_selesai >=', $f['tanggal']);
        }
        return $b->orderBy('izin_guru.tanggal_mulai', 'DESC')->findAll(200);
    }

    /** Izin guru yang disetujui dan berlaku pada tanggal tsb: [guru_id => izin]. */
    public function berlaku(string $tanggal): array
    {
        return array_column($this->daftar(['tanggal' => $tanggal, 'status' => 'Disetujui']), null, 'guru_id');
    }
}
