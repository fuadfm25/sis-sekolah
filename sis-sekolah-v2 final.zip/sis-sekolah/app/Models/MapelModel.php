<?php

namespace App\Models;

use CodeIgniter\Model;

class MapelModel extends Model
{
    protected $table         = 'mata_pelajaran';
    protected $returnType    = 'array';
    protected $allowedFields = ['kode_mapel', 'nama_mapel', 'kelompok', 'is_active'];
    protected $useTimestamps = true;

    public function listAktif(): array
    {
        return $this->where('is_active', 1)->orderBy('nama_mapel')->findAll();
    }
}
