<?php

namespace App\Models;

use CodeIgniter\Model;

class PembiasaanSiswaModel extends Model
{
    use SimpanUnikTrait;

    protected $table         = 'pembiasaan_siswa';
    protected $returnType    = 'array';
    protected $allowedFields = ['tahun_pelajaran_id', 'kelas_id', 'siswa_id', 'pembiasaan_id', 'tanggal', 'terlaksana', 'keterangan', 'dicatat_oleh',
        'sumber', 'lapor_siswa', 'lapor_at', 'verifikasi', 'diverifikasi_oleh', 'diverifikasi_at'];
    protected $useTimestamps = true;

    /** [siswa_id][pembiasaan_id] => row */
    public function petaKelasTanggal(int $kelasId, string $tanggal): array
    {
        $out = [];
        foreach ($this->where(['kelas_id' => $kelasId, 'tanggal' => $tanggal])->findAll() as $r) {
            $out[$r['siswa_id']][$r['pembiasaan_id']] = $r;
        }
        return $out;
    }

    /** Rekap [siswa_id][pembiasaan_id] => ['ya'=>n, 'total'=>n] dan jumlah hari tercatat. */
    public function rekap(int $kelasId, string $dari, string $sampai): array
    {
        $out  = [];
        $hari = [];
        $rows = $this->select('siswa_id, pembiasaan_id, tanggal, terlaksana')
            ->where('kelas_id', $kelasId)->where('tanggal >=', $dari)->where('tanggal <=', $sampai)->where('verifikasi !=', 'Menunggu')->findAll();
        foreach ($rows as $r) {
            $out[$r['siswa_id']][$r['pembiasaan_id']]['total'] = ($out[$r['siswa_id']][$r['pembiasaan_id']]['total'] ?? 0) + 1;
            $out[$r['siswa_id']][$r['pembiasaan_id']]['ya']    = ($out[$r['siswa_id']][$r['pembiasaan_id']]['ya'] ?? 0) + (int) $r['terlaksana'];
            $hari[$r['tanggal']] = true;
        }
        return ['data' => $out, 'jumlah_hari' => count($hari)];
    }

    /** Persentase keterlaksanaan per pembiasaan untuk satu siswa pada TP. */
    public function ringkasSiswa(int $siswaId, int $tpId): array
    {
        return $this->select('pembiasaan.nama, SUM(pembiasaan_siswa.terlaksana) AS ya, COUNT(*) AS total')
            ->join('pembiasaan', 'pembiasaan.id = pembiasaan_siswa.pembiasaan_id')
            ->where(['pembiasaan_siswa.siswa_id' => $siswaId, 'pembiasaan_siswa.tahun_pelajaran_id' => $tpId])->where('pembiasaan_siswa.verifikasi !=', 'Menunggu')
            ->groupBy(['pembiasaan.id', 'pembiasaan.nama'])->orderBy('pembiasaan.nama')->findAll();
    }

    /** Laporan siswa yang menunggu verifikasi pada kelas & tanggal (atau semua tanggal bila null). */
    public function menunggu(int $kelasId, ?string $tanggal = null): array
    {
        $b = $this->select('pembiasaan_siswa.*, siswa.nama_lengkap, pembiasaan.nama AS nama_pembiasaan, pembiasaan.tempat')
            ->join('siswa', 'siswa.id = pembiasaan_siswa.siswa_id')->join('pembiasaan', 'pembiasaan.id = pembiasaan_siswa.pembiasaan_id')
            ->where(['pembiasaan_siswa.kelas_id' => $kelasId, 'pembiasaan_siswa.verifikasi' => 'Menunggu']);
        if ($tanggal) {
            $b->where('pembiasaan_siswa.tanggal', $tanggal);
        }
        return $b->orderBy('pembiasaan_siswa.tanggal', 'DESC')->orderBy('siswa.nama_lengkap')->findAll(500);
    }
}
