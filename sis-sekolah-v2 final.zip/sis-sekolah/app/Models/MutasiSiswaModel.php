<?php

namespace App\Models;

use CodeIgniter\Model;

class MutasiSiswaModel extends Model
{
    protected $table         = 'mutasi_siswa';
    protected $returnType    = 'array';
    protected $allowedFields = ['tahun_pelajaran_id', 'siswa_id', 'jenis', 'tanggal', 'kelas_asal_id', 'kelas_tujuan_id', 'sekolah', 'alasan', 'no_surat', 'status_sebelum', 'dicatat_oleh'];
    protected $useTimestamps = true;

    /** jenis => [label, status siswa sesudahnya, status anggota rombel sesudahnya, warna] */
    public const JENIS = [
        'Masuk'             => ['Masuk (pindahan)', 'Aktif', 'Aktif', 'success'],
        'Pindah Kelas'      => ['Pindah kelas', 'Aktif', 'Aktif', 'info'],
        'Pindah Sekolah'    => ['Pindah sekolah', 'Pindah', 'Pindah', 'warning'],
        'Mengundurkan Diri' => ['Mengundurkan diri', 'Keluar', 'Pindah', 'secondary'],
        'Dikeluarkan'       => ['Dikeluarkan', 'Keluar', 'Pindah', 'danger'],
        'Meninggal'         => ['Meninggal dunia', 'Keluar', 'Pindah', 'dark'],
        'Lulus'             => ['Lulus', 'Lulus', 'Lulus', 'primary'],
    ];

    public const KELUAR = ['Pindah Sekolah', 'Mengundurkan Diri', 'Dikeluarkan', 'Meninggal'];

    public function daftar(?int $tpId, array $f = []): array
    {
        $b = $this->select('mutasi_siswa.*, siswa.nama_lengkap, siswa.nis, siswa.nisn, siswa.jenis_kelamin, ka.nama_kelas AS kelas_asal, kt.nama_kelas AS kelas_tujuan, users.nama_lengkap AS pencatat')
            ->join('siswa', 'siswa.id = mutasi_siswa.siswa_id')
            ->join('kelas ka', 'ka.id = mutasi_siswa.kelas_asal_id', 'left')
            ->join('kelas kt', 'kt.id = mutasi_siswa.kelas_tujuan_id', 'left')
            ->join('users', 'users.id = mutasi_siswa.dicatat_oleh', 'left');
        if ($tpId) {
            $b->where('mutasi_siswa.tahun_pelajaran_id', $tpId);
        }
        if (! empty($f['jenis'])) {
            $f['jenis'] === 'keluar' ? $b->whereIn('mutasi_siswa.jenis', self::KELUAR) : $b->where('mutasi_siswa.jenis', $f['jenis']);
        }
        if (! empty($f['dari'])) {
            $b->where('mutasi_siswa.tanggal >=', $f['dari']);
        }
        if (! empty($f['sampai'])) {
            $b->where('mutasi_siswa.tanggal <=', $f['sampai']);
        }
        return $b->orderBy('mutasi_siswa.tanggal', 'DESC')->orderBy('mutasi_siswa.id', 'DESC')->findAll();
    }
}
