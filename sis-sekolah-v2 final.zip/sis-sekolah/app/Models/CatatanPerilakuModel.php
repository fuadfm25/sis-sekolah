<?php

namespace App\Models;

use CodeIgniter\Model;

class CatatanPerilakuModel extends Model
{
    protected $table         = 'catatan_perilaku';
    protected $returnType    = 'array';
    protected $allowedFields = [
        'tahun_pelajaran_id', 'siswa_id', 'kelas_id', 'jenis_perilaku_id', 'tanggal', 'kategori', 'poin',
        'deskripsi', 'lokasi', 'tindak_lanjut', 'status', 'dicatat_oleh',
    ];
    protected $useTimestamps = true;

    public const STATUS = ['Tercatat', 'Ditindaklanjuti', 'Dirujuk BK', 'Ditangani BK', 'Selesai'];

    public function base()
    {
        return $this->select('catatan_perilaku.*, siswa.nama_lengkap AS nama_siswa, siswa.nis, kelas.nama_kelas,
                jenis_perilaku.nama AS nama_jenis, jenis_perilaku.tingkat, users.nama_lengkap AS pencatat')
            ->join('siswa', 'siswa.id = catatan_perilaku.siswa_id')
            ->join('kelas', 'kelas.id = catatan_perilaku.kelas_id', 'left')
            ->join('jenis_perilaku', 'jenis_perilaku.id = catatan_perilaku.jenis_perilaku_id', 'left')
            ->join('users', 'users.id = catatan_perilaku.dicatat_oleh', 'left');
    }

    public function detail(int $id): ?array
    {
        return $this->base()->where('catatan_perilaku.id', $id)->first();
    }

    public function daftar(int $tpId, array $f = [], int $perPage = 25): array
    {
        $b = $this->base()->where('catatan_perilaku.tahun_pelajaran_id', $tpId);
        // batasan akses: catatan buatan sendiri ATAU siswa di kelas perwalian
        if (isset($f['scope_user'])) {
            $b->groupStart()->where('catatan_perilaku.dicatat_oleh', (int) $f['scope_user']);
            if (! empty($f['scope_kelas'])) {
                $b->orWhereIn('catatan_perilaku.kelas_id', $f['scope_kelas']);
            }
            $b->groupEnd();
        }
        foreach (['kelas_id', 'siswa_id', 'dicatat_oleh'] as $k) {
            if (! empty($f[$k])) {
                $b->where('catatan_perilaku.' . $k, (int) $f[$k]);
            }
        }
        foreach (['kategori', 'status'] as $k) {
            if (! empty($f[$k])) {
                $b->where('catatan_perilaku.' . $k, $f[$k]);
            }
        }
        if (! empty($f['dari'])) {
            $b->where('catatan_perilaku.tanggal >=', $f['dari']);
        }
        if (! empty($f['sampai'])) {
            $b->where('catatan_perilaku.tanggal <=', $f['sampai']);
        }
        if (! empty($f['q'])) {
            $b->groupStart()->like('siswa.nama_lengkap', $f['q'])->orLike('siswa.nis', $f['q'])->orLike('catatan_perilaku.deskripsi', $f['q'])->groupEnd();
        }
        return $b->orderBy('catatan_perilaku.tanggal', 'DESC')->orderBy('catatan_perilaku.id', 'DESC')->paginate($perPage);
    }

    /**
     * Akumulasi poin per siswa pada TP.
     * @return list<array{siswa_id, nama_siswa, nis, nama_kelas, poin_positif, poin_negatif, jumlah_catatan}>
     */
    public function akumulasiPoin(int $tpId, ?array $kelasIds = null): array
    {
        $b = $this->db->table('catatan_perilaku cp')
            ->select("cp.siswa_id, s.nama_lengkap AS nama_siswa, s.nis, k.nama_kelas, k.id AS kelas_id,
                SUM(CASE WHEN cp.kategori = 'Positif' THEN cp.poin ELSE 0 END) AS poin_positif,
                SUM(CASE WHEN cp.kategori = 'Negatif' THEN cp.poin ELSE 0 END) AS poin_negatif,
                COUNT(*) AS jumlah_catatan")
            ->join('siswa s', 's.id = cp.siswa_id')
            ->join('anggota_kelas ak', 'ak.siswa_id = cp.siswa_id AND ak.tahun_pelajaran_id = cp.tahun_pelajaran_id', 'left')
            ->join('kelas k', 'k.id = ak.kelas_id', 'left')
            ->where('cp.tahun_pelajaran_id', $tpId);
        if ($kelasIds !== null) {
            $kelasIds ? $b->whereIn('k.id', $kelasIds) : $b->where('1 = 0');
        }
        return $b->groupBy(['cp.siswa_id', 's.nama_lengkap', 's.nis', 'k.nama_kelas', 'k.id'])
            ->orderBy('poin_negatif', 'DESC')->get()->getResultArray();
    }

    public function poinSiswa(int $siswaId, int $tpId): array
    {
        $r = $this->select("SUM(CASE WHEN kategori = 'Positif' THEN poin ELSE 0 END) AS positif, SUM(CASE WHEN kategori = 'Negatif' THEN poin ELSE 0 END) AS negatif")
            ->where(['siswa_id' => $siswaId, 'tahun_pelajaran_id' => $tpId])->first();
        return ['positif' => (int) ($r['positif'] ?? 0), 'negatif' => (int) ($r['negatif'] ?? 0)];
    }

    public function riwayatSiswa(int $siswaId, ?int $tpId = null): array
    {
        $b = $this->base()->where('catatan_perilaku.siswa_id', $siswaId);
        if ($tpId) {
            $b->where('catatan_perilaku.tahun_pelajaran_id', $tpId);
        }
        return $b->orderBy('catatan_perilaku.tanggal', 'DESC')->findAll();
    }
}
