<?php

namespace App\Models;

use CodeIgniter\Model;

class SiswaModel extends Model
{
    protected $table         = 'siswa';
    protected $returnType    = 'array';
    protected $allowedFields = ['nis', 'nisn', 'rfid', 'nama_lengkap', 'jenis_kelamin', 'tempat_lahir', 'tanggal_lahir', 'agama', 'alamat', 'nama_wali', 'no_hp_wali', 'status', 'password', 'login_terakhir'];
    protected $useTimestamps = true;

    /** Daftar siswa + kelas pada TP tertentu, dengan filter opsional. */
    public function listWithKelas(?int $tpId, array $f = []): array
    {
        $b = $this->select('siswa.*, kelas.nama_kelas, kelas.id AS kelas_id, anggota_kelas.no_absen')
            ->join('anggota_kelas', 'anggota_kelas.siswa_id = siswa.id AND anggota_kelas.tahun_pelajaran_id = ' . (int) $tpId, 'left')
            ->join('kelas', 'kelas.id = anggota_kelas.kelas_id', 'left');

        if (! empty($f['kelas_id'])) {
            $f['kelas_id'] === 'none' ? $b->where('anggota_kelas.id', null) : $b->where('anggota_kelas.kelas_id', (int) $f['kelas_id']);
        }
        if (! empty($f['status'])) {
            $b->where('siswa.status', $f['status']);
        }
        if (! empty($f['q'])) {
            $b->groupStart()->like('siswa.nama_lengkap', $f['q'])->orLike('siswa.nis', $f['q'])->orLike('siswa.nisn', $f['q'])->groupEnd();
        }
        return $b->orderBy('kelas.nama_kelas')->orderBy('siswa.nama_lengkap')->findAll();
    }

    /** Cari siswa aktif dari hasil scan: UID RFID, NIS, atau NISN. */
    public function cariKartu(string $kode): ?array
    {
        $kode = trim($kode);
        if ($kode === '') {
            return null;
        }
        // prioritas: UID RFID, lalu NIS, lalu NISN
        foreach (['rfid', 'nis', 'nisn'] as $kolom) {
            if ($row = $this->where('status', 'Aktif')->where($kolom, $kode)->first()) {
                return $row;
            }
        }
        return null;
    }

    /** Untuk dropdown pencarian siswa aktif (dikelompokkan per kelas). */
    public function dropdownAktif(?int $tpId, ?array $kelasIds = null): array
    {
        $b = $this->select('siswa.id, siswa.nis, siswa.nama_lengkap, kelas.nama_kelas, kelas.id AS kelas_id')
            ->join('anggota_kelas', 'anggota_kelas.siswa_id = siswa.id AND anggota_kelas.tahun_pelajaran_id = ' . (int) $tpId)
            ->join('kelas', 'kelas.id = anggota_kelas.kelas_id')
            ->where('siswa.status', 'Aktif');
        if ($kelasIds !== null) {
            $kelasIds ? $b->whereIn('kelas.id', $kelasIds) : $b->where('1 = 0');
        }
        return $b->orderBy('kelas.nama_kelas')->orderBy('siswa.nama_lengkap')->findAll();
    }
}
