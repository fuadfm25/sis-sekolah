<?php

namespace App\Models;

use CodeIgniter\Model;

class PengaturanModel extends Model
{
    protected $table         = 'pengaturan';
    protected $returnType    = 'array';
    protected $allowedFields = ['kunci', 'nilai', 'label'];
    protected $useTimestamps = true;
    protected $createdField  = '';

    public function allKeyValue(): array
    {
        return array_column($this->findAll(), 'nilai', 'kunci');
    }

    public function simpan(string $kunci, ?string $nilai): void
    {
        $row = $this->where('kunci', $kunci)->first();
        $row ? $this->update($row['id'], ['nilai' => $nilai]) : $this->insert(['kunci' => $kunci, 'nilai' => $nilai, 'label' => $kunci]);
    }
}
