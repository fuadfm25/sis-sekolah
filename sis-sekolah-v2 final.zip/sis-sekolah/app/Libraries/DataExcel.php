<?php

namespace App\Libraries;

use App\Models\KalenderModel;

/**
 * Definisi impor data dari Excel per jenis data: judul, hak akses, kolom template (label, contoh, keterangan, sinonim).
 * Template yang diunduh memakai label kolom di sini, sehingga terbaca otomatis saat diunggah kembali.
 * Siswa & guru juga menerima file unduhan Dapodik/EMIS (sinonim di ImporExcel::FIELD).
 */
class DataExcel
{
    /** jenis => [judul, ikon, keterangan singkat, kolom => [label, wajib, contoh, keterangan, sinonim[]]] */
    public static function definisi(): array
    {
        $jenisKal = implode(' / ', KalenderModel::JENIS);
        return [
            'siswa' => ['Siswa', 'people', 'Data siswa + penempatan rombel TP aktif. Bisa juga file unduhan Dapodik/EMIS.', [
                'nis'           => ['NIS', true, '26001', 'Nomor induk sekolah (atau NISN bila kosong)', []],
                'nisn'          => ['NISN', false, '0012345678', '10 digit; dipakai untuk mencocokkan data lama', []],
                'nama_lengkap'  => ['Nama lengkap', true, 'Ahmad Pratama', '', []],
                'jenis_kelamin' => ['L/P', true, 'L', 'L atau P (Laki-laki/Perempuan juga boleh)', []],
                'tempat_lahir'  => ['Tempat lahir', false, 'Palembang', '', []],
                'tanggal_lahir' => ['Tanggal lahir', false, '17/05/2013', 'dd/mm/yyyy, yyyy-mm-dd, atau "17 Mei 2013"', []],
                'agama'         => ['Agama', false, 'Islam', '', []],
                'alamat'        => ['Alamat', false, 'Jl. Merdeka No. 1', '', []],
                'nama_wali'     => ['Nama wali', false, 'Budi Santoso', 'Orang tua / wali', []],
                'no_hp_wali'    => ['No HP wali', false, '081234567890', '', []],
                'kelas'         => ['Kelas', false, 'VII A', 'Nama kelas; "7A", "VII-A" dianggap sama. Kelas baru bisa dibuat otomatis', []],
                'rfid'          => ['Kode RFID', false, '', 'UID kartu untuk kiosk (opsional)', []],
            ]],
            'guru' => ['Guru', 'person-badge', 'Data guru/GTK. Bisa juga file unduhan Dapodik GTK.', [
                'nama_lengkap'       => ['Nama lengkap', true, 'Siti Aminah', 'Tanpa gelar', []],
                'gelar_depan'        => ['Gelar depan', false, 'Dra.', '', []],
                'gelar_belakang'     => ['Gelar belakang', false, 'S.Pd.', '', []],
                'nip'                => ['NIP', false, '198501012010012001', 'Kosongkan bila tidak ber-NIP', []],
                'nuptk'              => ['NUPTK', false, '1234567890123456', '', []],
                'jenis_kelamin'      => ['L/P', true, 'P', '', []],
                'status_kepegawaian' => ['Status kepegawaian', false, 'PNS', 'PNS / PPPK / GTY / GTT / Honorer', []],
                'no_hp'              => ['No HP', false, '081234567890', '', []],
                'email'              => ['Email', false, 'siti@sekolah.sch.id', '', []],
                'rfid'               => ['Kode RFID', false, '', 'UID kartu guru untuk kiosk (opsional)', []],
            ]],
            'mapel' => ['Mata Pelajaran', 'book', 'Daftar mata pelajaran.', [
                'kode_mapel' => ['Kode mapel', true, 'MTK', 'Unik, huruf besar', ['kode', 'kode mata pelajaran']],
                'nama_mapel' => ['Nama mapel', true, 'Matematika', '', ['nama mata pelajaran', 'mata pelajaran', 'mapel', 'nama']],
                'kelompok'   => ['Kelompok', false, 'Umum', 'Umum / Muatan Lokal / Kejuruan / Pilihan', []],
                'aktif'      => ['Aktif', false, 'Ya', 'Ya / Tidak (bawaan Ya)', ['status']],
            ]],
            'kelas' => ['Kelas & Wali Kelas', 'door-open', 'Daftar kelas; wali kelas ditetapkan untuk TP aktif.', [
                'tingkat'    => ['Tingkat', true, 'VII', 'VII / 7 / X dst.', []],
                'nama_kelas' => ['Nama kelas', true, 'VII A', '', ['kelas', 'nama rombel', 'rombel']],
                'jurusan'    => ['Jurusan', false, '', 'Kode atau nama jurusan (SMA/SMK); dibuat bila belum ada', ['kode jurusan']],
                'wali'       => ['Wali kelas', false, 'Siti Aminah', 'Nama, NIP, atau NUPTK guru yang sudah ada', ['wali', 'nip wali', 'nama wali kelas']],
            ]],
            'penugasan' => ['Penugasan Guru', 'person-workspace', 'Siapa mengajar mapel apa di kelas mana pada TP aktif, beserta JP per minggu.', [
                'kelas' => ['Kelas', true, 'VII A', 'Nama kelas yang sudah ada', ['nama kelas', 'rombel']],
                'mapel' => ['Mapel', true, 'MTK', 'Kode atau nama mapel yang sudah ada', ['kode mapel', 'mata pelajaran', 'nama mapel']],
                'guru'  => ['Guru', true, 'Budi Santoso', 'Nama, NIP, atau NUPTK guru yang sudah ada', ['nama guru', 'nip', 'pengampu', 'guru pengampu']],
                'jp'    => ['JP per minggu', true, '4', 'Jam pelajaran per minggu', ['jp', 'jam', 'jam per minggu', 'jumlah jp']],
            ]],
            'kalender' => ['Agenda Kalender (Pekan Efektif)', 'calendar-event', 'Libur nasional, cuti bersama, libur semester, ujian, kegiatan – otomatis dipakai menghitung pekan efektif.', [
                'tanggal_mulai'   => ['Tanggal mulai', true, '17/08/2026', 'dd/mm/yyyy', ['mulai', 'tanggal', 'tgl mulai', 'dari']],
                'tanggal_selesai' => ['Tanggal selesai', false, '17/08/2026', 'Kosong = 1 hari', ['selesai', 'sampai', 'tgl selesai']],
                'jenis'           => ['Jenis', true, 'Libur Nasional', $jenisKal, ['jenis agenda', 'kategori']],
                'nama'            => ['Nama agenda', true, 'HUT Kemerdekaan RI', '', ['nama', 'agenda', 'kegiatan', 'keterangan agenda']],
                'kelas'           => ['Kelas', false, '', 'Kosong = semua kelas; atau daftar kelas dipisah koma (IX A, IX B)', ['kelas sasaran', 'untuk kelas']],
                'ada_kbm'         => ['Ada KBM', false, '', 'Ya / Tidak (kosong = mengikuti jenis)', ['kbm', 'jurnal']],
                'ada_absensi'     => ['Ada absensi', false, '', 'Ya / Tidak (kosong = mengikuti jenis)', ['absensi']],
                'hari_jadwal'     => ['Jadwal hari', false, '', 'Khusus Masuk Pengganti: Senin/Selasa/...', ['hari jadwal', 'memakai jadwal']],
                'keterangan'      => ['Keterangan', false, '', '', []],
            ]],
            'atp' => ['ATP / Tujuan Pembelajaran', 'bullseye', 'Alur tujuan pembelajaran per mapel & tingkat (Kurikulum Merdeka).', [
                'mapel'      => ['Mapel', true, 'BIN', 'Kode atau nama mapel', ['kode mapel', 'mata pelajaran', 'nama mapel']],
                'tingkat'    => ['Tingkat', true, 'VII', '', ['kelas']],
                'semester'   => ['Semester', false, 'Ganjil', 'Ganjil / Genap / kosong = semua', []],
                'elemen'     => ['Elemen', false, 'Membaca dan Memirsa', '', []],
                'kode'       => ['Kode TP', false, '7.1', '', ['kode', 'no tp', 'nomor']],
                'tujuan'     => ['Tujuan pembelajaran', true, 'Peserta didik mampu menemukan gagasan utama teks.', '', ['tujuan', 'tp', 'deskripsi']],
                'alokasi_jp' => ['Alokasi JP', false, '4', '', ['jp', 'alokasi waktu', 'alokasi']],
                'urutan'     => ['Urutan', false, '1', '', ['no', 'nomor urut']],
            ]],
            'perilaku' => ['Jenis Perilaku & Poin', 'list-ol', 'Daftar perilaku positif/pelanggaran beserta poin.', [
                'kategori' => ['Kategori', true, 'Negatif', 'Positif / Negatif', ['jenis']],
                'nama'     => ['Nama perilaku', true, 'Terlambat masuk sekolah', '', ['perilaku', 'nama', 'pelanggaran', 'uraian']],
                'tingkat'  => ['Tingkat', false, 'Ringan', 'Ringan / Sedang / Berat', ['tingkat pelanggaran']],
                'poin'     => ['Poin', true, '5', 'Angka positif', ['skor', 'nilai']],
            ]],
            'pembiasaan' => ['Daftar Pembiasaan', 'check2-square', 'Kegiatan pembiasaan harian siswa.', [
                'nama'      => ['Nama pembiasaan', true, 'Tadarus sebelum belajar', '', ['nama', 'pembiasaan', 'kegiatan']],
                'kategori'  => ['Kategori', false, 'Religius', '', []],
                'deskripsi' => ['Deskripsi', false, '', '', ['keterangan']],
                'urutan'    => ['Urutan', false, '1', '', ['no']],
            ]],
        ];
    }

    public static function boleh(string $jenis): bool
    {
        return match ($jenis) {
            'siswa', 'guru', 'mapel', 'kelas' => Akses::masterData(),
            'penugasan', 'kalender'           => Akses::pengaturanAkademik(),
            'atp'                             => Akses::punya('kurikulum'),
            'perilaku', 'pembiasaan'          => Akses::referensiKesiswaan(),
            default                           => false,
        };
    }

    /** Kolom untuk pembaca Excel: field => [label, sinonim ternormalisasi]. */
    public static function field(string $jenis): array
    {
        $def = self::definisi()[$jenis][3] ?? [];
        $out = [];
        foreach ($def as $f => [$label, , , , $sin]) {
            $s = array_merge([ImporExcel::norm($label)], array_map([ImporExcel::class, 'norm'], $sin));
            if (isset(ImporExcel::FIELD[$jenis][$f])) {     // sinonim Dapodik/EMIS
                $s = array_merge($s, ImporExcel::FIELD[$jenis][$f][1]);
            }
            $out[$f] = [$label, array_values(array_unique($s))];
        }
        return $out;
    }
}
