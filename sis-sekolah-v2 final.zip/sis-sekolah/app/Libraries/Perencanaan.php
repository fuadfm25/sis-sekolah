<?php

namespace App\Libraries;

/**
 * Perhitungan program semester dari kalender akademik:
 *  - daftar pekan semester aktif + jumlah hari KBM + JP tersedia per pekan (dari jadwal mapel di kelas tsb.);
 *  - penyebaran otomatis JP butir (TP/materi) ke pekan efektif secara berurutan.
 */
class Perencanaan
{
    public const FASE = [
        '1' => 'A', '2' => 'A', '3' => 'B', '4' => 'B', '5' => 'C', '6' => 'C',
        '7' => 'D', '8' => 'D', '9' => 'D', 'VII' => 'D', 'VIII' => 'D', 'IX' => 'D',
        'I' => 'A', 'II' => 'A', 'III' => 'B', 'IV' => 'B', 'V' => 'C', 'VI' => 'C',
        '10' => 'E', 'X' => 'E', '11' => 'F', '12' => 'F', 'XI' => 'F', 'XII' => 'F',
    ];

    public static function fase(string $tingkat): string
    {
        return self::FASE[strtoupper(trim($tingkat))] ?? '';
    }

    /** Penugasan guru untuk mapel–tingkat (kelas-kelasnya) beserta slot jadwal per hari. */
    public static function konteks(int $tpId, int $guruId, int $mapelId, string $tingkat): ?array
    {
        $db   = db_connect();
        $peng = $db->table('penugasan_guru pg')->select('pg.*, kelas.nama_kelas, kelas.tingkat')
            ->join('kelas', 'kelas.id = pg.kelas_id')
            ->where(['pg.tahun_pelajaran_id' => $tpId, 'pg.guru_id' => $guruId, 'pg.mapel_id' => $mapelId, 'kelas.tingkat' => $tingkat])
            ->orderBy('kelas.nama_kelas')->get()->getResultArray();
        if (! $peng) {
            return null;
        }
        $slot = [];
        foreach ($db->table('jadwal_pelajaran')->select('hari, COUNT(*) AS n')->where('penugasan_guru_id', $peng[0]['id'])
            ->where('berlaku_sampai', null)->groupBy('hari')->get()->getResultArray() as $j) {
            $slot[(int) $j['hari']] = (int) $j['n'];
        }
        return [
            'penugasan' => $peng,
            'kelas'     => array_column($peng, 'nama_kelas'),
            'kelas_id'  => (int) $peng[0]['kelas_id'],
            'jp_minggu' => max(array_map('intval', array_column($peng, 'jp_per_minggu'))),
            'slot'      => $slot,
            'fase'      => self::fase($tingkat),
        ];
    }

    /**
     * Pekan-pekan semester aktif. Kunci = tanggal Senin.
     * @return array<string, array{senin: string, bulan: string, minggu_ke: int, hari_sekolah: int, hari_kbm: int, jp: int, efektif: bool, ket: string}>
     */
    public static function pekan(array $tp, array $ktx): array
    {
        if (empty($tp['tanggal_mulai']) || empty($tp['tanggal_selesai'])) {
            return [];
        }
        $hariSeminggu = count(hari_list());
        $out = [];
        foreach (Kalender::tanggal($tp['tanggal_mulai'], $tp['tanggal_selesai']) as $d) {
            $senin = date('Y-m-d', strtotime($d . ' -' . ((int) date('N', strtotime($d)) - 1) . ' days'));
            $out[$senin] ??= ['senin' => $senin, 'bulan' => '', 'minggu_ke' => 0, 'hari_sekolah' => 0, 'hari_kbm' => 0, 'jp' => 0, 'efektif' => false, 'ket' => [], 'tanpa_jadwal' => false];
            $s = Kalender::status($d, $ktx['kelas_id']);
            if (! $s['sekolah']) {
                continue;
            }
            $w = &$out[$senin];
            $w['bulan'] = $w['bulan'] ?: substr($d, 0, 7);
            $w['hari_sekolah']++;
            if ($s['kbm']) {
                $w['hari_kbm']++;
                $w['jp'] += $ktx['slot'][$s['hari_jadwal']] ?? 0;
            }
            foreach ($s['agenda'] as $a) {
                if ($a['jenis'] !== 'Masuk Pengganti') {
                    $w['ket'][$a['nama']] = $a['nama'];
                }
            }
            unset($w);
        }
        $out = array_filter($out, static fn ($w) => $w['hari_sekolah'] > 0);
        $perBulan = [];
        foreach ($out as &$w) {
            if (! $ktx['slot'] && $w['hari_kbm'] > 0) {   // jadwal belum diatur: perkiraan dari JP per minggu
                $w['jp'] = (int) round($ktx['jp_minggu'] * $w['hari_kbm'] / max(1, $hariSeminggu));
                $w['tanpa_jadwal'] = true;
            }
            $w['efektif']   = $w['jp'] > 0;
            $w['minggu_ke'] = $perBulan[$w['bulan']] = ($perBulan[$w['bulan']] ?? 0) + 1;
            $w['ket']       = implode(', ', $w['ket']);
        }
        return $out;
    }

    /**
     * Sebar JP tiap butir (berurutan) ke pekan efektif mulai pekan pertama, mengisi kapasitas pekan.
     * @param list<array{id:int,jp:int}> $items
     * @return array<int, array<string,int>> item_id => [senin => jp]
     */
    public static function sebar(array $items, array $pekan): array
    {
        $sisa = [];
        foreach ($pekan as $k => $w) {
            if ($w['efektif']) {
                $sisa[$k] = (int) $w['jp'];
            }
        }
        $out = [];
        $keys = array_keys($sisa);
        $i = 0;
        foreach ($items as $it) {
            $butuh = (int) $it['jp'];
            while ($butuh > 0 && $i < count($keys)) {
                $k = $keys[$i];
                if ($sisa[$k] <= 0) {
                    $i++;
                    continue;
                }
                $ambil = min($butuh, $sisa[$k]);
                $out[$it['id']][$k] = ($out[$it['id']][$k] ?? 0) + $ambil;
                $sisa[$k] -= $ambil;
                $butuh -= $ambil;
            }
        }
        return $out;
    }
}
