<?php

namespace App\Libraries;

use App\Models\GuruPiketModel;
use App\Models\PenugasanGuruModel;

/**
 * SATU-SATUNYA tempat aturan hak akses. Controller, view, dan menu memanggil kelas ini.
 *
 * Prinsip:
 *  - admin      : selalu boleh semuanya.
 *  - kurikulum  : tahun pelajaran, kalender akademik (libur/ujian/kegiatan), jam, penugasan, jadwal, piket + pemantauan jurnal.
 *  - kesiswaan  : absensi pagi & pembiasaan semua kelas, seluruh catatan perilaku, referensi poin/pembiasaan.
 *  - bk         : modul BK, seluruh catatan perilaku (lihat & tindak lanjut), lihat rekap kesiswaan.
 *  - piket      : absensi pagi semua kelas & jurnal pengganti HANYA pada hari piketnya; pantau jurnal.
 *  - wali kelas : (bukan role, dari data rombel) semua urusan kesiswaan untuk kelas perwaliannya saja.
 *  - guru       : jurnal & absensi mapelnya sendiri, mencatat perilaku, melihat catatannya sendiri.
 *  - kepsek     : hanya melihat (monitoring & rekap), tidak mengubah data.
 *  - tu         : data master (siswa, guru, kelas, mapel, kenaikan kelas).
 */
class Akses
{
    private static array $cachePiket = [];

    // ------------------------------------------------------------------ dasar
    public static function roles(): array
    {
        return session()->get('roles') ?? [];
    }

    public static function admin(): bool
    {
        return in_array('admin', self::roles(), true);
    }

    /** Punya salah satu role (admin selalu true). */
    public static function punya(string ...$roles): bool
    {
        return self::admin() || (bool) array_intersect($roles, self::roles());
    }

    public static function userId(): int
    {
        return (int) session()->get('user_id');
    }

    public static function guruId(): ?int
    {
        $g = session()->get('guru_id');
        return $g ? (int) $g : null;
    }

    public static function waliKelas(int $kelasId): bool
    {
        return in_array($kelasId, wali_kelas_ids(), true);
    }

    /** Petugas piket pada tanggal tsb. (role piket + terjadwal di hari itu pada TP aktif). */
    public static function piketPada(?string $tanggal = null): bool
    {
        if (self::admin()) {
            return true;
        }
        if (! in_array('piket', self::roles(), true) || ! self::guruId() || ! ($tp = tp_aktif())) {
            return false;
        }
        $hari = (int) date('N', strtotime($tanggal ?: date('Y-m-d')));
        if (! array_key_exists($hari, self::$cachePiket)) {
            self::$cachePiket[$hari] = (bool) model(GuruPiketModel::class)
                ->where(['tahun_pelajaran_id' => $tp['id'], 'guru_id' => self::guruId(), 'hari' => $hari])->countAllResults();
        }
        return self::$cachePiket[$hari];
    }

    /** Hari-hari piket user (untuk pesan informasi). */
    public static function hariPiket(): array
    {
        if (! self::guruId() || ! ($tp = tp_aktif())) {
            return [];
        }
        return array_map('intval', array_column(model(GuruPiketModel::class)->select('hari')
            ->where(['tahun_pelajaran_id' => $tp['id'], 'guru_id' => self::guruId()])->findAll(), 'hari'));
    }

    // ------------------------------------------------------------------ menu / modul
    public static function masterData(): bool
    {
        return self::punya('tu');
    }

    public static function pengaturanAkademik(): bool
    {
        return self::punya('kurikulum');
    }

    public static function referensiKesiswaan(): bool
    {
        return self::punya('kesiswaan');
    }

    public static function modulBk(): bool
    {
        return self::punya('bk');
    }

    // ------------------------------------------------------------------ absensi pagi
    public static function absensiLihatSemua(): bool
    {
        return self::punya('kesiswaan', 'bk', 'kepsek', 'piket');
    }

    public static function absensiInputSemua(string $tanggal): bool
    {
        return self::punya('kesiswaan') || self::piketPada($tanggal);
    }

    public static function absensiInput(int $kelasId, string $tanggal): bool
    {
        return self::absensiInputSemua($tanggal) || self::waliKelas($kelasId);
    }

    public static function absensiMenu(): bool
    {
        return self::absensiLihatSemua() || is_wali_kelas();
    }

    // ------------------------------------------------------------------ pembiasaan
    public static function pembiasaanLihatSemua(): bool
    {
        return self::punya('kesiswaan', 'bk', 'kepsek');
    }

    public static function pembiasaanInput(int $kelasId): bool
    {
        return self::punya('kesiswaan') || self::waliKelas($kelasId);
    }

    public static function pembiasaanMenu(): bool
    {
        return self::pembiasaanLihatSemua() || is_wali_kelas();
    }

    // ------------------------------------------------------------------ catatan perilaku
    public static function perilakuLihatSemua(): bool
    {
        return self::punya('kesiswaan', 'bk', 'kepsek');
    }

    public static function perilakuLihat(array $c): bool
    {
        return self::perilakuLihatSemua() || (int) $c['dicatat_oleh'] === self::userId() || self::waliKelas((int) $c['kelas_id']);
    }

    /** Ubah status / tindak lanjut. Kepsek tidak termasuk (hanya melihat). */
    public static function perilakuTindakLanjut(array $c): bool
    {
        return self::punya('kesiswaan', 'bk') || (int) $c['dicatat_oleh'] === self::userId() || self::waliKelas((int) $c['kelas_id']);
    }

    /** Edit isi catatan / hapus. */
    public static function perilakuKelola(array $c): bool
    {
        return self::punya('kesiswaan') || (int) $c['dicatat_oleh'] === self::userId();
    }

    public static function rekapPoin(): bool
    {
        return self::perilakuLihatSemua() || is_wali_kelas();
    }

    // ------------------------------------------------------------------ jurnal
    public static function jurnalMonitoring(): bool
    {
        return self::punya('kurikulum', 'kepsek', 'piket');
    }

    /** Melihat jurnal & rekap absensi mapel semua guru. */
    public static function jurnalSemua(): bool
    {
        return self::punya('kurikulum', 'kepsek');
    }

    public static function jurnalPengampu(array $sesiAtauJurnal): bool
    {
        return self::guruId() && (int) $sesiAtauJurnal['guru_id'] === self::guruId();
    }

    /** Mengisi jurnal sesi milik guru lain (guru pengganti). */
    public static function jurnalPengganti(string $tanggal): bool
    {
        return self::punya('kurikulum') || self::piketPada($tanggal);
    }

    public static function jurnalIsi(array $sesi, string $tanggal): bool
    {
        return self::jurnalPengampu($sesi) || self::jurnalPengganti($tanggal);
    }

    public static function jurnalLihat(array $j): bool
    {
        return self::jurnalPengampu($j) || self::jurnalMonitoring() || self::waliKelas((int) $j['kelas_id']);
    }

    public static function jurnalHapus(array $j): bool
    {
        return self::jurnalPengampu($j) || self::punya('kurikulum');
    }

    public static function rekapAbsensiMapelMenu(): bool
    {
        return (bool) self::guruId() || is_wali_kelas() || self::jurnalSemua();
    }

    // ------------------------------------------------------------------ profil siswa
    /**
     * 'penuh' : identitas lengkap + kontak, pembiasaan, semua catatan perilaku
     * 'dasar' : identitas tanpa kontak/alamat, kehadiran, catatan perilaku buatannya sendiri
     *  null   : tidak boleh membuka
     */
    public static function profilSiswa(?int $kelasId): ?string
    {
        if (self::punya('kesiswaan', 'bk', 'kepsek') || ($kelasId && self::waliKelas($kelasId))) {
            return 'penuh';
        }
        if (self::punya('kurikulum', 'tu', 'piket')) {
            return 'dasar';
        }
        // guru yang mengajar di kelas siswa
        if ($kelasId && self::guruId() && ($tp = tp_aktif())
            && model(PenugasanGuruModel::class)->where(['tahun_pelajaran_id' => $tp['id'], 'kelas_id' => $kelasId, 'guru_id' => self::guruId()])->countAllResults()) {
            return 'dasar';
        }
        return null;
    }

    // ------------------------------------------------------------------ BK
    /** Membuka isi layanan: rahasia hanya konselornya & admin. */
    public static function bkBuka(array $l): bool
    {
        return self::punya('bk') && (! (int) $l['is_rahasia'] || (int) $l['konselor_id'] === self::userId() || self::admin());
    }

    /** Mengubah / menghapus layanan: hanya konselornya & admin. */
    public static function bkKelola(array $l): bool
    {
        return (int) $l['konselor_id'] === self::userId() || self::admin();
    }

    // ------------------------------------------------------------------ laporan cetak
    /** Jurnal pembelajaran seorang guru: guru ybs, atau kurikulum/kepsek untuk semua guru. */
    public static function laporanJurnalGuru(?int $guruId): bool
    {
        return self::jurnalSemua() || ($guruId && $guruId === self::guruId());
    }

    /** Laporan per kelas. $jenis: absensi | jurnal | perilaku | pembiasaan | siswa */
    public static function laporanKelas(int $kelasId, string $jenis): bool
    {
        if (self::waliKelas($kelasId)) {
            return true;
        }
        return match ($jenis) {
            'absensi'    => self::absensiLihatSemua(),
            'jurnal'     => self::jurnalSemua(),
            'perilaku'   => self::perilakuLihatSemua(),
            'pembiasaan' => self::pembiasaanLihatSemua(),
            'siswa'      => self::masterData() || self::punya('kesiswaan', 'kurikulum'),
            default      => false,
        };
    }

    /** Boleh memilih SEMUA kelas untuk laporan jenis tsb (selain kelas perwalian). */
    public static function laporanSemuaKelas(string $jenis): bool
    {
        return match ($jenis) {
            'absensi'    => self::absensiLihatSemua(),
            'jurnal'     => self::jurnalSemua(),
            'perilaku'   => self::perilakuLihatSemua(),
            'pembiasaan' => self::pembiasaanLihatSemua(),
            'siswa'      => self::masterData() || self::punya('kesiswaan', 'kurikulum'),
            default      => false,
        };
    }

    public static function laporanRekapKehadiran(): bool
    {
        return self::absensiLihatSemua();
    }

    public static function laporanKeterisianJurnal(): bool
    {
        return self::jurnalSemua();
    }

    public static function laporanBk(): bool
    {
        return self::modulBk();
    }

    public static function laporanPiket(): bool
    {
        return self::punya('piket', 'kesiswaan', 'kepsek');
    }

    // ------------------------------------------------------------------ izin siswa
    /** Pos gerbang: satpam, kesiswaan, atau guru piket pada hari piketnya. */
    public static function gerbang(): bool
    {
        return self::punya('satpam', 'kesiswaan') || self::piketPada(date('Y-m-d'));
    }

    // ------------------------------------------------------------------ perangkat pembelajaran
    public static function perangkatGuru(): bool
    {
        return self::guruId() !== null;
    }

    public static function perangkatPeriksa(): bool
    {
        return self::punya('kurikulum');
    }

    public static function perangkatSahkan(): bool
    {
        return self::punya('kepsek');
    }

    public static function perangkatLihatSemua(): bool
    {
        return self::punya('kurikulum', 'kepsek');
    }

    public static function izinSiswaInput(int $kelasId): bool
    {
        return self::punya('kesiswaan') || self::piketPada(date('Y-m-d')) || self::waliKelas($kelasId);
    }

    public static function izinSiswaLihat(int $kelasId): bool
    {
        return self::absensiLihatSemua() || self::waliKelas($kelasId);
    }

    public static function izinSiswaMenu(): bool
    {
        return self::absensiMenu();
    }

    // ------------------------------------------------------------------ kehadiran & izin guru
    public static function kehadiranGuruInput(string $tanggal): bool
    {
        return self::punya('kurikulum') || self::piketPada($tanggal);
    }

    public static function kehadiranGuruLihat(): bool
    {
        return self::punya('kurikulum', 'kepsek', 'piket');
    }

    /** Persetujuan izin guru: kurikulum dan kepala sekolah (pengecualian dari kepsek "hanya melihat"). */
    public static function izinGuruPutus(): bool
    {
        return self::punya('kurikulum', 'kepsek');
    }

    public static function izinGuruLihat(array $izin): bool
    {
        return self::izinGuruPutus() || self::piketPada(date('Y-m-d')) || (int) $izin['guru_id'] === (int) self::guruId();
    }

    // ------------------------------------------------------------------ Kurikulum Merdeka
    /** Kelola ATP: kurikulum, atau guru yang mengampu mapel tsb di tingkat tsb pada TP aktif. */
    public static function atpKelola(int $mapelId, string $tingkat): bool
    {
        if (self::punya('kurikulum')) {
            return true;
        }
        $tp = tp_aktif();
        if (! self::guruId() || ! $tp) {
            return false;
        }
        return db_connect()->table('penugasan_guru')->join('kelas', 'kelas.id = penugasan_guru.kelas_id')
            ->where(['penugasan_guru.guru_id' => self::guruId(), 'penugasan_guru.mapel_id' => $mapelId, 'kelas.tingkat' => $tingkat, 'penugasan_guru.tahun_pelajaran_id' => $tp['id']])
            ->countAllResults() > 0;
    }

    public static function kokurikulerKelola(): bool
    {
        return self::punya('kurikulum');
    }

    // ------------------------------------------------------------------ mutasi & kenaikan kelas
    public static function mutasiKelola(): bool
    {
        return self::masterData() || self::punya('kesiswaan');
    }

    public static function mutasiLihat(): bool
    {
        return self::mutasiKelola() || self::punya('kepsek', 'kurikulum', 'bk');
    }
}
