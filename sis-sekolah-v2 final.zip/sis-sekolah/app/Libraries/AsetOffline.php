<?php

namespace App\Libraries;

/**
 * Daftar aset tampilan (CSS/JS/font) dan pengunduhnya ke public/assets/vendor
 * agar aplikasi tetap rapi walau internet sekolah putus.
 */
class AsetOffline
{
    private const BI     = 'https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/';

    /** kunci => [url CDN, path lokal relatif public/assets/vendor/] */
    public const DAFTAR = [
        'bi-css'        => [self::BI . 'bootstrap-icons.min.css', 'bootstrap-icons/bootstrap-icons.min.css'],
        'bi-woff2'      => [self::BI . 'fonts/bootstrap-icons.woff2', 'bootstrap-icons/fonts/bootstrap-icons.woff2'],
        'bi-woff'       => [self::BI . 'fonts/bootstrap-icons.woff', 'bootstrap-icons/fonts/bootstrap-icons.woff'],
        'tom-css'       => ['https://cdn.jsdelivr.net/npm/tom-select@2.3.1/dist/css/tom-select.bootstrap5.min.css', 'tom-select/tom-select.bootstrap5.min.css'],
        'tom-js'        => ['https://cdn.jsdelivr.net/npm/tom-select@2.3.1/dist/js/tom-select.complete.min.js', 'tom-select/tom-select.complete.min.js'],
        'bootstrap-css' => ['https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css', 'bootstrap/bootstrap.min.css'],
        'bootstrap-js'  => ['https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js', 'bootstrap/bootstrap.bundle.min.js'],
        'font-jakarta'  => ['https://cdn.jsdelivr.net/npm/@fontsource-variable/plus-jakarta-sans@5/files/plus-jakarta-sans-latin-wght-normal.woff2', 'fonts/plus-jakarta-sans-latin-wght-normal.woff2'],
        'jsbarcode'     => ['https://cdn.jsdelivr.net/npm/jsbarcode@3.11.6/dist/JsBarcode.all.min.js', 'jsbarcode/JsBarcode.all.min.js'],
        'html5-qrcode'  => ['https://unpkg.com/html5-qrcode@2.3.8/html5-qrcode.min.js', 'html5-qrcode/html5-qrcode.min.js'],
    ];

    public static function lokal(string $kunci): string
    {
        return FCPATH . 'assets/vendor/' . self::DAFTAR[$kunci][1];
    }

    /** URL aset: file lokal bila sudah diunduh, selain itu CDN. */
    public static function url(string $kunci): string
    {
        [$cdn, $rel] = self::DAFTAR[$kunci];
        return is_file(self::lokal($kunci)) && filesize(self::lokal($kunci)) > 0 ? base_url('assets/vendor/' . $rel) : $cdn;
    }

    public static function status(): array
    {
        $out = [];
        foreach (self::DAFTAR as $k => [$cdn, $rel]) {
            $f       = self::lokal($k);
            $out[$k] = ['cdn' => $cdn, 'lokal' => 'public/assets/vendor/' . $rel, 'ada' => is_file($f), 'ukuran' => is_file($f) ? filesize($f) : 0];
        }
        return $out;
    }

    /** Unduh semua aset. @return array<string, array{ok: bool, pesan: string}> */
    public static function unduh(): array
    {
        $hasil = [];
        foreach (self::DAFTAR as $k => [$cdn, $rel]) {
            $tujuan = self::lokal($k);
            if (! is_dir(dirname($tujuan)) && ! @mkdir(dirname($tujuan), 0775, true)) {
                $hasil[$k] = ['ok' => false, 'pesan' => 'tidak dapat membuat folder ' . dirname($rel)];
                continue;
            }
            $isi = self::ambil($cdn, $err);
            if ($isi === null || $isi === '') {
                $hasil[$k] = ['ok' => false, 'pesan' => $err ?: 'gagal mengunduh'];
                continue;
            }
            $hasil[$k] = @file_put_contents($tujuan, $isi) !== false
                ? ['ok' => true, 'pesan' => number_format(strlen($isi) / 1024, 1) . ' KB']
                : ['ok' => false, 'pesan' => 'tidak dapat menulis file'];
        }
        return $hasil;
    }

    private static function ambil(string $url, ?string &$err): ?string
    {
        $err = null;
        if (function_exists('curl_init')) {
            $ch = curl_init($url);
            curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_FOLLOWLOCATION => true, CURLOPT_TIMEOUT => 30, CURLOPT_USERAGENT => 'SIS-Sekolah']);
            $isi  = curl_exec($ch);
            $kode = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
            if ($isi === false || $kode >= 400) {
                $err = $isi === false ? curl_error($ch) : 'HTTP ' . $kode;
                $isi = null;
            }
            curl_close($ch);
            return $isi;
        }
        $isi = @file_get_contents($url, false, stream_context_create(['http' => ['timeout' => 30], 'https' => ['timeout' => 30]]));
        if ($isi === false) {
            $err = 'tidak dapat terhubung (aktifkan ekstensi curl atau allow_url_fopen)';
            return null;
        }
        return $isi;
    }
}
