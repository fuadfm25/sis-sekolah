<?php

namespace App\Libraries;

/**
 * Satu sumber kebenaran untuk status siswa di absensi mapel pada suatu tanggal & jam:
 *   1. izin keluar/pulang awal (jam_keluar) → sesi yang dimulai pada/sesudah jam itu = S/I/D sesuai jenis izin;
 *   2. dispensasi sepanjang hari → D;
 *   3. absensi pagi S/I/A → sama; H/T → H.
 * Baris absensi mapel ber-sumber 'Otomatis' diperbarui setiap kali absensi pagi/izin berubah;
 * baris yang diubah guru ('Guru') tidak pernah ditimpa.
 */
class SinkronAbsensi
{
    /**
     * Saran status per siswa untuk satu tanggal & jam mulai sesi.
     * @return array<int, array{status: string, alasan: ?string}>
     */
    public static function saran(array $siswaIds, string $tanggal, ?string $jamMulai = null): array
    {
        $siswaIds = array_values(array_filter(array_map('intval', $siswaIds)));
        if (! $siswaIds) {
            return [];
        }
        $db   = db_connect();
        $pagi = array_column($db->table('presensi_harian')->select('siswa_id, status, jam_pulang')->whereIn('siswa_id', $siswaIds)->where('tanggal', $tanggal)->get()->getResultArray(), null, 'siswa_id');
        $izin = [];
        foreach ($db->table('izin_siswa')->whereIn('siswa_id', $siswaIds)->where('tanggal_mulai <=', $tanggal)->where('tanggal_selesai >=', $tanggal)->orderBy('id')->get()->getResultArray() as $z) {
            $izin[$z['siswa_id']][] = $z;
        }
        $jam = $jamMulai ? substr($jamMulai, 0, 5) : null;
        $out = [];
        foreach ($siswaIds as $sid) {
            $status = 'H';
            $alasan = null;
            $p      = $pagi[$sid] ?? null;
            if ($p) {
                $status = in_array($p['status'], ['S', 'I', 'A'], true) ? $p['status'] : 'H';
                $alasan = $status !== 'H' ? 'absensi pagi: ' . (status_presensi()[$p['status']] ?? $p['status']) : null;
            }
            foreach ($izin[$sid] ?? [] as $z) {
                $st = $z['jenis'];   // S / I / D
                if (! empty($z['jam_keluar'])) {
                    $jk    = IzinKeluar::mulai($z);
                    $label = str_replace(':', '.', substr($z['jam_keluar'], 0, 5));
                    if ($jk === null) {   // izin terbit tetapi siswa belum keluar gerbang
                        if ($jam !== null && $jam >= substr($z['jam_keluar'], 0, 5)) {
                            $alasan ??= 'izin keluar ' . $label . ' (belum tercatat keluar gerbang)';
                        }
                        continue;
                    }
                    if ($jam === null || $jam < $jk) {
                        continue;
                    }
                    if (! IzinKeluar::sementara($z)) {
                        $status = $st;
                        $alasan = 'izin pulang ' . str_replace(':', '.', $jk) . ($z['penjemput'] ? ' (dijemput ' . $z['penjemput'] . ')' : '');
                        continue;
                    }
                    $batas = substr($z['batas_kembali'], 0, 5);
                    $kbl   = IzinKeluar::kembali($z);
                    if ($kbl !== null && $jam >= $kbl) {
                        continue;   // sudah kembali sebelum sesi dimulai
                    }
                    if ($jam < $batas) {
                        $status = $st;
                        $alasan = 'izin keluar ' . str_replace(':', '.', $jk) . '–' . str_replace(':', '.', $batas);
                        continue;
                    }
                    $sk = IzinKeluar::status($z);
                    if ($sk['status'] === 'Membolos') {
                        $status = 'A';
                        $alasan = 'membolos: tidak kembali dari izin keluar' . ($kbl ? ' (kembali ' . str_replace(':', '.', $kbl) . ')' : '');
                    } else {
                        $alasan = 'terlambat kembali dari izin keluar (batas ' . str_replace(':', '.', $batas) . ')';
                    }
                } elseif ($st === 'D' && in_array($status, ['H'], true)) {
                    $status = 'D';
                    $alasan = 'dispensasi' . ($z['keterangan'] ? ': ' . $z['keterangan'] : '');
                }
            }
            $out[$sid] = ['status' => $status, 'alasan' => $alasan];
        }
        return $out;
    }

    /** Terapkan saran ke semua jurnal pada tanggal tsb untuk siswa-siswa ini (hanya baris 'Otomatis'). @return int jumlah baris berubah */
    public static function terapkan(array $siswaIds, string $tanggal): int
    {
        $siswaIds = array_values(array_filter(array_map('intval', $siswaIds)));
        if (! $siswaIds) {
            return 0;
        }
        $db   = db_connect();
        $rows = $db->table('presensi_mapel pm')->select('pm.id, pm.siswa_id, pm.status, pm.sumber, jp.jam_mulai')
            ->join('jurnal_pembelajaran j', 'j.id = pm.jurnal_id')
            ->join('jadwal_pelajaran jd', 'jd.id = j.jadwal_pelajaran_id', 'left')
            ->join('jam_pelajaran jp', 'jp.id = jd.jam_pelajaran_id', 'left')
            ->where('j.tanggal', $tanggal)->whereIn('pm.siswa_id', $siswaIds)->where('pm.sumber', 'Otomatis')
            ->get()->getResultArray();
        $ubah = 0;
        $now  = date('Y-m-d H:i:s');
        foreach ($rows as $r) {
            $s = self::saran([(int) $r['siswa_id']], $tanggal, $r['jam_mulai'])[(int) $r['siswa_id']];
            if ($s['status'] !== $r['status']) {
                $db->table('presensi_mapel')->where('id', $r['id'])->update(['status' => $s['status'], 'keterangan' => $s['alasan'], 'updated_at' => $now]);
                $ubah++;
            }
        }
        return $ubah;
    }
}
