<?php

namespace App\Libraries;

/**
 * Referensi penyusunan modul ajar.
 * - Pembelajaran Mendalam (Kemendikdasmen 2025): identifikasi → desain pembelajaran → pengalaman belajar
 *   (memahami, mengaplikasi, merefleksi) → asesmen (awal, proses, akhir).
 * - Madrasah: pembelajaran mendalam terintegrasi Kurikulum Berbasis Cinta (Panca Cinta + materi insersi).
 */
class ModulAjar
{
    public const FORMAT = [
        'PM'     => 'Pembelajaran Mendalam',
        'PM-KBC' => 'Pembelajaran Mendalam terintegrasi Kurikulum Berbasis Cinta (madrasah)',
    ];

    /** 8 dimensi profil lulusan. */
    public const DPL = ['Keimanan dan Ketakwaan terhadap Tuhan YME', 'Kewargaan', 'Penalaran Kritis', 'Kreativitas', 'Kolaborasi', 'Kemandirian', 'Kesehatan', 'Komunikasi'];

    /** Panca Cinta (Kurikulum Berbasis Cinta, Kemenag). */
    public const PANCA_CINTA = ['Cinta Allah dan Rasul-Nya', 'Cinta Ilmu', 'Cinta Lingkungan', 'Cinta Diri dan Sesama Manusia', 'Cinta Tanah Air'];

    public const PRINSIP = ['Berkesadaran', 'Bermakna', 'Menggembirakan'];

    public const METODE = ['Diskusi', 'Tanya jawab', 'Demonstrasi', 'Eksperimen/praktikum', 'Penugasan', 'Presentasi', 'Simulasi', 'Bermain peran', 'Ceramah interaktif',
        'Karya wisata', 'Observasi', 'Drill/latihan', 'Sorogan/setoran hafalan', 'Gallery walk', 'Think-Pair-Share', 'Jigsaw'];

    /**
     * Sintaks model pembelajaran, dipetakan ke tahap pengalaman belajar.
     * model => [memahami[], mengaplikasi[], merefleksi[]]
     */
    public const SINTAKS = [
        'Problem Based Learning (PBL)' => [
            ['Orientasi peserta didik pada masalah kontekstual tentang {topik}.', 'Mengorganisasikan peserta didik untuk belajar: membagi kelompok dan peran, menyepakati langkah penyelidikan.'],
            ['Membimbing penyelidikan individu dan kelompok: mengumpulkan informasi, mencoba, dan mendiskusikan alternatif solusi.', 'Mengembangkan dan menyajikan hasil karya/solusi.'],
            ['Menganalisis dan mengevaluasi proses pemecahan masalah bersama; peserta didik menuliskan refleksi singkat.'],
        ],
        'Project Based Learning (PjBL)' => [
            ['Penentuan pertanyaan mendasar terkait {topik} yang dekat dengan kehidupan peserta didik.'],
            ['Mendesain perencanaan proyek bersama kelompok.', 'Menyusun jadwal pelaksanaan proyek.', 'Melaksanakan proyek dengan pemantauan guru (monitoring kemajuan).', 'Menguji dan mempresentasikan hasil proyek.'],
            ['Mengevaluasi pengalaman: peserta didik merefleksikan proses, hambatan, dan pelajaran yang diperoleh.'],
        ],
        'Discovery Learning' => [
            ['Stimulasi: guru menyajikan fenomena/gambar/video tentang {topik}.', 'Identifikasi masalah: peserta didik merumuskan pertanyaan.'],
            ['Pengumpulan data melalui pengamatan, percobaan, atau literatur.', 'Pengolahan data secara berkelompok.', 'Pembuktian (verifikasi) temuan dengan konsep/teori.'],
            ['Menarik kesimpulan (generalisasi) dan merefleksikan proses penemuan.'],
        ],
        'Inquiry Learning' => [
            ['Orientasi dan penyampaian konteks {topik}.', 'Merumuskan masalah dan hipotesis.'],
            ['Mengumpulkan data.', 'Menguji hipotesis berdasarkan data.'],
            ['Merumuskan kesimpulan dan merefleksikan proses inkuiri.'],
        ],
        'Cooperative Learning' => [
            ['Menyampaikan tujuan dan memotivasi peserta didik.', 'Menyajikan informasi pokok tentang {topik}.'],
            ['Mengorganisasikan peserta didik ke dalam kelompok belajar.', 'Membimbing kelompok bekerja dan belajar (saling menjelaskan, berbagi tugas).'],
            ['Evaluasi/kuis singkat dan pemberian penghargaan kelompok; refleksi kerja sama.'],
        ],
        'Pembelajaran Langsung (Direct Instruction)' => [
            ['Menyampaikan tujuan dan mempersiapkan peserta didik.', 'Mendemonstrasikan pengetahuan/keterampilan tentang {topik} langkah demi langkah.'],
            ['Latihan terbimbing.', 'Mengecek pemahaman dan memberikan umpan balik.'],
            ['Latihan mandiri dan refleksi capaian.'],
        ],
        'Contextual Teaching and Learning (CTL)' => [
            ['Mengaitkan {topik} dengan pengalaman nyata peserta didik (konstruktivisme) dan memunculkan pertanyaan.'],
            ['Menemukan (inkuiri) dan belajar dalam masyarakat belajar (kelompok).', 'Pemodelan oleh guru/teman/narasumber.'],
            ['Refleksi dan penilaian autentik.'],
        ],
    ];

    /** Format modul bawaan sesuai jenis satuan pendidikan. */
    public static function formatBawaan(): string
    {
        $set = (string) setting('format_modul', 'otomatis');
        if (isset(self::FORMAT[$set])) {
            return $set;
        }
        return in_array(setting('jenjang'), ['MI', 'MTs', 'MA', 'MAK'], true) || setting('jenis_nomor') === 'NSM' ? 'PM-KBC' : 'PM';
    }

    /** Isi awal pertemuan dari sintaks model. */
    public static function pertemuanDariModel(string $model, string $topik, string $format, int $jumlah): array
    {
        $s   = self::SINTAKS[$model] ?? [[], [], []];
        $rep = static fn (array $a) => implode("\n", array_map(static fn ($x) => '- ' . str_replace('{topik}', $topik ?: 'materi', $x), $a));
        $awal = "- Salam, berdoa, dan mengecek kehadiran.\n- Apersepsi dan pertanyaan pemantik tentang " . ($topik ?: 'materi') . ".\n- Menyampaikan tujuan pembelajaran dan manfaatnya (berkesadaran)."
            . ($format === 'PM-KBC' ? "\n- Menumbuhkan nilai Panca Cinta yang terkait (materi insersi)." : '');
        $tutup = "- Peserta didik menyimpulkan pembelajaran.\n- Refleksi: apa yang dipelajari, bagaimana perasaan, apa yang ingin diketahui lagi.\n- Umpan balik dan informasi pertemuan berikutnya.\n- Berdoa dan salam.";
        $out = [];
        for ($i = 0; $i < max(1, $jumlah); $i++) {
            $out[] = ['awal' => $awal, 'memahami' => $rep($s[0]), 'mengaplikasi' => $rep($s[1]), 'merefleksi' => $rep($s[2]), 'penutup' => $tutup];
        }
        return $out;
    }

    /** Kerangka isi kosong. */
    public static function kosong(): array
    {
        return array_fill_keys(['identifikasi_murid', 'identifikasi_materi', 'cp', 'lintas_disiplin', 'tujuan', 'topik', 'model', 'strategi', 'kemitraan',
            'lingkungan', 'digital', 'alat_bahan', 'media', 'sumber_belajar', 'diferensiasi', 'kbc_insersi', 'asesmen_awal', 'asesmen_proses', 'asesmen_akhir',
            'lampiran_materi', 'lampiran_lkpd', 'lampiran_rubrik', 'glosarium', 'pustaka'], '') + ['dpl' => [], 'metode' => [], 'kbc_topik' => [], 'pertemuan' => []];
    }
}
