<?php

namespace App\Libraries;

/**
 * Izin keluar siswa di tengah hari:
 *  - pulang awal  : jam_keluar terisi, batas_kembali kosong (tidak kembali);
 *  - keluar sementara: jam_keluar + batas_kembali.
 * Bila verifikasi satpam aktif, izin baru "berlaku" setelah satpam mencatat siswa keluar gerbang (keluar_at).
 * Status keluar sementara:
 *  Diterbitkan → Di luar → Kembali (tepat waktu) | Terlambat kembali (≤ toleransi menit) | Membolos (> toleransi / tidak kembali).
 */
class IzinKeluar
{
    public const FINAL = ['Kembali', 'Terlambat kembali', 'Membolos', 'Pulang', 'Tidak jadi'];

    public static function verifikasiSatpam(): bool
    {
        return (string) setting('verifikasi_satpam', '1') === '1';
    }

    public static function toleransi(): int
    {
        return max(0, (int) setting('toleransi_kembali', 30));
    }

    public static function sementara(array $z): bool
    {
        return ! empty($z['jam_keluar']) && ! empty($z['batas_kembali']);
    }

    /** Jam (HH:MM) mulai izin berlaku, atau null bila siswa belum keluar gerbang. */
    public static function mulai(array $z): ?string
    {
        if (empty($z['jam_keluar'])) {
            return null;
        }
        if (! empty($z['keluar_at'])) {
            return substr($z['keluar_at'], 11, 5);
        }
        return self::verifikasiSatpam() ? null : substr($z['jam_keluar'], 0, 5);
    }

    /** Jam kembali (HH:MM) atau null. */
    public static function kembali(array $z): ?string
    {
        return ! empty($z['kembali_at']) ? substr($z['kembali_at'], 11, 5) : null;
    }

    /** Menit keterlambatan (relatif batas kembali) pada saat kembali atau — bila belum kembali — pada $sekarang. */
    public static function menitTerlambat(array $z, ?string $sekarang = null): int
    {
        if (! self::sementara($z)) {
            return 0;
        }
        $batas = strtotime($z['tanggal_mulai'] . ' ' . substr($z['batas_kembali'], 0, 5));
        $acuan = ! empty($z['kembali_at']) ? strtotime($z['kembali_at']) : strtotime($sekarang ?? date('Y-m-d H:i:s'));
        return max(0, (int) floor(($acuan - $batas) / 60));
    }

    /**
     * Status saat ini (dihitung, tidak bergantung pada kolom status_keluar).
     * @return array{status: string, menit: int, warna: string}
     */
    public static function status(array $z, ?string $sekarang = null): array
    {
        $sekarang ??= date('Y-m-d H:i:s');
        if (empty($z['jam_keluar'])) {
            return ['status' => '', 'menit' => 0, 'warna' => 'secondary'];
        }
        $berlaku = self::mulai($z) !== null;
        if (! self::sementara($z)) {   // pulang awal
            return $berlaku ? ['status' => 'Pulang', 'menit' => 0, 'warna' => 'secondary']
                : ['status' => substr($sekarang, 0, 10) > $z['tanggal_mulai'] ? 'Tidak jadi' : 'Diterbitkan', 'menit' => 0, 'warna' => 'info'];
        }
        if (! $berlaku) {
            $lewat = $sekarang > $z['tanggal_mulai'] . ' ' . substr($z['batas_kembali'], 0, 5) . ':59';
            return ['status' => $lewat ? 'Tidak jadi' : 'Diterbitkan', 'menit' => 0, 'warna' => 'info'];
        }
        $m = self::menitTerlambat($z, $sekarang);
        if ($m > self::toleransi()) {
            return ['status' => 'Membolos', 'menit' => $m, 'warna' => 'danger'];
        }
        if (! empty($z['kembali_at'])) {
            return $m > 0 ? ['status' => 'Terlambat kembali', 'menit' => $m, 'warna' => 'warning'] : ['status' => 'Kembali', 'menit' => 0, 'warna' => 'success'];
        }
        return $m > 0 ? ['status' => 'Terlambat kembali', 'menit' => $m, 'warna' => 'warning'] : ['status' => 'Di luar', 'menit' => 0, 'warna' => 'primary'];
    }

    /**
     * Mutakhirkan status izin keluar yang belum final pada tanggal tsb (dipanggil saat halaman gerbang, izin, jurnal,
     * laporan piket dibuka). Siswa yang melewati batas + toleransi tanpa kembali menjadi Membolos.
     * @return int jumlah izin yang statusnya berubah
     */
    public static function perbarui(?string $tanggal = null): int
    {
        $tanggal ??= date('Y-m-d');
        $db   = db_connect();
        $rows = $db->table('izin_siswa')->where('tanggal_mulai <=', $tanggal)->where('tanggal_mulai >=', date('Y-m-d', strtotime($tanggal . ' -7 days')))
            ->where('jam_keluar IS NOT NULL')->where('kembali_at', null)   // "Terlambat kembali" yang belum kembali masih bisa menjadi Membolos
            ->groupStart()->where('status_keluar', null)->orWhereNotIn('status_keluar', ['Membolos', 'Pulang', 'Tidak jadi'])->groupEnd()
            ->get()->getResultArray();
        $n = 0;
        foreach ($rows as $z) {
            if (self::simpanStatus($z)) {
                $n++;
            }
        }
        return $n;
    }

    /** Simpan status terkini ke database + efek sampingnya. @return bool berubah */
    public static function simpanStatus(array $z, ?int $oleh = null, bool $paksa = false): bool
    {
        $s    = self::status($z);
        $baru = $s['status'];
        if (! $paksa && $baru === ($z['status_keluar'] ?? null)) {
            return false;
        }
        $db = db_connect();
        $db->table('izin_siswa')->where('id', $z['id'])->update(['status_keluar' => $baru, 'updated_at' => date('Y-m-d H:i:s')]);
        $z['status_keluar'] = $baru;
        self::catatPerilaku($z, $s, $oleh);
        self::keteranganPagi($z, $s);
        SinkronAbsensi::terapkan([(int) $z['siswa_id']], $z['tanggal_mulai']);
        return true;
    }

    /** Catatan perilaku otomatis untuk terlambat kembali / membolos (bisa dimatikan di pengaturan). */
    private static function catatPerilaku(array $z, array $s, ?int $oleh): void
    {
        $db   = db_connect();
        $perlu = in_array($s['status'], ['Terlambat kembali', 'Membolos'], true)
            && (string) setting('izin_keluar_perilaku', '1') === '1';
        // status bisa naik (terlambat → membolos) atau turun (koreksi jam kembali): catatan lama diganti
        if (! empty($z['catatan_perilaku_id'])) {
            $lama = $db->table('catatan_perilaku')->where('id', $z['catatan_perilaku_id'])->get()->getRowArray();
            if ($lama && $lama['status'] === 'Tercatat') {
                $db->table('catatan_perilaku')->where('id', $lama['id'])->delete();
            }
            $db->table('izin_siswa')->where('id', $z['id'])->update(['catatan_perilaku_id' => null]);
        }
        if (! $perlu || $s['status'] === 'Terlambat kembali' && empty($z['kembali_at'])) {
            return;   // terlambat baru dicatat setelah siswa kembali (bisa saja berubah menjadi membolos)
        }
        $pola  = $s['status'] === 'Membolos' ? 'Membolos' : 'Terlambat kembali';
        $jenis = $db->table('jenis_perilaku')->like('nama', $pola, 'after')->where('kategori', 'Negatif')->get()->getRowArray();
        $ang   = $db->table('anggota_kelas')->where('siswa_id', $z['siswa_id'])->orderBy('tahun_pelajaran_id', 'DESC')->get()->getRowArray();
        $tp    = tp_aktif();
        if (! $tp) {
            return;
        }
        $desk = ($s['status'] === 'Membolos' ? 'Membolos: ' : 'Terlambat kembali: ') . 'izin keluar ' . substr($z['jam_keluar'], 0, 5) . '–' . substr($z['batas_kembali'], 0, 5)
            . (! empty($z['kembali_at']) ? ', kembali ' . substr($z['kembali_at'], 11, 5) . ' (terlambat ' . $s['menit'] . ' menit)' : ', tidak kembali sampai batas toleransi ' . self::toleransi() . ' menit')
            . ($z['keterangan'] ? '. Keperluan: ' . $z['keterangan'] : '') . '. (otomatis dari izin keluar)';
        $db->table('catatan_perilaku')->insert([
            'tahun_pelajaran_id' => $tp['id'], 'siswa_id' => $z['siswa_id'], 'kelas_id' => $ang['kelas_id'] ?? null,
            'jenis_perilaku_id' => $jenis['id'] ?? null, 'tanggal' => $z['tanggal_mulai'], 'kategori' => 'Negatif',
            'poin' => (int) ($jenis['poin'] ?? ($s['status'] === 'Membolos' ? 15 : 5)), 'deskripsi' => $desk, 'lokasi' => 'Gerbang sekolah',
            'status' => 'Tercatat', 'dicatat_oleh' => $oleh ?: ($z['kembali_oleh'] ?? $z['dicatat_oleh'] ?? null),
            'created_at' => date('Y-m-d H:i:s'), 'updated_at' => date('Y-m-d H:i:s'),
        ]);
        $db->table('izin_siswa')->where('id', $z['id'])->update(['catatan_perilaku_id' => $db->insertID()]);
    }

    /** Keterangan di absensi pagi (status pagi tetap Hadir). */
    public static function keteranganPagi(array $z, ?array $s = null): void
    {
        $db  = db_connect();
        $row = $db->table('presensi_harian')->where(['siswa_id' => $z['siswa_id'], 'tanggal' => $z['tanggal_mulai']])->get()->getRowArray();
        if (! $row) {
            return;
        }
        $ket = trim(preg_replace('/;?\s*\[keluar [^\]]*\]/', '', (string) $row['keterangan']));
        if (self::sementara($z)) {
            $s ??= self::status($z);
            $tag = '[keluar ' . substr($z['jam_keluar'], 0, 5) . '–' . substr($z['batas_kembali'], 0, 5) . ': ' . strtolower($s['status'])
                . (self::kembali($z) ? ' ' . self::kembali($z) : '') . ']';
            $ket = trim(($ket ? $ket . '; ' : '') . $tag);
        }
        $db->table('presensi_harian')->where('id', $row['id'])->update(['keterangan' => mb_substr($ket, 0, 150) ?: null]);
    }
}
