<?php

namespace App\Libraries;

use App\Models\KalenderModel;

/**
 * Status setiap tanggal menurut hari sekolah, periode tahun pelajaran aktif, dan kalender akademik.
 * Dipakai jurnal, absensi pagi, kiosk, pembiasaan, monitoring, dan laporan.
 *
 *  sekolah : hari sekolah (Senin–Jumat/Sabtu) di dalam periode TP aktif
 *  kbm     : ada kegiatan belajar terjadwal → jurnal wajib diisi
 *  absensi : absensi harian siswa diambil
 */
class Kalender
{
    private static array $agenda = [];   // cache per bulan "Y-m" => list
    private static array $cache  = [];

    public static function reset(): void
    {
        self::$agenda = [];
        self::$cache  = [];
    }

    private static function agendaBulan(string $ym): array
    {
        if (! array_key_exists($ym, self::$agenda)) {
            $dari = $ym . '-01';
            try {
                self::$agenda[$ym] = model(KalenderModel::class)->rentang($dari, date('Y-m-t', strtotime($dari)));
            } catch (\Throwable $e) {
                self::$agenda[$ym] = [];   // tabel belum dimigrasi
            }
        }
        return self::$agenda[$ym];
    }

    /**
     * Agenda kalender yang berlaku pada tanggal tsb.
     * $kelasId null → semua agenda (termasuk yang hanya untuk sebagian kelas); diisi → hanya yang mengenai kelas itu.
     */
    public static function agenda(string $tanggal, ?int $kelasId = null): array
    {
        return array_values(array_filter(self::agendaBulan(substr($tanggal, 0, 7)),
            static function ($a) use ($tanggal, $kelasId) {
                if ($a['tanggal_mulai'] > $tanggal || $a['tanggal_selesai'] < $tanggal) {
                    return false;
                }
                $sasaran = KalenderModel::kelasDari($a['kelas_ids'] ?? null);
                return $kelasId === null || $sasaran === [] || in_array($kelasId, $sasaran, true);
            }));
    }

    private static function untukSemua(array $a): bool
    {
        return KalenderModel::kelasDari($a['kelas_ids'] ?? null) === [];
    }

    /** Hari jadwal (1–7) yang dipakai sebagai pengganti pada tanggal tsb (dari agenda Masuk Pengganti). */
    public static function hariPengganti(string $tanggal): array
    {
        $out = [];
        foreach (self::agenda($tanggal) as $a) {
            if ($a['jenis'] === 'Masuk Pengganti' && ! empty($a['hari_jadwal'])) {
                $out[] = (int) $a['hari_jadwal'];
            }
        }
        return array_values(array_unique($out));
    }

    /** Jadwal hari apa yang berlaku untuk kelas tsb pada tanggal tsb. */
    public static function hariJadwal(string $tanggal, ?int $kelasId = null): int
    {
        foreach (self::agenda($tanggal, $kelasId) as $a) {
            if ($a['jenis'] === 'Masuk Pengganti' && ! empty($a['hari_jadwal']) && ($kelasId !== null || self::untukSemua($a))) {
                return (int) $a['hari_jadwal'];
            }
        }
        return (int) date('N', strtotime($tanggal));
    }

    /**
     * @param int|null $kelasId null = status umum sekolah (agenda sebagian kelas hanya ditampilkan, tidak menghentikan KBM)
     * @return array{sekolah: bool, kbm: bool, absensi: bool, agenda: list<array>, label: string, warna: string, hari_jadwal: int, sebagian: bool}
     */
    public static function status(string $tanggal, ?int $kelasId = null): array
    {
        $ck = $tanggal . '|' . ($kelasId ?? '*');
        if (isset(self::$cache[$ck])) {
            return self::$cache[$ck];
        }
        $tp      = tp_aktif();
        $dalamTp = ! $tp || ((empty($tp['tanggal_mulai']) || $tanggal >= $tp['tanggal_mulai']) && (empty($tp['tanggal_selesai']) || $tanggal <= $tp['tanggal_selesai']));
        $agenda  = self::agenda($tanggal, $kelasId);
        $berlaku = $kelasId === null ? array_values(array_filter($agenda, [self::class, 'untukSemua'])) : $agenda;

        $pengganti = array_values(array_filter($berlaku, static fn ($a) => $a['jenis'] === 'Masuk Pengganti'));
        $lainnya   = array_values(array_filter($berlaku, static fn ($a) => $a['jenis'] !== 'Masuk Pengganti'));

        $sekolah = $dalamTp && (isset(hari_list()[(int) date('N', strtotime($tanggal))]) || $pengganti);
        $kbm     = $absensi = $sekolah;
        foreach ($lainnya as $a) {
            $kbm     = $kbm && (int) $a['ada_kbm'] === 1;
            $absensi = $absensi && (int) $a['ada_absensi'] === 1;
        }
        $sebagian = count($agenda) > count($berlaku);

        if (! $sekolah) {
            $label = $dalamTp ? 'Bukan hari sekolah' : 'Di luar periode tahun pelajaran aktif';
            $warna = 'secondary';
        } elseif ($agenda) {
            $label = implode('; ', array_map(static function ($a) {
                $t = $a['jenis'] . ': ' . $a['nama'];
                if ($a['jenis'] === 'Masuk Pengganti' && ! empty($a['hari_jadwal'])) {
                    $t .= ' (jadwal hari ' . (hari_list()[(int) $a['hari_jadwal']] ?? $a['hari_jadwal']) . ')';
                }
                return $t . (self::untukSemua($a) ? '' : ' – sebagian kelas');
            }, $agenda));
            $utama = $lainnya[0] ?? $pengganti[0] ?? $agenda[0];
            $warna = KalenderModel::BAWAAN[$utama['jenis']][2] ?? 'info';
        } else {
            $label = 'Hari efektif';
            $warna = 'success';
        }
        $hari_jadwal = self::hariJadwal($tanggal, $kelasId);
        return self::$cache[$ck] = compact('sekolah', 'kbm', 'absensi', 'agenda', 'label', 'warna', 'hari_jadwal', 'sebagian');
    }

    public static function kbm(string $tanggal, ?int $kelasId = null): bool
    {
        return self::status($tanggal, $kelasId)['kbm'];
    }

    public static function absensi(string $tanggal, ?int $kelasId = null): bool
    {
        return self::status($tanggal, $kelasId)['absensi'];
    }

    /** Daftar tanggal Y-m-d dari $dari s.d. $sampai. */
    public static function tanggal(string $dari, string $sampai): array
    {
        $out = [];
        for ($d = $dari; $d <= $sampai; $d = date('Y-m-d', strtotime($d . ' +1 day'))) {
            $out[] = $d;
        }
        return $out;
    }

    /**
     * Rincian pekan & hari efektif per bulan untuk periode TP.
     * Pekan dihitung Senin–Minggu dan masuk ke bulan tempat hari sekolah pertamanya.
     * Pekan efektif = pekan yang memiliki minimal satu hari KBM.
     *
     * @return array{bulan: list<array>, total: array, per_hari: array<int,int>}
     */
    public static function pekanEfektif(string $dari, string $sampai): array
    {
        $pekan   = [];   // key "o-W" => ['bulan' => 'Y-m', 'sekolah' => n, 'kbm' => n]
        $bulan   = [];
        $perHari = array_fill_keys(array_keys(hari_list()), 0);

        foreach (self::tanggal($dari, $sampai) as $d) {
            $ym = substr($d, 0, 7);
            $bulan[$ym] ??= ['ym' => $ym, 'pekan' => 0, 'pekan_efektif' => 0, 'hari_sekolah' => 0, 'hari_efektif' => 0, 'agenda' => []];
            $s = self::status($d);
            if (! $s['sekolah']) {
                continue;
            }
            $key = date('o-W', strtotime($d));
            $pekan[$key] ??= ['bulan' => $ym, 'kbm' => 0];
            $bulan[$ym]['hari_sekolah']++;
            if ($s['kbm']) {
                $pekan[$key]['kbm']++;
                $bulan[$ym]['hari_efektif']++;
                $perHari[$s['hari_jadwal']] = ($perHari[$s['hari_jadwal']] ?? 0) + 1;
            }
            foreach ($s['agenda'] as $a) {
                $bulan[$ym]['agenda'][$a['id']] = $a;
            }
        }
        foreach ($pekan as $p) {
            $bulan[$p['bulan']]['pekan']++;
            $bulan[$p['bulan']]['pekan_efektif'] += $p['kbm'] > 0 ? 1 : 0;
        }
        $total = ['pekan' => 0, 'pekan_efektif' => 0, 'hari_sekolah' => 0, 'hari_efektif' => 0];
        foreach ($bulan as &$b) {
            $b['agenda'] = array_values($b['agenda']);
            foreach ($total as $k => $_) {
                $total[$k] += $b[$k];
            }
        }
        return ['bulan' => array_values($bulan), 'total' => $total, 'per_hari' => $perHari];
    }
}
