<?php

namespace App\Libraries;

use CodeIgniter\HTTP\Files\UploadedFile;

/**
 * Berkas lampiran (surat izin, surat dokter, modul ajar) disimpan di writable/uploads/<folder>,
 * di luar folder publik, dan hanya bisa diunduh lewat controller yang memeriksa hak akses.
 */
class Berkas
{
    public const EKSTENSI = ['pdf', 'jpg', 'jpeg', 'png', 'doc', 'docx'];
    public const MAKS_KB  = 2048;

    public static function dir(string $folder): string
    {
        $dir = WRITEPATH . 'uploads/' . preg_replace('/[^a-z_]/', '', $folder) . '/';
        if (! is_dir($dir)) {
            mkdir($dir, 0775, true);
            @file_put_contents(WRITEPATH . 'uploads/.htaccess', "Require all denied\nDeny from all\n");
        }
        return $dir;
    }

    /**
     * Simpan file unggahan. @return array{0: ?string, 1: ?string} [nama file, pesan galat]
     */
    public static function simpan(?UploadedFile $file, string $folder, array $ekstensi = self::EKSTENSI, int $maksKb = self::MAKS_KB): array
    {
        if (! $file || $file->getError() === UPLOAD_ERR_NO_FILE) {
            return [null, null];
        }
        if (! $file->isValid()) {
            return [null, 'Unggahan gagal: ' . $file->getErrorString()];
        }
        $ext = strtolower($file->getClientExtension() ?: $file->guessExtension() ?: '');
        if (! in_array($ext, $ekstensi, true)) {
            return [null, 'Jenis berkas tidak diizinkan. Gunakan: ' . implode(', ', $ekstensi) . '.'];
        }
        if ($file->getSizeByUnit('kb') > $maksKb) {
            return [null, 'Ukuran berkas maksimal ' . round($maksKb / 1024, 1) . ' MB.'];
        }
        $nama = date('Ymd_His') . '_' . bin2hex(random_bytes(4)) . '.' . $ext;
        $file->move(self::dir($folder), $nama);
        return [$nama, null];
    }

    public static function path(string $folder, ?string $nama): ?string
    {
        if (! $nama || ! preg_match('/^[\w.-]+$/', $nama)) {
            return null;
        }
        $p = self::dir($folder) . $nama;
        return is_file($p) ? $p : null;
    }

    public static function hapus(string $folder, ?string $nama): void
    {
        if ($p = self::path($folder, $nama)) {
            @unlink($p);
        }
    }
}
