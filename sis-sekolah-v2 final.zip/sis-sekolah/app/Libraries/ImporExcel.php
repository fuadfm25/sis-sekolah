<?php

namespace App\Libraries;

use PhpOffice\PhpSpreadsheet\Cell\Coordinate;
use PhpOffice\PhpSpreadsheet\IOFactory;
use PhpOffice\PhpSpreadsheet\Shared\Date as XlsDate;

/**
 * Membaca file unduhan Dapodik / EMIS / template sendiri:
 * - baris judul di atas tabel dilewati (deteksi baris header otomatis),
 * - header dua baris (mis. "Data Ayah" → "Nama", "Pekerjaan") digabung menjadi "Data Ayah Nama",
 * - kolom ditebak dari daftar sinonim dan bisa diubah pengguna di halaman pratinjau.
 */
class ImporExcel
{
    /** field => [label, sinonim (sudah dinormalisasi; urutan = prioritas)] */
    public const FIELD = [
        'siswa' => [
            'nama_lengkap'  => ['Nama lengkap', ['nama lengkap', 'nama', 'nama siswa', 'nama peserta didik', 'nama lengkap siswa', 'nama pd']],
            'nis'           => ['NIS', ['nis', 'nipd', 'nis lokal', 'nism', 'nis nism', 'nomor induk', 'no induk', 'nomor induk siswa', 'no induk siswa']],
            'nisn'          => ['NISN', ['nisn']],
            'jenis_kelamin' => ['L/P', ['jk', 'l p', 'jenis kelamin', 'kelamin', 'gender', 'lp']],
            'tempat_lahir'  => ['Tempat lahir', ['tempat lahir', 'tmp lahir']],
            'tanggal_lahir' => ['Tanggal lahir', ['tanggal lahir', 'tgl lahir', 'tanggal lahir yyyy mm dd']],
            'agama'         => ['Agama', ['agama']],
            'alamat'        => ['Alamat', ['alamat', 'alamat jalan', 'alamat lengkap', 'alamat tempat tinggal']],
            'nama_wali'     => ['Nama wali/orang tua', ['nama wali', 'data wali nama', 'nama ayah', 'data ayah nama', 'nama ayah kandung', 'nama ibu', 'data ibu nama', 'nama ibu kandung']],
            'no_hp_wali'    => ['No HP wali', ['no hp wali', 'nomor hp wali', 'hp orang tua', 'no hp orang tua', 'hp', 'no hp', 'nomor hp', 'telepon', 'no telepon', 'nomor telepon']],
            'kelas'         => ['Kelas / rombel', ['rombel saat ini', 'kelas', 'rombel', 'nama rombel', 'rombongan belajar', 'kelas saat ini', 'tingkat rombel']],
            'rfid'          => ['Kode RFID', ['kode rfid', 'rfid', 'kode rfid opsional', 'uid kartu']],
        ],
        'guru' => [
            'nama_lengkap'       => ['Nama lengkap', ['nama', 'nama lengkap', 'nama ptk', 'nama gtk', 'nama guru', 'nama pegawai']],
            'nip'                => ['NIP', ['nip', 'nip baru']],
            'nuptk'              => ['NUPTK', ['nuptk']],
            'jenis_kelamin'      => ['L/P', ['jk', 'l p', 'jenis kelamin', 'kelamin', 'lp']],
            'no_hp'              => ['No HP', ['hp', 'no hp', 'nomor hp', 'telepon', 'no telepon', 'nomor telepon']],
            'email'              => ['Email', ['email', 'e mail', 'alamat email']],
            'status_kepegawaian' => ['Status kepegawaian', ['status kepegawaian', 'status pegawai', 'status kepegawaian ptk']],
            'gelar_depan'        => ['Gelar depan', ['gelar depan']],
            'gelar_belakang'     => ['Gelar belakang', ['gelar belakang']],
        ],
    ];

    public static function norm($v): string
    {
        $v = strtolower(trim((string) $v));
        $v = preg_replace('/[^a-z0-9]+/', ' ', $v);
        return trim(preg_replace('/\s+/', ' ', $v));
    }

    /**
     * @return array{label: list<string>, data: list<array>, baris_header: int, dua_baris: bool, sumber: string}
     */
    public static function baca(string $path, string $jenis): array
    {
        $book  = IOFactory::load($path);
        $sheet = $book->getActiveSheet();
        // pilih sheet dengan skor header terbaik (file Dapodik kadang berisi beberapa sheet)
        $terbaik = [-1, null, 0];
        foreach ($book->getAllSheets() as $sh) {
            $rows = $sh->toArray(null, true, false, false);
            [$idx, $skor] = self::cariHeader($rows, $jenis);
            if ($skor > $terbaik[0]) {
                $terbaik = [$skor, $sh, $idx];
            }
        }
        $sheet = $terbaik[1] ?? $sheet;
        $h     = $terbaik[2];
        $rows  = $sheet->toArray(null, true, false, false);
        $atas  = $rows[$h] ?? [];
        $bawah = $rows[$h + 1] ?? [];

        // header dua baris: ada sel gabungan horizontal pada baris header, atau baris berikut berisi sub-judul di bawah sel kosong
        $merge = [];
        foreach ($sheet->getMergeCells() as $rng) {
            [$a, $b] = explode(':', $rng);
            [$ca, $ra] = Coordinate::coordinateFromString($a);
            [$cb, $rb] = Coordinate::coordinateFromString($b);
            if ((int) $ra === $h + 1 && $ca !== $cb) {
                for ($c = Coordinate::columnIndexFromString($ca); $c <= Coordinate::columnIndexFromString($cb); $c++) {
                    $merge[$c - 1] = (string) $atas[Coordinate::columnIndexFromString($ca) - 1];
                }
            }
        }
        $sub = 0;
        foreach ($bawah as $i => $v) {
            if (trim((string) $v) !== '' && ! is_numeric($v) && (isset($merge[$i]) || trim((string) ($atas[$i] ?? '')) === '')) {
                $sub++;
            }
        }
        $dua   = $sub >= 2;
        $label = [];
        $carry = '';
        $n     = max(count($atas), count($bawah));
        for ($i = 0; $i < $n; $i++) {
            $p = trim((string) ($atas[$i] ?? ''));
            if ($p !== '') {
                $carry = $p;
            }
            if ($dua && trim((string) ($bawah[$i] ?? '')) !== '') {
                $parent  = $merge[$i] ?? ($p !== '' ? $p : $carry);
                $label[] = trim($parent . ' ' . trim((string) $bawah[$i]));
            } else {
                $label[] = $p;
            }
        }
        $data = [];
        foreach (array_slice($rows, $h + ($dua ? 2 : 1)) as $r) {
            if (implode('', array_map(static fn ($x) => trim((string) $x), $r)) === '') {
                continue;
            }
            $data[] = $r;
        }
        $judul  = strtolower(implode(' ', array_map('strval', array_merge(...array_slice($rows, 0, max(1, $h)) ?: [[]]))));
        $sumber = str_contains($judul, 'dapodik') || in_array('nipd', array_map([self::class, 'norm'], $label), true) || str_contains($judul, 'peserta didik') ? 'Dapodik'
            : (str_contains($judul, 'emis') || str_contains(implode(' ', array_map([self::class, 'norm'], $label)), 'nism') ? 'EMIS' : 'Excel');

        return ['label' => $label, 'data' => $data, 'baris_header' => $h + 1, 'dua_baris' => $dua, 'sumber' => $sumber];
    }

    /** @return array{0:int,1:int} [indeks baris header, skor] */
    private static function cariHeader(array $rows, string $jenis): array
    {
        $kamus = [];
        foreach (DataExcel::field($jenis) as [, $sin]) {
            foreach ($sin as $s) {
                $kamus[$s] = true;
            }
        }
        $best = [0, 0];
        foreach (array_slice($rows, 0, 25) as $i => $r) {
            $skor = 0;
            foreach ($r as $v) {
                $skor += isset($kamus[self::norm($v)]) ? 1 : 0;
            }
            if ($skor > $best[1]) {
                $best = [$i, $skor];
            }
        }
        return $best;
    }

    /** Tebak pemetaan kolom → field. @return array<int,string> */
    public static function tebak(array $label, string $jenis): array
    {
        $norm = array_map([self::class, 'norm'], $label);
        $map  = [];
        $pakai = [];
        foreach (DataExcel::field($jenis) as $field => [, $sin]) {
            foreach ([true, false] as $persis) {
                foreach ($sin as $s) {
                    foreach ($norm as $i => $l) {
                        if (isset($pakai[$i]) || $l === '') {
                            continue;
                        }
                        if ($persis ? $l === $s : (strlen($s) > 3 && str_starts_with($l, $s . ' '))) {
                            $map[$i]    = $field;
                            $pakai[$i]  = true;
                            continue 4;
                        }
                    }
                }
            }
        }
        ksort($map);
        return $map;
    }

    // ------------------------------------------------------------------ konversi nilai
    public static function teks($v): ?string
    {
        if ($v === null) {
            return null;
        }
        if (is_float($v) && floor($v) === $v) {
            $v = number_format($v, 0, '', '');
        }
        $v = trim(ltrim((string) $v, "'"));
        return $v === '' || $v === '-' ? null : $v;
    }

    public static function jk($v): ?string
    {
        $v = self::norm($v);
        if ($v === '') {
            return null;
        }
        if (in_array($v, ['l', 'lk', 'laki laki', 'laki', 'pria', 'male'], true)) {
            return 'L';
        }
        return in_array($v, ['p', 'pr', 'perempuan', 'wanita', 'female'], true) ? 'P' : null;
    }

    public static function tanggal($v): ?string
    {
        if ($v === null || $v === '') {
            return null;
        }
        if (is_numeric($v) && $v > 1000 && $v < 80000) {
            return XlsDate::excelToDateTimeObject((float) $v)->format('Y-m-d');
        }
        $s = strtolower(trim((string) $v));
        if (preg_match('#^(\d{4})[-/.](\d{1,2})[-/.](\d{1,2})#', $s, $m)) {
            return checkdate((int) $m[2], (int) $m[3], (int) $m[1]) ? sprintf('%04d-%02d-%02d', $m[1], $m[2], $m[3]) : null;
        }
        if (preg_match('#^(\d{1,2})[-/.](\d{1,2})[-/.](\d{2,4})$#', $s, $m)) {   // format Indonesia: dd/mm/yyyy
            $y = (int) $m[3] < 100 ? 2000 + (int) $m[3] : (int) $m[3];
            return checkdate((int) $m[2], (int) $m[1], $y) ? sprintf('%04d-%02d-%02d', $y, $m[2], $m[1]) : null;
        }
        $bulan = ['januari' => 1, 'februari' => 2, 'pebruari' => 2, 'maret' => 3, 'april' => 4, 'mei' => 5, 'juni' => 6, 'juli' => 7,
            'agustus' => 8, 'september' => 9, 'oktober' => 10, 'november' => 11, 'nopember' => 11, 'desember' => 12,
            'jan' => 1, 'feb' => 2, 'mar' => 3, 'apr' => 4, 'jun' => 6, 'jul' => 7, 'agu' => 8, 'agt' => 8, 'sep' => 9, 'okt' => 10, 'nov' => 11, 'des' => 12];
        if (preg_match('#^(\d{1,2})\s+([a-z]+)\s+(\d{4})$#', $s, $m) && isset($bulan[$m[2]])) {
            return checkdate($bulan[$m[2]], (int) $m[1], (int) $m[3]) ? sprintf('%04d-%02d-%02d', $m[3], $bulan[$m[2]], $m[1]) : null;
        }
        return null;
    }

    /** Status kepegawaian Dapodik/EMIS → pilihan aplikasi (PNS, PPPK, GTY, GTT, Honorer). */
    public static function statusPegawai($v): ?string
    {
        $n = self::norm($v);
        if ($n === '') {
            return null;
        }
        return match (true) {
            str_contains($n, 'pppk') || str_contains($n, 'p3k')                        => 'PPPK',
            str_contains($n, 'pns') || str_contains($n, 'cpns')                       => 'PNS',
            str_contains($n, 'gty') || str_contains($n, 'tetap yayasan')               => 'GTY',
            str_contains($n, 'gtt') || str_contains($n, 'tidak tetap')                 => 'GTT',
            default                                                                    => 'Honorer',
        };
    }

    /** Kunci pencocokan nama kelas: "VII A", "7-A", "Kelas 7A" → "7A". */
    public static function kunciKelas(string $nama): string
    {
        $s = strtoupper(trim($nama));
        $s = preg_replace('/^(KELAS|ROMBEL)\s+/', '', $s);
        $romawi = ['XII' => 12, 'XI' => 11, 'X' => 10, 'IX' => 9, 'VIII' => 8, 'VII' => 7, 'VI' => 6, 'V' => 5, 'IV' => 4, 'III' => 3, 'II' => 2, 'I' => 1];
        if (preg_match('/^(XII|XI|IX|X|VIII|VII|VI|IV|V|III|II|I)(?![IVX])/', $s, $m)) {
            $s = $romawi[$m[1]] . substr($s, strlen($m[1]));
        }
        return preg_replace('/[^A-Z0-9]/', '', $s);
    }

    /** Tingkat dari nama kelas ("VII A" → "VII", "10 IPA 1" → "10"). */
    public static function tingkat(string $nama): string
    {
        $s = strtoupper(trim(preg_replace('/^(kelas|rombel)\s+/i', '', $nama)));
        return preg_match('/^(XII|XI|IX|X|VIII|VII|VI|IV|V|III|II|I)(?![IVX])|^(\d{1,2})(?!\d)/', $s, $m) ? ($m[1] !== '' ? $m[1] : $m[2]) : '-';
    }
}
