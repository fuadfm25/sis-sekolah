<?php

namespace App\Libraries;

use App\Models\AnggotaKelasModel;
use App\Models\SiswaModel;

/**
 * Akun portal siswa. Username: NISN atau NIS. Password bawaan (selama kolom password kosong):
 * tanggal lahir format ddmmyyyy, atau NIS bila tanggal lahir belum diisi. Wajib diganti saat login pertama.
 */
class PortalSiswa
{
    public static function aktif(): bool
    {
        return (string) setting('portal_siswa', '1') === '1';
    }

    public static function passwordBawaan(array $s): string
    {
        return ! empty($s['tanggal_lahir']) ? date('dmY', strtotime($s['tanggal_lahir'])) : (string) $s['nis'];
    }

    public static function petunjukBawaan(array $s): string
    {
        return ! empty($s['tanggal_lahir']) ? 'tanggal lahir (ddmmyyyy), mis. 17052013' : 'NIS';
    }

    public static function cocok(array $s, string $pw): bool
    {
        return empty($s['password']) ? hash_equals(self::passwordBawaan($s), $pw) : password_verify($pw, $s['password']);
    }

    public static function cari(string $id): ?array
    {
        $id = trim($id);
        if ($id === '') {
            return null;
        }
        $m = model(SiswaModel::class);
        return $m->where('nisn', $id)->first() ?: $m->where('nis', $id)->first();
    }

    /** Siswa yang sedang login + kelasnya pada TP aktif. */
    public static function saya(): ?array
    {
        static $s = false;
        if ($s === false) {
            $s  = null;
            $id = (int) session('siswa_id');
            if ($id && ($row = model(SiswaModel::class)->find($id)) && $row['status'] === 'Aktif') {
                $tp           = tp_aktif();
                $kelas        = $tp ? model(AnggotaKelasModel::class)->kelasSiswa($id, (int) $tp['id']) : null;
                $s            = $row + ['kelas' => $kelas];
            }
        }
        return $s;
    }
}
