<?php

namespace App\Libraries;

/**
 * Backup database ke file .sql (atau .sql.gz) di writable/backups.
 * Dapat dipulihkan lewat phpMyAdmin → Import.
 */
class Backup
{
    public static function folder(): string
    {
        $d = WRITEPATH . 'backups/';
        if (! is_dir($d)) {
            @mkdir($d, 0775, true);
            @file_put_contents($d . 'index.html', '');
            @file_put_contents($d . '.htaccess', "Require all denied\nDeny from all\n");
        }
        return $d;
    }

    /** Buat backup; mengembalikan path file. */
    public static function buat(bool $gzip = true): string
    {
        $db    = db_connect();
        $nama  = 'backup_' . ($db->getDatabase() ? basename((string) $db->getDatabase(), '.db') . '_' : '') . date('Ymd_His') . '.sql';
        $path  = self::folder() . $nama;
        $fh    = fopen($path, 'wb');
        $tulis = static fn (string $s) => fwrite($fh, $s);

        $tulis("-- Backup SIS Sekolah\n-- Dibuat: " . date('Y-m-d H:i:s') . "\n-- Pulihkan: phpMyAdmin > pilih database kosong > Import file ini\n\n");
        $tulis("SET NAMES utf8mb4;\nSET FOREIGN_KEY_CHECKS = 0;\nSET SQL_MODE = \"NO_AUTO_VALUE_ON_ZERO\";\n\n");

        foreach ($db->listTables() as $t) {
            if ($db->DBDriver === 'MySQLi') {
                $create = $db->query('SHOW CREATE TABLE `' . $t . '`')->getRowArray()['Create Table'] ?? '';
            } else {
                $create = (string) $db->query("SELECT sql FROM sqlite_master WHERE type='table' AND name=" . $db->escape($t))->getRow('sql');
            }
            $tulis("-- ---------------------------------------------\n-- Tabel `{$t}`\nDROP TABLE IF EXISTS `{$t}`;\n{$create};\n\n");

            $offset = 0;
            while (true) {
                $rows = $db->table($t)->limit(500, $offset)->get()->getResultArray();
                if (! $rows) {
                    break;
                }
                $kolom = '`' . implode('`, `', array_keys($rows[0])) . '`';
                $nilai = [];
                foreach ($rows as $r) {
                    $nilai[] = '(' . implode(', ', array_map(static fn ($v) => $v === null ? 'NULL' : $db->escape($v), $r)) . ')';
                }
                $tulis("INSERT INTO `{$t}` ({$kolom}) VALUES\n" . implode(",\n", $nilai) . ";\n");
                $offset += 500;
            }
            $tulis("\n");
        }
        $tulis("SET FOREIGN_KEY_CHECKS = 1;\n");
        fclose($fh);

        if ($gzip && function_exists('gzencode')) {
            file_put_contents($path . '.gz', gzencode((string) file_get_contents($path), 6));
            unlink($path);
            $path .= '.gz';
        }
        return $path;
    }

    /** Hapus backup lama, sisakan $simpan file terbaru. */
    public static function rapikan(int $simpan = 14): int
    {
        $files = self::daftar();
        $hapus = 0;
        foreach (array_slice($files, $simpan) as $f) {
            if (@unlink(self::folder() . $f['nama'])) {
                $hapus++;
            }
        }
        return $hapus;
    }

    public static function daftar(): array
    {
        $out = [];
        foreach (glob(self::folder() . 'backup_*.sql*') ?: [] as $f) {
            $out[] = ['nama' => basename($f), 'ukuran' => filesize($f), 'waktu' => filemtime($f)];
        }
        usort($out, static fn ($a, $b) => $b['waktu'] <=> $a['waktu']);
        return $out;
    }
}
