<?php

namespace App\Database\Migrations;

use App\Database\MigrasiSis;
use CodeIgniter\Database\Seeder;
use Config\Database;

/**
 * Data awal: role, akun admin (admin / admin123), pengaturan sekolah, dan data referensi.
 * Dijalankan otomatis oleh "php spark migrate" sehingga instalasi baru cukup satu perintah.
 * Seeder aman dijalankan ulang (hanya mengisi yang belum ada).
 */
class DataAwal extends MigrasiSis
{
    public function up()
    {
        // seeder memakai koneksi yang sama dengan migration (penting untuk grup "tests" pada PHPUnit)
        (new Seeder(config(Database::class), $this->db))->setSilent(true)->call('App\Database\Seeds\DatabaseSeeder');
    }

    public function down()
    {
        // data awal ikut terhapus saat tabel di-rollback
    }
}
