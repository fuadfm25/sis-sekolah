<?php

namespace App\Database\Migrations;

use App\Database\MigrasiSis;

/**
 * Perangkat pembelajaran, program semester/tahunan, dan modul ajar.
 */
class PerangkatPembelajaran extends MigrasiSis
{
    public function up()
    {
        if ($this->sudahTerpasang()) {
            return;
        }
        // jenis_perangkat
        $this->forge->addField([
            'id'                 => ['type' => 'INT', 'unsigned' => true, 'auto_increment' => true],
            'nama'               => ['type' => 'VARCHAR', 'constraint' => 120, 'null' => false],
            'periode'            => ['type' => 'VARCHAR', 'constraint' => 10, 'default' => 'Semester', 'null' => false],
            'wajib'              => ['type' => 'TINYINT', 'constraint' => 1, 'default' => 1, 'null' => false],
            'keterangan'         => ['type' => 'VARCHAR', 'constraint' => 255, 'null' => true],
            'urutan'             => ['type' => 'SMALLINT', 'default' => 0, 'null' => false],
            'is_active'          => ['type' => 'TINYINT', 'constraint' => 1, 'default' => 1, 'null' => false],
            'created_at'         => ['type' => 'DATETIME', 'null' => true],
            'updated_at'         => ['type' => 'DATETIME', 'null' => true],
        ]);
        $this->forge->addPrimaryKey('id');
        $this->forge->createTable('jenis_perangkat', true);

        // perangkat_pembelajaran
        $this->forge->addField([
            'id'                 => ['type' => 'INT', 'unsigned' => true, 'auto_increment' => true],
            'tahun_pelajaran_id' => ['type' => 'INT', 'unsigned' => true, 'null' => false],
            'guru_id'            => ['type' => 'INT', 'unsigned' => true, 'null' => false],
            'mapel_id'           => ['type' => 'INT', 'unsigned' => true, 'null' => false],
            'tingkat'            => ['type' => 'VARCHAR', 'constraint' => 5, 'null' => false],
            'jenis_perangkat_id' => ['type' => 'INT', 'unsigned' => true, 'null' => false],
            'file'               => ['type' => 'VARCHAR', 'constraint' => 120, 'null' => true],
            'nama_file'          => ['type' => 'VARCHAR', 'constraint' => 150, 'null' => true],
            'tautan'             => ['type' => 'VARCHAR', 'constraint' => 255, 'null' => true],
            'sumber'             => ['type' => 'VARCHAR', 'constraint' => 10, 'null' => true],
            'catatan_guru'       => ['type' => 'TEXT', 'null' => true],
            'status'             => ['type' => 'VARCHAR', 'constraint' => 15, 'default' => 'Diajukan', 'null' => false],
            'versi'              => ['type' => 'SMALLINT', 'unsigned' => true, 'default' => 1, 'null' => false],
            'diajukan_at'        => ['type' => 'DATETIME', 'null' => true],
            'catatan_pemeriksa'  => ['type' => 'TEXT', 'null' => true],
            'diperiksa_oleh'     => ['type' => 'INT', 'unsigned' => true, 'null' => true],
            'diperiksa_at'       => ['type' => 'DATETIME', 'null' => true],
            'disahkan_oleh'      => ['type' => 'INT', 'unsigned' => true, 'null' => true],
            'disahkan_at'        => ['type' => 'DATETIME', 'null' => true],
            'created_at'         => ['type' => 'DATETIME', 'null' => true],
            'updated_at'         => ['type' => 'DATETIME', 'null' => true],
        ]);
        $this->forge->addPrimaryKey('id');
        $this->forge->addUniqueKey(['tahun_pelajaran_id', 'guru_id', 'mapel_id', 'tingkat', 'jenis_perangkat_id']);
        $this->forge->addKey('status');
        $this->forge->addForeignKey('tahun_pelajaran_id', 'tahun_pelajaran', 'id', 'CASCADE', 'CASCADE');
        $this->forge->addForeignKey('guru_id', 'guru', 'id', 'CASCADE', 'CASCADE');
        $this->forge->addForeignKey('mapel_id', 'mata_pelajaran', 'id', 'CASCADE', 'CASCADE');
        $this->forge->addForeignKey('jenis_perangkat_id', 'jenis_perangkat', 'id', 'CASCADE', 'CASCADE');
        $this->forge->createTable('perangkat_pembelajaran', true);

        // perangkat_riwayat
        $this->forge->addField([
            'id'                 => ['type' => 'INT', 'unsigned' => true, 'auto_increment' => true],
            'perangkat_id'       => ['type' => 'INT', 'unsigned' => true, 'null' => false],
            'aksi'               => ['type' => 'VARCHAR', 'constraint' => 20, 'null' => false],
            'versi'              => ['type' => 'SMALLINT', 'unsigned' => true, 'default' => 1, 'null' => false],
            'catatan'            => ['type' => 'TEXT', 'null' => true],
            'file'               => ['type' => 'VARCHAR', 'constraint' => 120, 'null' => true],
            'user_id'            => ['type' => 'INT', 'unsigned' => true, 'null' => true],
            'created_at'         => ['type' => 'DATETIME', 'null' => true],
        ]);
        $this->forge->addPrimaryKey('id');
        $this->forge->addKey('perangkat_id');
        $this->forge->addForeignKey('perangkat_id', 'perangkat_pembelajaran', 'id', 'CASCADE', 'CASCADE');
        $this->forge->createTable('perangkat_riwayat', true);

        // promes_item
        $this->forge->addField([
            'id'                 => ['type' => 'INT', 'unsigned' => true, 'auto_increment' => true],
            'tahun_pelajaran_id' => ['type' => 'INT', 'unsigned' => true, 'null' => false],
            'guru_id'            => ['type' => 'INT', 'unsigned' => true, 'null' => false],
            'mapel_id'           => ['type' => 'INT', 'unsigned' => true, 'null' => false],
            'tingkat'            => ['type' => 'VARCHAR', 'constraint' => 5, 'null' => false],
            'atp_id'             => ['type' => 'INT', 'unsigned' => true, 'null' => true],
            'jenis'              => ['type' => 'VARCHAR', 'constraint' => 10, 'default' => 'Materi', 'null' => false],
            'materi'             => ['type' => 'VARCHAR', 'constraint' => 255, 'null' => false],
            'tujuan'             => ['type' => 'TEXT', 'null' => true],
            'jp'                 => ['type' => 'SMALLINT', 'unsigned' => true, 'default' => 0, 'null' => false],
            'urutan'             => ['type' => 'SMALLINT', 'default' => 0, 'null' => false],
            'created_at'         => ['type' => 'DATETIME', 'null' => true],
            'updated_at'         => ['type' => 'DATETIME', 'null' => true],
        ]);
        $this->forge->addPrimaryKey('id');
        $this->forge->addKey(['tahun_pelajaran_id', 'guru_id', 'mapel_id', 'tingkat']);
        $this->forge->addForeignKey('tahun_pelajaran_id', 'tahun_pelajaran', 'id', 'CASCADE', 'CASCADE');
        $this->forge->addForeignKey('guru_id', 'guru', 'id', 'CASCADE', 'CASCADE');
        $this->forge->addForeignKey('mapel_id', 'mata_pelajaran', 'id', 'CASCADE', 'CASCADE');
        $this->forge->createTable('promes_item', true);

        // promes_alokasi
        $this->forge->addField([
            'id'                 => ['type' => 'INT', 'unsigned' => true, 'auto_increment' => true],
            'item_id'            => ['type' => 'INT', 'unsigned' => true, 'null' => false],
            'pekan'              => ['type' => 'DATE', 'null' => false],
            'jp'                 => ['type' => 'SMALLINT', 'unsigned' => true, 'default' => 0, 'null' => false],
        ]);
        $this->forge->addPrimaryKey('id');
        $this->forge->addUniqueKey(['item_id', 'pekan']);
        $this->forge->addForeignKey('item_id', 'promes_item', 'id', 'CASCADE', 'CASCADE');
        $this->forge->createTable('promes_alokasi', true);

        // modul_ajar
        $this->forge->addField([
            'id'                 => ['type' => 'INT', 'unsigned' => true, 'auto_increment' => true],
            'tahun_pelajaran_id' => ['type' => 'INT', 'unsigned' => true, 'null' => false],
            'guru_id'            => ['type' => 'INT', 'unsigned' => true, 'null' => false],
            'mapel_id'           => ['type' => 'INT', 'unsigned' => true, 'null' => false],
            'tingkat'            => ['type' => 'VARCHAR', 'constraint' => 5, 'null' => false],
            'promes_item_id'     => ['type' => 'INT', 'unsigned' => true, 'null' => true],
            'judul'              => ['type' => 'VARCHAR', 'constraint' => 200, 'null' => false],
            'format'             => ['type' => 'VARCHAR', 'constraint' => 10, 'default' => 'PM', 'null' => false],
            'jp'                 => ['type' => 'SMALLINT', 'unsigned' => true, 'default' => 0, 'null' => false],
            'pertemuan'          => ['type' => 'TINYINT', 'unsigned' => true, 'default' => 1, 'null' => false],
            'isi'                => ['type' => 'MEDIUMTEXT', 'null' => true],
            'urutan'             => ['type' => 'SMALLINT', 'default' => 0, 'null' => false],
            'created_at'         => ['type' => 'DATETIME', 'null' => true],
            'updated_at'         => ['type' => 'DATETIME', 'null' => true],
        ]);
        $this->forge->addPrimaryKey('id');
        $this->forge->addKey(['tahun_pelajaran_id', 'guru_id', 'mapel_id', 'tingkat']);
        $this->forge->addForeignKey('tahun_pelajaran_id', 'tahun_pelajaran', 'id', 'CASCADE', 'CASCADE');
        $this->forge->addForeignKey('guru_id', 'guru', 'id', 'CASCADE', 'CASCADE');
        $this->forge->addForeignKey('mapel_id', 'mata_pelajaran', 'id', 'CASCADE', 'CASCADE');
        $this->forge->createTable('modul_ajar', true);
    }

    public function down()
    {
        $this->db->disableForeignKeyChecks();
        $this->forge->dropTable('modul_ajar', true);
        $this->forge->dropTable('promes_alokasi', true);
        $this->forge->dropTable('promes_item', true);
        $this->forge->dropTable('perangkat_riwayat', true);
        $this->forge->dropTable('perangkat_pembelajaran', true);
        $this->forge->dropTable('jenis_perangkat', true);
        $this->db->enableForeignKeyChecks();
    }
}
