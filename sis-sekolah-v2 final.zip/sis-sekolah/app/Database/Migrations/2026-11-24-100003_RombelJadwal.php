<?php

namespace App\Database\Migrations;

use App\Database\MigrasiSis;

/**
 * Rombel, wali kelas, guru piket, penugasan mengajar, jadwal, dan kalender akademik.
 */
class RombelJadwal extends MigrasiSis
{
    public function up()
    {
        if ($this->sudahTerpasang()) {
            return;
        }
        // wali_kelas
        $this->forge->addField([
            'id'                 => ['type' => 'INT', 'unsigned' => true, 'auto_increment' => true],
            'tahun_pelajaran_id' => ['type' => 'INT', 'unsigned' => true, 'null' => false],
            'kelas_id'           => ['type' => 'INT', 'unsigned' => true, 'null' => false],
            'guru_id'            => ['type' => 'INT', 'unsigned' => true, 'null' => false],
            'created_at'         => ['type' => 'DATETIME', 'null' => true],
            'updated_at'         => ['type' => 'DATETIME', 'null' => true],
        ]);
        $this->forge->addPrimaryKey('id');
        $this->forge->addUniqueKey(['tahun_pelajaran_id', 'kelas_id']);
        $this->forge->addForeignKey('tahun_pelajaran_id', 'tahun_pelajaran', 'id', 'CASCADE', 'CASCADE');
        $this->forge->addForeignKey('kelas_id', 'kelas', 'id', 'CASCADE', 'CASCADE');
        $this->forge->addForeignKey('guru_id', 'guru', 'id', 'CASCADE', 'CASCADE');
        $this->forge->createTable('wali_kelas', true);

        // anggota_kelas
        $this->forge->addField([
            'id'                 => ['type' => 'INT', 'unsigned' => true, 'auto_increment' => true],
            'tahun_pelajaran_id' => ['type' => 'INT', 'unsigned' => true, 'null' => false],
            'kelas_id'           => ['type' => 'INT', 'unsigned' => true, 'null' => false],
            'siswa_id'           => ['type' => 'INT', 'unsigned' => true, 'null' => false],
            'no_absen'           => ['type' => 'SMALLINT', 'unsigned' => true, 'null' => true],
            'status'             => ['type' => 'ENUM', 'constraint' => ['Aktif', 'Naik Kelas', 'Tinggal Kelas', 'Lulus', 'Pindah'], 'default' => 'Aktif', 'null' => false],
            'created_at'         => ['type' => 'DATETIME', 'null' => true],
            'updated_at'         => ['type' => 'DATETIME', 'null' => true],
        ]);
        $this->forge->addPrimaryKey('id');
        $this->forge->addUniqueKey(['tahun_pelajaran_id', 'siswa_id']);
        $this->forge->addKey('kelas_id');
        $this->forge->addForeignKey('tahun_pelajaran_id', 'tahun_pelajaran', 'id', 'CASCADE', 'CASCADE');
        $this->forge->addForeignKey('kelas_id', 'kelas', 'id', 'CASCADE', 'CASCADE');
        $this->forge->addForeignKey('siswa_id', 'siswa', 'id', 'CASCADE', 'CASCADE');
        $this->forge->createTable('anggota_kelas', true);

        // guru_piket
        $this->forge->addField([
            'id'                 => ['type' => 'INT', 'unsigned' => true, 'auto_increment' => true],
            'tahun_pelajaran_id' => ['type' => 'INT', 'unsigned' => true, 'null' => false],
            'guru_id'            => ['type' => 'INT', 'unsigned' => true, 'null' => false],
            'hari'               => ['type' => 'TINYINT', 'unsigned' => true, 'null' => false],
            'created_at'         => ['type' => 'DATETIME', 'null' => true],
            'updated_at'         => ['type' => 'DATETIME', 'null' => true],
        ]);
        $this->forge->addPrimaryKey('id');
        $this->forge->addUniqueKey(['tahun_pelajaran_id', 'guru_id', 'hari']);
        $this->forge->addForeignKey('tahun_pelajaran_id', 'tahun_pelajaran', 'id', 'CASCADE', 'CASCADE');
        $this->forge->addForeignKey('guru_id', 'guru', 'id', 'CASCADE', 'CASCADE');
        $this->forge->createTable('guru_piket', true);

        // penugasan_guru
        $this->forge->addField([
            'id'                 => ['type' => 'INT', 'unsigned' => true, 'auto_increment' => true],
            'tahun_pelajaran_id' => ['type' => 'INT', 'unsigned' => true, 'null' => false],
            'guru_id'            => ['type' => 'INT', 'unsigned' => true, 'null' => false],
            'mapel_id'           => ['type' => 'INT', 'unsigned' => true, 'null' => false],
            'kelas_id'           => ['type' => 'INT', 'unsigned' => true, 'null' => false],
            'jp_per_minggu'      => ['type' => 'TINYINT', 'unsigned' => true, 'default' => 2, 'null' => false],
            'created_at'         => ['type' => 'DATETIME', 'null' => true],
            'updated_at'         => ['type' => 'DATETIME', 'null' => true],
        ]);
        $this->forge->addPrimaryKey('id');
        $this->forge->addUniqueKey(['tahun_pelajaran_id', 'mapel_id', 'kelas_id']);
        $this->forge->addKey('guru_id');
        $this->forge->addForeignKey('tahun_pelajaran_id', 'tahun_pelajaran', 'id', 'CASCADE', 'CASCADE');
        $this->forge->addForeignKey('guru_id', 'guru', 'id', 'CASCADE', 'CASCADE');
        $this->forge->addForeignKey('mapel_id', 'mata_pelajaran', 'id', 'CASCADE', 'CASCADE');
        $this->forge->addForeignKey('kelas_id', 'kelas', 'id', 'CASCADE', 'CASCADE');
        $this->forge->createTable('penugasan_guru', true);

        // jadwal_pelajaran
        $this->forge->addField([
            'id'                 => ['type' => 'INT', 'unsigned' => true, 'auto_increment' => true],
            'tahun_pelajaran_id' => ['type' => 'INT', 'unsigned' => true, 'null' => false],
            'penugasan_guru_id'  => ['type' => 'INT', 'unsigned' => true, 'null' => false],
            'kelas_id'           => ['type' => 'INT', 'unsigned' => true, 'null' => false],
            'hari'               => ['type' => 'TINYINT', 'unsigned' => true, 'null' => false],
            'jam_pelajaran_id'   => ['type' => 'INT', 'unsigned' => true, 'null' => false],
            'berlaku_mulai'      => ['type' => 'DATE', 'null' => true],
            'berlaku_sampai'     => ['type' => 'DATE', 'null' => true],
            'created_at'         => ['type' => 'DATETIME', 'null' => true],
            'updated_at'         => ['type' => 'DATETIME', 'null' => true],
        ]);
        $this->forge->addPrimaryKey('id');
        $this->forge->addKey('penugasan_guru_id');
        $this->forge->addKey(['tahun_pelajaran_id', 'kelas_id', 'hari']);
        $this->forge->addForeignKey('tahun_pelajaran_id', 'tahun_pelajaran', 'id', 'CASCADE', 'CASCADE');
        $this->forge->addForeignKey('penugasan_guru_id', 'penugasan_guru', 'id', 'CASCADE', 'CASCADE');
        $this->forge->addForeignKey('kelas_id', 'kelas', 'id', 'CASCADE', 'CASCADE');
        $this->forge->addForeignKey('jam_pelajaran_id', 'jam_pelajaran', 'id', 'CASCADE', 'CASCADE');
        $this->forge->createTable('jadwal_pelajaran', true);

        // kalender_akademik
        $this->forge->addField([
            'id'                 => ['type' => 'INT', 'unsigned' => true, 'auto_increment' => true],
            'tahun_pelajaran_id' => ['type' => 'INT', 'unsigned' => true, 'null' => false],
            'tanggal_mulai'      => ['type' => 'DATE', 'null' => false],
            'tanggal_selesai'    => ['type' => 'DATE', 'null' => false],
            'jenis'              => ['type' => 'VARCHAR', 'constraint' => 30, 'null' => false],
            'nama'               => ['type' => 'VARCHAR', 'constraint' => 150, 'null' => false],
            'kelas_ids'          => ['type' => 'VARCHAR', 'constraint' => 500, 'null' => true],
            'hari_jadwal'        => ['type' => 'TINYINT', 'unsigned' => true, 'null' => true],
            'keterangan'         => ['type' => 'TEXT', 'null' => true],
            'ada_kbm'            => ['type' => 'TINYINT', 'constraint' => 1, 'default' => 0, 'null' => false],
            'ada_absensi'        => ['type' => 'TINYINT', 'constraint' => 1, 'default' => 0, 'null' => false],
            'created_at'         => ['type' => 'DATETIME', 'null' => true],
            'updated_at'         => ['type' => 'DATETIME', 'null' => true],
        ]);
        $this->forge->addPrimaryKey('id');
        $this->forge->addKey(['tanggal_mulai', 'tanggal_selesai']);
        $this->forge->addForeignKey('tahun_pelajaran_id', 'tahun_pelajaran', 'id', 'CASCADE', 'CASCADE');
        $this->forge->createTable('kalender_akademik', true);
    }

    public function down()
    {
        $this->db->disableForeignKeyChecks();
        $this->forge->dropTable('kalender_akademik', true);
        $this->forge->dropTable('jadwal_pelajaran', true);
        $this->forge->dropTable('penugasan_guru', true);
        $this->forge->dropTable('guru_piket', true);
        $this->forge->dropTable('anggota_kelas', true);
        $this->forge->dropTable('wali_kelas', true);
        $this->db->enableForeignKeyChecks();
    }
}
