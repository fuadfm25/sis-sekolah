<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

/**
 * Waktu berlaku kegiatan pembiasaan: setiap hari, hanya hari masuk sekolah, atau hanya hari libur.
 * Contoh: bangun pagi, tidur awal, belajar di rumah → "hari masuk sekolah".
 */
class PembiasaanBerlaku extends Migration
{
    public function up()
    {
        $this->forge->addColumn('pembiasaan', [
            'berlaku' => ['type' => 'VARCHAR', 'constraint' => 10, 'default' => 'Semua', 'null' => false, 'after' => 'tempat'],   // Semua / Sekolah / Libur
        ]);
    }

    public function down()
    {
        $this->forge->dropColumn('pembiasaan', 'berlaku');
    }
}
