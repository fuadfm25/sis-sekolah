<?php

namespace App\Database\Migrations;

use App\Database\MigrasiSis;

/**
 * Layanan BK (Permendikbud 111/2014) dan pesertanya.
 */
class BimbinganKonseling extends MigrasiSis
{
    public function up()
    {
        if ($this->sudahTerpasang()) {
            return;
        }
        // bk_layanan
        $this->forge->addField([
            'id'                    => ['type' => 'INT', 'unsigned' => true, 'auto_increment' => true],
            'tahun_pelajaran_id'    => ['type' => 'INT', 'unsigned' => true, 'null' => false],
            'tanggal'               => ['type' => 'DATE', 'null' => false],
            'jenis_layanan'         => ['type' => 'VARCHAR', 'constraint' => 50, 'null' => false],
            'komponen'              => ['type' => 'VARCHAR', 'constraint' => 40, 'null' => true],
            'format'                => ['type' => 'VARCHAR', 'constraint' => 20, 'null' => true],
            'media'                 => ['type' => 'VARCHAR', 'constraint' => 20, 'null' => true],
            'bidang'                => ['type' => 'ENUM', 'constraint' => ['Pribadi', 'Sosial', 'Belajar', 'Karier'], 'null' => false],
            'kelas_id'              => ['type' => 'INT', 'unsigned' => true, 'null' => true],
            'pihak_terkait'         => ['type' => 'VARCHAR', 'constraint' => 150, 'null' => true],
            'catatan_perilaku_id'   => ['type' => 'INT', 'unsigned' => true, 'null' => true],
            'topik'                 => ['type' => 'VARCHAR', 'constraint' => 200, 'null' => false],
            'permasalahan'          => ['type' => 'TEXT', 'null' => true],
            'penanganan'            => ['type' => 'TEXT', 'null' => true],
            'hasil'                 => ['type' => 'TEXT', 'null' => true],
            'rencana_tindak_lanjut' => ['type' => 'TEXT', 'null' => true],
            'status'                => ['type' => 'ENUM', 'constraint' => ['Dijadwalkan', 'Berlangsung', 'Selesai'], 'default' => 'Dijadwalkan', 'null' => false],
            'is_rahasia'            => ['type' => 'TINYINT', 'constraint' => 1, 'default' => 1, 'null' => false],
            'konselor_id'           => ['type' => 'INT', 'unsigned' => true, 'null' => true],
            'created_at'            => ['type' => 'DATETIME', 'null' => true],
            'updated_at'            => ['type' => 'DATETIME', 'null' => true],
        ]);
        $this->forge->addPrimaryKey('id');
        $this->forge->addKey('tanggal');
        $this->forge->addForeignKey('tahun_pelajaran_id', 'tahun_pelajaran', 'id', 'CASCADE', 'CASCADE');
        $this->forge->addForeignKey('kelas_id', 'kelas', 'id', 'CASCADE', 'SET NULL');
        $this->forge->addForeignKey('catatan_perilaku_id', 'catatan_perilaku', 'id', 'CASCADE', 'SET NULL');
        $this->forge->addForeignKey('konselor_id', 'users', 'id', 'CASCADE', 'SET NULL');
        $this->forge->createTable('bk_layanan', true);

        // bk_peserta
        $this->forge->addField([
            'id'                    => ['type' => 'INT', 'unsigned' => true, 'auto_increment' => true],
            'layanan_id'            => ['type' => 'INT', 'unsigned' => true, 'null' => false],
            'siswa_id'              => ['type' => 'INT', 'unsigned' => true, 'null' => false],
        ]);
        $this->forge->addPrimaryKey('id');
        $this->forge->addUniqueKey(['layanan_id', 'siswa_id']);
        $this->forge->addForeignKey('layanan_id', 'bk_layanan', 'id', 'CASCADE', 'CASCADE');
        $this->forge->addForeignKey('siswa_id', 'siswa', 'id', 'CASCADE', 'CASCADE');
        $this->forge->createTable('bk_peserta', true);
    }

    public function down()
    {
        $this->db->disableForeignKeyChecks();
        $this->forge->dropTable('bk_peserta', true);
        $this->forge->dropTable('bk_layanan', true);
        $this->db->enableForeignKeyChecks();
    }
}
