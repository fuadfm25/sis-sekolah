<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

/**
 * Pembiasaan yang bisa diisi siswa sendiri lewat portal (diatur kesiswaan per kegiatan),
 * dengan verifikasi wali kelas. Kolom "terlaksana" tetap berisi nilai yang sudah sah (diverifikasi/dicatat guru),
 * laporan siswa disimpan terpisah di "lapor_siswa".
 */
class PembiasaanMandiri extends Migration
{
    public function up()
    {
        $this->forge->addColumn('pembiasaan', [
            'pengisi'          => ['type' => 'VARCHAR', 'constraint' => 10, 'default' => 'Guru', 'null' => false, 'after' => 'hari'],     // Guru / Siswa / Keduanya
            'tempat'           => ['type' => 'VARCHAR', 'constraint' => 10, 'default' => 'Sekolah', 'null' => false, 'after' => 'pengisi'], // Sekolah / Rumah
            'perlu_verifikasi' => ['type' => 'TINYINT', 'constraint' => 1, 'default' => 1, 'null' => false, 'after' => 'tempat'],
            'wajib_catatan'    => ['type' => 'TINYINT', 'constraint' => 1, 'default' => 0, 'null' => false, 'after' => 'perlu_verifikasi'],
            'petunjuk_catatan' => ['type' => 'VARCHAR', 'constraint' => 100, 'null' => true, 'after' => 'wajib_catatan'],
            'tingkat'          => ['type' => 'VARCHAR', 'constraint' => 60, 'null' => true, 'after' => 'petunjuk_catatan'],              // csv; kosong = semua tingkat
        ]);
        $this->forge->addColumn('pembiasaan_siswa', [
            'sumber'           => ['type' => 'VARCHAR', 'constraint' => 10, 'default' => 'Guru', 'null' => false, 'after' => 'keterangan'], // Guru / Siswa
            'lapor_siswa'      => ['type' => 'TINYINT', 'constraint' => 1, 'null' => true, 'after' => 'sumber'],
            'lapor_at'         => ['type' => 'DATETIME', 'null' => true, 'after' => 'lapor_siswa'],
            'verifikasi'       => ['type' => 'VARCHAR', 'constraint' => 10, 'default' => 'Disetujui', 'null' => false, 'after' => 'lapor_at'], // Menunggu / Disetujui / Ditolak
            'diverifikasi_oleh' => ['type' => 'INT', 'unsigned' => true, 'null' => true, 'after' => 'verifikasi'],
            'diverifikasi_at'  => ['type' => 'DATETIME', 'null' => true, 'after' => 'diverifikasi_oleh'],
        ]);
        if ($this->db->tableExists('pengaturan') && ! $this->db->table('pengaturan')->where('kunci', 'pembiasaan_mundur')->countAllResults()) {
            $this->db->table('pengaturan')->insert(['kunci' => 'pembiasaan_mundur', 'nilai' => '1', 'label' => 'Siswa boleh mengisi pembiasaan sampai N hari ke belakang']);
        }
    }

    public function down()
    {
        $this->forge->dropColumn('pembiasaan_siswa', ['sumber', 'lapor_siswa', 'lapor_at', 'verifikasi', 'diverifikasi_oleh', 'diverifikasi_at']);
        $this->forge->dropColumn('pembiasaan', ['pengisi', 'tempat', 'perlu_verifikasi', 'wajib_catatan', 'petunjuk_catatan', 'tingkat']);
    }
}
