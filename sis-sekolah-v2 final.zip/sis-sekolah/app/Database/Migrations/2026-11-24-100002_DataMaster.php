<?php

namespace App\Database\Migrations;

use App\Database\MigrasiSis;

/**
 * Data master: tahun pelajaran, jurusan, kelas, guru, siswa, mata pelajaran, jam pelajaran.
 */
class DataMaster extends MigrasiSis
{
    public function up()
    {
        if ($this->sudahTerpasang()) {
            return;
        }
        // tahun_pelajaran
        $this->forge->addField([
            'id'                 => ['type' => 'INT', 'unsigned' => true, 'auto_increment' => true],
            'tahun_pelajaran'    => ['type' => 'VARCHAR', 'constraint' => 20, 'null' => false],
            'semester'           => ['type' => 'ENUM', 'constraint' => ['Ganjil', 'Genap'], 'default' => 'Ganjil', 'null' => false],
            'tanggal_mulai'      => ['type' => 'DATE', 'null' => true],
            'tanggal_selesai'    => ['type' => 'DATE', 'null' => true],
            'is_active'          => ['type' => 'TINYINT', 'constraint' => 1, 'default' => 0, 'null' => false],
            'created_at'         => ['type' => 'DATETIME', 'null' => true],
            'updated_at'         => ['type' => 'DATETIME', 'null' => true],
        ]);
        $this->forge->addPrimaryKey('id');
        $this->forge->addUniqueKey(['tahun_pelajaran', 'semester']);
        $this->forge->createTable('tahun_pelajaran', true);

        // jurusan
        $this->forge->addField([
            'id'                 => ['type' => 'INT', 'unsigned' => true, 'auto_increment' => true],
            'kode_jurusan'       => ['type' => 'VARCHAR', 'constraint' => 20, 'null' => false],
            'nama_jurusan'       => ['type' => 'VARCHAR', 'constraint' => 100, 'null' => false],
            'created_at'         => ['type' => 'DATETIME', 'null' => true],
            'updated_at'         => ['type' => 'DATETIME', 'null' => true],
        ]);
        $this->forge->addPrimaryKey('id');
        $this->forge->addUniqueKey('kode_jurusan');
        $this->forge->createTable('jurusan', true);

        // kelas
        $this->forge->addField([
            'id'                 => ['type' => 'INT', 'unsigned' => true, 'auto_increment' => true],
            'tingkat'            => ['type' => 'VARCHAR', 'constraint' => 5, 'null' => false],
            'nama_kelas'         => ['type' => 'VARCHAR', 'constraint' => 50, 'null' => false],
            'jurusan_id'         => ['type' => 'INT', 'unsigned' => true, 'null' => true],
            'is_active'          => ['type' => 'TINYINT', 'constraint' => 1, 'default' => 1, 'null' => false],
            'created_at'         => ['type' => 'DATETIME', 'null' => true],
            'updated_at'         => ['type' => 'DATETIME', 'null' => true],
        ]);
        $this->forge->addPrimaryKey('id');
        $this->forge->addUniqueKey('nama_kelas');
        $this->forge->addForeignKey('jurusan_id', 'jurusan', 'id', 'CASCADE', 'SET NULL');
        $this->forge->createTable('kelas', true);

        // guru
        $this->forge->addField([
            'id'                 => ['type' => 'INT', 'unsigned' => true, 'auto_increment' => true],
            'user_id'            => ['type' => 'INT', 'unsigned' => true, 'null' => true],
            'nip'                => ['type' => 'VARCHAR', 'constraint' => 30, 'null' => true],
            'nuptk'              => ['type' => 'VARCHAR', 'constraint' => 30, 'null' => true],
            'rfid'               => ['type' => 'VARCHAR', 'constraint' => 50, 'null' => true],
            'nama_lengkap'       => ['type' => 'VARCHAR', 'constraint' => 100, 'null' => false],
            'gelar_depan'        => ['type' => 'VARCHAR', 'constraint' => 20, 'null' => true],
            'gelar_belakang'     => ['type' => 'VARCHAR', 'constraint' => 50, 'null' => true],
            'jenis_kelamin'      => ['type' => 'ENUM', 'constraint' => ['L', 'P'], 'null' => false],
            'no_hp'              => ['type' => 'VARCHAR', 'constraint' => 20, 'null' => true],
            'email'              => ['type' => 'VARCHAR', 'constraint' => 100, 'null' => true],
            'status_kepegawaian' => ['type' => 'ENUM', 'constraint' => ['PNS', 'PPPK', 'GTY', 'GTT', 'Honorer'], 'default' => 'Honorer', 'null' => false],
            'is_active'          => ['type' => 'TINYINT', 'constraint' => 1, 'default' => 1, 'null' => false],
            'created_at'         => ['type' => 'DATETIME', 'null' => true],
            'updated_at'         => ['type' => 'DATETIME', 'null' => true],
        ]);
        $this->forge->addPrimaryKey('id');
        $this->forge->addUniqueKey('user_id');
        $this->forge->addUniqueKey('rfid');
        $this->forge->addForeignKey('user_id', 'users', 'id', 'CASCADE', 'SET NULL');
        $this->forge->createTable('guru', true);

        // siswa
        $this->forge->addField([
            'id'                 => ['type' => 'INT', 'unsigned' => true, 'auto_increment' => true],
            'nis'                => ['type' => 'VARCHAR', 'constraint' => 20, 'null' => false],
            'nisn'               => ['type' => 'VARCHAR', 'constraint' => 20, 'null' => true],
            'rfid'               => ['type' => 'VARCHAR', 'constraint' => 50, 'null' => true],
            'password'           => ['type' => 'VARCHAR', 'constraint' => 255, 'null' => true],
            'login_terakhir'     => ['type' => 'DATETIME', 'null' => true],
            'nama_lengkap'       => ['type' => 'VARCHAR', 'constraint' => 100, 'null' => false],
            'jenis_kelamin'      => ['type' => 'ENUM', 'constraint' => ['L', 'P'], 'null' => false],
            'tempat_lahir'       => ['type' => 'VARCHAR', 'constraint' => 50, 'null' => true],
            'tanggal_lahir'      => ['type' => 'DATE', 'null' => true],
            'agama'              => ['type' => 'VARCHAR', 'constraint' => 20, 'null' => true],
            'alamat'             => ['type' => 'TEXT', 'null' => true],
            'nama_wali'          => ['type' => 'VARCHAR', 'constraint' => 100, 'null' => true],
            'no_hp_wali'         => ['type' => 'VARCHAR', 'constraint' => 20, 'null' => true],
            'status'             => ['type' => 'ENUM', 'constraint' => ['Aktif', 'Lulus', 'Pindah', 'Keluar'], 'default' => 'Aktif', 'null' => false],
            'created_at'         => ['type' => 'DATETIME', 'null' => true],
            'updated_at'         => ['type' => 'DATETIME', 'null' => true],
        ]);
        $this->forge->addPrimaryKey('id');
        $this->forge->addUniqueKey('nis');
        $this->forge->addUniqueKey('rfid');
        $this->forge->createTable('siswa', true);

        // mata_pelajaran
        $this->forge->addField([
            'id'                 => ['type' => 'INT', 'unsigned' => true, 'auto_increment' => true],
            'kode_mapel'         => ['type' => 'VARCHAR', 'constraint' => 20, 'null' => false],
            'nama_mapel'         => ['type' => 'VARCHAR', 'constraint' => 100, 'null' => false],
            'kelompok'           => ['type' => 'VARCHAR', 'constraint' => 50, 'null' => true],
            'is_active'          => ['type' => 'TINYINT', 'constraint' => 1, 'default' => 1, 'null' => false],
            'created_at'         => ['type' => 'DATETIME', 'null' => true],
            'updated_at'         => ['type' => 'DATETIME', 'null' => true],
        ]);
        $this->forge->addPrimaryKey('id');
        $this->forge->addUniqueKey('kode_mapel');
        $this->forge->createTable('mata_pelajaran', true);

        // jam_pelajaran
        $this->forge->addField([
            'id'                 => ['type' => 'INT', 'unsigned' => true, 'auto_increment' => true],
            'hari'               => ['type' => 'TINYINT', 'unsigned' => true, 'null' => true],
            'jam_ke'             => ['type' => 'TINYINT', 'unsigned' => true, 'null' => false],
            'jam_mulai'          => ['type' => 'TIME', 'null' => false],
            'jam_selesai'        => ['type' => 'TIME', 'null' => false],
            'is_kbm'             => ['type' => 'TINYINT', 'constraint' => 1, 'default' => 1, 'null' => false],
            'keterangan'         => ['type' => 'VARCHAR', 'constraint' => 50, 'null' => true],
            'created_at'         => ['type' => 'DATETIME', 'null' => true],
            'updated_at'         => ['type' => 'DATETIME', 'null' => true],
        ]);
        $this->forge->addPrimaryKey('id');
        $this->forge->createTable('jam_pelajaran', true);
    }

    public function down()
    {
        $this->db->disableForeignKeyChecks();
        $this->forge->dropTable('jam_pelajaran', true);
        $this->forge->dropTable('mata_pelajaran', true);
        $this->forge->dropTable('siswa', true);
        $this->forge->dropTable('guru', true);
        $this->forge->dropTable('kelas', true);
        $this->forge->dropTable('jurusan', true);
        $this->forge->dropTable('tahun_pelajaran', true);
        $this->db->enableForeignKeyChecks();
    }
}
