<?php

namespace App\Database\Migrations;

use App\Database\MigrasiSis;

/**
 * Pengguna, role, pengaturan sekolah, dan log aktivitas.
 */
class PenggunaSistem extends MigrasiSis
{
    public function up()
    {
        if ($this->sudahTerpasang()) {
            return;
        }
        // users
        $this->forge->addField([
            'id'                   => ['type' => 'INT', 'unsigned' => true, 'auto_increment' => true],
            'username'             => ['type' => 'VARCHAR', 'constraint' => 50, 'null' => false],
            'password'             => ['type' => 'VARCHAR', 'constraint' => 255, 'null' => false],
            'nama_lengkap'         => ['type' => 'VARCHAR', 'constraint' => 100, 'null' => false],
            'email'                => ['type' => 'VARCHAR', 'constraint' => 100, 'null' => true],
            'is_active'            => ['type' => 'TINYINT', 'constraint' => 1, 'default' => 1, 'null' => false],
            'wajib_ganti_password' => ['type' => 'TINYINT', 'constraint' => 1, 'default' => 0, 'null' => false],
            'password_sendiri_at'  => ['type' => 'DATETIME', 'null' => true],
            'last_login'           => ['type' => 'DATETIME', 'null' => true],
            'created_at'           => ['type' => 'DATETIME', 'null' => true],
            'updated_at'           => ['type' => 'DATETIME', 'null' => true],
        ]);
        $this->forge->addPrimaryKey('id');
        $this->forge->addUniqueKey('username');
        $this->forge->createTable('users', true);

        // roles
        $this->forge->addField([
            'id'                   => ['type' => 'INT', 'unsigned' => true, 'auto_increment' => true],
            'nama_role'            => ['type' => 'VARCHAR', 'constraint' => 50, 'null' => false],
            'keterangan'           => ['type' => 'VARCHAR', 'constraint' => 100, 'null' => true],
        ]);
        $this->forge->addPrimaryKey('id');
        $this->forge->addUniqueKey('nama_role');
        $this->forge->createTable('roles', true);

        // user_roles
        $this->forge->addField([
            'user_id'              => ['type' => 'INT', 'unsigned' => true, 'null' => false],
            'role_id'              => ['type' => 'INT', 'unsigned' => true, 'null' => false],
        ]);
        $this->forge->addPrimaryKey(['user_id', 'role_id']);
        $this->forge->addForeignKey('user_id', 'users', 'id', 'CASCADE', 'CASCADE');
        $this->forge->addForeignKey('role_id', 'roles', 'id', 'CASCADE', 'CASCADE');
        $this->forge->createTable('user_roles', true);

        // pengaturan
        $this->forge->addField([
            'id'                   => ['type' => 'INT', 'unsigned' => true, 'auto_increment' => true],
            'kunci'                => ['type' => 'VARCHAR', 'constraint' => 60, 'null' => false],
            'nilai'                => ['type' => 'TEXT', 'null' => true],
            'label'                => ['type' => 'VARCHAR', 'constraint' => 100, 'null' => true],
            'updated_at'           => ['type' => 'DATETIME', 'null' => true],
        ]);
        $this->forge->addPrimaryKey('id');
        $this->forge->addUniqueKey('kunci');
        $this->forge->createTable('pengaturan', true);

        // log_aktivitas
        $this->forge->addField([
            'id'                   => ['type' => 'INT', 'unsigned' => true, 'auto_increment' => true],
            'user_id'              => ['type' => 'INT', 'unsigned' => true, 'null' => true],
            'nama_user'            => ['type' => 'VARCHAR', 'constraint' => 100, 'null' => true],
            'aksi'                 => ['type' => 'VARCHAR', 'constraint' => 30, 'null' => false],
            'objek'                => ['type' => 'VARCHAR', 'constraint' => 60, 'null' => true],
            'objek_id'             => ['type' => 'INT', 'unsigned' => true, 'null' => true],
            'keterangan'           => ['type' => 'TEXT', 'null' => true],
            'ip'                   => ['type' => 'VARCHAR', 'constraint' => 45, 'null' => true],
            'created_at'           => ['type' => 'DATETIME', 'null' => true],
        ]);
        $this->forge->addPrimaryKey('id');
        $this->forge->addKey('created_at');
        $this->forge->addKey(['objek', 'objek_id']);
        $this->forge->createTable('log_aktivitas', true);
    }

    public function down()
    {
        $this->db->disableForeignKeyChecks();
        $this->forge->dropTable('log_aktivitas', true);
        $this->forge->dropTable('pengaturan', true);
        $this->forge->dropTable('user_roles', true);
        $this->forge->dropTable('roles', true);
        $this->forge->dropTable('users', true);
        $this->db->enableForeignKeyChecks();
    }
}
