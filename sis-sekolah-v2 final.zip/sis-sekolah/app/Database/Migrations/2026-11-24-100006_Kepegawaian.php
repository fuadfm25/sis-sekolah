<?php

namespace App\Database\Migrations;

use App\Database\MigrasiSis;

/**
 * Izin dan kehadiran guru.
 */
class Kepegawaian extends MigrasiSis
{
    public function up()
    {
        if ($this->sudahTerpasang()) {
            return;
        }
        // izin_guru
        $this->forge->addField([
            'id'                 => ['type' => 'INT', 'unsigned' => true, 'auto_increment' => true],
            'guru_id'            => ['type' => 'INT', 'unsigned' => true, 'null' => false],
            'tanggal_mulai'      => ['type' => 'DATE', 'null' => false],
            'tanggal_selesai'    => ['type' => 'DATE', 'null' => false],
            'jenis'              => ['type' => 'VARCHAR', 'constraint' => 2, 'null' => false],
            'keterangan'         => ['type' => 'TEXT', 'null' => true],
            'tugas_siswa'        => ['type' => 'TEXT', 'null' => true],
            'lampiran'           => ['type' => 'VARCHAR', 'constraint' => 100, 'null' => true],
            'status'             => ['type' => 'VARCHAR', 'constraint' => 12, 'default' => 'Diajukan', 'null' => false],
            'diputus_oleh'       => ['type' => 'INT', 'unsigned' => true, 'null' => true],
            'catatan_putusan'    => ['type' => 'VARCHAR', 'constraint' => 255, 'null' => true],
            'created_at'         => ['type' => 'DATETIME', 'null' => true],
            'updated_at'         => ['type' => 'DATETIME', 'null' => true],
        ]);
        $this->forge->addPrimaryKey('id');
        $this->forge->addKey(['guru_id', 'tanggal_mulai']);
        $this->forge->addForeignKey('guru_id', 'guru', 'id', 'CASCADE', 'CASCADE');
        $this->forge->createTable('izin_guru', true);

        // presensi_guru
        $this->forge->addField([
            'id'                 => ['type' => 'INT', 'unsigned' => true, 'auto_increment' => true],
            'tahun_pelajaran_id' => ['type' => 'INT', 'unsigned' => true, 'null' => false],
            'guru_id'            => ['type' => 'INT', 'unsigned' => true, 'null' => false],
            'tanggal'            => ['type' => 'DATE', 'null' => false],
            'status'             => ['type' => 'VARCHAR', 'constraint' => 2, 'default' => 'H', 'null' => false],
            'jam_datang'         => ['type' => 'TIME', 'null' => true],
            'jam_pulang'         => ['type' => 'TIME', 'null' => true],
            'keterangan'         => ['type' => 'VARCHAR', 'constraint' => 150, 'null' => true],
            'izin_guru_id'       => ['type' => 'INT', 'unsigned' => true, 'null' => true],
            'sumber'             => ['type' => 'VARCHAR', 'constraint' => 10, 'default' => 'Manual', 'null' => false],
            'dicatat_oleh'       => ['type' => 'INT', 'unsigned' => true, 'null' => true],
            'created_at'         => ['type' => 'DATETIME', 'null' => true],
            'updated_at'         => ['type' => 'DATETIME', 'null' => true],
        ]);
        $this->forge->addPrimaryKey('id');
        $this->forge->addUniqueKey(['tanggal', 'guru_id']);
        $this->forge->addForeignKey('tahun_pelajaran_id', 'tahun_pelajaran', 'id', 'CASCADE', 'CASCADE');
        $this->forge->addForeignKey('guru_id', 'guru', 'id', 'CASCADE', 'CASCADE');
        $this->forge->addForeignKey('izin_guru_id', 'izin_guru', 'id', 'CASCADE', 'SET NULL');
        $this->forge->createTable('presensi_guru', true);
    }

    public function down()
    {
        $this->db->disableForeignKeyChecks();
        $this->forge->dropTable('presensi_guru', true);
        $this->forge->dropTable('izin_guru', true);
        $this->db->enableForeignKeyChecks();
    }
}
