<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;
use RuntimeException;

/**
 * Pemeriksaan sebelum migration lain dijalankan (berkas ini sengaja bertanggal paling awal).
 *
 * 1. Berkas migration versi lama (2026-11-23-0000xx / 2026-11-24-0000xx) masih ada di folder Migrations.
 *    Ini terjadi bila zip versi baru diekstrak menimpa folder lama: berkas lama tidak ikut terhapus,
 *    lalu dijalankan bersama berkas baru dan bentrok.
 * 2. Database tujuan sudah berisi tabel dari aplikasi lain / impor lain, padahal belum pernah dipasang
 *    lewat migration SIS Sekolah.
 */
class PeriksaPemasangan extends Migration
{
    private const TABEL_INTI = ['users', 'roles', 'siswa', 'guru', 'kelas', 'rombel', 'tahun_pelajaran'];

    public function up()
    {
        $folder = APPPATH . 'Database' . DIRECTORY_SEPARATOR . 'Migrations' . DIRECTORY_SEPARATOR;
        $lama   = array_merge(glob($folder . '2026-11-23-0000*.php') ?: [], glob($folder . '2026-11-24-0000*.php') ?: []);
        if ($lama) {
            throw new RuntimeException(
                "Masih ada " . count($lama) . " berkas migration versi lama di app/Database/Migrations "
                . "(nama berawalan 2026-11-23-0000 dan 2026-11-24-0000), contohnya " . basename($lama[0]) . ".\n"
                . "Hapus berkas-berkas itu (yang dipakai hanya 2026-11-22-000000 dan 2026-11-24-1000xx), "
                . "atau hapus seluruh folder app/Database/Migrations lalu ekstrak ulang dari zip. "
                . "Setelah itu jalankan lagi \"php spark migrate\"."
            );
        }

        $sudahAda = array_values(array_filter(self::TABEL_INTI, fn ($t) => $this->db->tableExists($t)));
        if ($sudahAda && ! $this->pernahDipasang()) {
            throw new RuntimeException(
                'Database "' . $this->db->getDatabase() . '" sudah berisi tabel (' . implode(', ', $sudahAda) . ') '
                . "yang tidak dibuat oleh migration SIS Sekolah, sehingga struktur tabel bisa tidak cocok.\n"
                . 'Gunakan database kosong: buat database baru (atau DROP lalu CREATE ulang database ini bila isinya '
                . 'tidak diperlukan), sesuaikan nama database di .env bila perlu, lalu jalankan lagi "php spark migrate".'
            );
        }
    }

    public function down()
    {
        // tidak mengubah apa pun
    }

    /** Ada catatan migration SIS Sekolah (lama atau baru) selain berkas ini sendiri. */
    private function pernahDipasang(): bool
    {
        if (! $this->db->tableExists('migrations')) {
            return false;
        }

        return $this->db->table('migrations')
            ->groupStart()->like('version', '2026-11-23-', 'after')->orLike('version', '2026-11-24-', 'after')->groupEnd()
            ->countAllResults() > 0;
    }
}
