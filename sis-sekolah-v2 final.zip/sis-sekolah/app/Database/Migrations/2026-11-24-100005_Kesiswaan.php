<?php

namespace App\Database\Migrations;

use App\Database\MigrasiSis;

/**
 * Absensi pagi, izin siswa (termasuk izin keluar/satpam), pembiasaan, catatan perilaku, mutasi.
 */
class Kesiswaan extends MigrasiSis
{
    public function up()
    {
        if ($this->sudahTerpasang()) {
            return;
        }
        // izin_siswa
        $this->forge->addField([
            'id'                  => ['type' => 'INT', 'unsigned' => true, 'auto_increment' => true],
            'siswa_id'            => ['type' => 'INT', 'unsigned' => true, 'null' => false],
            'tanggal_mulai'       => ['type' => 'DATE', 'null' => false],
            'tanggal_selesai'     => ['type' => 'DATE', 'null' => false],
            'jenis'               => ['type' => 'VARCHAR', 'constraint' => 1, 'null' => false],
            'jam_keluar'          => ['type' => 'TIME', 'null' => true],
            'penjemput'           => ['type' => 'VARCHAR', 'constraint' => 100, 'null' => true],
            'batas_kembali'       => ['type' => 'TIME', 'null' => true],
            'keluar_at'           => ['type' => 'DATETIME', 'null' => true],
            'keluar_oleh'         => ['type' => 'INT', 'unsigned' => true, 'null' => true],
            'kembali_at'          => ['type' => 'DATETIME', 'null' => true],
            'kembali_oleh'        => ['type' => 'INT', 'unsigned' => true, 'null' => true],
            'status_keluar'       => ['type' => 'VARCHAR', 'constraint' => 20, 'null' => true],
            'catatan_perilaku_id' => ['type' => 'INT', 'unsigned' => true, 'null' => true],
            'keterangan'          => ['type' => 'VARCHAR', 'constraint' => 255, 'null' => true],
            'lampiran'            => ['type' => 'VARCHAR', 'constraint' => 100, 'null' => true],
            'dicatat_oleh'        => ['type' => 'INT', 'unsigned' => true, 'null' => true],
            'created_at'          => ['type' => 'DATETIME', 'null' => true],
            'updated_at'          => ['type' => 'DATETIME', 'null' => true],
        ]);
        $this->forge->addPrimaryKey('id');
        $this->forge->addKey(['siswa_id', 'tanggal_mulai']);
        $this->forge->addForeignKey('siswa_id', 'siswa', 'id', 'CASCADE', 'CASCADE');
        $this->forge->createTable('izin_siswa', true);

        // presensi_harian
        $this->forge->addField([
            'id'                  => ['type' => 'INT', 'unsigned' => true, 'auto_increment' => true],
            'tahun_pelajaran_id'  => ['type' => 'INT', 'unsigned' => true, 'null' => false],
            'kelas_id'            => ['type' => 'INT', 'unsigned' => true, 'null' => false],
            'siswa_id'            => ['type' => 'INT', 'unsigned' => true, 'null' => false],
            'tanggal'             => ['type' => 'DATE', 'null' => false],
            'status'              => ['type' => 'ENUM', 'constraint' => ['H', 'T', 'S', 'I', 'A'], 'default' => 'H', 'null' => false],
            'jam_datang'          => ['type' => 'TIME', 'null' => true],
            'jam_pulang'          => ['type' => 'TIME', 'null' => true],
            'keterangan'          => ['type' => 'VARCHAR', 'constraint' => 150, 'null' => true],
            'izin_siswa_id'       => ['type' => 'INT', 'unsigned' => true, 'null' => true],
            'sumber'              => ['type' => 'VARCHAR', 'constraint' => 10, 'default' => 'Manual', 'null' => false],
            'dicatat_oleh'        => ['type' => 'INT', 'unsigned' => true, 'null' => true],
            'created_at'          => ['type' => 'DATETIME', 'null' => true],
            'updated_at'          => ['type' => 'DATETIME', 'null' => true],
        ]);
        $this->forge->addPrimaryKey('id');
        $this->forge->addUniqueKey(['tanggal', 'siswa_id']);
        $this->forge->addKey(['kelas_id', 'tanggal']);
        $this->forge->addForeignKey('tahun_pelajaran_id', 'tahun_pelajaran', 'id', 'CASCADE', 'CASCADE');
        $this->forge->addForeignKey('kelas_id', 'kelas', 'id', 'CASCADE', 'CASCADE');
        $this->forge->addForeignKey('siswa_id', 'siswa', 'id', 'CASCADE', 'CASCADE');
        $this->forge->addForeignKey('dicatat_oleh', 'users', 'id', 'CASCADE', 'SET NULL');
        $this->forge->createTable('presensi_harian', true);

        // pembiasaan
        $this->forge->addField([
            'id'                  => ['type' => 'INT', 'unsigned' => true, 'auto_increment' => true],
            'nama'                => ['type' => 'VARCHAR', 'constraint' => 100, 'null' => false],
            'kategori'            => ['type' => 'VARCHAR', 'constraint' => 50, 'null' => true],
            'deskripsi'           => ['type' => 'TEXT', 'null' => true],
            'hari'                => ['type' => 'VARCHAR', 'constraint' => 20, 'null' => true],
            'urutan'              => ['type' => 'SMALLINT', 'default' => 0, 'null' => false],
            'is_active'           => ['type' => 'TINYINT', 'constraint' => 1, 'default' => 1, 'null' => false],
            'created_at'          => ['type' => 'DATETIME', 'null' => true],
            'updated_at'          => ['type' => 'DATETIME', 'null' => true],
        ]);
        $this->forge->addPrimaryKey('id');
        $this->forge->createTable('pembiasaan', true);

        // pembiasaan_siswa
        $this->forge->addField([
            'id'                  => ['type' => 'INT', 'unsigned' => true, 'auto_increment' => true],
            'tahun_pelajaran_id'  => ['type' => 'INT', 'unsigned' => true, 'null' => false],
            'kelas_id'            => ['type' => 'INT', 'unsigned' => true, 'null' => false],
            'siswa_id'            => ['type' => 'INT', 'unsigned' => true, 'null' => false],
            'pembiasaan_id'       => ['type' => 'INT', 'unsigned' => true, 'null' => false],
            'tanggal'             => ['type' => 'DATE', 'null' => false],
            'terlaksana'          => ['type' => 'TINYINT', 'constraint' => 1, 'default' => 0, 'null' => false],
            'keterangan'          => ['type' => 'VARCHAR', 'constraint' => 150, 'null' => true],
            'dicatat_oleh'        => ['type' => 'INT', 'unsigned' => true, 'null' => true],
            'created_at'          => ['type' => 'DATETIME', 'null' => true],
            'updated_at'          => ['type' => 'DATETIME', 'null' => true],
        ]);
        $this->forge->addPrimaryKey('id');
        $this->forge->addUniqueKey(['tanggal', 'siswa_id', 'pembiasaan_id']);
        $this->forge->addKey(['kelas_id', 'tanggal']);
        $this->forge->addForeignKey('tahun_pelajaran_id', 'tahun_pelajaran', 'id', 'CASCADE', 'CASCADE');
        $this->forge->addForeignKey('kelas_id', 'kelas', 'id', 'CASCADE', 'CASCADE');
        $this->forge->addForeignKey('siswa_id', 'siswa', 'id', 'CASCADE', 'CASCADE');
        $this->forge->addForeignKey('pembiasaan_id', 'pembiasaan', 'id', 'CASCADE', 'CASCADE');
        $this->forge->addForeignKey('dicatat_oleh', 'users', 'id', 'CASCADE', 'SET NULL');
        $this->forge->createTable('pembiasaan_siswa', true);

        // jenis_perilaku
        $this->forge->addField([
            'id'                  => ['type' => 'INT', 'unsigned' => true, 'auto_increment' => true],
            'kategori'            => ['type' => 'ENUM', 'constraint' => ['Positif', 'Negatif'], 'null' => false],
            'nama'                => ['type' => 'VARCHAR', 'constraint' => 150, 'null' => false],
            'tingkat'             => ['type' => 'ENUM', 'constraint' => ['Ringan', 'Sedang', 'Berat'], 'null' => true],
            'poin'                => ['type' => 'SMALLINT', 'default' => 0, 'null' => false],
            'is_active'           => ['type' => 'TINYINT', 'constraint' => 1, 'default' => 1, 'null' => false],
            'created_at'          => ['type' => 'DATETIME', 'null' => true],
            'updated_at'          => ['type' => 'DATETIME', 'null' => true],
        ]);
        $this->forge->addPrimaryKey('id');
        $this->forge->createTable('jenis_perilaku', true);

        // catatan_perilaku
        $this->forge->addField([
            'id'                  => ['type' => 'INT', 'unsigned' => true, 'auto_increment' => true],
            'tahun_pelajaran_id'  => ['type' => 'INT', 'unsigned' => true, 'null' => false],
            'siswa_id'            => ['type' => 'INT', 'unsigned' => true, 'null' => false],
            'kelas_id'            => ['type' => 'INT', 'unsigned' => true, 'null' => true],
            'jenis_perilaku_id'   => ['type' => 'INT', 'unsigned' => true, 'null' => true],
            'tanggal'             => ['type' => 'DATE', 'null' => false],
            'kategori'            => ['type' => 'ENUM', 'constraint' => ['Positif', 'Negatif'], 'null' => false],
            'poin'                => ['type' => 'SMALLINT', 'default' => 0, 'null' => false],
            'deskripsi'           => ['type' => 'TEXT', 'null' => false],
            'lokasi'              => ['type' => 'VARCHAR', 'constraint' => 100, 'null' => true],
            'tindak_lanjut'       => ['type' => 'TEXT', 'null' => true],
            'status'              => ['type' => 'ENUM', 'constraint' => ['Tercatat', 'Ditindaklanjuti', 'Dirujuk BK', 'Ditangani BK', 'Selesai'], 'default' => 'Tercatat', 'null' => false],
            'dicatat_oleh'        => ['type' => 'INT', 'unsigned' => true, 'null' => true],
            'created_at'          => ['type' => 'DATETIME', 'null' => true],
            'updated_at'          => ['type' => 'DATETIME', 'null' => true],
        ]);
        $this->forge->addPrimaryKey('id');
        $this->forge->addKey(['siswa_id', 'tanggal']);
        $this->forge->addKey('status');
        $this->forge->addForeignKey('tahun_pelajaran_id', 'tahun_pelajaran', 'id', 'CASCADE', 'CASCADE');
        $this->forge->addForeignKey('siswa_id', 'siswa', 'id', 'CASCADE', 'CASCADE');
        $this->forge->addForeignKey('kelas_id', 'kelas', 'id', 'CASCADE', 'SET NULL');
        $this->forge->addForeignKey('jenis_perilaku_id', 'jenis_perilaku', 'id', 'CASCADE', 'SET NULL');
        $this->forge->addForeignKey('dicatat_oleh', 'users', 'id', 'CASCADE', 'SET NULL');
        $this->forge->createTable('catatan_perilaku', true);

        // mutasi_siswa
        $this->forge->addField([
            'id'                  => ['type' => 'INT', 'unsigned' => true, 'auto_increment' => true],
            'tahun_pelajaran_id'  => ['type' => 'INT', 'unsigned' => true, 'null' => false],
            'siswa_id'            => ['type' => 'INT', 'unsigned' => true, 'null' => false],
            'jenis'               => ['type' => 'VARCHAR', 'constraint' => 20, 'null' => false],
            'tanggal'             => ['type' => 'DATE', 'null' => false],
            'kelas_asal_id'       => ['type' => 'INT', 'unsigned' => true, 'null' => true],
            'kelas_tujuan_id'     => ['type' => 'INT', 'unsigned' => true, 'null' => true],
            'sekolah'             => ['type' => 'VARCHAR', 'constraint' => 150, 'null' => true],
            'alasan'              => ['type' => 'VARCHAR', 'constraint' => 255, 'null' => true],
            'no_surat'            => ['type' => 'VARCHAR', 'constraint' => 60, 'null' => true],
            'status_sebelum'      => ['type' => 'VARCHAR', 'constraint' => 20, 'null' => true],
            'dicatat_oleh'        => ['type' => 'INT', 'unsigned' => true, 'null' => true],
            'created_at'          => ['type' => 'DATETIME', 'null' => true],
            'updated_at'          => ['type' => 'DATETIME', 'null' => true],
        ]);
        $this->forge->addPrimaryKey('id');
        $this->forge->addKey(['tahun_pelajaran_id', 'tanggal']);
        $this->forge->addForeignKey('siswa_id', 'siswa', 'id', 'CASCADE', 'CASCADE');
        $this->forge->createTable('mutasi_siswa', true);
    }

    public function down()
    {
        $this->db->disableForeignKeyChecks();
        $this->forge->dropTable('mutasi_siswa', true);
        $this->forge->dropTable('catatan_perilaku', true);
        $this->forge->dropTable('jenis_perilaku', true);
        $this->forge->dropTable('pembiasaan_siswa', true);
        $this->forge->dropTable('pembiasaan', true);
        $this->forge->dropTable('presensi_harian', true);
        $this->forge->dropTable('izin_siswa', true);
        $this->db->enableForeignKeyChecks();
    }
}
