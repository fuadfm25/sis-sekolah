<?php

namespace App\Database\Migrations;

use App\Database\MigrasiSis;

/**
 * Jurnal mengajar, absensi per mapel, ATP, dan kokurikuler.
 */
class Pembelajaran extends MigrasiSis
{
    public function up()
    {
        if ($this->sudahTerpasang()) {
            return;
        }
        // jurnal_pembelajaran
        $this->forge->addField([
            'id'                  => ['type' => 'INT', 'unsigned' => true, 'auto_increment' => true],
            'tahun_pelajaran_id'  => ['type' => 'INT', 'unsigned' => true, 'null' => false],
            'jadwal_pelajaran_id' => ['type' => 'INT', 'unsigned' => true, 'null' => true],
            'penugasan_guru_id'   => ['type' => 'INT', 'unsigned' => true, 'null' => false],
            'guru_id'             => ['type' => 'INT', 'unsigned' => true, 'null' => true],
            'kelas_id'            => ['type' => 'INT', 'unsigned' => true, 'null' => false],
            'tanggal'             => ['type' => 'DATE', 'null' => false],
            'jam_ke'              => ['type' => 'VARCHAR', 'constraint' => 20, 'null' => true],
            'jumlah_jp'           => ['type' => 'TINYINT', 'unsigned' => true, 'default' => 1, 'null' => false],
            'pertemuan_ke'        => ['type' => 'SMALLINT', 'unsigned' => true, 'null' => true],
            'materi'              => ['type' => 'VARCHAR', 'constraint' => 255, 'null' => false],
            'tujuan_pembelajaran' => ['type' => 'TEXT', 'null' => true],
            'kegiatan'            => ['type' => 'TEXT', 'null' => true],
            'metode'              => ['type' => 'VARCHAR', 'constraint' => 150, 'null' => true],
            'penilaian'           => ['type' => 'VARCHAR', 'constraint' => 255, 'null' => true],
            'catatan'             => ['type' => 'TEXT', 'null' => true],
            'status_kbm'          => ['type' => 'ENUM', 'constraint' => ['Terlaksana', 'Penilaian', 'Tugas Mandiri', 'Diganti Guru Lain', 'Tidak Terlaksana'], 'default' => 'Terlaksana', 'null' => false],
            'diisi_oleh'          => ['type' => 'INT', 'unsigned' => true, 'null' => true],
            'created_at'          => ['type' => 'DATETIME', 'null' => true],
            'updated_at'          => ['type' => 'DATETIME', 'null' => true],
        ]);
        $this->forge->addPrimaryKey('id');
        $this->forge->addUniqueKey(['jadwal_pelajaran_id', 'tanggal']);
        $this->forge->addKey(['kelas_id', 'tanggal']);
        $this->forge->addKey('penugasan_guru_id');
        $this->forge->addKey(['guru_id', 'tanggal']);
        $this->forge->addForeignKey('tahun_pelajaran_id', 'tahun_pelajaran', 'id', 'CASCADE', 'CASCADE');
        $this->forge->addForeignKey('jadwal_pelajaran_id', 'jadwal_pelajaran', 'id', 'CASCADE', 'SET NULL');
        $this->forge->addForeignKey('penugasan_guru_id', 'penugasan_guru', 'id', 'CASCADE', 'CASCADE');
        $this->forge->addForeignKey('kelas_id', 'kelas', 'id', 'CASCADE', 'CASCADE');
        $this->forge->addForeignKey('diisi_oleh', 'users', 'id', 'CASCADE', 'SET NULL');
        $this->forge->createTable('jurnal_pembelajaran', true);

        // presensi_mapel
        $this->forge->addField([
            'id'                  => ['type' => 'INT', 'unsigned' => true, 'auto_increment' => true],
            'jurnal_id'           => ['type' => 'INT', 'unsigned' => true, 'null' => false],
            'siswa_id'            => ['type' => 'INT', 'unsigned' => true, 'null' => false],
            'status'              => ['type' => 'ENUM', 'constraint' => ['H', 'S', 'I', 'A', 'D'], 'default' => 'H', 'null' => false],
            'keterangan'          => ['type' => 'VARCHAR', 'constraint' => 150, 'null' => true],
            'sumber'              => ['type' => 'VARCHAR', 'constraint' => 10, 'default' => 'Guru', 'null' => false],
            'created_at'          => ['type' => 'DATETIME', 'null' => true],
            'updated_at'          => ['type' => 'DATETIME', 'null' => true],
        ]);
        $this->forge->addPrimaryKey('id');
        $this->forge->addUniqueKey(['jurnal_id', 'siswa_id']);
        $this->forge->addForeignKey('jurnal_id', 'jurnal_pembelajaran', 'id', 'CASCADE', 'CASCADE');
        $this->forge->addForeignKey('siswa_id', 'siswa', 'id', 'CASCADE', 'CASCADE');
        $this->forge->createTable('presensi_mapel', true);

        // atp
        $this->forge->addField([
            'id'                  => ['type' => 'INT', 'unsigned' => true, 'auto_increment' => true],
            'mapel_id'            => ['type' => 'INT', 'unsigned' => true, 'null' => false],
            'tingkat'             => ['type' => 'VARCHAR', 'constraint' => 5, 'null' => false],
            'fase'                => ['type' => 'VARCHAR', 'constraint' => 5, 'null' => true],
            'semester'            => ['type' => 'VARCHAR', 'constraint' => 6, 'null' => true],
            'elemen'              => ['type' => 'VARCHAR', 'constraint' => 150, 'null' => true],
            'kode'                => ['type' => 'VARCHAR', 'constraint' => 20, 'null' => true],
            'tujuan'              => ['type' => 'TEXT', 'null' => false],
            'alokasi_jp'          => ['type' => 'SMALLINT', 'unsigned' => true, 'null' => true],
            'urutan'              => ['type' => 'SMALLINT', 'default' => 0, 'null' => false],
            'modul_ajar'          => ['type' => 'VARCHAR', 'constraint' => 120, 'null' => true],
            'dibuat_oleh'         => ['type' => 'INT', 'unsigned' => true, 'null' => true],
            'created_at'          => ['type' => 'DATETIME', 'null' => true],
            'updated_at'          => ['type' => 'DATETIME', 'null' => true],
        ]);
        $this->forge->addPrimaryKey('id');
        $this->forge->addKey(['mapel_id', 'tingkat']);
        $this->forge->addForeignKey('mapel_id', 'mata_pelajaran', 'id', 'CASCADE', 'CASCADE');
        $this->forge->createTable('atp', true);

        // jurnal_atp
        $this->forge->addField([
            'id'                  => ['type' => 'INT', 'unsigned' => true, 'auto_increment' => true],
            'jurnal_id'           => ['type' => 'INT', 'unsigned' => true, 'null' => false],
            'atp_id'              => ['type' => 'INT', 'unsigned' => true, 'null' => false],
        ]);
        $this->forge->addPrimaryKey('id');
        $this->forge->addUniqueKey(['jurnal_id', 'atp_id']);
        $this->forge->addForeignKey('jurnal_id', 'jurnal_pembelajaran', 'id', 'CASCADE', 'CASCADE');
        $this->forge->addForeignKey('atp_id', 'atp', 'id', 'CASCADE', 'CASCADE');
        $this->forge->createTable('jurnal_atp', true);

        // kokurikuler
        $this->forge->addField([
            'id'                  => ['type' => 'INT', 'unsigned' => true, 'auto_increment' => true],
            'tahun_pelajaran_id'  => ['type' => 'INT', 'unsigned' => true, 'null' => false],
            'judul'               => ['type' => 'VARCHAR', 'constraint' => 200, 'null' => false],
            'tema'                => ['type' => 'VARCHAR', 'constraint' => 150, 'null' => true],
            'bentuk'              => ['type' => 'VARCHAR', 'constraint' => 40, 'null' => true],
            'dimensi'             => ['type' => 'VARCHAR', 'constraint' => 255, 'null' => true],
            'kelas_ids'           => ['type' => 'VARCHAR', 'constraint' => 500, 'null' => true],
            'tanggal_mulai'       => ['type' => 'DATE', 'null' => false],
            'tanggal_selesai'     => ['type' => 'DATE', 'null' => false],
            'alokasi_jp'          => ['type' => 'SMALLINT', 'unsigned' => true, 'null' => true],
            'deskripsi'           => ['type' => 'TEXT', 'null' => true],
            'koordinator_id'      => ['type' => 'INT', 'unsigned' => true, 'null' => true],
            'kalender_id'         => ['type' => 'INT', 'unsigned' => true, 'null' => true],
            'refleksi'            => ['type' => 'TEXT', 'null' => true],
            'created_at'          => ['type' => 'DATETIME', 'null' => true],
            'updated_at'          => ['type' => 'DATETIME', 'null' => true],
        ]);
        $this->forge->addPrimaryKey('id');
        $this->forge->addForeignKey('tahun_pelajaran_id', 'tahun_pelajaran', 'id', 'CASCADE', 'CASCADE');
        $this->forge->createTable('kokurikuler', true);
    }

    public function down()
    {
        $this->db->disableForeignKeyChecks();
        $this->forge->dropTable('kokurikuler', true);
        $this->forge->dropTable('jurnal_atp', true);
        $this->forge->dropTable('atp', true);
        $this->forge->dropTable('presensi_mapel', true);
        $this->forge->dropTable('jurnal_pembelajaran', true);
        $this->db->enableForeignKeyChecks();
    }
}
