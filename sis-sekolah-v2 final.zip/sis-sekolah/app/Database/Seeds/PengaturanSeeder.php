<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;

class PengaturanSeeder extends Seeder
{
    public function run()
    {
        $data = [
            ['kunci' => 'nama_aplikasi',     'nilai' => 'SIS Sekolah',   'label' => 'Nama aplikasi'],
            ['kunci' => 'nama_sekolah',      'nilai' => 'Nama Sekolah',  'label' => 'Nama Sekolah'],
            ['kunci' => 'jenjang',           'nilai' => '',              'label' => 'Jenjang'],
            ['kunci' => 'jenis_nomor',       'nilai' => 'NPSN',          'label' => 'Jenis nomor induk sekolah (NPSN/NSM)'],
            ['kunci' => 'npsn',              'nilai' => '',              'label' => 'NPSN / NSM'],
            ['kunci' => 'kota',              'nilai' => '',              'label' => 'Kota/kabupaten (tempat tanda tangan)'],
            ['kunci' => 'telepon_sekolah',   'nilai' => '',              'label' => 'Telepon sekolah'],
            ['kunci' => 'email_sekolah',     'nilai' => '',              'label' => 'Email sekolah'],
            ['kunci' => 'logo',              'nilai' => '',              'label' => 'Logo sekolah'],
            ['kunci' => 'alamat_sekolah',    'nilai' => '',              'label' => 'Alamat Sekolah'],
            ['kunci' => 'kepala_sekolah',    'nilai' => '',              'label' => 'Nama Kepala Sekolah'],
            ['kunci' => 'nip_kepala_sekolah','nilai' => '',              'label' => 'NIP Kepala Sekolah'],
            ['kunci' => 'jam_masuk',         'nilai' => '07:00',         'label' => 'Jam Masuk (batas terlambat)'],
            ['kunci' => 'hari_sekolah',      'nilai' => '5',             'label' => 'Jumlah Hari Sekolah (5/6)'],
            ['kunci' => 'batas_poin_bk',     'nilai' => '50',            'label' => 'Batas Poin Pelanggaran untuk Peringatan BK'],
            // absensi kiosk
            ['kunci' => 'kiosk_aktif',       'nilai' => '1',             'label' => 'Absensi kiosk (RFID/barcode) aktif'],
            ['kunci' => 'kiosk_token',       'nilai' => bin2hex(random_bytes(12)), 'label' => 'Token alamat kiosk'],
            ['kunci' => 'jam_pulang',        'nilai' => '13:00',         'label' => 'Jam mulai absen pulang (kiosk)'],
            // portal siswa
            ['kunci' => 'portal_siswa',      'nilai' => '1',             'label' => 'Portal siswa aktif'],
            ['kunci' => 'pembiasaan_mundur', 'nilai' => '1',             'label' => 'Siswa boleh mengisi pembiasaan sampai N hari ke belakang'],
            // izin keluar & pos gerbang
            ['kunci' => 'toleransi_kembali', 'nilai' => '30',            'label' => 'Terlambat kembali lebih dari (menit) = membolos'],
            ['kunci' => 'verifikasi_satpam', 'nilai' => '1',             'label' => 'Izin keluar berlaku setelah dicatat satpam'],
            ['kunci' => 'izin_keluar_perilaku', 'nilai' => '1',          'label' => 'Catatan perilaku otomatis untuk terlambat kembali/membolos'],
            // perangkat pembelajaran & modul ajar
            ['kunci' => 'perangkat_tenggat', 'nilai' => '',              'label' => 'Batas pengumpulan perangkat pembelajaran'],
            ['kunci' => 'format_modul',      'nilai' => 'otomatis',      'label' => 'Format modul ajar (otomatis/PM/PM-KBC)'],
        ];

        foreach ($data as $row) {
            if (! $this->db->table('pengaturan')->where('kunci', $row['kunci'])->countAllResults()) {
                $this->db->table('pengaturan')->insert($row + ['updated_at' => date('Y-m-d H:i:s')]);
            }
        }
    }
}
