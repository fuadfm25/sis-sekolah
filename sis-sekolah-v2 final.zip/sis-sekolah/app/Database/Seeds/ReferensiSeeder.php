<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;

/**
 * Data referensi awal: jam pelajaran, daftar pembiasaan, jenis perilaku, jenis perangkat pembelajaran.
 * Silakan sesuaikan lewat menu aplikasi.
 */
class ReferensiSeeder extends Seeder
{
    public function run()
    {
        $now = date('Y-m-d H:i:s');

        if (! $this->db->table('jam_pelajaran')->countAllResults()) {
            $jam = [
                [1, '07:00', '07:40', 1, null],
                [2, '07:40', '08:20', 1, null],
                [3, '08:20', '09:00', 1, null],
                [0, '09:00', '09:15', 0, 'Istirahat'],
                [4, '09:15', '09:55', 1, null],
                [5, '09:55', '10:35', 1, null],
                [6, '10:35', '11:15', 1, null],
                [0, '11:15', '11:45', 0, 'Istirahat / Sholat'],
                [7, '11:45', '12:25', 1, null],
                [8, '12:25', '13:05', 1, null],
            ];
            foreach ($jam as [$ke, $m, $s, $kbm, $ket]) {
                $this->db->table('jam_pelajaran')->insert([
                    'jam_ke' => $ke, 'jam_mulai' => $m, 'jam_selesai' => $s,
                    'is_kbm' => $kbm, 'keterangan' => $ket, 'created_at' => $now,
                ]);
            }
        }

        if (! $this->db->table('pembiasaan')->countAllResults()) {
            $pb = [
                ['Berdoa sebelum belajar', 'Religius', ''],
                ['Tadarus / membaca kitab suci', 'Religius', ''],
                ['Literasi 15 menit', 'Literasi', ''],
                ['Menyanyikan lagu kebangsaan', 'Nasionalisme', ''],
                ['Piket kebersihan kelas', 'Kebersihan', ''],
                ['Berpakaian rapi & lengkap', 'Kedisiplinan', ''],
            ];
            foreach ($pb as $i => [$nama, $kat, $hari]) {
                $this->db->table('pembiasaan')->insert([
                    'nama' => $nama, 'kategori' => $kat, 'hari' => $hari ?: null,
                    'urutan' => $i + 1, 'is_active' => 1, 'created_at' => $now,
                ]);
            }
        }

        if (! $this->db->table('jenis_perilaku')->countAllResults()) {
            $jp = [
                ['Negatif', 'Terlambat masuk sekolah', 'Ringan', 5],
                ['Negatif', 'Tidak mengerjakan tugas', 'Ringan', 5],
                ['Negatif', 'Atribut seragam tidak lengkap', 'Ringan', 5],
                ['Negatif', 'Membolos / meninggalkan pelajaran tanpa izin', 'Sedang', 15],
                ['Negatif', 'Terlambat kembali dari izin keluar', 'Ringan', 5],
                ['Negatif', 'Membawa / menggunakan HP saat KBM tanpa izin', 'Sedang', 10],
                ['Negatif', 'Berkata kasar / tidak sopan', 'Sedang', 15],
                ['Negatif', 'Berkelahi', 'Berat', 50],
                ['Negatif', 'Merokok di lingkungan sekolah', 'Berat', 50],
                ['Negatif', 'Perundungan (bullying)', 'Berat', 75],
                ['Positif', 'Membantu teman / guru', null, 5],
                ['Positif', 'Menjadi petugas upacara', null, 10],
                ['Positif', 'Juara lomba tingkat sekolah', null, 20],
                ['Positif', 'Juara lomba tingkat kabupaten/kota atau lebih', null, 50],
            ];
            foreach ($jp as [$kat, $nama, $tingkat, $poin]) {
                $this->db->table('jenis_perilaku')->insert([
                    'kategori' => $kat, 'nama' => $nama, 'tingkat' => $tingkat,
                    'poin' => $poin, 'is_active' => 1, 'created_at' => $now,
                ]);
            }
        }

        if (! $this->db->table('jenis_perangkat')->countAllResults()) {
            $jenis = [
                // nama, periode, wajib, keterangan
                ['Analisis CP & Tujuan Pembelajaran', 'Tahunan', 1, 'Pemetaan capaian pembelajaran fase menjadi tujuan pembelajaran.'],
                ['Alur Tujuan Pembelajaran (ATP)', 'Tahunan', 1, 'Urutan tujuan pembelajaran selama satu fase/tahun.'],
                ['Program Tahunan (Prota)', 'Tahunan', 1, 'Sebaran tujuan/materi dan alokasi JP dalam satu tahun pelajaran.'],
                ['Program Semester (Promes)', 'Semester', 1, 'Sebaran tujuan/materi per minggu efektif dalam satu semester.'],
                ['Modul Ajar / RPP', 'Semester', 1, 'Rencana pembelajaran (pendekatan pembelajaran mendalam) beserta asesmen, LKPD, dan media.'],
                ['Kriteria Ketercapaian Tujuan Pembelajaran (KKTP)', 'Semester', 1, 'Kriteria/rubrik untuk menentukan ketercapaian tujuan pembelajaran.'],
                ['Instrumen Asesmen', 'Semester', 1, 'Asesmen awal/diagnostik, formatif, dan sumatif beserta kisi-kisi & rubrik.'],
                ['Bahan Ajar / LKPD', 'Semester', 0, 'Bahan ajar, lembar kerja, atau media pendukung.'],
                ['Analisis Hasil Asesmen & Tindak Lanjut', 'Semester', 0, 'Analisis hasil asesmen, program remedial dan pengayaan.'],
            ];
            foreach ($jenis as $i => [$nama, $periode, $wajib, $ket]) {
                $this->db->table('jenis_perangkat')->insert(['nama' => $nama, 'periode' => $periode, 'wajib' => $wajib, 'keterangan' => $ket,
                    'urutan' => $i + 1, 'is_active' => 1, 'created_at' => $now]);
            }
        }
    }
}
