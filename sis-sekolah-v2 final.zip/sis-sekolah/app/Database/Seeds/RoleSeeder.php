<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;

class RoleSeeder extends Seeder
{
    public function run()
    {
        $roles = [
            ['nama_role' => 'admin',     'keterangan' => 'Administrator Sistem'],
            ['nama_role' => 'kepsek',    'keterangan' => 'Kepala Sekolah'],
            ['nama_role' => 'kurikulum', 'keterangan' => 'Wakil Kepala Bidang Kurikulum'],
            ['nama_role' => 'kesiswaan', 'keterangan' => 'Wakil Kepala Bidang Kesiswaan'],
            ['nama_role' => 'guru',      'keterangan' => 'Guru Mata Pelajaran'],
            ['nama_role' => 'piket',     'keterangan' => 'Guru Piket'],
            ['nama_role' => 'bk',        'keterangan' => 'Guru Bimbingan & Konseling'],
            ['nama_role' => 'tu',        'keterangan' => 'Staf Tata Usaha'],
            ['nama_role' => 'satpam',    'keterangan' => 'Satpam / Petugas Keamanan'],
        ];

        foreach ($roles as $r) {
            if (! $this->db->table('roles')->where('nama_role', $r['nama_role'])->countAllResults()) {
                $this->db->table('roles')->insert($r);
            }
        }
    }
}
