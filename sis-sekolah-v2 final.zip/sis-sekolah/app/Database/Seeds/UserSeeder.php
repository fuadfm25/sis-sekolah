<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;

class UserSeeder extends Seeder
{
    public function run()
    {
        if ($this->db->table('users')->where('username', 'admin')->countAllResults()) {
            return;
        }

        $this->db->table('users')->insert([
            'username'     => 'admin',
            'password'     => password_hash('admin123', PASSWORD_DEFAULT),
            'nama_lengkap' => 'Administrator',
            'is_active'    => 1,
            'created_at'   => date('Y-m-d H:i:s'),
        ]);
        $userId = $this->db->insertID();
        $roleId = $this->db->table('roles')->where('nama_role', 'admin')->get()->getRow('id');

        $this->db->table('user_roles')->insert(['user_id' => $userId, 'role_id' => $roleId]);
    }
}
