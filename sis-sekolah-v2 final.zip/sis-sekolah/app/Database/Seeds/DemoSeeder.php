<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;

/**
 * Data contoh untuk mencoba aplikasi. JANGAN dijalankan di database produksi.
 * php spark db:seed DemoSeeder
 * Semua akun demo berpassword: 123456
 */
class DemoSeeder extends Seeder
{
    public function run()
    {
        $db  = $this->db;
        $now = date('Y-m-d H:i:s');
        $pw  = password_hash('123456', PASSWORD_DEFAULT);

        $this->call('DatabaseSeeder');

        // Tahun pelajaran aktif
        $db->table('tahun_pelajaran')->update(['is_active' => 0]);
        $db->table('tahun_pelajaran')->insert([
            'tahun_pelajaran' => '2026/2027', 'semester' => 'Ganjil',
            'tanggal_mulai' => '2026-07-13', 'tanggal_selesai' => '2026-12-19',
            'is_active' => 1, 'created_at' => $now,
        ]);
        $tp = $db->insertID();

        $role = fn ($n) => $db->table('roles')->where('nama_role', $n)->get()->getRow('id');

        // Guru + akun
        $guruData = [
            ['guru.budi',  'Budi Santoso', 'S.Pd.', 'L', ['guru', 'piket']],
            ['guru.siti',  'Siti Aminah', 'S.Pd.', 'P', ['guru']],
            ['guru.andi',  'Andi Wijaya', 'S.Pd.', 'L', ['guru', 'kesiswaan']],
            ['guru.rina',  'Rina Lestari', 'S.Psi.', 'P', ['guru', 'bk']],
            ['guru.dedi',  'Dedi Kurniawan', 'M.Pd.', 'L', ['guru', 'kurikulum']],
        ];
        $guruIds = [];
        foreach ($guruData as [$u, $nama, $gelar, $jk, $roles]) {
            $db->table('users')->insert(['username' => $u, 'password' => $pw, 'nama_lengkap' => "$nama, $gelar", 'is_active' => 1, 'created_at' => $now]);
            $uid = $db->insertID();
            foreach ($roles as $r) {
                $db->table('user_roles')->insert(['user_id' => $uid, 'role_id' => $role($r)]);
            }
            $db->table('guru')->insert(['user_id' => $uid, 'nama_lengkap' => $nama, 'gelar_belakang' => $gelar, 'jenis_kelamin' => $jk, 'status_kepegawaian' => 'PNS', 'is_active' => 1, 'created_at' => $now]);
            $guruIds[] = $db->insertID();
        }

        // Kelas
        $kelasIds = [];
        foreach (['VII A', 'VII B', 'VIII A'] as $i => $nk) {
            $db->table('kelas')->insert(['tingkat' => explode(' ', $nk)[0], 'nama_kelas' => $nk, 'is_active' => 1, 'created_at' => $now]);
            $kelasIds[] = $db->insertID();
            $db->table('wali_kelas')->insert(['tahun_pelajaran_id' => $tp, 'kelas_id' => $kelasIds[$i], 'guru_id' => $guruIds[$i], 'created_at' => $now]);
        }

        // Mapel
        $mapelIds = [];
        foreach ([['MTK', 'Matematika'], ['BIN', 'Bahasa Indonesia'], ['IPA', 'Ilmu Pengetahuan Alam'], ['BIG', 'Bahasa Inggris'], ['PAI', 'Pendidikan Agama Islam']] as [$k, $n]) {
            $db->table('mata_pelajaran')->insert(['kode_mapel' => $k, 'nama_mapel' => $n, 'kelompok' => 'Umum', 'is_active' => 1, 'created_at' => $now]);
            $mapelIds[] = $db->insertID();
        }

        // Siswa
        $namaDepan = ['Ahmad', 'Bunga', 'Citra', 'Dimas', 'Eka', 'Fajar', 'Gita', 'Hadi', 'Intan', 'Joko', 'Kirana', 'Lukman'];
        $nis = 26001;
        foreach ($kelasIds as $ki => $kid) {
            foreach ($namaDepan as $j => $nd) {
                $db->table('siswa')->insert([
                    'nis' => (string) $nis++, 'nisn' => '00' . rand(10000000, 99999999),
                    'nama_lengkap' => $nd . ' ' . ['Pratama', 'Sari', 'Putra', 'Putri'][($j + $ki) % 4],
                    'jenis_kelamin' => $j % 2 ? 'P' : 'L', 'status' => 'Aktif', 'created_at' => $now,
                ]);
                $db->table('anggota_kelas')->insert(['tahun_pelajaran_id' => $tp, 'kelas_id' => $kid, 'siswa_id' => $db->insertID(), 'no_absen' => $j + 1, 'status' => 'Aktif', 'created_at' => $now]);
            }
        }

        // Penugasan: guru i mengajar mapel i di semua kelas
        $jamKbm = $db->table('jam_pelajaran')->where('is_kbm', 1)->orderBy('jam_ke')->get()->getResultArray();
        foreach ($kelasIds as $ki => $kid) {
            $pen = [];
            foreach ($mapelIds as $mi => $mid) {
                $db->table('penugasan_guru')->insert(['tahun_pelajaran_id' => $tp, 'guru_id' => $guruIds[$mi], 'mapel_id' => $mid, 'kelas_id' => $kid, 'jp_per_minggu' => 4, 'created_at' => $now]);
                $pen[] = $db->insertID();
            }
            // Jadwal: blok 2 JP, digeser per kelas agar guru tidak bentrok
            for ($hari = 1; $hari <= 5; $hari++) {
                for ($blok = 0; $blok < 4; $blok++) {
                    $mi = ($hari + $blok + $ki) % count($mapelIds);
                    foreach ([0, 1] as $x) {
                        $slot = $jamKbm[$blok * 2 + $x] ?? null;
                        if (! $slot) {
                            continue;
                        }
                        $db->table('jadwal_pelajaran')->insert(['tahun_pelajaran_id' => $tp, 'penugasan_guru_id' => $pen[$mi], 'kelas_id' => $kid, 'hari' => $hari, 'jam_pelajaran_id' => $slot['id'], 'created_at' => $now]);
                    }
                }
            }
        }

        // Kalender akademik contoh
        foreach ([
            ['2026-08-17', '2026-08-17', 'Libur Nasional', 'HUT Kemerdekaan RI', 0, 0],
            ['2026-09-21', '2026-09-26', 'Ujian', 'Penilaian Tengah Semester Ganjil', 0, 1],
            ['2026-11-25', '2026-11-25', 'Libur Fakultatif', 'Hari Guru Nasional', 0, 0],
            ['2026-12-07', '2026-12-12', 'Ujian', 'Penilaian Akhir Semester Ganjil', 0, 1],
            ['2026-12-14', '2026-12-16', 'Kegiatan Sekolah', 'Class Meeting', 0, 1],
        ] as [$m, $sl, $j, $n, $kbm, $abs]) {
            $db->table('kalender_akademik')->insert(['tahun_pelajaran_id' => $tp, 'tanggal_mulai' => $m, 'tanggal_selesai' => $sl, 'jenis' => $j, 'nama' => $n, 'ada_kbm' => $kbm, 'ada_absensi' => $abs, 'created_at' => $now]);
        }

        // Piket
        foreach (range(1, 5) as $h) {
            $db->table('guru_piket')->insert(['tahun_pelajaran_id' => $tp, 'guru_id' => $guruIds[($h - 1) % count($guruIds)], 'hari' => $h, 'created_at' => $now]);
        }
    }
}
