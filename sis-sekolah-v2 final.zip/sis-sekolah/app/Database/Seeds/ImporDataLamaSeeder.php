<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\BaseConnection;
use CodeIgniter\Database\Seeder;

/**
 * Memindahkan data dari database versi lama (koneksi 'lama') ke struktur baru (koneksi default).
 *
 * Langkah:
 *   1. Buat database baru kosong, mis. db_sis_sekolah_v2. Database lama TIDAK diubah.
 *   2. .env:
 *        database.default.database = db_sis_sekolah_v2
 *        database.lama.database    = db_sis_sekolah
 *   3. php spark migrate
 *      php spark db:seed DatabaseSeeder
 *      php spark db:seed ImporDataLamaSeeder
 *
 * Aman dijalankan ulang: data dicocokkan lewat kunci unik (username, kode, nama kelas, NIS).
 */
class ImporDataLamaSeeder extends Seeder
{
    private BaseConnection $lama;
    private string $now;
    private array $log = [];

    /** peta id lama => id baru */
    private array $mapUser = [];
    private array $mapGuruByUser = [];   // users.id lama => guru.id baru
    private array $mapTp = [];
    private array $mapJurusan = [];
    private array $mapKelas = [];
    private array $mapMapel = [];
    private array $mapJam = [];
    private array $mapSiswa = [];
    private array $mapPenugasan = [];
    private array $mapJadwal = [];
    private array $mapJurnal = [];

    public function run()
    {
        $this->lama = \Config\Database::connect('lama');
        $this->now  = date('Y-m-d H:i:s');

        if (! $this->db->tableExists('roles') || ! $this->db->table('roles')->countAllResults()) {
            throw new \RuntimeException('Jalankan dulu: php spark migrate && php spark db:seed DatabaseSeeder');
        }

        $this->db->transStart();
        $this->users();
        $this->guru();
        $this->tahunPelajaran();
        $this->jurusan();
        $this->kelas();
        $this->mapel();
        $this->jamPelajaran();
        $this->siswa();
        $this->waliKelas();
        $this->penugasan();
        $this->jadwal();
        $this->jurnal();
        $this->db->transComplete();

        if (! $this->db->transStatus()) {
            throw new \RuntimeException('Impor gagal, seluruh perubahan dibatalkan.');
        }

        foreach ($this->log as $l) {
            echo '  - ' . $l . PHP_EOL;
        }
    }

    // ------------------------------------------------------------------ helper
    private function ada(string $table): bool
    {
        return $this->lama->tableExists($table);
    }

    private function rows(string $table): array
    {
        return $this->ada($table) ? $this->lama->table($table)->get()->getResultArray() : [];
    }

    private function hasField(string $table, string $field): bool
    {
        return $this->ada($table) && in_array($field, $this->lama->getFieldNames($table), true);
    }

    /** Cari baris by kriteria; jika tidak ada insert. Mengembalikan id. */
    private function upsert(string $table, array $where, array $data, bool $update = true): int
    {
        $row = $this->db->table($table)->where($where)->get()->getRowArray();
        if ($row) {
            if ($update && $data) {
                $this->db->table($table)->where('id', $row['id'])->update($data);
            }
            return (int) $row['id'];
        }
        $this->db->table($table)->insert($where + $data);
        return (int) $this->db->insertID();
    }

    private function tpAktifId(): ?int
    {
        $id = $this->db->table('tahun_pelajaran')->where('is_active', 1)->get()->getRow('id');
        return $id ? (int) $id : null;
    }

    private static function hariAngka($h): int
    {
        if (is_numeric($h)) {
            return (int) $h;
        }
        return ['senin' => 1, 'selasa' => 2, 'rabu' => 3, 'kamis' => 4, 'jumat' => 5, "jum'at" => 5, 'sabtu' => 6][strtolower(trim((string) $h))] ?? 1;
    }

    /** "Fuat Fatah Musafak, S.Pd" => ['Fuat Fatah Musafak', 'S.Pd'] */
    private static function pisahGelar(string $nama): array
    {
        $parts = array_map('trim', explode(',', $nama, 2));
        return [$parts[0], $parts[1] ?? null];
    }

    // ------------------------------------------------------------------ tabel
    private function users(): void
    {
        $roleMap = ['admin' => 'admin', 'guru' => 'guru', 'tu' => 'tu', 'bk' => 'bk',
            'waka_kesiswaan' => 'kesiswaan', 'waka_kurikulum' => 'kurikulum', 'kesiswaan' => 'kesiswaan',
            'kurikulum' => 'kurikulum', 'kepsek' => 'kepsek', 'piket' => 'piket'];
        $roleBaru = array_column($this->db->table('roles')->get()->getResultArray(), 'id', 'nama_role');
        $roleLama = array_column($this->rows('roles'), 'nama_role', 'id');

        $userRoles = [];
        foreach ($this->rows('user_roles') as $ur) {
            $userRoles[$ur['user_id']][] = $roleLama[$ur['role_id']] ?? null;
        }

        foreach ($this->rows('users') as $u) {
            $id = $this->upsert('users', ['username' => $u['username']], [
                'password'     => $u['password'],          // hash lama tetap valid
                'nama_lengkap' => $u['nama_lengkap'],
                'is_active'    => (int) ($u['is_active'] ?? 1),
                'created_at'   => $u['created_at'] ?? $this->now,
            ]);
            $this->mapUser[$u['id']] = $id;

            foreach ($userRoles[$u['id']] ?? [] as $r) {
                $nama = $roleMap[$r] ?? null;
                if ($nama && isset($roleBaru[$nama])
                    && ! $this->db->table('user_roles')->where(['user_id' => $id, 'role_id' => $roleBaru[$nama]])->countAllResults()) {
                    $this->db->table('user_roles')->insert(['user_id' => $id, 'role_id' => $roleBaru[$nama]]);
                }
            }
            if (! empty($u['is_guru_piket']) && isset($roleBaru['piket'])
                && ! $this->db->table('user_roles')->where(['user_id' => $id, 'role_id' => $roleBaru['piket']])->countAllResults()) {
                $this->db->table('user_roles')->insert(['user_id' => $id, 'role_id' => $roleBaru['piket']]);
            }
        }
        $this->log[] = count($this->mapUser) . ' akun pengguna (password lama tetap berlaku)';
    }

    private function guru(): void
    {
        // 1. tabel guru lama (bila terisi)
        foreach ($this->rows('guru') as $g) {
            $userId = $g['user_id'] ? ($this->mapUser[$g['user_id']] ?? null) : null;
            $where  = $userId ? ['user_id' => $userId] : ['nama_lengkap' => $g['nama_lengkap']];
            $id     = $this->upsert('guru', $where, [
                'nip' => $g['nip'] ?: null, 'nama_lengkap' => $g['nama_lengkap'],
                'gelar_depan' => $g['gelar_depan'] ?? null, 'gelar_belakang' => $g['gelar_belakang'] ?? null,
                'jenis_kelamin' => $g['jenis_kelamin'] ?: 'L', 'no_hp' => $g['no_hp'] ?? null, 'email' => $g['email'] ?? null,
                'status_kepegawaian' => $g['status_kepegawaian'] ?? 'Honorer', 'is_active' => 1, 'created_at' => $this->now,
            ]);
            if ($g['user_id']) {
                $this->mapGuruByUser[$g['user_id']] = $id;
            }
        }

        // 2. Versi lama memakai users.id sebagai "guru" (penugasan, wali kelas).
        //    Buat data guru untuk setiap user ber-role guru/waka/bk yang belum punya.
        $guruRole = $this->db->table('user_roles ur')->select('ur.user_id')->join('roles r', 'r.id = ur.role_id')
            ->whereIn('r.nama_role', ['guru', 'kurikulum', 'kesiswaan', 'bk', 'piket', 'kepsek'])->get()->getResultArray();
        $userIdsGuru = array_unique(array_map('intval', array_column($guruRole, 'user_id')));
        $dibuat      = 0;
        foreach ($this->mapUser as $lamaId => $baruId) {
            if (isset($this->mapGuruByUser[$lamaId]) || ! in_array($baruId, $userIdsGuru, true)) {
                continue;
            }
            $ada = $this->db->table('guru')->where('user_id', $baruId)->get()->getRowArray();
            if (! $ada) {
                $u = $this->db->table('users')->where('id', $baruId)->get()->getRowArray();
                [$nama, $gelar] = self::pisahGelar($u['nama_lengkap']);
                $this->db->table('guru')->insert([
                    'user_id' => $baruId, 'nama_lengkap' => $nama, 'gelar_belakang' => $gelar,
                    'nip' => preg_match('/^\d{18}$/', $u['username']) ? $u['username'] : null,
                    'jenis_kelamin' => 'L', 'status_kepegawaian' => 'Honorer', 'is_active' => 1, 'created_at' => $this->now,
                ]);
                $ada = ['id' => $this->db->insertID()];
                $dibuat++;
            }
            $this->mapGuruByUser[$lamaId] = (int) $ada['id'];
        }
        $this->log[] = count($this->mapGuruByUser) . " data guru ($dibuat dibuat dari akun; CEK jenis kelamin & status kepegawaian di menu Guru)";
    }

    private function tahunPelajaran(): void
    {
        $src  = $this->ada('tahun_pelajaran') ? 'tahun_pelajaran' : 'tahun_akademik';
        $col  = $src === 'tahun_pelajaran' ? 'tahun_pelajaran' : 'tahun';
        $aktifLama = null;
        foreach ($this->rows($src) as $t) {
            $id = $this->upsert('tahun_pelajaran', ['tahun_pelajaran' => $t[$col], 'semester' => $t['semester']], ['created_at' => $this->now], false);
            $this->mapTp[$t['id']] = $id;
            if ((int) $t['is_active']) {
                $aktifLama = $id;
            }
        }
        if ($aktifLama) {
            $this->db->table('tahun_pelajaran')->update(['is_active' => 0]);
            $this->db->table('tahun_pelajaran')->where('id', $aktifLama)->update(['is_active' => 1]);
        }
        $this->log[] = count($this->mapTp) . ' tahun pelajaran';
    }

    private function jurusan(): void
    {
        foreach ($this->rows('jurusan') as $j) {
            $this->mapJurusan[$j['id']] = $this->upsert('jurusan', ['kode_jurusan' => $j['kode_jurusan']], ['nama_jurusan' => $j['nama_jurusan'], 'created_at' => $this->now]);
        }
        $this->log[] = count($this->mapJurusan) . ' jurusan';
    }

    private function kelas(): void
    {
        foreach ($this->rows('kelas') as $k) {
            $this->mapKelas[$k['id']] = $this->upsert('kelas', ['nama_kelas' => trim($k['nama_kelas'])], [
                'tingkat'    => (string) $k['tingkat'],
                'jurusan_id' => $k['jurusan_id'] ? ($this->mapJurusan[$k['jurusan_id']] ?? null) : null,
                'is_active'  => 1,
                'created_at' => $this->now,
            ]);
        }
        $this->log[] = count($this->mapKelas) . ' kelas';
    }

    private function mapel(): void
    {
        foreach ($this->rows('mata_pelajaran') as $m) {
            $this->mapMapel[$m['id']] = $this->upsert('mata_pelajaran', ['kode_mapel' => $m['kode_mapel']], ['nama_mapel' => $m['nama_mapel'], 'is_active' => 1, 'created_at' => $this->now]);
        }
        $this->log[] = count($this->mapMapel) . ' mata pelajaran';
    }

    private function jamPelajaran(): void
    {
        $lama = $this->rows('jam_pelajaran');
        if (! $lama) {
            return;
        }
        // jam lama menggantikan jam bawaan seeder bila belum dipakai jadwal
        if (! $this->db->table('jadwal_pelajaran')->countAllResults()) {
            $this->db->table('jam_pelajaran')->emptyTable();
        }
        foreach ($lama as $j) {
            $this->mapJam[$j['id']] = $this->upsert('jam_pelajaran', ['jam_mulai' => $j['jam_mulai'], 'jam_selesai' => $j['jam_selesai']], [
                'jam_ke'     => (int) $j['jam_ke'],
                'is_kbm'     => (int) $j['is_kbm'],
                'keterangan' => (int) $j['is_kbm'] ? null : $j['keterangan'],
                'created_at' => $this->now,
            ]);
        }
        $this->log[] = count($this->mapJam) . ' slot jam pelajaran (menggantikan jam bawaan)';
    }

    private function siswa(): void
    {
        $tp = $this->tpAktifId();
        if (! $tp) {
            $this->log[] = 'PERINGATAN: tidak ada TP aktif, siswa tidak dimasukkan ke rombel';
        }
        $lamaPunyaNama = $this->hasField('siswa', 'nama_lengkap');
        $kelasTerisi   = [];
        foreach ($this->rows('siswa') as $s) {
            // versi lama: username = NISN. Dipakai sebagai NIS & NISN (NIS dapat diubah nanti).
            $nis  = trim((string) ($s['nis'] ?? $s['username'] ?? $s['nisn'] ?? ''));
            $nama = trim((string) ($lamaPunyaNama ? $s['nama_lengkap'] : ($s['nama'] ?? '')));
            if ($nis === '' || $nama === '') {
                continue;
            }
            $id = $this->upsert('siswa', ['nis' => $nis], [
                'nisn' => $s['nisn'] ?? (preg_match('/^\d{10}$/', $nis) ? $nis : null),
                'nama_lengkap' => $nama, 'jenis_kelamin' => $s['jenis_kelamin'] ?: 'L',
                'status' => 'Aktif', 'created_at' => $s['created_at'] ?? $this->now,
            ]);
            $this->mapSiswa[$s['id']] = $id;

            $kelasId = isset($s['kelas_id']) ? ($this->mapKelas[$s['kelas_id']] ?? null) : null;
            if ($tp && $kelasId) {
                $this->upsert('anggota_kelas', ['tahun_pelajaran_id' => $tp, 'siswa_id' => $id], ['kelas_id' => $kelasId, 'status' => 'Aktif', 'created_at' => $this->now]);
                $kelasTerisi[$kelasId] = true;
            }
        }
        // anggota_kelas lama (bila ada)
        foreach ($this->rows('anggota_kelas') as $a) {
            $tpId = $this->mapTp[$a['tahun_pelajaran_id'] ?? $a['tahun_akademik_id'] ?? 0] ?? null;
            $sid  = $this->mapSiswa[$a['siswa_id']] ?? null;
            $kid  = $this->mapKelas[$a['kelas_id']] ?? null;
            if ($tpId && $sid && $kid) {
                $this->upsert('anggota_kelas', ['tahun_pelajaran_id' => $tpId, 'siswa_id' => $sid], ['kelas_id' => $kid, 'created_at' => $this->now]);
                $kelasTerisi[$kid] = true;
            }
        }
        // nomor absen urut nama
        if ($tp) {
            foreach (array_keys($kelasTerisi) as $kid) {
                $rows = $this->db->table('anggota_kelas ak')->select('ak.id')->join('siswa s', 's.id = ak.siswa_id')
                    ->where(['ak.kelas_id' => $kid, 'ak.tahun_pelajaran_id' => $tp])->orderBy('s.nama_lengkap')->get()->getResultArray();
                foreach ($rows as $i => $r) {
                    $this->db->table('anggota_kelas')->where('id', $r['id'])->update(['no_absen' => $i + 1]);
                }
            }
        }
        $this->log[] = count($this->mapSiswa) . ' siswa (NISN lama dipakai sebagai NIS; login siswa tidak dipindahkan)';
    }

    private function waliKelas(): void
    {
        $tp = $this->tpAktifId();
        $n  = 0;
        // versi lama: kelas.wali_kelas_id = users.id
        if ($tp && $this->hasField('kelas', 'wali_kelas_id')) {
            foreach ($this->rows('kelas') as $k) {
                $guru = $k['wali_kelas_id'] ? ($this->mapGuruByUser[$k['wali_kelas_id']] ?? null) : null;
                if ($guru && isset($this->mapKelas[$k['id']])) {
                    $this->upsert('wali_kelas', ['tahun_pelajaran_id' => $tp, 'kelas_id' => $this->mapKelas[$k['id']]], ['guru_id' => $guru, 'created_at' => $this->now]);
                    $n++;
                }
            }
        }
        $this->log[] = "$n wali kelas";
    }

    private function penugasan(): void
    {
        $tp = $this->tpAktifId();
        foreach ($this->rows('penugasan_guru') as $p) {
            // versi lama: guru_id = users.id ; tahun_ajaran berupa teks "2026/2027"
            $guru  = $this->mapGuruByUser[$p['guru_id']] ?? null;
            $mapel = $this->mapMapel[$p['mapel_id']] ?? null;
            $kelas = $this->mapKelas[$p['kelas_id']] ?? null;
            $tpId  = $tp;
            if (! empty($p['tahun_ajaran'])) {
                $cocok = $this->db->table('tahun_pelajaran')->where('tahun_pelajaran', $p['tahun_ajaran'])->orderBy('is_active', 'DESC')->get()->getRow('id');
                $tpId  = $cocok ? (int) $cocok : $tp;
            }
            if (! $guru || ! $mapel || ! $kelas || ! $tpId) {
                $this->log[] = "PERINGATAN: penugasan lama #{$p['id']} dilewati (guru/mapel/kelas tidak ditemukan)";
                continue;
            }
            $this->mapPenugasan[$p['id']] = $this->upsert('penugasan_guru', ['tahun_pelajaran_id' => $tpId, 'mapel_id' => $mapel, 'kelas_id' => $kelas], [
                'guru_id' => $guru, 'jp_per_minggu' => 2, 'created_at' => $this->now,
            ]);
        }
        $this->log[] = count($this->mapPenugasan) . ' penugasan guru (JP/minggu diisi 2, silakan sesuaikan)';
    }

    private function jadwal(): void
    {
        foreach ($this->rows('jadwal_pelajaran') as $j) {
            $pen = $this->mapPenugasan[$j['penugasan_id'] ?? $j['penugasan_guru_id'] ?? 0] ?? null;
            $jam = $this->mapJam[$j['jam_pelajaran_id']] ?? null;
            if (! $pen || ! $jam) {
                continue;
            }
            $p = $this->db->table('penugasan_guru')->where('id', $pen)->get()->getRowArray();
            $this->mapJadwal[$j['id']] = $this->upsert('jadwal_pelajaran', [
                'tahun_pelajaran_id' => $p['tahun_pelajaran_id'], 'kelas_id' => $p['kelas_id'],
                'hari' => self::hariAngka($j['hari']), 'jam_pelajaran_id' => $jam,
            ], ['penugasan_guru_id' => $pen, 'created_at' => $this->now]);
        }
        $this->log[] = count($this->mapJadwal) . ' slot jadwal';
    }

    private function jurnal(): void
    {
        $statusMap = ['Terlaksana' => 'Terlaksana', 'Kuis/Ujian' => 'Penilaian', 'Kendala/Kosong' => 'Tidak Terlaksana'];
        foreach ($this->rows('jurnal_pembelajaran') as $j) {
            $jadwalId = $this->mapJadwal[$j['jadwal_pelajaran_id']] ?? null;
            if (! $jadwalId) {
                continue;
            }
            $jd = $this->db->table('jadwal_pelajaran jp')->select('jp.*, jam.jam_ke')->join('jam_pelajaran jam', 'jam.id = jp.jam_pelajaran_id')
                ->where('jp.id', $jadwalId)->get()->getRowArray();
            $this->mapJurnal[$j['id']] = $this->upsert('jurnal_pembelajaran', ['jadwal_pelajaran_id' => $jadwalId, 'tanggal' => $j['tanggal']], [
                'tahun_pelajaran_id' => $jd['tahun_pelajaran_id'], 'penugasan_guru_id' => $jd['penugasan_guru_id'],
                'kelas_id' => $jd['kelas_id'], 'jam_ke' => (string) $jd['jam_ke'], 'jumlah_jp' => 1,
                'materi' => mb_substr(trim((string) ($j['materi_terealisasi'] ?? '-')) ?: '-', 0, 255),
                'catatan' => $j['catatan_kendala'] ?? null,
                'status_kbm' => $statusMap[$j['status_kbm'] ?? 'Terlaksana'] ?? 'Terlaksana',
                'created_at' => $j['created_at'] ?? $this->now,
            ]);
        }
        $stMap = ['Hadir' => 'H', 'Sakit' => 'S', 'Izin' => 'I', 'Alpa' => 'A'];
        $n     = 0;
        foreach ($this->rows('presensi_siswa') as $p) {
            $jid = $this->mapJurnal[$p['jurnal_pembelajaran_id']] ?? null;
            $sid = $this->mapSiswa[$p['siswa_id']] ?? null;
            if ($jid && $sid) {
                $this->upsert('presensi_mapel', ['jurnal_id' => $jid, 'siswa_id' => $sid], ['status' => $stMap[$p['status']] ?? 'H', 'keterangan' => $p['catatan'] ?? null, 'created_at' => $this->now]);
                $n++;
            }
        }
        $this->log[] = count($this->mapJurnal) . " jurnal, $n presensi mapel";
    }
}
