<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;

/**
 * Data awal (role, admin, pengaturan, referensi). Dijalankan otomatis oleh migration 100009_DataAwal,
 * jadi instalasi baru cukup "php spark migrate". Aman dijalankan ulang: php spark db:seed DatabaseSeeder
 * Data contoh (opsional): php spark db:seed DemoSeeder
 */
class DatabaseSeeder extends Seeder
{
    public function run()
    {
        $this->call('RoleSeeder');
        $this->call('UserSeeder');
        $this->call('PengaturanSeeder');
        $this->call('ReferensiSeeder');
    }
}
