<?php

namespace App\Database;

use CodeIgniter\Database\Migration;
use RuntimeException;

/**
 * Dasar migration SIS Sekolah (skema final, satu berkas per kelompok tabel).
 *
 * Instalasi yang dibuat dengan susunan migration lama (2026-11-23-000001 … 2026-11-24-000024) sudah memiliki
 * semua tabel: migration baru dilewati dan hanya dicatat. Instalasi lama yang belum sampai 000024 harus
 * dimutakhirkan dulu dengan database/upgrade_v2.sql.
 */
abstract class MigrasiSis extends Migration
{
    public const VERSI_LAMA_TERAKHIR = '2026-11-24-000024';

    protected function sudahTerpasang(): bool
    {
        if (! $this->db->tableExists('migrations')) {
            return false;
        }
        $lama = $this->db->table('migrations')->groupStart()->like('version', '2026-11-23-0000', 'after')->orLike('version', '2026-11-24-0000', 'after')->groupEnd()
            ->select('version')->get()->getResultArray();
        if (! $lama) {
            return false;
        }
        if (in_array(self::VERSI_LAMA_TERAKHIR, array_column($lama, 'version'), true)) {
            return true;
        }
        throw new RuntimeException('Database ini memakai susunan migration lama yang belum lengkap. Jalankan dulu database/upgrade_v2.sql '
            . '(lewat phpMyAdmin), lalu ulangi "php spark migrate".');
    }
}
