<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 *
 * Hak akses:  filter 'auth' = wajib login,  'role:a,b' = salah satu role (admin selalu lolos).
 * Aturan yang lebih rinci (wali kelas, hari piket, kepemilikan data) ada di App\Libraries\Akses.
 */

// ---------------------------------------------------------------- Pemasangan (hanya sebelum terpasang)
$routes->get('install', 'Install::index');
$routes->post('install/proses', 'Install::proses');

// ---------------------------------------------------------------- Auth
$routes->get('/', static fn () => redirect()->to('/dashboard'));
$routes->get('login', 'Auth::index');
$routes->post('login', 'Auth::login');
$routes->get('logout', 'Auth::logout');

// ---------------------------------------------------------------- Kiosk absensi (tanpa login, dilindungi token)
$routes->get('kiosk/(:segment)', 'KioskController::index/$1');
$routes->post('kiosk/(:segment)/scan', 'KioskController::scan/$1');

// ---------------------------------------------------------------- Portal siswa (login terpisah dengan NISN/NIS)
$routes->get('portal/login', 'Portal\PortalController::login');
$routes->post('portal/login', 'Portal\PortalController::masuk');
$routes->get('portal/keluar', 'Portal\PortalController::keluar');
$routes->group('portal', ['namespace' => 'App\Controllers\Portal', 'filter' => 'siswa'], static function ($r) {
    $r->get('/', 'PortalController::beranda');
    $r->get('jadwal', 'PortalController::jadwal');
    $r->get('materi', 'PortalController::materi');
    $r->get('kehadiran', 'PortalController::kehadiran');
    $r->get('perilaku', 'PortalController::perilaku');
    $r->get('pembiasaan', 'PortalController::pembiasaan');
    $r->post('pembiasaan', 'PortalController::pembiasaanSimpan');
    $r->get('akun', 'PortalController::akun');
    $r->post('akun', 'PortalController::gantiPassword');
});

$routes->group('', ['filter' => 'auth'], static function (RouteCollection $routes) {
    $routes->get('dashboard', 'Dashboard::index');
    $routes->get('ping', static fn () => service('response')->setJSON(['ok' => true, 'waktu' => date('H:i')]));
    $routes->get('profil', 'Profil::index');
    $routes->post('profil/password', 'Profil::password');

    // ------------------------------------------------------------ Jadwal (lihat)
    $routes->get('jadwal', 'Akademik\JadwalController::lihat');
    $routes->get('kalender', 'Akademik\KalenderController::lihat');

    // ------------------------------------------------------------ Jurnal & absensi mapel
    $routes->group('jurnal', ['namespace' => 'App\Controllers\Akademik'], static function ($r) {
        $r->get('/', 'JurnalController::index');
        $r->get('riwayat', 'JurnalController::riwayat');
        $r->get('isi/(:num)', 'JurnalController::form/$1');
        $r->post('simpan/(:num)', 'JurnalController::simpan/$1');
        $r->get('detail/(:num)', 'JurnalController::detail/$1');
        $r->post('hapus/(:num)', 'JurnalController::hapus/$1');
        $r->get('rekap-presensi', 'JurnalController::rekapPresensi');
        $r->get('monitoring', 'JurnalController::monitoring', ['filter' => 'role:kurikulum,kepsek,piket']);
    });

    // ------------------------------------------------------------ Absensi pagi
    $routes->group('absensi-pagi', ['namespace' => 'App\Controllers\Kesiswaan'], static function ($r) {
        $r->get('/', 'PresensiHarianController::index');
        $r->post('simpan', 'PresensiHarianController::simpan');
        $r->get('rekap', 'PresensiHarianController::rekap');
    });

    // ------------------------------------------------------------ Kurikulum Merdeka: ATP & kokurikuler
    $routes->group('atp', ['namespace' => 'App\Controllers\Akademik'], static function ($r) {
        $r->get('/', 'AtpController::index');
        $r->post('store', 'AtpController::store');
        $r->post('update/(:num)', 'AtpController::update/$1');
        $r->post('delete/(:num)', 'AtpController::delete/$1');
        $r->get('modul/(:num)', 'AtpController::modul/$1');
    });
    $routes->group('program', ['namespace' => 'App\Controllers\Akademik'], static function ($r) {
        $r->get('/', 'ProgramController::index');
        $r->post('ambil-atp', 'ProgramController::ambilAtp');
        $r->post('sebar', 'ProgramController::sebar');
        $r->post('alokasi', 'ProgramController::alokasiSimpan');
        $r->post('butir/simpan', 'ProgramController::itemSimpan');
        $r->post('butir/simpan/(:num)', 'ProgramController::itemSimpan/$1');
        $r->post('butir/hapus/(:num)', 'ProgramController::itemHapus/$1');
        $r->post('butir/geser/(:num)/(naik|turun)', 'ProgramController::itemGeser/$1/$2');
        $r->post('ajukan/(promes|prota)', 'ProgramController::ajukan/$1');
        $r->get('cetak/(promes|prota)', 'ProgramController::cetak/$1', ['filter' => 'excel']);
    });
    $routes->group('modul-ajar', ['namespace' => 'App\Controllers\Akademik'], static function ($r) {
        $r->get('/', 'ModulAjarController::index');
        $r->post('buat', 'ModulAjarController::buat');
        $r->get('edit/(:num)', 'ModulAjarController::edit/$1');
        $r->post('simpan/(:num)', 'ModulAjarController::simpan/$1');
        $r->post('salin/(:num)', 'ModulAjarController::salin/$1');
        $r->post('hapus/(:num)', 'ModulAjarController::hapus/$1');
        $r->post('ajukan', 'ModulAjarController::ajukan');
        $r->get('cetak/(:num)', 'ModulAjarController::cetak/$1', ['filter' => 'excel']);
        $r->get('cetak-semua', 'ModulAjarController::cetakSemua', ['filter' => 'excel']);
    });
    $routes->group('perangkat', ['namespace' => 'App\Controllers\Akademik'], static function ($r) {
        $r->get('/', 'PerangkatController::index');
        $r->post('unggah', 'PerangkatController::unggah');
        $r->post('tarik/(:num)', 'PerangkatController::tarik/$1');
        $r->get('detail/(:num)', 'PerangkatController::detail/$1');
        $r->get('unduh/(:num)', 'PerangkatController::unduh/$1');
        $r->get('unduh/(:num)/(:num)', 'PerangkatController::unduh/$1/$2');
        $r->get('pemeriksaan', 'PerangkatController::pemeriksaan');
        $r->post('periksa/(:num)', 'PerangkatController::periksa/$1');
        $r->post('sahkan', 'PerangkatController::sahkan');
        $r->post('tenggat', 'PerangkatController::tenggatSimpan');
        $r->get('jenis', 'PerangkatController::jenis');
        $r->post('jenis/simpan', 'PerangkatController::jenisSimpan');
        $r->post('jenis/simpan/(:num)', 'PerangkatController::jenisSimpan/$1');
    });
    $routes->group('kokurikuler', ['namespace' => 'App\Controllers\Akademik'], static function ($r) {
        $r->get('/', 'KokurikulerController::index');
        $r->post('store', 'KokurikulerController::store');
        $r->post('update/(:num)', 'KokurikulerController::update/$1');
        $r->post('delete/(:num)', 'KokurikulerController::delete/$1');
    });

    // ------------------------------------------------------------ Impor data Excel (hak akses per jenis di DataExcel::boleh)
    $routes->group('excel', ['namespace' => 'App\Controllers\Master'], static function ($r) {
        $r->get('/', 'ImporController::index');
        $r->get('template/(:segment)', 'ImporController::template/$1');
        $r->post('unggah', 'ImporController::unggah');
        $r->get('pratinjau', 'ImporController::pratinjau');
        $r->post('proses', 'ImporController::proses');
    });

    // ------------------------------------------------------------ Mutasi siswa
    $routes->group('mutasi', ['namespace' => 'App\Controllers\Kesiswaan'], static function ($r) {
        $r->get('/', 'MutasiController::index');
        $r->post('keluar', 'MutasiController::keluar');
        $r->post('masuk', 'MutasiController::masuk');
        $r->post('pindah-kelas', 'MutasiController::pindahKelas');
        $r->post('batal/(:num)', 'MutasiController::batal/$1');
    });

    // ------------------------------------------------------------ Akun portal siswa
    $routes->group('akun-siswa', ['namespace' => 'App\Controllers\Kesiswaan'], static function ($r) {
        $r->get('/', 'AkunSiswaController::index');
        $r->post('reset', 'AkunSiswaController::reset');
        $r->get('kartu', 'AkunSiswaController::kartu', ['filter' => 'excel']);
    });

    // ------------------------------------------------------------ Izin siswa
    $routes->group('gerbang', ['namespace' => 'App\Controllers\Kesiswaan'], static function ($r) {
        $r->get('/', 'GerbangController::index');
        $r->post('keluar/(:num)', 'GerbangController::keluar/$1');
        $r->post('kembali/(:num)', 'GerbangController::kembali/$1');
    });
    $routes->group('izin-siswa', ['namespace' => 'App\Controllers\Kesiswaan'], static function ($r) {
        $r->get('/', 'IzinSiswaController::index');
        $r->post('simpan', 'IzinSiswaController::simpan');
        $r->post('hapus/(:num)', 'IzinSiswaController::hapus/$1');
        $r->get('lampiran/(:num)', 'IzinSiswaController::lampiran/$1');
    });

    // ------------------------------------------------------------ Kehadiran & izin guru
    $routes->group('guru-hadir', ['namespace' => 'App\Controllers\Akademik'], static function ($r) {
        $r->get('/', 'KehadiranGuruController::index');
        $r->post('simpan', 'KehadiranGuruController::simpan');
    });
    $routes->group('izin-guru', ['namespace' => 'App\Controllers\Akademik'], static function ($r) {
        $r->get('/', 'IzinGuruController::index');
        $r->post('ajukan', 'IzinGuruController::ajukan');
        $r->post('putus/(:num)', 'IzinGuruController::putus/$1');
        $r->post('batal/(:num)', 'IzinGuruController::batal/$1');
        $r->get('lampiran/(:num)', 'IzinGuruController::lampiran/$1');
    });

    // ------------------------------------------------------------ Pembiasaan
    $routes->group('pembiasaan', ['namespace' => 'App\Controllers\Kesiswaan'], static function ($r) {
        $r->get('/', 'PembiasaanController::index');
        $r->post('simpan', 'PembiasaanController::simpan');
        $r->get('rekap', 'PembiasaanController::rekap');
        $r->post('verifikasi', 'PembiasaanController::verifikasi');
        $r->group('master', ['filter' => 'role:kesiswaan'], static function ($r) {
            $r->post('pengaturan', 'PembiasaanController::pengaturan');
            $r->post('paket-7kaih', 'PembiasaanController::paket7kaih');
            $r->get('/', 'PembiasaanController::master');
            $r->post('store', 'PembiasaanController::store');
            $r->post('update/(:num)', 'PembiasaanController::update/$1');
            $r->post('delete/(:num)', 'PembiasaanController::delete/$1');
        });
    });

    // ------------------------------------------------------------ Catatan perilaku
    $routes->group('perilaku', ['namespace' => 'App\Controllers\Kesiswaan'], static function ($r) {
        $r->get('/', 'PerilakuController::index');
        $r->get('tambah', 'PerilakuController::create');
        $r->post('simpan', 'PerilakuController::store');
        $r->get('edit/(:num)', 'PerilakuController::edit/$1');
        $r->post('update/(:num)', 'PerilakuController::update/$1');
        $r->post('status/(:num)', 'PerilakuController::status/$1');
        $r->post('hapus/(:num)', 'PerilakuController::delete/$1');
        $r->get('rekap', 'PerilakuController::rekap'); // dicek di controller (wali kelas bukan role)
        $r->group('jenis', ['filter' => 'role:kesiswaan'], static function ($r) {
            $r->get('/', 'JenisPerilakuController::index');
            $r->post('store', 'JenisPerilakuController::store');
            $r->post('update/(:num)', 'JenisPerilakuController::update/$1');
            $r->post('delete/(:num)', 'JenisPerilakuController::delete/$1');
        });
    });

    // ------------------------------------------------------------ Laporan cetak (hak akses di App\Libraries\Akses::laporan*)
    $routes->group('laporan', ['filter' => 'excel'], static function ($r) {
        $r->get('/', 'LaporanController::index');
        $r->get('jurnal-guru', 'LaporanController::jurnalGuru');
        $r->get('rekap-mapel', 'LaporanController::rekapMapel');
        $r->get('absensi-kelas', 'LaporanController::absensiKelas');
        $r->get('jurnal-kelas', 'LaporanController::jurnalKelas');
        $r->get('perilaku-kelas', 'LaporanController::perilakuKelas');
        $r->get('perilaku-siswa', 'LaporanController::perilakuSiswa');
        $r->get('pembiasaan', 'LaporanController::pembiasaan');
        $r->get('daftar-siswa', 'LaporanController::daftarSiswa');
        $r->get('rekap-poin', 'LaporanController::rekapPoin');
        $r->get('rekap-kehadiran', 'LaporanController::rekapKehadiran');
        $r->get('layanan-bk', 'LaporanController::layananBk');
        $r->get('keterisian-jurnal', 'LaporanController::keterisianJurnal');
        $r->get('harian-piket', 'LaporanController::harianPiket');
        $r->get('pekan-efektif', 'LaporanController::pekanEfektif');
        $r->get('kehadiran-guru', 'LaporanController::kehadiranGuru');
        $r->get('rekap-semester', 'LaporanController::rekapSemester');
        $r->get('ketercapaian-atp', 'LaporanController::ketercapaianAtp');
        $r->get('perangkat', 'LaporanController::perangkat');
        $r->get('mutasi', 'LaporanController::mutasi');
    });

    // Profil siswa (rangkuman presensi, pembiasaan, perilaku, BK)
    $routes->get('siswa/profil/(:num)', 'Kesiswaan\ProfilSiswaController::index/$1');

    // ------------------------------------------------------------ Bimbingan Konseling
    $routes->group('bk', ['namespace' => 'App\Controllers\Bk', 'filter' => 'role:bk'], static function ($r) {
        $r->get('/', 'BkController::index');
        $r->get('layanan', 'BkController::layanan');
        $r->get('layanan/tambah', 'BkController::create');
        $r->post('layanan/simpan', 'BkController::store');
        $r->get('layanan/(:num)', 'BkController::show/$1');
        $r->get('layanan/edit/(:num)', 'BkController::edit/$1');
        $r->post('layanan/update/(:num)', 'BkController::update/$1');
        $r->post('layanan/hapus/(:num)', 'BkController::delete/$1');
        $r->get('rujukan', 'BkController::rujukan');
        $r->get('rujukan/tangani/(:num)', 'BkController::tangani/$1');
    });

    // ------------------------------------------------------------ Pengaturan akademik
    $routes->group('akademik', ['namespace' => 'App\Controllers\Akademik', 'filter' => 'role:kurikulum'], static function ($r) {
        $r->get('tahun-pelajaran', 'TahunPelajaranController::index');
        $r->post('tahun-pelajaran/store', 'TahunPelajaranController::store');
        $r->post('tahun-pelajaran/update/(:num)', 'TahunPelajaranController::update/$1');
        $r->post('tahun-pelajaran/aktifkan/(:num)', 'TahunPelajaranController::aktifkan/$1');
        $r->post('tahun-pelajaran/delete/(:num)', 'TahunPelajaranController::delete/$1');

        $r->get('kalender', 'KalenderController::index');
        $r->post('kalender/store', 'KalenderController::store');
        $r->post('kalender/update/(:num)', 'KalenderController::update/$1');
        $r->post('kalender/delete/(:num)', 'KalenderController::delete/$1');

        $r->get('jam-pelajaran', 'JamPelajaranController::index');
        $r->post('jam-pelajaran/store', 'JamPelajaranController::store');
        $r->post('jam-pelajaran/update/(:num)', 'JamPelajaranController::update/$1');
        $r->post('jam-pelajaran/delete/(:num)', 'JamPelajaranController::delete/$1');
        $r->post('jam-pelajaran/buat-khusus/(:num)', 'JamPelajaranController::buatKhusus/$1');
        $r->post('jam-pelajaran/hapus-khusus/(:num)', 'JamPelajaranController::hapusKhusus/$1');

        $r->get('salin-semester', 'SalinSemesterController::index');
        $r->post('salin-semester/proses', 'SalinSemesterController::proses');

        $r->get('penugasan', 'PenugasanController::index');
        $r->post('penugasan/store', 'PenugasanController::store');
        $r->post('penugasan/update/(:num)', 'PenugasanController::update/$1');
        $r->post('penugasan/delete/(:num)', 'PenugasanController::delete/$1');

        $r->get('jadwal', 'JadwalController::index');
        $r->post('jadwal/store', 'JadwalController::store');
        $r->post('jadwal/update/(:num)', 'JadwalController::update/$1');
        $r->post('jadwal/delete/(:num)', 'JadwalController::delete/$1');
        $r->post('jadwal/kosongkan', 'JadwalController::kosongkan');

        $r->get('piket', 'PiketController::index');
        $r->post('piket/store', 'PiketController::store');
        $r->post('piket/delete/(:num)', 'PiketController::delete/$1');
    });

    // ------------------------------------------------------------ Data master
    $routes->group('master', ['namespace' => 'App\Controllers\Master', 'filter' => 'role:tu'], static function ($r) {

        $r->get('jurusan', 'JurusanController::index');
        $r->post('jurusan/store', 'JurusanController::store');
        $r->post('jurusan/update/(:num)', 'JurusanController::update/$1');
        $r->post('jurusan/delete/(:num)', 'JurusanController::delete/$1');

        $r->get('kelas', 'KelasController::index');
        $r->post('kelas/store', 'KelasController::store');
        $r->post('kelas/update/(:num)', 'KelasController::update/$1');
        $r->post('kelas/delete/(:num)', 'KelasController::delete/$1');
        $r->get('kelas/(:num)', 'KelasController::detail/$1');
        $r->post('kelas/(:num)/wali', 'KelasController::wali/$1');
        $r->post('kelas/(:num)/anggota', 'KelasController::tambahAnggota/$1');
        $r->post('kelas/(:num)/urutkan', 'KelasController::urutkan/$1');
        $r->post('kelas/anggota/hapus/(:num)', 'KelasController::hapusAnggota/$1');

        $r->get('guru', 'GuruController::index');
        $r->post('guru/store', 'GuruController::store');
        $r->post('guru/update/(:num)', 'GuruController::update/$1');
        $r->post('guru/delete/(:num)', 'GuruController::delete/$1');
        $r->post('guru/buat-akun/(:num)', 'GuruController::buatAkun/$1');

        $r->get('siswa', 'SiswaController::index');
        $r->get('siswa/tambah', 'SiswaController::create');
        $r->post('siswa/store', 'SiswaController::store');
        $r->get('siswa/edit/(:num)', 'SiswaController::edit/$1');
        $r->post('siswa/update/(:num)', 'SiswaController::update/$1');
        $r->post('siswa/delete/(:num)', 'SiswaController::delete/$1');
        $r->get('siswa/template', static fn () => redirect()->to('/excel/template/siswa'));
        $r->post('siswa/import', static fn () => redirect()->to('/excel?jenis=siswa'));
        $r->get('impor', static fn () => redirect()->to('/excel'));
        $r->get('siswa/kartu', 'SiswaController::kartu');

        $r->get('mapel', 'MapelController::index');
        $r->post('mapel/store', 'MapelController::store');
        $r->post('mapel/update/(:num)', 'MapelController::update/$1');
        $r->post('mapel/delete/(:num)', 'MapelController::delete/$1');

        $r->get('kenaikan-kelas', 'KenaikanKelasController::index');
        $r->post('kenaikan-kelas/proses', 'KenaikanKelasController::proses');
        $r->get('kenaikan-kelas/otomatis', 'KenaikanKelasController::otomatis');
        $r->post('kenaikan-kelas/otomatis', 'KenaikanKelasController::prosesOtomatis');
    });

    // ------------------------------------------------------------ Sistem (admin saja)
    $routes->group('sistem', ['namespace' => 'App\Controllers\Master', 'filter' => 'role:admin'], static function ($r) {
        $r->get('pengguna', 'PenggunaController::index');
        $r->get('pengguna/tambah', 'PenggunaController::create');
        $r->post('pengguna/store', 'PenggunaController::store');
        $r->get('pengguna/edit/(:num)', 'PenggunaController::edit/$1');
        $r->post('pengguna/update/(:num)', 'PenggunaController::update/$1');
        $r->post('pengguna/delete/(:num)', 'PenggunaController::delete/$1');
        $r->post('pengguna/reset-password/(:num)', 'PenggunaController::resetPassword/$1');
        $r->post('pengguna/reset-massal', 'PenggunaController::resetMassal');
        $r->post('pengguna/cetak-password', 'PenggunaController::cetakPassword');
        $r->post('pengguna/aktif/(:num)', 'PenggunaController::toggleAktif/$1');
        $r->post('pengguna/buka-kunci/(:num)', 'PenggunaController::bukaKunci/$1');
        $r->post('pengguna/akun-guru', 'PenggunaController::akunGuru');
        $r->get('pengguna/daftar-akun', 'PenggunaController::daftarAkun', ['filter' => 'excel']);

        $r->get('pengaturan', 'PengaturanController::index');
        $r->post('pengaturan', 'PengaturanController::simpan');
        $r->post('pengaturan/token-kiosk', 'PengaturanController::tokenKiosk');
        $r->post('pengaturan/hapus-logo', 'PengaturanController::hapusLogo');

        $r->get('aset', '\App\Controllers\Sistem\SistemController::aset');
        $r->post('aset/unduh', '\App\Controllers\Sistem\SistemController::unduhAset');
        $r->get('backup', '\App\Controllers\Sistem\SistemController::backup');
        $r->post('backup/buat', '\App\Controllers\Sistem\SistemController::buatBackup');
        $r->get('backup/unduh/(:segment)', '\App\Controllers\Sistem\SistemController::unduhBackup/$1');
        $r->post('backup/hapus/(:segment)', '\App\Controllers\Sistem\SistemController::hapusBackup/$1');
        $r->get('log', '\App\Controllers\Sistem\SistemController::log');
    });
});
