<?php

return [
    'disallowedAction' => 'Sesi formulir sudah kedaluwarsa. Isian Anda dikembalikan – silakan kirim ulang.',
    'insecureCookie'   => 'Mencoba mengirim cookie aman melalui koneksi tidak aman.',
    'invalidSameSite'  => 'Nilai SameSite harus None, Lax, Strict, atau kosong. Diberikan: "{0}"',
];
