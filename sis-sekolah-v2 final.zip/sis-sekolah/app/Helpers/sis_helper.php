<?php

/**
 * Helper umum aplikasi SIS Sekolah.
 * Dimuat otomatis lewat BaseController::$helpers.
 */

if (! function_exists('hari_list')) {
    /** Daftar hari sekolah (1 = Senin). Mengikuti pengaturan "hari_sekolah" (5/6). */
    function hari_list(): array
    {
        $all = [1 => 'Senin', 2 => 'Selasa', 3 => 'Rabu', 4 => 'Kamis', 5 => 'Jumat', 6 => 'Sabtu'];
        return (int) setting('hari_sekolah', 6) === 5 ? array_slice($all, 0, 5, true) : $all;
    }
}

if (! function_exists('nama_hari')) {
    function nama_hari($n): string
    {
        $all = [1 => 'Senin', 2 => 'Selasa', 3 => 'Rabu', 4 => 'Kamis', 5 => 'Jumat', 6 => 'Sabtu', 7 => 'Minggu'];
        return $all[(int) $n] ?? '-';
    }
}

if (! function_exists('hari_dari_tanggal')) {
    /** Angka hari ISO (1=Senin ... 7=Minggu) dari tanggal Y-m-d. */
    function hari_dari_tanggal(string $tanggal): int
    {
        return (int) date('N', strtotime($tanggal));
    }
}

if (! function_exists('bulan_list')) {
    function bulan_list(): array
    {
        return [1 => 'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'];
    }
}

if (! function_exists('tgl_indo')) {
    function tgl_indo(?string $tanggal, bool $denganHari = false): string
    {
        if (empty($tanggal) || str_starts_with($tanggal, '0000')) {
            return '-';
        }
        $ts  = strtotime($tanggal);
        $str = date('j', $ts) . ' ' . bulan_list()[(int) date('n', $ts)] . ' ' . date('Y', $ts);
        return $denganHari ? nama_hari(date('N', $ts)) . ', ' . $str : $str;
    }
}

if (! function_exists('jam')) {
    function jam(?string $time): string
    {
        return $time ? substr($time, 0, 5) : '-';
    }
}

if (! function_exists('auth_user')) {
    function auth_user(?string $key = null)
    {
        $s = session();
        return $key ? $s->get($key) : [
            'id'    => $s->get('user_id'),
            'nama'  => $s->get('nama_lengkap'),
            'roles' => $s->get('roles') ?? [],
        ];
    }
}

if (! function_exists('has_role')) {
    /** true jika user memiliki salah satu role. Admin selalu true. */
    function has_role(string ...$roles): bool
    {
        return \App\Libraries\Akses::punya(...$roles);
    }
}

if (! function_exists('tp_aktif')) {
    /** Tahun pelajaran aktif (di-cache per request). */
    function tp_aktif(): ?array
    {
        static $tp = false;
        if ($tp === false) {
            $tp = model(\App\Models\TahunPelajaranModel::class)->getAktif();
        }
        return $tp;
    }
}

if (! function_exists('wali_kelas_ids')) {
    /** ID kelas yang diwalikan user login pada TP aktif. */
    function wali_kelas_ids(): array
    {
        static $ids = null;
        if ($ids === null) {
            $guruId = session()->get('guru_id');
            $tp     = tp_aktif();
            $ids    = ($guruId && $tp) ? model(\App\Models\WaliKelasModel::class)->kelasIdsByGuru((int) $guruId, (int) $tp['id']) : [];
        }
        return $ids;
    }
}

if (! function_exists('is_wali_kelas')) {
    function is_wali_kelas(): bool
    {
        return wali_kelas_ids() !== [];
    }
}

if (! function_exists('setting')) {
    function setting(string $kunci, $default = null)
    {
        static $cache = null;
        if ($cache === null) {
            try {
                $cache = model(\App\Models\PengaturanModel::class)->allKeyValue();
            } catch (\Throwable $e) {
                $cache = [];
            }
        }
        return ($cache[$kunci] ?? '') !== '' ? $cache[$kunci] : $default;
    }
}

if (! function_exists('nama_guru')) {
    /** Nama guru lengkap dengan gelar dari baris data yang berisi kolom guru. */
    function nama_guru(array $row, string $prefix = ''): string
    {
        $depan    = trim($row[$prefix . 'gelar_depan'] ?? '');
        $nama     = trim($row[$prefix . 'nama_lengkap'] ?? ($row['nama_guru'] ?? ''));
        $belakang = trim($row[$prefix . 'gelar_belakang'] ?? '');
        return trim(($depan ? $depan . ' ' : '') . $nama . ($belakang ? ', ' . $belakang : ''));
    }
}

if (! function_exists('status_presensi')) {
    function status_presensi(): array
    {
        return ['H' => 'Hadir', 'T' => 'Terlambat', 'S' => 'Sakit', 'I' => 'Izin', 'A' => 'Alpa', 'D' => 'Dispensasi'];
    }
}

if (! function_exists('badge_presensi')) {
    function badge_presensi(?string $s): string
    {
        $map = ['H' => 'success', 'T' => 'warning', 'S' => 'info', 'I' => 'primary', 'A' => 'danger', 'D' => 'secondary'];
        if (! $s) {
            return '<span class="text-muted">-</span>';
        }
        return '<span class="badge bg-' . ($map[$s] ?? 'secondary') . '">' . esc($s) . '</span>';
    }
}

if (! function_exists('badge_status')) {
    /** Badge generik untuk status catatan perilaku / layanan BK / KBM. */
    function badge_status(?string $s): string
    {
        $map = [
            'Tercatat' => 'secondary', 'Ditindaklanjuti' => 'info', 'Dirujuk BK' => 'warning', 'Ditangani BK' => 'primary', 'Selesai' => 'success',
            'Dijadwalkan' => 'secondary', 'Berlangsung' => 'warning',
            'Terlaksana' => 'success', 'Penilaian' => 'primary', 'Tugas Mandiri' => 'info', 'Diganti Guru Lain' => 'warning', 'Tidak Terlaksana' => 'danger',
            'Positif' => 'success', 'Negatif' => 'danger',
            'Aktif' => 'success', 'Lulus' => 'primary', 'Pindah' => 'secondary', 'Keluar' => 'dark',
        ];
        return '<span class="badge bg-' . ($map[$s] ?? 'secondary') . '">' . esc($s ?? '-') . '</span>';
    }
}

if (! function_exists('delete_button')) {
    /** Tombol hapus via POST + CSRF + konfirmasi. */
    function delete_button(string $url, string $label = '', string $konfirmasi = 'Yakin ingin menghapus data ini?'): string
    {
        return '<form action="' . site_url($url) . '" method="post" class="d-inline" onsubmit="return confirm(\'' . esc($konfirmasi, 'js') . '\')">'
            . csrf_field()
            . '<button type="submit" class="btn btn-sm btn-outline-danger" title="Hapus"><i class="bi bi-trash"></i>' . ($label ? ' ' . esc($label) : '') . '</button>'
            . '</form>';
    }
}

if (! function_exists('nama_aplikasi')) {
    function nama_aplikasi(): string
    {
        return (string) setting('nama_aplikasi', 'SIS Sekolah');
    }
}

if (! function_exists('tombol_impor')) {
    /** Tombol dropdown "Impor Excel" (unggah + template) untuk halaman daftar data. */
    function tombol_impor(string $jenis): string
    {
        if (! \App\Libraries\DataExcel::boleh($jenis)) {
            return '';
        }
        return '<div class="dropdown d-inline-block"><button class="btn btn-light dropdown-toggle" data-bs-toggle="dropdown" type="button"><i class="bi bi-file-earmark-spreadsheet me-1"></i>Impor Excel</button>'
            . '<ul class="dropdown-menu dropdown-menu-end"><li><a class="dropdown-item" href="' . site_url('excel?jenis=' . $jenis . '#' . $jenis) . '"><i class="bi bi-upload me-2"></i>Unggah data dari Excel</a></li>'
            . '<li><a class="dropdown-item" href="' . site_url('excel/template/' . $jenis) . '"><i class="bi bi-file-earmark-arrow-down me-2"></i>Unduh template</a></li></ul></div>';
    }
}

if (! function_exists('logo_aplikasi')) {
    /** Logo aplikasi (SVG bawaan). */
    function logo_aplikasi(): string
    {
        return base_url('assets/img/logo-sis.svg');
    }
}

if (! function_exists('tema_css')) {
    /** URL stylesheet tema dengan penanda versi agar perubahan langsung terlihat. */
    function tema_css(): string
    {
        $f = FCPATH . 'assets/css/sis.css';
        return base_url('assets/css/sis.css') . (is_file($f) ? '?v=' . filemtime($f) : '');
    }
}

if (! function_exists('logo_url')) {
    /** URL logo sekolah atau null bila belum diunggah. */
    function logo_url(): ?string
    {
        $f = (string) setting('logo', '');
        return ($f !== '' && is_file(FCPATH . 'uploads/logo/' . $f)) ? base_url('uploads/logo/' . $f) : null;
    }
}

if (! function_exists('nomor_sekolah')) {
    /** "NPSN 10603xxx" atau "NSM 1211xxx", kosong bila belum diisi. */
    function nomor_sekolah(): string
    {
        $n = trim((string) setting('npsn', ''));
        return $n === '' ? '' : setting('jenis_nomor', 'NPSN') . ' ' . $n;
    }
}

if (! function_exists('penanda_tangan_user')) {
    /** Nama & NIP pengguna login (dari data guru bila tertaut) untuk blok tanda tangan laporan. */
    function penanda_tangan_user(): array
    {
        $guruId = session()->get('guru_id');
        if ($guruId && ($g = model(\App\Models\GuruModel::class)->find($guruId))) {
            return ['nama' => nama_guru($g), 'nip' => $g['nip'] ?: null];
        }
        return ['nama' => (string) session()->get('nama_lengkap'), 'nip' => null];
    }
}

if (! function_exists('aset')) {
    /** URL aset tampilan: lokal (mode offline) bila sudah diunduh, selain itu CDN. */
    function aset(string $kunci): string
    {
        return \App\Libraries\AsetOffline::url($kunci);
    }
}

if (! function_exists('catat_log')) {
    /** Catat aktivitas penting ke log_aktivitas. Tidak pernah menggagalkan proses utama. */
    function catat_log(string $aksi, ?string $objek = null, ?int $objekId = null, ?string $keterangan = null): void
    {
        try {
            db_connect()->table('log_aktivitas')->insert([
                'user_id'    => session()->get('user_id') ?: null,
                'nama_user'  => session()->get('nama_lengkap') ?: null,
                'aksi'       => substr($aksi, 0, 30),
                'objek'      => $objek ? substr($objek, 0, 60) : null,
                'objek_id'   => $objekId,
                'keterangan' => $keterangan,
                'ip'         => service('request')->getIPAddress(),
                'created_at' => date('Y-m-d H:i:s'),
            ]);
        } catch (\Throwable $e) {
            log_message('error', 'catat_log gagal: ' . $e->getMessage());
        }
    }
}
