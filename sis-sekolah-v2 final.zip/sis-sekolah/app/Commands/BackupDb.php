<?php

namespace App\Commands;

use App\Libraries\Backup;
use CodeIgniter\CLI\BaseCommand;
use CodeIgniter\CLI\CLI;

/**
 * php spark db:backup            → backup + sisakan 14 file terbaru
 * Jadwalkan harian lewat Task Scheduler (Windows) atau cron (Linux). Lihat PANDUAN_INSTALASI.md.
 */
class BackupDb extends BaseCommand
{
    protected $group       = 'SIS Sekolah';
    protected $name        = 'db:backup';
    protected $description = 'Backup database ke writable/backups (menyisakan 14 file terbaru).';
    protected $options     = ['--simpan' => 'Jumlah file backup yang disimpan (bawaan 14)'];

    public function run(array $params)
    {
        $path  = Backup::buat();
        $hapus = Backup::rapikan((int) (CLI::getOption('simpan') ?: 14));
        CLI::write('Backup dibuat: ' . $path, 'green');
        if ($hapus) {
            CLI::write("{$hapus} backup lama dihapus.");
        }
    }
}
