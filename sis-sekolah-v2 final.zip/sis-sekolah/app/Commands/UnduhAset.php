<?php

namespace App\Commands;

use App\Libraries\AsetOffline;
use CodeIgniter\CLI\BaseCommand;
use CodeIgniter\CLI\CLI;

class UnduhAset extends BaseCommand
{
    protected $group       = 'SIS Sekolah';
    protected $name        = 'aset:unduh';
    protected $description = 'Unduh file tampilan (CSS/JS/font) ke public/assets/vendor agar aplikasi berjalan tanpa internet.';

    public function run(array $params)
    {
        foreach (AsetOffline::unduh() as $k => $h) {
            CLI::write(str_pad($k, 15) . ($h['ok'] ? CLI::color('OK ', 'green') : CLI::color('GAGAL ', 'red')) . $h['pesan']);
        }
    }
}
