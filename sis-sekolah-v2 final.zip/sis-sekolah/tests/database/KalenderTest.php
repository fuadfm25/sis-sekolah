<?php

use App\Libraries\Kalender;
use Tests\Support\SekolahTestCase;

/**
 * @internal
 */
final class KalenderTest extends SekolahTestCase
{
    public function testHariSekolahDanLuarPeriode(): void
    {
        $this->assertTrue(Kalender::status('2026-11-16')['kbm']);          // Senin
        $this->assertFalse(Kalender::status('2026-11-21')['sekolah']);     // Sabtu, 5 hari sekolah
        $this->assertFalse(Kalender::status('2027-01-04')['sekolah']);     // di luar TP
    }

    public function testLiburNasionalMenghentikanKbmDanAbsensi(): void
    {
        $this->agenda(['tanggal_mulai' => '2026-11-17', 'tanggal_selesai' => '2026-11-17', 'jenis' => 'Libur Nasional', 'nama' => 'Libur']);
        $s = Kalender::status('2026-11-17');
        $this->assertTrue($s['sekolah']);
        $this->assertFalse($s['kbm']);
        $this->assertFalse($s['absensi']);
    }

    public function testAgendaKhususKelas(): void
    {
        $this->agenda(['tanggal_mulai' => '2026-11-18', 'tanggal_selesai' => '2026-11-18', 'jenis' => 'Ujian', 'nama' => 'Ujian IX', 'ada_absensi' => 1, 'kelas_ids' => '2']);
        $this->assertTrue(Kalender::kbm('2026-11-18'));          // status umum tetap KBM
        $this->assertTrue(Kalender::kbm('2026-11-18', 1));       // kelas VII normal
        $this->assertFalse(Kalender::kbm('2026-11-18', 2));      // kelas IX ujian
        $this->assertTrue(Kalender::absensi('2026-11-18', 2));
        $this->assertTrue(Kalender::status('2026-11-18')['sebagian']);
    }

    public function testMasukPenggantiMemakaiJadwalHariLain(): void
    {
        $this->agenda(['tanggal_mulai' => '2026-11-22', 'tanggal_selesai' => '2026-11-22', 'jenis' => 'Masuk Pengganti', 'nama' => 'Ganti Senin', 'ada_kbm' => 1, 'ada_absensi' => 1, 'hari_jadwal' => 1]);
        $s = Kalender::status('2026-11-22');   // Minggu
        $this->assertTrue($s['sekolah']);
        $this->assertTrue($s['kbm']);
        $this->assertSame(1, $s['hari_jadwal']);
        $this->assertSame([1], Kalender::hariPengganti('2026-11-22'));
    }

    public function testPekanEfektif(): void
    {
        $this->agenda(['tanggal_mulai' => '2026-11-23', 'tanggal_selesai' => '2026-11-27', 'jenis' => 'Libur Semester', 'nama' => 'Libur sepekan']);
        $p = Kalender::pekanEfektif('2026-11-16', '2026-11-29');
        $this->assertSame(10, $p['total']['hari_sekolah']);
        $this->assertSame(5, $p['total']['hari_efektif']);
        $this->assertSame(2, $p['total']['pekan']);
        $this->assertSame(1, $p['total']['pekan_efektif']);
    }
}
