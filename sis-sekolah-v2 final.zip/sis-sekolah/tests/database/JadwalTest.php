<?php

use App\Models\JadwalModel;
use App\Models\JamPelajaranModel;
use Tests\Support\SekolahTestCase;

/**
 * @internal
 */
final class JadwalTest extends SekolahTestCase
{
    public function testSlotBerurutanDigabungMenjadiSatuSesi(): void
    {
        $p = $this->penugasan(1, 1);
        $this->jadwal($p, 1, 1, 1);
        $this->jadwal($p, 1, 1, 2);
        $this->jadwal($p, 1, 1, 4);   // tidak bersambung (jam 3 kosong)
        $sesi = model(JadwalModel::class)->sesiHari(1, 1, [], '2026-11-16');
        $this->assertCount(2, $sesi);
        $this->assertSame('1-2', $sesi[0]['jam_ke_label']);
        $this->assertSame(2, $sesi[0]['jumlah_jp']);
    }

    public function testVersiJadwalMenurutTanggal(): void
    {
        $lama = $this->penugasan(1, 1);
        $baru = $this->penugasan(2, 1);
        $this->jadwal($lama, 1, 1, 1, null, '2026-11-15');
        $this->jadwal($baru, 1, 1, 1, '2026-11-16');
        $m = model(JadwalModel::class);
        $this->assertSame(1, (int) $m->sesiHari(1, 1, [], '2026-11-09')[0]['guru_id']);
        $this->assertSame(2, (int) $m->sesiHari(1, 1, [], '2026-11-16')[0]['guru_id']);
    }

    public function testBentrokGuruMemperhitungkanMasaBerlaku(): void
    {
        $p1 = $this->penugasan(1, 1);
        $p2 = $this->penugasan(1, 2);
        $this->jadwal($p1, 1, 2, 1, null, '2026-10-31');
        $jam = $this->db->table('jam_pelajaran')->where('jam_ke', 1)->get()->getFirstRow('array');
        $m   = model(JadwalModel::class);
        $this->assertNull($m->bentrokGuru(1, 1, 2, (int) $jam['id'], '2026-11-01'));
        $this->assertNotNull($m->bentrokGuru(1, 1, 2, (int) $jam['id'], '2026-10-01'));
    }

    public function testSesiTanggalLiburKelasDanMasukPengganti(): void
    {
        $p = $this->penugasan(1, 1);
        $q = $this->penugasan(2, 2);
        $this->jadwal($p, 1, 1, 1);
        $this->jadwal($q, 2, 1, 1);
        $m = model(JadwalModel::class);
        $this->agenda(['tanggal_mulai' => '2026-11-16', 'tanggal_selesai' => '2026-11-16', 'jenis' => 'Ujian', 'nama' => 'Ujian IX', 'ada_absensi' => 1, 'kelas_ids' => '2']);
        $this->assertCount(1, $m->sesiTanggal(1, '2026-11-16'));
        $this->agenda(['tanggal_mulai' => '2026-11-22', 'tanggal_selesai' => '2026-11-22', 'jenis' => 'Masuk Pengganti', 'nama' => 'Ganti', 'ada_kbm' => 1, 'ada_absensi' => 1, 'hari_jadwal' => 1]);
        $this->assertCount(2, $m->sesiTanggal(1, '2026-11-22'));
    }

    public function testJamKhususHariMemetakanUlangJadwal(): void
    {
        $p = $this->penugasan(1, 1);
        $this->jadwal($p, 1, 5, 2);
        $jm     = model(JamPelajaranModel::class);
        $bawaan = $jm->bawaan();
        foreach ($bawaan as $b) {
            $jm->insert(['hari' => 5, 'jam_ke' => $b['jam_ke'], 'jam_mulai' => $b['jam_mulai'], 'jam_selesai' => $b['jam_selesai'], 'is_kbm' => 1]);
        }
        JamPelajaranModel::resetCache();
        $gagal = model(JadwalModel::class)->petakanUlangHari(5, $bawaan, $jm->khusus(5));
        $this->assertSame(0, $gagal);
        $row = $this->db->table('jadwal_pelajaran j')->select('jp.hari, jp.jam_ke')->join('jam_pelajaran jp', 'jp.id = j.jam_pelajaran_id')->get()->getFirstRow('array');
        $this->assertSame(5, (int) $row['hari']);
        $this->assertSame(2, (int) $row['jam_ke']);
    }
}
