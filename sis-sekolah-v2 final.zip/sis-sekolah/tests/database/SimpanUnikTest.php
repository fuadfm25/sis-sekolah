<?php

use App\Models\PresensiHarianModel;
use Tests\Support\SekolahTestCase;

/**
 * @internal
 */
final class SimpanUnikTest extends SekolahTestCase
{
    public function testSimpanUlangTidakMenggandakanBaris(): void
    {
        $this->db->table('siswa')->insert(['id' => 1, 'nis' => '1', 'nama_lengkap' => 'A', 'jenis_kelamin' => 'L', 'status' => 'Aktif']);
        $m = model(PresensiHarianModel::class);
        $m->simpanUnik(['tanggal' => '2026-11-16', 'siswa_id' => 1], ['tahun_pelajaran_id' => 1, 'kelas_id' => 1, 'status' => 'H', 'sumber' => 'Kiosk']);
        $m->simpanUnik(['tanggal' => '2026-11-16', 'siswa_id' => 1], ['tahun_pelajaran_id' => 1, 'kelas_id' => 1, 'status' => 'S', 'sumber' => 'Izin']);
        $rows = $m->where('siswa_id', 1)->findAll();
        $this->assertCount(1, $rows);
        $this->assertSame('S', $rows[0]['status']);
        $this->assertSame('Izin', $rows[0]['sumber']);
    }
}
