<?php

namespace Tests\Support;

use App\Libraries\Kalender;
use App\Models\JamPelajaranModel;
use CodeIgniter\Test\CIUnitTestCase;
use CodeIgniter\Test\DatabaseTestTrait;

/**
 * Basis tes database: SQLite :memory:, semua migration aplikasi, seeder dasar, satu TP aktif,
 * dua kelas, dua guru, mapel, slot jam (Senin–Jumat, 5 hari sekolah).
 */
abstract class SekolahTestCase extends CIUnitTestCase
{
    use DatabaseTestTrait;

    protected $migrate     = true;
    protected $migrateOnce = false;
    protected $refresh     = true;
    protected $namespace   = 'App';
    protected $seed        = \App\Database\Seeds\DatabaseSeeder::class;
    protected $basePath    = APPPATH . 'Database';

    protected function setUp(): void
    {
        parent::setUp();
        helper('sis');
        Kalender::reset();
        JamPelajaranModel::resetCache();
        $now = date('Y-m-d H:i:s');
        $db  = $this->db;
        $db->table('pengaturan')->where('kunci', 'hari_sekolah')->update(['nilai' => '5']);
        $db->table('tahun_pelajaran')->insert(['id' => 1, 'tahun_pelajaran' => '2026/2027', 'semester' => 'Ganjil', 'tanggal_mulai' => '2026-07-13', 'tanggal_selesai' => '2026-12-19', 'is_active' => 1, 'created_at' => $now]);
        $db->table('kelas')->insertBatch([
            ['id' => 1, 'tingkat' => 'VII', 'nama_kelas' => 'VII A', 'is_active' => 1],
            ['id' => 2, 'tingkat' => 'IX', 'nama_kelas' => 'IX A', 'is_active' => 1],
        ]);
        $db->table('guru')->insertBatch([
            ['id' => 1, 'nama_lengkap' => 'Guru Satu', 'jenis_kelamin' => 'L', 'is_active' => 1],
            ['id' => 2, 'nama_lengkap' => 'Guru Dua', 'jenis_kelamin' => 'P', 'is_active' => 1],
        ]);
        $mapel = $db->table('mata_pelajaran')->get()->getFirstRow('array');
        if (! $mapel) {
            $db->table('mata_pelajaran')->insert(['kode_mapel' => 'MTK', 'nama_mapel' => 'Matematika']);
        }
        $this->mapelId = (int) $db->table('mata_pelajaran')->get()->getFirstRow('array')['id'];
        $db->table('jam_pelajaran')->truncate();
        foreach ([[1, '07:00', '07:40'], [2, '07:40', '08:20'], [3, '08:20', '09:00'], [4, '09:15', '09:55']] as [$ke, $m, $s]) {
            $db->table('jam_pelajaran')->insert(['hari' => null, 'jam_ke' => $ke, 'jam_mulai' => $m, 'jam_selesai' => $s, 'is_kbm' => 1]);
        }
    }

    protected int $mapelId = 0;

    protected function penugasan(int $guruId, int $kelasId, ?int $mapelId = null): int
    {
        if ($mapelId === null && $this->db->table('penugasan_guru')->where(['mapel_id' => $this->mapelId, 'kelas_id' => $kelasId])->countAllResults()) {
            $this->db->table('mata_pelajaran')->insert(['kode_mapel' => 'M' . random_int(100, 999), 'nama_mapel' => 'Mapel lain']);
            $mapelId = (int) $this->db->insertID();
        }
        $this->db->table('penugasan_guru')->insert(['tahun_pelajaran_id' => 1, 'guru_id' => $guruId, 'mapel_id' => $mapelId ?? $this->mapelId, 'kelas_id' => $kelasId, 'jp_per_minggu' => 4]);
        return (int) $this->db->insertID();
    }

    protected function jadwal(int $penugasanId, int $kelasId, int $hari, int $jamKe, ?string $mulai = null, ?string $sampai = null): int
    {
        $jam = $this->db->table('jam_pelajaran')->where(['hari' => null, 'jam_ke' => $jamKe])->get()->getFirstRow('array');
        $this->db->table('jadwal_pelajaran')->insert(['tahun_pelajaran_id' => 1, 'penugasan_guru_id' => $penugasanId, 'kelas_id' => $kelasId,
            'hari' => $hari, 'jam_pelajaran_id' => $jam['id'], 'berlaku_mulai' => $mulai, 'berlaku_sampai' => $sampai]);
        return (int) $this->db->insertID();
    }

    protected function agenda(array $data): void
    {
        $this->db->table('kalender_akademik')->insert($data + ['tahun_pelajaran_id' => 1, 'ada_kbm' => 0, 'ada_absensi' => 0, 'keterangan' => null]);
        Kalender::reset();
    }
}
