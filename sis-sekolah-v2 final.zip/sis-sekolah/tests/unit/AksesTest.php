<?php

use App\Libraries\Akses;
use CodeIgniter\Test\CIUnitTestCase;

/**
 * @internal
 */
final class AksesTest extends CIUnitTestCase
{
    protected function setUp(): void
    {
        parent::setUp();
        $this->mockSession();
    }

    private function sebagai(array $roles): void
    {
        session()->set(['isLoggedIn' => true, 'user_id' => 9, 'roles' => $roles, 'guru_id' => null]);
    }

    public function testAdminSelaluBoleh(): void
    {
        $this->sebagai(['admin']);
        $this->assertTrue(Akses::punya('kurikulum'));
        $this->assertTrue(Akses::izinGuruPutus());
        $this->assertTrue(Akses::kokurikulerKelola());
    }

    public function testRoleTidakTumpangTindih(): void
    {
        $this->sebagai(['bk']);
        $this->assertTrue(Akses::modulBk());
        $this->assertFalse(Akses::pengaturanAkademik());
        $this->assertFalse(Akses::masterData());
        $this->assertFalse(Akses::izinGuruPutus());
        $this->assertFalse(Akses::kehadiranGuruLihat());

        $this->sebagai(['kurikulum']);
        $this->assertTrue(Akses::pengaturanAkademik());
        $this->assertTrue(Akses::izinGuruPutus());
        $this->assertFalse(Akses::modulBk());

        $this->sebagai(['kepsek']);
        $this->assertTrue(Akses::izinGuruPutus());    // pengecualian: kepala sekolah menyetujui izin guru
        $this->assertFalse(Akses::kokurikulerKelola());
    }
}
