<?php

use App\Models\AtpModel;
use CodeIgniter\Test\CIUnitTestCase;

/**
 * @internal
 */
final class AtpFaseTest extends CIUnitTestCase
{
    public function testFaseMenurutTingkat(): void
    {
        $this->assertSame('A', AtpModel::faseDari('2'));
        $this->assertSame('C', AtpModel::faseDari('VI'));
        $this->assertSame('D', AtpModel::faseDari('VII'));
        $this->assertSame('D', AtpModel::faseDari('9'));
        $this->assertSame('E', AtpModel::faseDari('X'));
        $this->assertSame('F', AtpModel::faseDari('XII'));
        $this->assertNull(AtpModel::faseDari('-'));
    }
}
