<?php

use App\Libraries\ImporExcel;
use CodeIgniter\Test\CIUnitTestCase;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

/**
 * @internal
 */
final class ImporExcelTest extends CIUnitTestCase
{
    public function testJenisKelamin(): void
    {
        $this->assertSame('L', ImporExcel::jk('Laki-laki'));
        $this->assertSame('P', ImporExcel::jk('Perempuan'));
        $this->assertSame('L', ImporExcel::jk('l'));
        $this->assertNull(ImporExcel::jk('?'));
    }

    public function testTanggalBerbagaiFormat(): void
    {
        $this->assertSame('2013-05-17', ImporExcel::tanggal('17/05/2013'));
        $this->assertSame('2013-05-17', ImporExcel::tanggal('2013-05-17'));
        $this->assertSame('2013-05-17', ImporExcel::tanggal('17 Mei 2013'));
        $this->assertSame('2013-05-17', ImporExcel::tanggal(41411));     // serial Excel
        $this->assertNull(ImporExcel::tanggal('31/02/2013'));
    }

    public function testKunciDanTingkatKelas(): void
    {
        $this->assertSame(ImporExcel::kunciKelas('VII A'), ImporExcel::kunciKelas('Kelas 7-A'));
        $this->assertSame(ImporExcel::kunciKelas('IX.C'), ImporExcel::kunciKelas('9C'));
        $this->assertSame('VIII', ImporExcel::tingkat('VIII B'));
        $this->assertSame('10', ImporExcel::tingkat('10 IPA 1'));
    }

    public function testTeksNomorTanpaDesimalDanApostrof(): void
    {
        $this->assertSame('12345678', ImporExcel::teks(12345678.0));
        $this->assertSame('0012', ImporExcel::teks("'0012"));
        $this->assertNull(ImporExcel::teks('-'));
    }

    public function testStatusPegawai(): void
    {
        $this->assertSame('PNS', ImporExcel::statusPegawai('PNS Daerah'));
        $this->assertSame('PPPK', ImporExcel::statusPegawai('PPPK'));
        $this->assertSame('GTT', ImporExcel::statusPegawai('Guru Tidak Tetap'));
        $this->assertSame('Honorer', ImporExcel::statusPegawai('Tenaga Honor Sekolah'));
    }

    public function testTebakKolomDapodik(): void
    {
        $label = ['No', 'Nama', 'NIPD', 'JK', 'NISN', 'Tanggal Lahir', 'Data Ayah Nama', 'Data Ibu Nama', 'Rombel Saat Ini'];
        $map   = ImporExcel::tebak($label, 'siswa');
        $this->assertSame('nama_lengkap', $map[1]);
        $this->assertSame('nis', $map[2]);
        $this->assertSame('nisn', $map[4]);
        $this->assertSame('nama_wali', $map[6]);      // ayah lebih dulu dari ibu
        $this->assertArrayNotHasKey(7, $map);
        $this->assertSame('kelas', $map[8]);
    }

    public function testBacaHeaderDuaBarisDenganJudul(): void
    {
        $ss = new Spreadsheet();
        $sh = $ss->getActiveSheet();
        $sh->setCellValue('A1', 'Daftar Peserta Didik');
        $sh->fromArray(['No', 'Nama', 'NIPD', 'NISN', 'Data Ayah', null, 'Rombel Saat Ini'], null, 'A4');
        $sh->fromArray([null, null, null, null, 'Nama', 'Pekerjaan', null], null, 'A5');
        $sh->mergeCells('E4:F4');
        $sh->fromArray([1, 'Andi', '2601', '0012345678', 'Budi', 'Petani', 'VII A'], null, 'A6');
        $f = tempnam(sys_get_temp_dir(), 'imp') . '.xlsx';
        (new Xlsx($ss))->save($f);

        $h = ImporExcel::baca($f, 'siswa');
        @unlink($f);
        $this->assertSame(4, $h['baris_header']);
        $this->assertTrue($h['dua_baris']);
        $this->assertSame('Data Ayah Nama', $h['label'][4]);
        $this->assertCount(1, $h['data']);
        $this->assertSame('Dapodik', $h['sumber']);
    }
}
